# TODO

- Verify on device: small roundabouts / U-turns — car stays on route line, arrow shape + head direction correct (card icon too).
- If car still detaches: log `_routeMatchLastProgressM` vs animator `_routeProgressM` in roundabouts.
- Consider smoothing offline route geometry at creation (ManeuverGeometry.smoothRoute is unused) — needs instruction index remap.
- Mini-roundabouts: derive exit bearing from geometry instead of instruction modifier.
- Roundabout icon: entrance-only arms no longer drawn (only ring + exits + active path)
- Roundabout angles now measured from ring centroid (entrance/exit/branches), merge+match tolerance 16 deg; verify exit 3 on 4-exit roundabout points left, dual carriageways merge
- Lane guidance: needs maps rebuilt with new turn_lanes columns (abtin-maps-main builder); app shows LaneGuidanceStrip under card within 700 m when lanes useful
- Bridges: builder stores bridge kinds+layer (flags bits 4-7), style sorts bridges by layer, app emits 'bridge enter/exit' instructions (>=80 m); arrow start snaps to real corner (ManeuverGeometry.snapToCorner). Needs rebuilt maps.
