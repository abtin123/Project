import 'dart:math' as math;

/// ارتفاع خورشید (درجه) بالای افق برای lat/lng و زمان UTC (تقریب NOAA، آفلاین).
double solarElevationDeg(double latDeg, double lngDeg, DateTime utc) {
  final n = utc.toUtc().millisecondsSinceEpoch / 86400000.0 + 2440587.5 - 2451545.0;
  double wrap(double d) => d - 360.0 * (d / 360.0).floorToDouble();
  const r = math.pi / 180.0;
  final l = wrap(280.460 + 0.9856474 * n);
  final g = wrap(357.528 + 0.9856003 * n) * r;
  final lambda = (l + 1.915 * math.sin(g) + 0.020 * math.sin(2 * g)) * r;
  final eps = (23.439 - 0.0000004 * n) * r;
  final decl = math.asin(math.sin(eps) * math.sin(lambda));
  final ra = math.atan2(math.cos(eps) * math.sin(lambda), math.cos(lambda));
  final gmst = wrap(280.46061837 + 360.98564736629 * n);
  final ha = (gmst + lngDeg) * r - ra;
  final lat = latDeg * r;
  return math.asin(math.sin(lat) * math.sin(decl) +
          math.cos(lat) * math.cos(decl) * math.cos(ha)) /
      r;
}

/// شب/روز با hysteresis؛ روشن زیر -1° و خاموش بالای +2° تا نزدیک غروب/طلوع
/// چشمک نزند. محاسبه حداکثر هر [minInterval] یک‌بار انجام می‌شود.
class NightDetector {
  NightDetector({this.minInterval = const Duration(seconds: 30)});
  final Duration minInterval;
  bool _night = false;
  DateTime _at = DateTime.fromMillisecondsSinceEpoch(0);

  bool isNight(double lat, double lng, [DateTime? now]) {
    final t = now ?? DateTime.now();
    if (t.difference(_at) < minInterval) return _night;
    _at = t;
    final e = solarElevationDeg(lat, lng, t);
    if (!_night && e < -1.0) _night = true;
    if (_night && e > 2.0) _night = false;
    return _night;
  }
}
