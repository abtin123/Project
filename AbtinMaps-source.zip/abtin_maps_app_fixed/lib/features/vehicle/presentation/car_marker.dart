
import 'package:flutter/material.dart';
import 'package:model_viewer_plus/model_viewer_plus.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'vehicle_provider.dart';

/// محیطِ نوریِ HDR (بدونِ skybox صریح؛ model_viewer_plus خودش پس‌زمینه را
/// شفاف نگه می‌دارد و فقط از exposure/shadow پیش‌فرض استفاده می‌کند).

/// اصلاحِ زاویهٔ چرخشِ افقیِ دوربین دور خودرو، اگر جلوی مدلِ GLB با محورِ
/// پیش‌فرض هم‌راستا نبود. پیش‌فرض صفر؛ بعد از دیدنِ مدل روی دستگاهِ واقعی
/// در صورت نیاز فقط همین عدد برای همان ایندکس تغییر کند.
const _yawCorrectionDegrees = <double>[0.0, 0.0, 0.0, 0.0];

double vehicleModelYawCorrectionDegrees(int modelIndex) {
  return _yawCorrectionDegrees[modelIndex.clamp(0, vehicleModels.length - 1)];
}

/// زاویهٔ چرخشِ صفحه‌ایِ مکان‌نمای خودرو نسبت به heading جغرافیایی/نقشه.
double vehicleScreenRotationDegrees(double headingDeg) {
  final normalized = headingDeg.isFinite ? headingDeg : 0.0;
  final value = normalized % 360.0;
  return value < 0 ? value + 360.0 : value;
}

/// زاویهٔ افقیِ دوربین model-viewer برای اینکه جلوی خودرو روی صفحه در جهت
/// [screenHeadingDeg] (ساعت‌گرد از بالای صفحه) باشد. theta=180 یعنی جلوی
/// خودرو رو به بالای صفحه.
double _orbitTheta(double screenHeadingDeg) =>
    (vehicleScreenRotationDegrees(screenHeadingDeg) + 180.0) % 360.0;

/// زاویهٔ عمودیِ دوربین: دقیقاً برابر با tilt نقشه، پس خودرو با همان پرسپکتیوِ
/// جاده دیده می‌شود (۰ = از بالا، ۶۰ = نمای دنبال‌کنندهٔ سه‌بعدی از پشت).
double _orbitPhi(double tiltDegrees) =>
    (tiltDegrees.isFinite ? tiltDegrees : 0.0).clamp(2.0, 78.0).toDouble();

const String _carJs = '''
window.__carLast = null;
window.__carApply = function () {
  var m = document.querySelector('model-viewer');
  if (!m || !window.__carLast) return false;
  m.cameraOrbit = window.__carLast;
  if (m.jumpCameraToGoal) m.jumpCameraToGoal();
  return true;
};
window.__carSet = function (theta, phi) {
  window.__carLast = theta + 'deg ' + phi + 'deg auto';
  window.__carApply();
};
window.__lightsLast = [0, 0];
window.__carLightsApply = function () {
  var m = document.querySelector('model-viewer');
  if (!m || !m.model || !m.model.materials) return false;
  var r = window.__lightsLast[0], f = window.__lightsLast[1];
  m.model.materials.forEach(function (mt) {
    var n = mt.name;
    if (!mt.setEmissiveFactor) return;
    if (n === 'abm_brake' || n === 'abm_brake_in') mt.setEmissiveFactor([r, r, r]);
    else if (n === 'abm_head') mt.setEmissiveFactor([f, f, f]);
  });
  return true;
};
window.__carLights = function (r, f) {
  window.__lightsLast = [r, f];
  window.__carLightsApply();
};
(function wait() {
  var m = document.querySelector('model-viewer');
  if (!m) { setTimeout(wait, 100); return; }
  m.addEventListener('load', function () {
    window.__carApply();
    window.__carLightsApply();
  });
  m.addEventListener('camera-change', function () {});
})();
''';

/// مکان‌نمای واقعیِ سه‌بعدیِ خودرو (model-viewer / WebGL).
///
/// خودرو دیگر یک تصویرِ تخت نیست که با Flutter بچرخد یا کج شود؛ جهتِ خودرو
/// ([headingDeg]) و زاویهٔ نگاه ([cameraAngleDegrees]، همان tilt نقشه) مستقیماً
/// به دوربینِ سه‌بعدیِ مدل داده می‌شود، پس مدل واقعاً در فضای سه‌بعدی
/// می‌چرخد و از پشت دیده می‌شود.
class CarMarker3D extends StatefulWidget {
  const CarMarker3D({
    super.key,
    required this.size,
    required this.modelIndex,
    this.headingDeg = 0,
    this.cameraAngleDegrees = 0,
    this.sizePercent = 80,
    this.interactive = false,
    this.isBraking = false,
    this.headlightsOn = false,
  });

  final double size;
  final int modelIndex;

  /// جهتِ جلوی خودرو روی صفحه (ساعت‌گرد از بالا)، نسبت به bearing نقشه.
  final double headingDeg;

  /// ۰ = از بالا، ۶۰ = نمای مایلِ دنبال‌کننده. معمولاً tilt واقعی نقشه.
  final double cameraAngleDegrees;
  final double sizePercent;
  final bool interactive;
  final bool isBraking;

  /// چراغ جلو (شب/تونل). چراغ عقب هم با شدت کم روشن می‌شود؛ ترمز = شدت کامل.
  final bool headlightsOn;

  @override
  State<CarMarker3D> createState() => _CarMarker3DState();
}

class _CarMarker3DState extends State<CarMarker3D> {
  WebViewController? _controller;
  String? _lastSent;
  String? _lastLights;
  late final String _initialOrbit;

  @override
  void initState() {
    super.initState();
    _initialOrbit = _orbit();
  }

  String _orbit() =>
      '${_orbitTheta(widget.headingDeg).toStringAsFixed(1)}deg '
      '${_orbitPhi(widget.cameraAngleDegrees).toStringAsFixed(1)}deg auto';

  void _push() {
    final c = _controller;
    if (c == null) return;
    final theta = _orbitTheta(widget.headingDeg).toStringAsFixed(1);
    final phi = _orbitPhi(widget.cameraAngleDegrees).toStringAsFixed(1);
    final sig = '$theta/$phi';
    if (sig != _lastSent) {
      _lastSent = sig;
      try {
        c.runJavaScript(
            "if(window.__carSet)window.__carSet('$theta','$phi');");
      } catch (_) {}
    }
    final rear = widget.isBraking ? 1.0 : (widget.headlightsOn ? 0.3 : 0.0);
    final front = widget.headlightsOn ? 1.0 : 0.0;
    final ls = '$rear/$front';
    if (ls != _lastLights) {
      _lastLights = ls;
      try {
        c.runJavaScript(
            "if(window.__carLights)window.__carLights($rear,$front);");
      } catch (_) {}
    }
  }

  @override
  void didUpdateWidget(CarMarker3D old) {
    super.didUpdateWidget(old);
    if (old.modelIndex != widget.modelIndex) {
      _controller = null;
      _lastSent = null;
      _lastLights = null;
    }
    _push();
  }

  @override
  Widget build(BuildContext context) {
    final safeIndex = widget.modelIndex.clamp(0, vehicleModels.length - 1);
    final key = ValueKey<String>('car-$safeIndex');
    final viewer = ModelViewer(
      key: key,
      src: vehicleModels[safeIndex],
      alt: 'Vehicle',
      backgroundColor: Colors.transparent,
      cameraOrbit: _initialOrbit,
      minCameraOrbit: 'auto 0deg auto',
      maxCameraOrbit: 'auto 180deg auto',
      cameraControls: widget.interactive,
      disableZoom: !widget.interactive,
      disablePan: true,
      autoRotate: false,
      ar: false,
      loading: Loading.lazy,
      reveal: Reveal.auto,
      shadowIntensity: 0.6,
      shadowSoftness: 1,
      exposure: 1.1,
      interactionPrompt: InteractionPrompt.none,
      relatedJs: _carJs,
      onWebViewCreated: (c) {
        _controller = c;
        _lastSent = null;
        _lastLights = null;
        _push();
      },
    );

    final visualScale = (widget.sizePercent.clamp(45.0, 150.0) / 100.0);

    return SizedBox.square(
      dimension: widget.size,
      child: IgnorePointer(
        ignoring: !widget.interactive,
        child: Transform.scale(
          scale: visualScale,
          alignment: Alignment.center,
          child: viewer,
        ),
      ),
    );
  }
}
