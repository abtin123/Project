import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/localization/app_localizations.dart';
import '../../../core/localization/locale_flags.dart';
import '../../../core/theme/app_colors.dart';
import '../../../shared/providers/app_settings_providers.dart';
import '../../../shared/widgets/page_header.dart';
import '../../../shared/widgets/flag_avatar.dart';
import '../../../shared/providers/abtinmap_providers.dart';
import '../../../shared/providers/map_style_providers.dart';
import '../../routing/data/routing_provider.dart';
import '../../settings/data/settings_repository.dart';
import '../../settings/presentation/settings_repository_provider.dart';
import '../data/map_catalog.dart';
import '../data/vector_map_service.dart';
import 'iran_province_map.dart';
import 'map_download_providers.dart';
import 'offline_maps_providers.dart';

/// صفحه‌ی «دانلود نقشه». طراحی مطابق نمونه‌ی مرجع: کارت‌های مستقل برای هر
/// کشور با نوار پیشرفت، دکمه‌های دانلود/توقف/به‌روزرسانی/حذف، و بخش پایانی
/// فقط برای فضای دستگاه (بدون تفکیک حجم نقشه‌ها). همه‌ی رنگ‌ها از
/// [AppColors] (یعنی از ColorScheme فعلی برنامه) خوانده می‌شوند تا با
/// انتخاب تم رنگی کاربر هماهنگ بمانند.
class DownloadMapScreen extends ConsumerStatefulWidget {
  const DownloadMapScreen({super.key});

  @override
  ConsumerState<DownloadMapScreen> createState() => _DownloadMapScreenState();
}

enum _MapMode { online, offline }

enum _MapDownloadTab { downloaded, notDownloaded }

class _DownloadMapScreenState extends ConsumerState<DownloadMapScreen> {
  _MapDownloadTab _tab = _MapDownloadTab.notDownloaded;
  final TextEditingController _searchController = TextEditingController();
  String _query = '';
  final Set<String> _expandedCountries = <String>{};
  final Set<String> _showDownloadMapsByCountry = <String>{};

  @override
  void initState() {
    super.initState();
    // A weekly release is mutable at the same URL. Always check the release
    // manifest when this screen is opened so an available map update is not
    // hidden behind the short-lived catalog cache.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      ref.read(catalogRefreshProvider.notifier).state++;
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isEnglish = ref.watch(languageProvider) == 'en';

    // تب «دانلودشده‌ها» فقط به دیسک وابسته است و نباید با خطای مانیفست
    // آنلاین مسدود شود؛ تب «دانلود نشده‌ها» ذاتاً به فهرست آنلاین نیاز دارد.
    if (_tab == _MapDownloadTab.downloaded) {
      final installedAsync = ref.watch(installedMapRegionsProvider);
      return Scaffold(
        backgroundColor: AppColors.background(context),
        appBar: PageHeader(
          title: AppStrings.get(context, ref, 'download_map_title'),
          backRoute: '/settings',
        ),
        body: SafeArea(
          top: false,
          child: installedAsync.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, _) => _ErrorState(
              message: '$error',
              retryLabel: AppStrings.get(context, ref, 'downloads_retry'),
              onRetry: () => ref.invalidate(installedMapRegionsProvider),
            ),
            data: (regions) => _buildBody(context, regions, isEnglish),
          ),
        ),
      );
    }

    final catalogAsync = ref.watch(mapCatalogProvider);
    return Scaffold(
      backgroundColor: AppColors.background(context),
      appBar: PageHeader(
        title: AppStrings.get(context, ref, 'download_map_title'),
        backRoute: '/settings',
      ),
      body: SafeArea(
        top: false,
        child: catalogAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, _) => _ErrorState(
            message: '$error',
            retryLabel: AppStrings.get(context, ref, 'downloads_retry'),
            onRetry: () => ref.read(catalogRefreshProvider.notifier).state++,
          ),
          data: (catalog) => _buildBody(context, catalog.regions, isEnglish),
        ),
      ),
    );
  }

  Widget _buildBody(
      BuildContext context, List<MapRegion> regions, bool isEnglish) {
    // در تب «دانلودشده‌ها»، regions از قبل همان فهرست نصب‌شدهٔ دیسک است؛
    // فیلترِ installedIds اینجا لازم نیست و — مهم‌تر — نباید نقشه‌ای را که
    // در مانیفست نیست (پس در abmInstalledMapIdsProvider هم شرکت نمی‌کند)
    // به‌اشتباه حذف کند.
    final filtered = _tab == _MapDownloadTab.downloaded
        ? regions.where((r) => r.matches(_query)).where((r) {
            final installedIds =
                ref.watch(abmInstalledMapIdsProvider).valueOrNull ??
                    const <String>{};
            return installedIds.contains(r.id);
          }).toList()
        : (() {
            final installedIds =
                ref.watch(abmInstalledMapIdsProvider).valueOrNull ??
                    const <String>{};
            return regions
                .where((r) => r.matches(_query))
                .where((r) => !installedIds.contains(r.id))
                .toList();
          })();
    filtered.sort((a, b) => (isEnglish ? a.nameEn : a.name)
        .compareTo(isEnglish ? b.nameEn : b.name));
    final grouped = <String, List<MapRegion>>{};
    for (final region in filtered) {
      grouped.putIfAbsent(region.effectiveCountryCode, () => []).add(region);
    }
    final groupKeys = grouped.keys.toList()
      ..sort((a, b) {
        final left = grouped[a]!.first.displayCountryName(isEnglish);
        final right = grouped[b]!.first.displayCountryName(isEnglish);
        return left.compareTo(right);
      });
    // فقط widgetهای سبک ساخته می‌شوند؛ ساخت و build کارت‌ها به اسکرول واگذار
    // می‌شود تا ۱۶۴ کشور هم‌زمان درخت سنگینِ قابل‌رندر نسازند.
    final listChildren = <Widget>[
      Text(
        AppStrings.get(context, ref, 'download_map_subtitle'),
        textAlign: TextAlign.center,
        style: TextStyle(
          color: AppColors.textSecondary(context),
          fontSize: 13.5,
          height: 1.5,
        ),
      ),
      const SizedBox(height: 16),
      Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(
          color: AppColors.primaryAccent(context).withOpacity(0.12),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Text(
          AppStrings.literal('نقشه و مسیریابی فقط آفلاین هستند.'),
          textAlign: TextAlign.center,
          style: TextStyle(
              color: AppColors.textPrimary(context),
              fontWeight: FontWeight.w700),
        ),
      ),
      const SizedBox(height: 14),
      _DownloadTabs(
        selected: _tab,
        downloadedLabel: AppStrings.get(context, ref, 'downloaded_ones'),
        notDownloadedLabel: AppStrings.get(context, ref, 'not_downloaded_ones'),
        onChanged: (value) => setState(() => _tab = value),
      ),
      const SizedBox(height: 14),
      _SearchRow(
        controller: _searchController,
        onChanged: (v) => setState(() => _query = v),
        onRefresh: () => ref.read(catalogRefreshProvider.notifier).state++,
      ),
      const SizedBox(height: 14),
      Row(
        children: [
          Icon(Icons.public_rounded,
              size: 18, color: AppColors.primaryAccent(context)),
          const SizedBox(width: 6),
          Text(
            AppStrings.getWithParams(
              context,
              ref,
              'all_countries_count',
              {'count': groupKeys.length},
            ),
            style: TextStyle(
              color: AppColors.textPrimary(context),
              fontWeight: FontWeight.w600,
              fontSize: 14,
            ),
          ),
        ],
      ),
      const SizedBox(height: 12),
    ];
    for (final key in groupKeys) {
      final items = grouped[key]!
        ..sort((a, b) {
          final order = a.groupOrder.compareTo(b.groupOrder);
          return order != 0
              ? order
              : a
                  .displayRegionName(isEnglish)
                  .compareTo(b.displayRegionName(isEnglish));
        });
      final countryKey = key.toUpperCase();
      final isExpanded = _expandedCountries.contains(countryKey);
      final showMaps = _showDownloadMapsByCountry.contains(countryKey);

      listChildren
        ..add(
          _CountryAccordion(
            regions: items,
            countryCode: countryKey,
            isEnglish: isEnglish,
            expanded: isExpanded,
            showDownloadMaps: showMaps,
            onToggle: () {
              setState(() {
                if (isExpanded) {
                  _expandedCountries.remove(countryKey);
                } else {
                  _expandedCountries.add(countryKey);
                }
              });
            },
            onToggleMaps: () {
              setState(() {
                if (showMaps) {
                  _showDownloadMapsByCountry.remove(countryKey);
                } else {
                  _showDownloadMapsByCountry.add(countryKey);
                }
              });
            },
          ),
        )
        ..add(const SizedBox(height: 12));
    }
    listChildren.add(const SizedBox(height: 8));
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
      itemCount: listChildren.length,
      itemBuilder: (_, index) => listChildren[index],
    );
  }
}

class _CountryAccordion extends ConsumerWidget {
  const _CountryAccordion({
    required this.regions,
    required this.countryCode,
    required this.isEnglish,
    required this.expanded,
    required this.showDownloadMaps,
    required this.onToggle,
    required this.onToggleMaps,
  });

  final List<MapRegion> regions;
  final String countryCode;
  final bool isEnglish;
  final bool expanded;
  final bool showDownloadMaps;
  final VoidCallback onToggle;
  final VoidCallback onToggleMaps;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final accent = AppColors.primaryAccent(context);
    final installedIds =
        ref.watch(abmInstalledMapIdsProvider).valueOrNull ?? const <String>{};
    final installedCount =
        regions.where((r) => installedIds.contains(r.id)).length;
    final isIran = countryCode == 'IR';
    final countryName = regions.first.displayCountryName(isEnglish);
    final countLabel = isIran
        ? AppStrings.getWithParams(
            context, ref, 'download_province_count', {'count': regions.length})
        : AppStrings.getWithParams(
            context, ref, 'download_region_count', {'count': regions.length});

    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: AppColors.glassPanelSoft(context),
        border: Border.all(
          color: expanded
              ? accent.withOpacity(.45)
              : AppColors.glassBorder(context),
          width: expanded ? 1.2 : 1,
        ),
      ),
      child: Column(
        children: [
          Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: onToggle,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 11, 10, 11),
                child: Row(
                  children: [
                    _FlagBadge(countryCode: countryCode, glow: expanded),
                    const SizedBox(width: 11),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            countryName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: AppColors.textPrimary(context),
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            countLabel,
                            style: TextStyle(
                              color: AppColors.textMuted(context),
                              fontSize: 11.5,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (installedCount > 0)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 5),
                        decoration: BoxDecoration(
                          color: const Color(0xFF3DDC84).withOpacity(.12),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '$installedCount',
                          style: const TextStyle(
                            color: Color(0xFF3DDC84),
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    const SizedBox(width: 8),
                    Icon(
                      expanded
                          ? Icons.keyboard_arrow_up_rounded
                          : Icons.keyboard_arrow_down_rounded,
                      color: AppColors.textSecondary(context),
                      size: 24,
                    ),
                  ],
                ),
              ),
            ),
          ),
          if (expanded) ...[
            Divider(
              height: 1,
              color: AppColors.glassBorder(context).withOpacity(.65),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  SizedBox(
                    height: 44,
                    child: OutlinedButton.icon(
                      onPressed: onToggleMaps,
                      icon: Icon(
                        showDownloadMaps
                            ? Icons.map_rounded
                            : Icons.map_outlined,
                        size: 19,
                      ),
                      label: Text(
                        AppStrings.get(
                            context, ref, 'view_downloadable_maps'),
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: accent,
                        side: BorderSide(color: accent.withOpacity(.42)),
                        backgroundColor: accent.withOpacity(.07),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                    ),
                  ),
                  if (showDownloadMaps) ...[
                    const SizedBox(height: 12),
                    if (isIran) ...[
                      _IranMapDownloadPanel(
                        regions: regions,
                        isEnglish: isEnglish,
                      ),
                      const SizedBox(height: 12),
                    ],
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.black.withOpacity(.16),
                        border: Border.all(
                            color: AppColors.glassBorder(context)),
                      ),
                      child: Column(
                        children: [
                          for (var i = 0; i < regions.length; i++) ...[
                            if (i > 0)
                              Divider(
                                  height: 1,
                                  color: AppColors.glassBorder(context)
                                      .withOpacity(.6)),
                            _RegionDownloadTile(region: regions[i]),
                          ],
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _IranMapDownloadPanel extends ConsumerStatefulWidget {
  const _IranMapDownloadPanel({required this.regions, required this.isEnglish});

  final List<MapRegion> regions;
  final bool isEnglish;

  @override
  ConsumerState<_IranMapDownloadPanel> createState() =>
      _IranMapDownloadPanelState();
}

class _IranMapDownloadPanelState
    extends ConsumerState<_IranMapDownloadPanel> {
  String? _selectedId;

  static String _fmtBytes(int b) {
    if (b >= 1 << 30) return '${(b / (1 << 30)).toStringAsFixed(2)} GB';
    if (b >= 1 << 20) return '${(b / (1 << 20)).toStringAsFixed(1)} MB';
    if (b >= 1 << 10) return '${(b / (1 << 10)).toStringAsFixed(0)} KB';
    return '$b B';
  }

  static String _formatSize(double mb) {
    if (mb >= 1024) return '${(mb / 1024).toStringAsFixed(1)} GB';
    if (mb >= 1) return '${mb.toStringAsFixed(0)} MB';
    if (mb > 0) return '${(mb * 1024).toStringAsFixed(0)} KB';
    return '—';
  }

  @override
  Widget build(BuildContext context) {
    final provinceRegions = <String, MapRegion>{
      for (final region in widget.regions)
        if (region.id != 'iran') region.id: region,
    };
    final installed =
        ref.watch(abmInstalledMapIdsProvider).valueOrNull ?? const <String>{};
    final selected = _selectedId == null
        ? null
        : provinceRegions[_selectedId!];
    final selectedDownload = selected == null
        ? null
        : ref.watch(regionDownloadControllerProvider(selected));
    final updatableIds =
        ref.watch(updatableMapIdsProvider).valueOrNull ?? const <String>{};
    final selectedUpdatable =
        selected != null && updatableIds.contains(selected.id);
    final accent = AppColors.primaryAccent(context);

    return Container(
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: const Color(0xFF061222).withOpacity(.82),
        border: Border.all(color: const Color(0xFF35508B).withOpacity(.55)),
      ),
      child: Column(
        children: [
          SizedBox(
            height: 285,
            child: IranProvinceMap(
              regions: widget.regions,
              isEnglish: widget.isEnglish,
              onProvinceTap: (region) async {
                setState(() => _selectedId = region.id);
                final state = ref.read(regionDownloadControllerProvider(region));
                if (state.downloading) return;
                final updatable = ref
                        .read(updatableMapIdsProvider)
                        .valueOrNull
                        ?.contains(region.id) ??
                    false;
                if (installed.contains(region.id) && !updatable) return;
                await ref
                    .read(regionDownloadControllerProvider(region).notifier)
                    .start();
              },
            ),
          ),
          const SizedBox(height: 4),
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 16,
            runSpacing: 7,
            children: [
              const _LegendDot(
                color: Color(0xFFF5F7FB),
                label: 'آماده دانلود',
              ),
              const _LegendDot(
                color: Color(0xFF18B88A),
                label: 'دانلود شده',
              ),
              const _LegendDot(
                color: Color(0xFF2E9BFF),
                label: 'آپدیت دارد',
              ),
              _LegendDot(color: accent, label: 'در حال دانلود'),
            ],
          ),
          if (selected != null) ...[
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: accent.withOpacity(.09),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: accent.withOpacity(.22)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          selected.displayRegionName(widget.isEnglish),
                          style: TextStyle(
                            color: AppColors.textPrimary(context),
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          _formatSize(selected.totalSizeMb),
                          style: TextStyle(
                            color: AppColors.textMuted(context),
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (selectedDownload?.downloading == true)
                    const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  else if (!installed.contains(selected.id) ||
                      selectedUpdatable)
                    FilledButton.icon(
                      onPressed: () => ref
                          .read(regionDownloadControllerProvider(selected).notifier)
                          .start(),
                      icon: Icon(
                        selectedUpdatable
                            ? Icons.refresh_rounded
                            : Icons.download_rounded,
                        size: 17,
                      ),
                      label: Text(
                        selectedUpdatable ? 'آپدیت' : 'دانلود',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      style: FilledButton.styleFrom(
                        backgroundColor:
                            selectedUpdatable ? const Color(0xFF2E9BFF) : accent,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(11),
                        ),
                      ),
                    )
                  else
                    const Icon(
                      Icons.check_circle_rounded,
                      color: Color(0xFF18B88A),
                    ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _LegendDot extends StatelessWidget {
  const _LegendDot({required this.color, required this.label});

  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 9,
            height: 9,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: AppColors.textMuted(context),
              fontSize: 10.5,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      );
}

class _RegionDownloadTile extends ConsumerWidget {
  const _RegionDownloadTile({required this.region});

  final MapRegion region;

  static String _fmtBytes(int b) {
    if (b >= 1 << 30) return '${(b / (1 << 30)).toStringAsFixed(2)} GB';
    if (b >= 1 << 20) return '${(b / (1 << 20)).toStringAsFixed(1)} MB';
    if (b >= 1 << 10) return '${(b / (1 << 10)).toStringAsFixed(0)} KB';
    return '$b B';
  }

  static String _formatSize(double mb) {
    if (mb >= 1024) return '${(mb / 1024).toStringAsFixed(1)} GB';
    if (mb >= 1) return '${mb.toStringAsFixed(0)} MB';
    if (mb > 0) return '${(mb * 1024).toStringAsFixed(0)} KB';
    return '—';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final download = ref.watch(regionDownloadControllerProvider(region));
    final installed = ref
            .watch(abmInstalledMapIdsProviderFamily(region.id))
            .valueOrNull ??
        false;
    final updatable =
        ref.watch(updatableMapIdsProvider).valueOrNull?.contains(region.id) ??
            false;
    // همهٔ نقشه‌های دانلودشده هم‌زمان فعال‌اند؛ دکمهٔ «فعال‌سازی» حذف شده است.
    final isActive = installed;
    final isEnglish = ref.watch(languageProvider) == 'en';
    final accent = AppColors.primaryAccent(context);
    final totalBytes =
        region.totalSizeBytes > 0 ? region.totalSizeBytes : (download.total ?? 0);
    final staged = installed
        ? 0
        : (ref.watch(regionStagedBytesProvider(region)).valueOrNull ?? 0);
    final receivedBytes =
        download.received > staged ? download.received : staged;
    final hasPartial = !installed && !download.downloading && receivedBytes > 0;
    final progress = totalBytes > 0
        ? (receivedBytes / totalBytes).clamp(0.0, 1.0).toDouble()
        : download.fraction;
    final showProgress =
        (download.downloading || hasPartial) && progress != null;

    String status;
    if (download.downloading) {
      status = download.phase == RegionDownloadPhase.building
          ? AppStrings.get(context, ref, 'map_building')
          : download.phase == RegionDownloadPhase.saving
              ? AppStrings.get(context, ref, 'map_saving')
              : AppStrings.get(context, ref, 'map_downloading');
    } else if (hasPartial) {
      status = AppStrings.literal('متوقف‌شده');
    } else if (isActive) {
      status = AppStrings.get(context, ref, 'active_label');
    } else if (updatable) {
      status = AppStrings.get(context, ref, 'map_update_available');
    } else if (installed) {
      status = AppStrings.get(context, ref, 'map_downloaded');
    } else {
      status = AppStrings.get(context, ref, 'map_not_downloaded');
    }

    final primaryName = region.displayRegionName(isEnglish);
    final secondaryName = isEnglish ? region.name : region.nameEn;
    final showSecondary = secondaryName.trim().isNotEmpty &&
        secondaryName.trim() != primaryName.trim();
    const green = Color(0xFF3DDC84);
    final btnColor = isActive ? green : accent;
    final btnIcon = download.downloading
        ? Icons.pause_rounded
        : isActive
            ? Icons.check_rounded
            : updatable
                ? Icons.refresh_rounded
                : installed || hasPartial
                    ? Icons.play_arrow_rounded
                    : null;
    final btnLabel = download.downloading
        ? AppStrings.get(context, ref, 'map_pause_action')
        : isActive
            ? AppStrings.get(context, ref, 'active_label')
            : updatable
                ? AppStrings.get(context, ref, 'map_update_action')
                : installed
                    ? AppStrings.get(context, ref, 'map_activate_action')
                    : hasPartial
                        ? AppStrings.literal('ادامه')
                        : AppStrings.get(context, ref, 'map_download_action_short');
    final notifier = ref.read(regionDownloadControllerProvider(region).notifier);
    final VoidCallback? onPressed = download.downloading
        ? notifier.pause
        : isActive
            ? null
            : (updatable || !installed)
                ? () => notifier.start()
                : null;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              _FlagBadge(countryCode: region.effectiveCountryCode, glow: isActive),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      primaryName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: AppColors.textPrimary(context),
                        fontWeight: FontWeight.w800,
                        fontSize: 16,
                      ),
                    ),
                    if (showSecondary) ...[
                      const SizedBox(height: 2),
                      Text(
                        secondaryName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: AppColors.textSecondary(context),
                          fontSize: 13,
                        ),
                      ),
                    ],
                    const SizedBox(height: 2),
                    Text(
                      '${_formatSize(region.totalSizeMb)}  •  $status',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: isActive
                            ? green
                            : download.downloading || updatable || hasPartial
                                ? accent
                                : AppColors.textMuted(context),
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              if (installed)
                IconButton(
                  tooltip: AppStrings.get(context, ref, 'map_delete_action'),
                  onPressed: download.downloading ? null : notifier.delete,
                  icon: Icon(Icons.delete_outline_rounded,
                      size: 20, color: AppColors.textMuted(context)),
                  visualDensity: VisualDensity.compact,
                ),
              const SizedBox(width: 4),
              OutlinedButton.icon(
                onPressed: onPressed,
                icon: btnIcon == null
                    ? const SizedBox.shrink()
                    : Icon(btnIcon, size: 17),
                label: Text(
                  btnLabel,
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 13.5),
                ),
                style: OutlinedButton.styleFrom(
                  foregroundColor: btnColor,
                  disabledForegroundColor: green,
                  side: BorderSide(
                      color: btnColor.withOpacity(isActive ? .35 : .75),
                      width: 1.3),
                  shape: const StadiumBorder(),
                  minimumSize: const Size(96, 46),
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                ),
              ),
            ],
          ),
          if (showProgress) ...[
            const SizedBox(height: 8),
            SliderTheme(
              data: SliderTheme.of(context).copyWith(
                trackHeight: 5,
                disabledActiveTrackColor: accent,
                disabledInactiveTrackColor:
                    AppColors.textMuted(context).withOpacity(.18),
                disabledThumbColor: accent,
                thumbShape: const RoundSliderThumbShape(
                    enabledThumbRadius: 6, disabledThumbRadius: 6),
                overlayShape: SliderComponentShape.noOverlay,
              ),
              child: SizedBox(
                height: 18,
                child: Slider(value: progress!, onChanged: null),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${(progress * 100).toStringAsFixed(0)}%',
                  style: TextStyle(
                      color: accent,
                      fontSize: 11,
                      fontWeight: FontWeight.w800),
                ),
                if (totalBytes > 0)
                  Flexible(
                    child: Text(
                      '${_fmtBytes(receivedBytes)} / ${_fmtBytes(totalBytes)}'
                      '  •  ${_fmtBytes((totalBytes - receivedBytes).clamp(0, totalBytes).toInt())} ${AppStrings.literal('مانده')}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textDirection: TextDirection.ltr,
                      style: TextStyle(
                          color: AppColors.textMuted(context), fontSize: 11),
                    ),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _ModeToggle extends ConsumerWidget {
  const _ModeToggle({required this.mode, required this.onChanged});

  final _MapMode mode;
  final ValueChanged<_MapMode> onChanged;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Row(
      children: [
        Expanded(
          child: _ModeCard(
            selected: mode == _MapMode.online,
            icon: Icons.cloud_outlined,
            title: AppStrings.get(context, ref, 'map_mode_online'),
            subtitle: AppStrings.get(context, ref, 'map_mode_online_desc'),
            onTap: () => onChanged(_MapMode.online),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _ModeCard(
            selected: mode == _MapMode.offline,
            icon: Icons.check_circle_rounded,
            title: AppStrings.get(context, ref, 'map_mode_offline'),
            subtitle: AppStrings.get(context, ref, 'map_mode_offline_desc'),
            onTap: () => onChanged(_MapMode.offline),
          ),
        ),
      ],
    );
  }
}

class _ModeCard extends StatelessWidget {
  const _ModeCard({
    required this.selected,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final bool selected;
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.primaryAccent(context);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            color: selected
                ? accent.withOpacity(0.14)
                : AppColors.glassPanelSoft(context),
            border: Border.all(
              color: selected
                  ? accent.withOpacity(0.85)
                  : AppColors.glassBorder(context),
              width: selected ? 1.4 : 1,
            ),
            boxShadow: selected
                ? [
                    BoxShadow(
                      color: accent.withOpacity(0.28),
                      blurRadius: 18,
                      spreadRadius: 1,
                    ),
                  ]
                : null,
          ),
          child: Column(
            children: [
              Icon(icon,
                  color: selected ? accent : AppColors.textSecondary(context),
                  size: 24),
              const SizedBox(height: 8),
              Text(
                title,
                style: TextStyle(
                  color: selected
                      ? AppColors.textPrimary(context)
                      : AppColors.textSecondary(context),
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: AppColors.textMuted(context),
                  fontSize: 11.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DownloadTabs extends StatelessWidget {
  const _DownloadTabs({
    required this.selected,
    required this.downloadedLabel,
    required this.notDownloadedLabel,
    required this.onChanged,
  });

  final _MapDownloadTab selected;
  final String downloadedLabel;
  final String notDownloadedLabel;
  final ValueChanged<_MapDownloadTab> onChanged;

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.primaryAccent(context);
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppColors.glassPanelSoft(context),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.glassBorder(context)),
      ),
      child: Row(
        children: [
          Expanded(
            child: _DownloadTabButton(
              label: downloadedLabel,
              selected: selected == _MapDownloadTab.downloaded,
              accent: accent,
              onTap: () => onChanged(_MapDownloadTab.downloaded),
            ),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: _DownloadTabButton(
              label: notDownloadedLabel,
              selected: selected == _MapDownloadTab.notDownloaded,
              accent: accent,
              onTap: () => onChanged(_MapDownloadTab.notDownloaded),
            ),
          ),
        ],
      ),
    );
  }
}

class _DownloadTabButton extends StatelessWidget {
  const _DownloadTabButton({
    required this.label,
    required this.selected,
    required this.accent,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final Color accent;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(11),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          padding: const EdgeInsets.symmetric(vertical: 11),
          decoration: BoxDecoration(
            color: selected ? accent.withOpacity(0.18) : Colors.transparent,
            borderRadius: BorderRadius.circular(11),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: selected
                  ? AppColors.textPrimary(context)
                  : AppColors.textSecondary(context),
              fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
              fontSize: 13,
            ),
          ),
        ),
      );
}

class _SearchRow extends StatelessWidget {
  const _SearchRow({
    required this.controller,
    required this.onChanged,
    required this.onRefresh,
  });

  final TextEditingController controller;
  final ValueChanged<String> onChanged;
  final VoidCallback onRefresh;

  @override
  Widget build(BuildContext context) {
    return Consumer(
      builder: (context, ref, _) => Row(
        children: [
          Expanded(
            child: Container(
              height: 46,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(23),
                color: AppColors.glassPanelSoft(context),
                border: Border.all(color: AppColors.glassBorder(context)),
              ),
              child: Row(
                children: [
                  Icon(Icons.search_rounded,
                      size: 19, color: AppColors.textMuted(context)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: controller,
                      onChanged: onChanged,
                      style: TextStyle(color: AppColors.textPrimary(context)),
                      decoration: InputDecoration(
                        isDense: true,
                        border: InputBorder.none,
                        hintText:
                            AppStrings.get(context, ref, 'search_country_hint'),
                        hintStyle:
                            TextStyle(color: AppColors.textMuted(context)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 10),
          _CircleIconButton(
            icon: Icons.refresh_rounded,
            onTap: onRefresh,
          ),
        ],
      ),
    );
  }
}

class _CircleIconButton extends StatelessWidget {
  const _CircleIconButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(23),
        onTap: onTap,
        child: Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.glassPanelSoft(context),
            border: Border.all(color: AppColors.glassBorder(context)),
          ),
          child: Icon(icon, size: 19, color: AppColors.textSecondary(context)),
        ),
      ),
    );
  }
}

class _CountryGroupHeader extends ConsumerWidget {
  const _CountryGroupHeader({required this.region, required this.count});

  final MapRegion region;
  final int count;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isEnglish = ref.watch(languageProvider) == 'en';
    final label = region.displayCountryName(isEnglish);
    return Row(
      children: [
        _FlagBadge(countryCode: region.effectiveCountryCode, glow: false),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            label,
            style: TextStyle(
              color: AppColors.textPrimary(context),
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        Text(
          isEnglish ? '$count regions' : '$count بخش',
          style: TextStyle(
            color: AppColors.textMuted(context),
            fontSize: 12.5,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

class _RegionCard extends StatelessWidget {
  const _RegionCard({required this.region});

  final MapRegion region;

  @override
  Widget build(BuildContext context) => _RegionDownloadTile(region: region);
}

class _DeleteButton extends ConsumerWidget {
  const _DeleteButton({required this.enabled, required this.onTap});

  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Opacity(
      opacity: enabled ? 1 : 0.4,
      child: Material(
        color: AppColors.danger.withOpacity(0.14),
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: enabled ? onTap : null,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.danger.withOpacity(0.35)),
            ),
            alignment: Alignment.center,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.delete_outline_rounded,
                    size: 17, color: AppColors.danger),
                const SizedBox(width: 6),
                Text(
                  AppStrings.get(context, ref, 'map_delete_action'),
                  style: const TextStyle(
                    color: AppColors.danger,
                    fontWeight: FontWeight.w600,
                    fontSize: 12.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ActionButton extends ConsumerWidget {
  const _ActionButton({
    required this.isDownloading,
    required this.installed,
    required this.active,
    required this.updatable,
    required this.onActivate,
    required this.onTap,
  });

  final bool isDownloading;
  final bool installed;
  final bool active;
  final bool updatable;
  final Future<void> Function() onActivate;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final accent = AppColors.primaryAccent(context);

    IconData icon;
    String label;
    Color color;

    if (isDownloading) {
      icon = Icons.pause_rounded;
      label = AppStrings.get(context, ref, 'map_pause_action');
      color = accent;
    } else if (updatable) {
      icon = Icons.refresh_rounded;
      label = AppStrings.get(context, ref, 'map_update_action');
      color = accent;
    } else if (active) {
      icon = Icons.check_rounded;
      label = AppStrings.get(context, ref, 'active_label');
      color = const Color(0xFF3DDC84);
    } else if (installed) {
      icon = Icons.phone_android_rounded;
      label = AppStrings.get(context, ref, 'map_downloaded');
      color = AppColors.primaryAccent(context);
    } else {
      icon = Icons.download_rounded;
      label = AppStrings.get(context, ref, 'map_download_action');
      color = const Color(0xFF3DDC84);
    }

    final bool tappable = isDownloading || updatable || !installed || !active;

    return Material(
      color: color.withOpacity(0.16),
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: !tappable
            ? null
            : () {
                if (installed && !active && !updatable) {
                  onActivate();
                } else {
                  onTap();
                }
              },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: color.withOpacity(0.45)),
          ),
          alignment: Alignment.center,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 17, color: color),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w600,
                  fontSize: 12.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// نشان پرچم کشور. تمام پرچم‌ها از SVGهای محلی assets/images/flags خوانده می‌شوند؛
/// هیچ emoji پرچمی در رابط دانلود نقشه استفاده نمی‌شود.
class _FlagBadge extends StatelessWidget {
  const _FlagBadge({required this.countryCode, required this.glow});

  final String countryCode;
  final bool glow;

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.primaryAccent(context);
    final flagAsset = flagAssetForCountryCode(countryCode);
    return Container(
      width: 46,
      height: 34,
      padding: const EdgeInsets.all(2),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(9),
        color: AppColors.glassPanel(context),
        border: Border.all(
          color: glow ? accent.withOpacity(.72) : AppColors.glassBorder(context),
          width: glow ? 1.3 : 1,
        ),
        boxShadow: glow
            ? [BoxShadow(color: accent.withOpacity(.20), blurRadius: 10)]
            : null,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(7),
        child: FlagAvatar.rectangle(
          flag: flagAsset,
          width: 40,
          height: 28,
          size: 28,
          borderRadius: BorderRadius.circular(7),
          semanticsLabel: 'پرچم $countryCode',
        ),
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  const _ErrorState(
      {required this.message, required this.retryLabel, required this.onRetry});

  final String message;
  final String retryLabel;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.wifi_off_rounded,
                size: 40, color: AppColors.textMuted(context)),
            const SizedBox(height: 12),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textSecondary(context)),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh_rounded),
              label: Text(retryLabel),
            ),
          ],
        ),
      ),
    );
  }
}
