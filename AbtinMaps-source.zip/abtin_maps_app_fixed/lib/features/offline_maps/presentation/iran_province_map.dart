import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../data/map_catalog.dart';
import 'iran_province_paths.dart';
import 'map_download_providers.dart';
import 'offline_maps_providers.dart';

/// Interactive Iran province map. Geometry comes directly from
/// assets/maps/iran_provinces.svg; the same path is used for drawing and hit
/// testing, so a tap cannot select a neighbouring province by its rectangle.
class IranProvinceMap extends ConsumerStatefulWidget {
  const IranProvinceMap({
    super.key,
    required this.regions,
    required this.isEnglish,
    required this.onProvinceTap,
  });

  final List<MapRegion> regions;
  final bool isEnglish;
  final Future<void> Function(MapRegion region) onProvinceTap;

  @override
  ConsumerState<IranProvinceMap> createState() => _IranProvinceMapState();
}

class _IranProvinceMapState extends ConsumerState<IranProvinceMap> {
  static const double _maxZoom = 14;
  final TransformationController _tc = TransformationController();
  bool _zoomed = false;

  @override
  void initState() {
    super.initState();
    _tc.addListener(() {
      final z = _tc.value.getMaxScaleOnAxis() > 1.01;
      if (z != _zoomed) setState(() => _zoomed = z);
    });
  }

  @override
  void dispose() {
    _tc.dispose();
    super.dispose();
  }

  void _zoomBy(double factor, Size size) {
    final cur = _tc.value.getMaxScaleOnAxis();
    final target = (cur * factor).clamp(1.0, _maxZoom);
    final f = target / cur;
    final c = Offset(size.width / 2, size.height / 2);
    var m = Matrix4.identity()
      ..translate(c.dx, c.dy)
      ..scale(f)
      ..translate(-c.dx, -c.dy);
    m = m * _tc.value;
    if (target <= 1.0) m = Matrix4.identity();
    // clamp pan so map stays within the viewport
    final s = m.getMaxScaleOnAxis();
    final t = m.getTranslation();
    final minX = size.width - size.width * s, minY = size.height - size.height * s;
    m.setTranslationRaw(t.x.clamp(minX, 0.0), t.y.clamp(minY, 0.0), 0);
    _tc.value = m;
  }

  String? _selectedId;

  @override
  Widget build(BuildContext context) {
    final installed =
        ref.watch(abmInstalledMapIdsProvider).valueOrNull ?? const <String>{};
    final accent = AppColors.primaryAccent(context);
    final regionById = <String, MapRegion>{
      for (final region in widget.regions)
        if (region.id != 'iran') region.id: region,
    };

    final states = <String, IranProvinceVisualState>{};
    for (final path in kIranProvincePathData) {
      final region = regionById[path.id];
      if (region == null) continue;
      final download = ref.watch(regionDownloadControllerProvider(region));
      final updatable =
          ref.watch(updatableMapIdsProvider).valueOrNull?.contains(path.id) ??
              false;
      states[path.id] = IranProvinceVisualState(
        installed: installed.contains(path.id),
        updatable: updatable,
        downloading: download.downloading,
        selected: _selectedId == path.id,
        accent: accent,
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final height = math.min(constraints.maxHeight, 340.0);
        final size = Size(constraints.maxWidth, height);
        return Semantics(
          label: widget.isEnglish ? 'Iran provinces map' : 'نقشه استان‌های ایران',
          child: SizedBox(
            width: double.infinity,
            height: height,
            child: Stack(
              children: [
                Positioned.fill(
                  child: ClipRect(
                    child: InteractiveViewer(
                      transformationController: _tc,
                      minScale: 1,
                      maxScale: _maxZoom,
                      panEnabled: _zoomed,
                      boundaryMargin: EdgeInsets.zero,
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTapUp: (details) async {
                          final id = IranProvinceMapPainter.hitTestProvince(
                            details.localPosition,
                            size,
                          );
                          if (id == null) return;
                          final region = regionById[id];
                          if (region == null) return;
                          setState(() => _selectedId = id);
                          await widget.onProvinceTap(region);
                        },
                        child: SizedBox(
                          width: size.width,
                          height: size.height,
                          child: ListenableBuilder(
                            listenable: _tc,
                            builder: (_, __) => CustomPaint(
                              painter: IranProvinceMapPainter(
                                states: states,
                                borderColor: const Color(0xFFC7DAFF),
                                zoom: _tc.value.getMaxScaleOnAxis(),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                PositionedDirectional(
                  end: 4,
                  bottom: 4,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _ZoomButton(
                        icon: Icons.add,
                        onTap: () => _zoomBy(1.6, size),
                      ),
                      const SizedBox(height: 6),
                      _ZoomButton(
                        icon: Icons.remove,
                        onTap: () => _zoomBy(1 / 1.6, size),
                      ),
                      const SizedBox(height: 6),
                      _ZoomButton(
                        icon: Icons.center_focus_strong_outlined,
                        onTap: () => _tc.value = Matrix4.identity(),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _ZoomButton extends StatelessWidget {
  const _ZoomButton({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Material(
        color: const Color(0xFF16294D).withOpacity(.85),
        shape: const CircleBorder(
          side: BorderSide(color: Color(0xFF35508B)),
        ),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: SizedBox(
            width: 34,
            height: 34,
            child: Icon(icon, size: 18, color: Colors.white),
          ),
        ),
      );
}

class IranProvinceVisualState {
  const IranProvinceVisualState({
    required this.installed,
    required this.updatable,
    required this.downloading,
    required this.selected,
    required this.accent,
  });

  final bool installed;
  final bool updatable;
  final bool downloading;
  final bool selected;
  final Color accent;
}

class IranProvinceMapPainter extends CustomPainter {
  IranProvinceMapPainter({
    required this.states,
    required this.borderColor,
    this.zoom = 1,
  });

  final double zoom;

  final Map<String, IranProvinceVisualState> states;
  final Color borderColor;

  // viewBox="-8 -8 516 516" of assets/maps/iran_provinces.svg
  static const Rect _viewBox = Rect.fromLTWH(-8, -8, 516, 516);

  static Map<String, Path>? _cache;
  static Map<String, Path> get _paths => _cache ??= <String, Path>{
        for (final data in kIranProvincePathData)
          data.id: parseSvgPath(data.d),
      };

  /// Full SVG path-data parser: M m L l H h V v C c S s Z z.
  static Path parseSvgPath(String d) {
    final path = Path();
    final tokens =
        RegExp(r'[MmLlHhVvCcSsZz]|-?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?')
            .allMatches(d)
            .map((m) => m.group(0)!)
            .toList();
    var i = 0;
    var cx = 0.0, cy = 0.0, sx = 0.0, sy = 0.0;
    double? lcx, lcy; // last cubic control point (for S)
    var cmd = '';
    double n() => double.parse(tokens[i++]);
    bool isCmd(String t) => RegExp(r'^[A-Za-z]$').hasMatch(t);

    while (i < tokens.length) {
      if (isCmd(tokens[i])) cmd = tokens[i++];
      switch (cmd) {
        case 'M':
        case 'm':
          var x = n(), y = n();
          if (cmd == 'm') {
            x += cx;
            y += cy;
          }
          path.moveTo(x, y);
          cx = sx = x;
          cy = sy = y;
          lcx = lcy = null;
          cmd = cmd == 'M' ? 'L' : 'l';
          break;
        case 'L':
        case 'l':
          var x = n(), y = n();
          if (cmd == 'l') {
            x += cx;
            y += cy;
          }
          path.lineTo(x, y);
          cx = x;
          cy = y;
          lcx = lcy = null;
          break;
        case 'H':
        case 'h':
          var x = n();
          if (cmd == 'h') x += cx;
          path.lineTo(x, cy);
          cx = x;
          lcx = lcy = null;
          break;
        case 'V':
        case 'v':
          var y = n();
          if (cmd == 'v') y += cy;
          path.lineTo(cx, y);
          cy = y;
          lcx = lcy = null;
          break;
        case 'C':
        case 'c':
          var x1 = n(), y1 = n(), x2 = n(), y2 = n(), x = n(), y = n();
          if (cmd == 'c') {
            x1 += cx;
            y1 += cy;
            x2 += cx;
            y2 += cy;
            x += cx;
            y += cy;
          }
          path.cubicTo(x1, y1, x2, y2, x, y);
          lcx = x2;
          lcy = y2;
          cx = x;
          cy = y;
          break;
        case 'S':
        case 's':
          var x2 = n(), y2 = n(), x = n(), y = n();
          if (cmd == 's') {
            x2 += cx;
            y2 += cy;
            x += cx;
            y += cy;
          }
          final x1 = lcx == null ? cx : 2 * cx - lcx;
          final y1 = lcy == null ? cy : 2 * cy - lcy;
          path.cubicTo(x1, y1, x2, y2, x, y);
          lcx = x2;
          lcy = y2;
          cx = x;
          cy = y;
          break;
        case 'Z':
        case 'z':
          path.close();
          cx = sx;
          cy = sy;
          lcx = lcy = null;
          break;
        default:
          return path;
      }
    }
    return path;
  }

  static _MapTransform _transformFor(Size size) {
    final scale =
        math.min(size.width / _viewBox.width, size.height / _viewBox.height);
    return _MapTransform(
      scale: scale,
      dx: (size.width - _viewBox.width * scale) / 2 - _viewBox.left * scale,
      dy: (size.height - _viewBox.height * scale) / 2 - _viewBox.top * scale,
    );
  }

  static String? hitTestProvince(Offset point, Size size) {
    final t = _transformFor(size);
    final p = Offset((point.dx - t.dx) / t.scale, (point.dy - t.dy) / t.scale);
    for (final data in kIranProvincePathData.reversed) {
      if (_paths[data.id]!.contains(p)) return data.id;
    }
    return null;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final t = _transformFor(size);
    canvas.save();
    canvas.translate(t.dx, t.dy);
    canvas.scale(t.scale);

    for (final data in kIranProvincePathData) {
      final path = _paths[data.id]!;
      final state = states[data.id];
      final paint = Paint()..style = PaintingStyle.fill;
      if (state?.selected == true && state?.downloading != true) {
        paint.shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF6B4DFF), Color(0xFF287BEF)],
        ).createShader(path.getBounds());
      } else {
        paint.color = _fillFor(state);
      }
      canvas.drawPath(path, paint);
      canvas.drawPath(
        path,
        Paint()
          ..color = const Color(0xFF16294D).withOpacity(.6)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.9 / zoom
          ..strokeJoin = StrokeJoin.round,
      );
    }
    canvas.restore();
  }

  Color _fillFor(IranProvinceVisualState? state) {
    if (state == null) return const Color(0xFFF5F7FB);
    if (state.downloading) return state.accent;
    if (state.updatable) return const Color(0xFF2E9BFF);
    if (state.installed) return const Color(0xFF18B88A);
    return const Color(0xFFF5F7FB);
  }

  @override
  bool shouldRepaint(covariant IranProvinceMapPainter oldDelegate) => true;
}

class _MapTransform {
  const _MapTransform({required this.scale, required this.dx, required this.dy});
  final double scale;
  final double dx;
  final double dy;
}
