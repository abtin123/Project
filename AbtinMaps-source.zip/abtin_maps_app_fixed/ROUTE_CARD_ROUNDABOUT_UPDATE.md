# Route-card maneuver icons — solid style

Arrows and the roundabout are drawn as vectors (no SVG assets) in one shared style
(`lib/shared/widgets/solid_arrow.dart`): coloured body + inner outline (default white)
+ outer border (default black). Active path = full colour; alternatives = same colour, faded, no outline.

- Kinds: straight, slight/left/right/sharp, u-turn L/R, fork L/R/straight (faded alternatives),
  lane shift L/R, keep L/R (faded lane bars).
- Roundabout: entrance → ring → selected exit is one solid path with an arrow head; ring and all other
  physical arms (from routing bearings) are faded. Exit number in the island is off (`RoundaboutStyle.showExitNumber`).
- Colours (Settings → route card): arrow colour, inner outline, outer border, roundabout active colour,
  roundabout faded colour + opacity.
- The route card shows only the icon on the left (no distance text under it);
  `RouteGuidanceCard(showManeuverDistance: true)` brings it back.
- Note: previously saved roundabout colours (teal/white) stay in stored settings; change them once in Settings.
