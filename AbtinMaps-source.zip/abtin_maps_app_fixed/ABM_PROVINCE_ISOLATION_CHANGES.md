# Abtin Maps — ABM Province Isolation

## Implemented
- Runtime store names are read from the ABM internal manifest/metadata instead of assuming `map.sqlite` / `map.mbtiles`.
- Each installed ABM gets its own cache directory keyed by province/package id.
- New ABM v7 packages require an internal `manifest.json` with `id`, `database`, `tiles`, per-file SHA-256 hashes and sizes.
- Legacy ABM v6 packages using `map.sqlite` / `map.mbtiles` remain accepted by the app.
- Download staging, resumable parts, patch files and version state remain keyed by province id.
- Existing chunk-patch updater remains the update mechanism; failed/incompatible patches fall back to a complete province download and the previous installed file is preserved until validation succeeds.
- Search and routing already iterate over installed province packages; each provider receives the SQLite extracted from its own ABM.

## App files changed
- `lib/abtinmap/abm_map_service.dart`
- `lib/features/offline_maps/data/vector_map_service.dart`

## Validation limitation
Flutter/Dart SDK is not installed in this execution environment, so Flutter analyzer/build and device UI tests could not be executed here. Python-side ABM builder tests were executed.

## Fix (verification pass, 2026-09-30)
- `vector_map_service.dart`: `_prepareInternal` looked for `map.sqlite`/`map.mbtiles` in the extraction dir on first install (no cached metadata), while the v7 archive contains `<ID>.sqlite`/`<ID>.mbtiles` -> new provinces failed to open. `_extractRuntimeStores` now returns the real names from the archive manifest; stale legacy-named files in that province's own dir are removed after migration.
