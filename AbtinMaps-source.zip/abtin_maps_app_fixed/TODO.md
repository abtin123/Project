# TODO — ALL MAPS ACTIVE (2026-09-29)

Done:
- دکمهٔ «فعال‌سازی» حذف شد؛ هر نقشهٔ دانلودشده = «فعال» (همه هم‌زمان).
- رندر: همهٔ map.mbtiles نصب‌شده هرکدام یک source (`abm-tiles`, `abm-tiles-1..N`)؛ لایه‌های `abm-tiles` در همان جایگاه تکثیر می‌شوند (`abm_style_assets.dart::_expandTileLayers`).
- POI/places/نام خیابان: از همهٔ نقشه‌های تلاقی‌کننده با viewport (`online_map_view.dart::_refreshAbmViewport`).
- مسیریابی: ترتیب تلاش = نقشهٔ حاوی مبدأ+مقصد → مبدأ → مقصد → بقیه (`routing_service.dart`).
- حذف یک نقشه: بقیه فعال می‌مانند؛ فقط با صفر نقشه → آنلاین.
- `installedOfflineMapSourcesProvider` بعد از دانلود/حذف invalidate می‌شود.

Open / untested (no Flutter SDK in sandbox):
- کامپایل و اجرا روی دستگاه بررسی نشده؛ فقط بالانس براکت.
- مسیریابی بین‌استانی (stitching) هنوز نیست؛ فقط یک گراف در هر محاسبه.
- ids مشترک POI بین نقشه‌ها در GeoJSON ادغام‌شده تغییر نکرده (اگر تپ روی POI به id متکی باشد چک شود).
- با ده‌ها نقشهٔ نصب‌شده، تعداد source/لایه زیاد می‌شود؛ اگر کند شد فقط نقشه‌های نزدیک viewport را در style بگذار.

# Roundabout icon (2026-09-29)
Done:
- `roundabout_dynamic.dart::_makeData`: آیکون جهت‌محور شد؛ بازوی ورودی همیشه پایین (90°) و بقیهٔ بازوها/خروجی فعال نسبت به آن چرخانده می‌شوند (`toCanvas`).
- بازوی ورودی و خروجی فعال اگر در branchAngles نبودند اضافه می‌شوند.
Open / untested:
- کامپایل/اجرا روی دستگاه بررسی نشده (SDK فلاتر در sandbox نیست).
- ورودیِ نامعلوم (angleDegrees=null) → شمال‌بالا مثل قبل.

# Offline road alerts (2026-09-29)
Done:
- `RoadSafetyService.routeAlertsOffline`: هشدارهای POI (دوربین/سرعت‌گیر/چراغ/پلیس) روی خط مسیر آفلاین از map.sqlite؛ در `abtinmap_routing_provider.dart` به `RouteInfo.alerts` داده می‌شود (قبلاً همیشه خالی بود).
- `home_screen.dart::_displayRoadAlerts`: fallback فقط وقتی route.alerts خالی است و تا ۳ هشدار نشان می‌دهد.
Open:
- نقشه‌های ساخته‌شده قبل از آپدیت builder (`extractors/osm.py::pois`) دستهٔ speed_camera/traffic_calming/traffic_signals ندارند → باید دوباره build و دانلود شوند.
- کامپایل/اجرا بررسی نشده.

# Camera freeze after navigation (2026-09-29)
Done:
- `online_map_view.dart`: صف حرکت دوربین (`_cameraMoveRunning`) اگر `animateCamera` بومی resolve نمی‌شد برای همیشه true می‌ماند و دوربین دیگر دنبال نمی‌کرد. حالا: timeout روی animateCamera، watchdog ۲ثانیه‌ای در `_syncCamera`، و `_resetCameraDrain()` هنگام دکمهٔ GPS، تغییر followVehicle/drivingMode و پایان مسیر.
Open / untested:
- کامپایل/اجرا روی دستگاه بررسی نشده.
- در ویدیو نیمهٔ بالای صفحه پنل/نقشهٔ اپ دیگری (Snapp) است، احتمالاً split-screen؛ اگر اپ در پنجرهٔ کوچک اجرا می‌شود جداگانه بررسی شود.
- ماشین با سرعت 0 در ویدیو جابه‌جا می‌شود (نویز GPS/snap)؛ بررسی نشده.

# Frozen map render after navigation (2026-09-29, round 2)
یافته: با لمس، دوربین/state عوض می‌شود (ماشین جابه‌جا می‌شود) ولی تصویر نقشه ثابت است → سطح رندر بومی MapLibre قفل است، نه فقط صف دوربین.
Done:
- `home_screen.dart::_scheduleMapSurfaceRebuild`: ۷۰۰ms بعد از پایان مسیر، `_mapReloadKey++` (ساخت دوبارهٔ MapLibreMap).
- لمس طولانی روی دکمهٔ GPS = ساخت دوبارهٔ دستی نقشه.
- timeoutها: getVisibleRegion / Isolate ABM / setGeoJsonSource / toScreenLocation / road-safety / offline snap.
Open / untested:
- علت ریشه‌ای قفل رندر مشخص نیست؛ این یک workaround است. کامپایل/اجرا بررسی نشده.
- اگر بدون پایان مسیر هم رخ داد، لاگ و زمان دقیق لازم است.

# Freeze diagnostics (2026-09-29)
- `AbmDebugLog.freezeLogs` (تگ FREEZE، بافر جدا، در گزارش ادغام می‌شود): lifecycle اپ، NAV stop/arrived، ساخت دوبارهٔ نقشه، MAP created/style loaded، ریست/timeout صف دوربین، timeout تصویرسازی/ویوپورت/ایمنی، و هر ۲ثانیه وضعیت دوربین (`CAM move`).
- لاگ فقط در حافظه است؛ با بستن اپ پاک می‌شود → قبل از خروج از اپ کپی شود.
