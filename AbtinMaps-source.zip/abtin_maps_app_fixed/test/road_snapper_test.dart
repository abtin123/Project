import 'package:flutter_test/flutter_test.dart';

import 'package:abtin_maps/features/gps/data/road_snapper.dart';

SnapRoad _road(int key, List<List<double>> pts, {String cls = 'primary', int oneway = 0}) =>
    SnapRoad(
      key: key,
      roadClass: cls,
      oneway: oneway,
      lats: [for (final p in pts) p[0]],
      lngs: [for (final p in pts) p[1]],
    );

void main() {
  final s = RoadSnapper.instance;

  setUp(() {
    s.reset();
    s.enabled = true;
  });

  test('snaps to the nearest road and aligns bearing with heading', () {
    // خیابان شمالی-جنوبی در lng=51.0
    s.updateRoads([_road(1, [[35.0, 51.0], [35.001, 51.0]])]);
    final r = s.snap(35.0005, 51.00015,
        headingDeg: 178, speedKmh: 40, accuracyM: 8, referenceHeadingDeg: 0)!;
    expect((r.lng - 51.0).abs() < 1e-7, isTrue);
    expect((r.bearingDeg - 180).abs() < 1, isTrue);
  });

  test('prefers the road that matches the driving direction', () {
    s.updateRoads([
      _road(1, [[35.0, 51.0], [35.001, 51.0]]), // شمالی-جنوبی
      _road(2, [[35.0005, 50.999], [35.0005, 51.001]]), // شرقی-غربی
    ]);
    final r = s.snap(35.0005, 51.00005,
        headingDeg: 90, speedKmh: 50, accuracyM: 6, referenceHeadingDeg: 90)!;
    expect(r.roadKey, 2);
  });

  test('does not snap when no road is close (parking lot)', () {
    s.updateRoads([_road(1, [[35.0, 51.0], [35.001, 51.0]])]);
    final r = s.snap(35.0005, 51.001,
        headingDeg: 0, speedKmh: 0, accuracyM: 5, referenceHeadingDeg: 0);
    expect(r, isNull);
  });

  test('one-way roads force the legal bearing', () {
    s.updateRoads([_road(1, [[35.0, 51.0], [35.001, 51.0]], oneway: 1)]);
    final r = s.snap(35.0005, 51.00003,
        headingDeg: 0, speedKmh: 0, accuracyM: 5, referenceHeadingDeg: 180)!;
    expect((r.bearingDeg - 0).abs() < 1, isTrue);
  });
}
