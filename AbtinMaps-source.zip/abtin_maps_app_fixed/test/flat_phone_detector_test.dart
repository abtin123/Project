import 'dart:math' as math;

import 'package:flutter_test/flutter_test.dart';

import 'package:abtin_maps/features/hud/domain/flat_phone_detector.dart';

const _g = 9.80665;
typedef _Acc = List<double> Function(double t);

class _Rig {
  _Rig() {
    d = FlatPhoneDetector(onCanAttemptOpenHud: () => triggers++);
  }
  late final FlatPhoneDetector d;
  int triggers = 0;
  int illegalAttempts = 0; // trigger while canAttempt was false
  final rnd = math.Random(7);
  DateTime now = DateTime(2026, 1, 1);
  double t = 0;

  double n(double a) => (rnd.nextDouble() * 2 - 1) * a;

  /// [acc]: خروجی شتاب‌سنج (m/s²)، [gyro]: اندازهٔ سرعت زاویه‌ای (rad/s).
  void run(double sec, _Acc acc, double Function(double t) gyro,
      {double accNoise = 0.05, double gyroNoise = 0.01}) {
    final end = t + sec;
    while (t < end) {
      t += 0.04;
      now = now.add(const Duration(milliseconds: 40));
      final g = gyro(t);
      d.onGyroscope(g + n(gyroNoise), n(gyroNoise), n(gyroNoise), now);
      final a = acc(t);
      final before = triggers;
      d.onAccelerometer(
          a[0] + n(accNoise), a[1] + n(accNoise), a[2] + n(accNoise), now);
      if (triggers > before && !d.snapshot.canAttemptOpenHud) illegalAttempts++;
    }
  }
}

List<double> _tilted(double deg, {double azimuth = 0}) {
  final r = deg * math.pi / 180;
  return [
    _g * math.sin(r) * math.cos(azimuth),
    _g * math.sin(r) * math.sin(azimuth),
    _g * math.cos(r),
  ];
}

void main() {
  test('1 portrait in hand → no HUD', () {
    final r = _Rig();
    r.run(4, (_) => [0.3, 9.7, 1.5], (_) => 0.12, accNoise: 0.3, gyroNoise: 0.08);
    expect(r.triggers, 0);
    expect(r.d.snapshot.canAttemptOpenHud, false);
  });

  test('2 landscape in hand → no HUD', () {
    final r = _Rig();
    r.run(4, (_) => [9.6, 0.4, 1.8], (_) => 0.1, accNoise: 0.3, gyroNoise: 0.08);
    expect(r.triggers, 0);
  });

  test('2b landscape perfectly still, not flat → no HUD', () {
    final r = _Rig();
    r.run(4, (_) => [_g, 0, 0], (_) => 0.0);
    expect(r.triggers, 0);
  });

  test('3 flat, face-up, still → HUD after ≥500ms, exactly once', () {
    final r = _Rig();
    r.run(0.3, (_) => [0, 0, _g], (_) => 0.02);
    expect(r.triggers, 0);
    expect(r.d.state, FlatPhoneState.candidate);
    r.run(0.8, (_) => [0, 0, _g], (_) => 0.02);
    expect(r.triggers, 1);
    expect(r.d.state, FlatPhoneState.hudActive);
    expect(r.d.snapshot.canAttemptOpenHud, true);
    r.run(3, (_) => [0, 0, _g], (_) => 0.02);
    expect(r.triggers, 1);
    expect(r.illegalAttempts, 0);
  });

  test('4 flat, face-down → no HUD', () {
    final r = _Rig();
    r.run(4, (_) => [0, 0, -_g], (_) => 0.02);
    expect(r.triggers, 0);
    expect(r.d.snapshot.faceUp, false);
  });

  test('5 moderate tilt (6°, 20°) → HUD', () {
    final r = _Rig();
    r.run(1.5, (_) => _tilted(6, azimuth: 1.0), (_) => 0.02);
    expect(r.triggers, 1);
    final r2 = _Rig();
    r2.run(1.5, (_) => _tilted(20, azimuth: 1.0), (_) => 0.02);
    expect(r2.triggers, 1);
  });

  test('6 large tilt (40°, 60°) → no HUD', () {
    final r = _Rig();
    r.run(3, (_) => _tilted(40), (_) => 0.02);
    r.run(3, (_) => _tilted(60), (_) => 0.02);
    expect(r.triggers, 0);
  });

  test('7 fast placement: waits for settle + 500ms', () {
    final r = _Rig();
    r.run(1, (_) => [0.4, 8.5, 3.0], (_) => 0.2, accNoise: 0.3);
    // ضربه + چرخش سریع در ۰٫۴ ثانیه
    r.run(0.4, (t) => [2.5 * math.sin(t * 40), 0.5, _g + 4 * math.sin(t * 60)],
        (_) => 1.4, accNoise: 0.4, gyroNoise: 0.2);
    expect(r.triggers, 0);
    r.run(0.3, (_) => [0, 0, _g], (_) => 0.02);
    expect(r.triggers, 0); // هنوز ۵۰۰ms کامل نشده
    r.run(0.8, (_) => [0, 0, _g], (_) => 0.02);
    expect(r.triggers, 1);
    expect(r.illegalAttempts, 0);
  });

  test('8 fast pickup: HUD_ACTIVE → NOT_FLAT immediately, no new trigger', () {
    final r = _Rig();
    r.run(1.5, (_) => [0, 0, _g], (_) => 0.02);
    expect(r.d.state, FlatPhoneState.hudActive);
    final t0 = r.t;
    r.run(0.4, (t) => _tilted(math.min(70, (t - t0) * 200)), (_) => 1.2,
        accNoise: 0.3);
    expect(r.d.state, FlatPhoneState.notFlat);
    expect(r.d.snapshot.canAttemptOpenHud, false);
    r.run(2, (_) => [0.3, 9.6, 1.5], (_) => 0.15, accNoise: 0.3);
    expect(r.triggers, 1);
  });

  test('9 rotating phone on dashboard (spin about Z) → no HUD / drops', () {
    final r = _Rig();
    r.run(3, (_) => [0, 0, _g], (_) => 1.5);
    expect(r.triggers, 0);
    final r2 = _Rig();
    r2.run(1.5, (_) => [0, 0, _g], (_) => 0.02);
    expect(r2.d.state, FlatPhoneState.hudActive);
    r2.run(1.0, (_) => [0, 0, _g], (_) => 1.5);
    expect(r2.d.state, FlatPhoneState.notFlat);
  });

  test('10 car vibration / bumps: activates, does not flicker', () {
    final r = _Rig();
    r.run(6, (t) => [0.5 * math.sin(t * 75), 0.5 * math.cos(t * 65), _g + 0.8 * math.sin(t * 80)],
        (_) => 0.08, accNoise: 0.25, gyroNoise: 0.06);
    expect(r.triggers, 1);
    expect(r.d.state, FlatPhoneState.hudActive);
    // دست‌انداز کوتاه (۱۰۰ms) بدون خروج
    r.run(0.1, (_) => [1.5, 1.0, _g + 3], (_) => 1.1, accNoise: 0.4);
    r.run(2, (_) => [0, 0, _g], (_) => 0.05);
    expect(r.d.state, FlatPhoneState.hudActive);
    expect(r.triggers, 1);
  });

  test('hysteresis: 35° keeps active, 45° deactivates', () {
    final r = _Rig();
    r.run(1.5, (_) => [0, 0, _g], (_) => 0.02);
    r.run(1.5, (_) => _tilted(35), (_) => 0.02);
    expect(r.d.state, FlatPhoneState.hudActive);
    r.run(1.0, (_) => _tilted(45), (_) => 0.02);
    expect(r.d.state, FlatPhoneState.notFlat);
    r.run(1.5, (_) => _tilted(35), (_) => 0.02);
    expect(r.triggers, 1); // برای فعال‌سازی مجدد باید ≤۳۰° شود
  });
}
