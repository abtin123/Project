import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:abtin_maps/features/routing/presentation/roundabout_dynamic.dart';
import 'package:abtin_maps/features/settings/domain/appearance_settings.dart';
import 'package:abtin_maps/shared/widgets/route_guidance_card.dart';

Future<void> _loadAppFonts() async {
  final loader = FontLoader('Vazirmatn')
    ..addFont(rootBundle.load('assets/fonts/Vazirmatn-Regular.ttf'))
    ..addFont(rootBundle.load('assets/fonts/Vazirmatn-Medium.ttf'))
    ..addFont(rootBundle.load('assets/fonts/Vazirmatn-Bold.ttf'))
    ..addFont(rootBundle.load('assets/fonts/Vazirmatn-ExtraBold.ttf'));
  await loader.load();
}

void main() {
  testWidgets('navigation home route card preview', (tester) async {
    await _loadAppFonts();
    final settings = const AppearanceSettings();
    final roundabout = RoundaboutManeuverIcon(
      color: settings.routeCardArrowColor,
      exit: 2,
      exitCount: 3,
      branchAngles: const [0, 90, 180, 270],
      entranceAngles: const [0],
      exitAngles: const [90, 180, 270],
      activeExitAngle: 180,
      drivingSide: 'right',
      thickness: settings.routeCardArrowThickness,
      style: RoundaboutStyle(
        roundaboutColor: settings.roundaboutRingColor,
        entranceColor: settings.roundaboutEntranceColor,
        mainExitColor: settings.roundaboutMainExitColor,
        secondaryExitColor: settings.roundaboutSecondaryExitColor,
        laneMarkColor: settings.roundaboutLaneColor,
        glowColor: settings.roundaboutGlowColor,
        roundaboutOpacity: settings.roundaboutOpacity,
        entranceOpacity: settings.roundaboutEntranceOpacity,
        mainExitOpacity: 1,
        secondaryExitOpacity: settings.roundaboutSecondaryOpacity,
        laneMarkOpacity: settings.roundaboutLaneOpacity,
        glowOpacity: settings.roundaboutGlowOpacity,
        roadWidth: 16.5,
        ringWidth: 16.5,
        laneMarkWidth: 1.5,
        arrowLength: 18,
        arrowWidth: 10,
        arrowThickness: settings.routeCardArrowThickness,
        arrowPosition: .72,
        glowEnabled: settings.roundaboutGlowOpacity > 0,
      ),
    );

    await tester.pumpWidget(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          backgroundColor: const Color(0xFF101622),
          body: Center(
            child: SizedBox(
              width: 800,
              child: RouteGuidanceCard(
                settings: settings,
                data: RouteGuidanceCardData(
                  icon: Icons.roundabout_right_rounded,
                  iconWidget: roundabout,
                  iconScale: 1,
                  distanceText: '300 متر',
                  streetText: 'به راست بپیچید',
                  subtitleText: 'خیابان شهدا',
                  etaLabel: 'رسیدن',
                  etaValue: '14:32',
                  remainingLabel: 'مسافت',
                  remainingValue: '4.2 کیلومتر',
                  durationLabel: 'زمان',
                  durationValue: '۹ دقیقه',
                ),
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.byType(RouteGuidanceCard), findsOneWidget);
    expect(find.byType(RoundaboutManeuverIcon), findsOneWidget);
  });
}
