import 'package:flutter/material.dart';

import '../data/routing_service.dart';

/// مسیر تصویر هر هشدار؛ دقیقاً همان تصاویری که زیر کارت مسیر نشان داده
/// می‌شوند (دایرهٔ قرمز دورشان است).
String roadAlertAsset(RouteAlertType type) => switch (type) {
      RouteAlertType.speedCamera => 'assets/sprites/route_camera.png',
      RouteAlertType.speedBump => 'assets/sprites/route_speed_bump.png',
      RouteAlertType.policeCheckpoint => 'assets/sprites/route_police.png',
      RouteAlertType.trafficLight => 'assets/sprites/route_traffic_light.png',
    };

/// پیش‌نمایش هشدارهای مسیر در تنظیمات: فقط خودِ آیکن‌ها، بدون کارت.
class RoadAlertStack extends StatelessWidget {
  const RoadAlertStack({
    super.key,
    required this.alerts,
    this.sizePercent = 100,
  });

  final List<RouteAlert> alerts;
  final double sizePercent;

  @override
  Widget build(BuildContext context) {
    if (alerts.isEmpty) return const SizedBox.shrink();
    return Wrap(
      spacing: 4,
      runSpacing: 4,
      children: [
        for (final alert in alerts)
          RoadAlertBadge(alert: alert, sizePercent: sizePercent),
      ],
    );
  }
}

class RoadAlertBadge extends StatelessWidget {
  const RoadAlertBadge({
    super.key,
    required this.alert,
    this.sizePercent = 100,
  });

  final RouteAlert alert;
  final double sizePercent;

  @override
  Widget build(BuildContext context) {
    final scale = (sizePercent / 100.0).clamp(0.65, 1.6).toDouble();
    final side = 48.0 * scale;
    return SizedBox(
      width: side,
      height: side,
      child: Image.asset(
        roadAlertAsset(alert.type),
        fit: BoxFit.contain,
        filterQuality: FilterQuality.high,
        gaplessPlayback: true,
      ),
    );
  }
}
