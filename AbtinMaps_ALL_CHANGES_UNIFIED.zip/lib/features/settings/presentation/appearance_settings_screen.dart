import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/localization/app_localizations.dart';
import '../../../core/theme/app_colors.dart';
import '../../../shared/widgets/bottom_nav.dart';
import '../../../shared/widgets/page_header.dart' show PageHeader;
import 'package:abtin_maps/features/settings/presentation/shared/color_page.dart';

/// Appearance فقط ظاهر خود برنامه و ویجت آب‌وهوا را نگه می‌دارد.
/// تغییرها در providerها فوراً ذخیره می‌شوند؛ دکمهٔ Save یا Reset لازم نیست.
class AppearanceSettingsScreen extends ConsumerWidget {
  const AppearanceSettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: AppColors.background(context),
      appBar: PageHeader(
        title: AppStrings.get(context, ref, 'as_page_title'),
        backRoute: '/settings',
      ),
      body: const SafeArea(
        top: false,
        bottom: false,
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(16, 12, 16, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              AppAppearanceContent(),
              SizedBox(height: 12),
              WeatherSettingsContent(),
            ],
          ),
        ),
      ),
      bottomNavigationBar: const BottomNav(currentPage: NavKey.settings),
    );
  }
}
