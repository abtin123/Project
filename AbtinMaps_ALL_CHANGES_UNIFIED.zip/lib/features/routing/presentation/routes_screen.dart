import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/localization/app_localizations.dart';
import '../../../shared/providers/app_settings_providers.dart';
import '../../../shared/providers/abtinmap_providers.dart';
import '../../../shared/widgets/bottom_nav.dart';
import '../../../shared/widgets/page_header.dart';
import '../../gps/presentation/gps_providers.dart';
import '../../map/presentation/destination_provider.dart';
import '../data/routing_provider.dart';
import 'routing_providers.dart';

/// صفحهٔ مسیر که از منوی پایین قابل دسترسی است؛ محاسبهٔ واقعی در HomeScreen
/// انجام می‌شود و این صفحه وضعیت مقصد و گزینه‌های آماده را به کاربر نشان می‌دهد.
class RoutesScreen extends ConsumerWidget {
  const RoutesScreen({super.key});

  String _duration(BuildContext context, WidgetRef ref, double minutes) {
    final total = minutes.round();
    if (total < 60) {
      return AppStrings.getWithParams(context, ref, 'route_duration_minutes', {'value': total});
    }
    return AppStrings.getWithParams(context, ref, 'route_duration_hours_minutes', {
      'hours': total ~/ 60,
      'minutes': total % 60,
    });
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final destination = ref.watch(selectedDestinationProvider);
    final position = ref.watch(vehiclePositionProvider).valueOrNull;
    final engine = ref.watch(routingEngineProvider);
    final routes = ref.watch(calculateRoutesProvider);

    return Scaffold(
      backgroundColor: AppColors.background(context),
      appBar: const PageHeader(
        title: AppStrings.get(context, ref, 'routes'),
        backRoute: '/',
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
          children: [
            _InfoCard(
              icon: Icons.flag_rounded,
              title: destination?.label ?? AppStrings.get(context, ref, 'route_no_destination'),
              subtitle: destination == null
                  ? AppStrings.get(context, ref, 'route_open_search_destination')
                  : AppStrings.get(context, ref, 'route_destination_ready'),
              color: const Color(0xFF2FE6C4),
            ),
            const SizedBox(height: 12),
            _InfoCard(
              icon: Icons.my_location_rounded,
              title: position == null
                  ? AppStrings.get(context, ref, 'route_location_unavailable')
                  : AppStrings.get(context, ref, 'route_location_ready'),
              subtitle: position == null
                  ? AppStrings.get(context, ref, 'route_check_gps')
                  : AppStrings.getWithParams(context, ref, 'route_accuracy', {'value': position.accuracyM.round()}),
              color: Colors.orangeAccent,
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () => context.push('/search'),
              icon: const Icon(Icons.search_rounded),
              label: Text(destination == null ? AppStrings.get(context, ref, 'route_select_destination') : AppStrings.get(context, ref, 'route_change_destination')),
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.primaryAccent(context),
                foregroundColor: AppColors.primaryOnAccent(context),
                padding: const EdgeInsets.symmetric(vertical: 15),
              ),
            ),
            if (destination != null && position != null) ...[
              const SizedBox(height: 24),
              Text(AppStrings.get(context, ref, 'route_suggested_routes'),
                  textAlign: TextAlign.right,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: AppColors.textPrimary(context),
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              routes.when(
                loading: () => const Center(
                    child: Padding(
                  padding: EdgeInsets.all(28),
                  child: CircularProgressIndicator(),
                )),
                error: (error, _) =>
                    _ErrorCard(message: AppStrings.getWithParams(context, ref, 'route_calculation_failed', {'error': error})),
                data: (items) => items.isEmpty
                    ? _ErrorCard(
                        message: engine == RoutingEngine.abtinmap
                            ? AppStrings.get(context, ref, 'route_download_offline_map')
                            : AppStrings.get(context, ref, 'route_online_not_found_check_internet'))
                    : Column(
                        children: [
                          for (var i = 0; i < items.length; i++)
                            _RouteCard(
                              index: i + 1,
                              distance: items[i].distanceKm,
                              duration: _duration(context, ref, items[i].durationMin),
                              onTap: () => context.go('/'),
                            ),
                        ],
                      ),
              ),
            ] else
              const Padding(
                padding: EdgeInsets.only(top: 30),
                child: Text(
                    AppStrings.get(context, ref, 'route_set_location_destination_hint'),
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white54)),
              ),
          ],
        ),
      ),
      bottomNavigationBar: const BottomNav(currentPage: NavKey.routes),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard(
      {required this.icon,
      required this.title,
      required this.subtitle,
      required this.color});
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  @override
  Widget build(BuildContext context) => Card(
        color: AppColors.glassPanelSoft(context),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: ListTile(
          leading: Icon(icon, color: color, size: 30),
          title: Text(title,
              textAlign: TextAlign.right,
              style: TextStyle(
                  color: AppColors.textPrimary(context),
                  fontWeight: FontWeight.bold)),
          subtitle: Text(subtitle,
              textAlign: TextAlign.right,
              style: TextStyle(color: AppColors.textMuted(context))),
        ),
      );
}

class _RouteCard extends StatelessWidget {
  const _RouteCard(
      {required this.index,
      required this.distance,
      required this.duration,
      required this.onTap});
  final int index;
  final double distance;
  final String duration;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(
        color: AppColors.glassPanelSoft(context),
        child: ListTile(
          onTap: onTap,
          leading: CircleAvatar(child: Text('$index')),
          title: Text(AppStrings.getWithParams(context, ref, 'route_distance_km', {'value': distance.toStringAsFixed(1)}),
              textAlign: TextAlign.right,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold)),
          subtitle: Text(duration,
              textAlign: TextAlign.right,
              style: const TextStyle(color: Colors.white60)),
          trailing:
              const Icon(Icons.play_arrow_rounded, color: Color(0xFF2FE6C4)),
        ),
      );
}

class _ErrorCard extends StatelessWidget {
  const _ErrorCard({required this.message});
  final String message;
  @override
  Widget build(BuildContext context) => Card(
        color: Colors.white.withOpacity(.06),
        child: Padding(
            padding: const EdgeInsets.all(18),
            child: Text(message,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70))),
      );
}
