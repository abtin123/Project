import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

enum DbgLevel { debug, info, warn, error, fatal }

class DbgEntry {
  DbgEntry(this.time, this.level, this.tag, this.message);
  final DateTime time;
  final DbgLevel level;
  final String tag;
  final String message;

  String get line {
    final t = time;
    String two(int n) => n.toString().padLeft(2, '0');
    final ts = '${two(t.hour)}:${two(t.minute)}:${two(t.second)}.'
        '${t.millisecond.toString().padLeft(3, '0')}';
    final lv = level.name.toUpperCase().padRight(5);
    return '$ts $lv [$tag] $message';
  }
}

/// Whole-app flight recorder.
///
///  * every `print`, Flutter error, async error, isolate error is captured
///  * lifecycle, memory pressure, slow frames, navigation, provider failures
///  * a heartbeat with native memory numbers (to see leaks / OOM kills)
///  * a session marker that tells, on the NEXT launch, whether the previous run
///    ended abnormally and in which app state (foreground / background)
///  * the Android side (NativeDebug.kt) adds uncaught exceptions, main-thread
///    stalls and ApplicationExitInfo (why the OS killed us)
class AppDebugger {
  AppDebugger._();
  static final AppDebugger instance = AppDebugger._();

  static const MethodChannel _native = MethodChannel('ir.abtin.abtinmaps/debug');
  static const int _maxEntries = 6000;
  static const int _maxFileBytes = 1536 * 1024;

  final ListQueue<DbgEntry> _buffer = ListQueue<DbgEntry>();
  final ValueNotifier<int> revision = ValueNotifier<int>(0);
  bool _revisionScheduled = false;

  Directory? _dir;
  RandomAccessFile? _raf;
  final StringBuffer _pending = StringBuffer();
  Timer? _flushTimer;
  Timer? _heartbeat;
  File? _sessionFile;

  /// فقط وقتی مشکل واقعی بوده (کرش/ANR/کمبود حافظه/…) پر می‌شود و نشان قرمز را روشن می‌کند.
  String? previousSessionVerdict;

  /// توضیح بی‌خطر (مثلاً «کاربر/MIUI برنامه را از لیست اخیر بست»)؛ فقط در گزارش می‌آید.
  String? previousSessionNote;
  String appInfo = '';
  AppLifecycleState? lifecycle;
  int errorCount = 0;
  final DateTime startedAt = DateTime.now();
  bool _initialized = false;
  bool _hooksInstalled = false;

  Directory? get logDir => _dir;
  List<DbgEntry> get entries => _buffer.toList(growable: false);

  // ------------------------------------------------------------ bootstrap --

  /// Runs [body] inside a guarded zone that records `print` and uncaught errors.
  static void runGuarded(FutureOr<void> Function() body) {
    runZonedGuarded<void>(
      () {
        final r = body();
        if (r is Future<void>) {
          r.catchError((Object e, StackTrace s) {
            instance.recordError('zone', e, s, fatal: true);
          });
        }
      },
      (Object e, StackTrace s) => instance.recordError('zone', e, s, fatal: true),
      zoneSpecification: ZoneSpecification(
        print: (self, parent, zone, line) {
          instance.log(DbgLevel.info, 'print', line);
          parent.print(zone, line);
        },
      ),
    );
  }

  Future<void> init() async {
    if (_initialized) return;
    _initialized = true;
    _installHooks();
    try {
      _dir = await _resolveDir();
      if (_dir != null) {
        await _dir!.create(recursive: true);
        final f = File('${_dir!.path}/dart.log');
        try {
          if (await f.exists() && await f.length() > _maxFileBytes) {
            final old = File('${_dir!.path}/dart.1.log');
            if (await old.exists()) await old.delete();
            await f.rename(old.path);
          }
        } catch (_) {}
        _raf = await f.open(mode: FileMode.append);
        _flushTimer = Timer.periodic(
            const Duration(milliseconds: 400), (_) => _flushPending());
      }
    } catch (e) {
      log(DbgLevel.warn, 'debug', 'file logging unavailable: $e');
    }

    try {
      final info = await PackageInfo.fromPlatform();
      appInfo =
          '${info.packageName} v${info.version}+${info.buildNumber} [build: filament-r9]';
    } catch (_) {}
    log(DbgLevel.info, 'session',
        '=== START $appInfo | ${Platform.operatingSystem} ${Platform.operatingSystemVersion} '
        '| ${kReleaseMode ? 'release' : (kProfileMode ? 'profile' : 'debug')} '
        '| logs: ${_dir?.path}');

    await _checkPreviousSession();
    _startHeartbeat();
    unawaited(_sampleMemory());
  }

  Future<Directory?> _resolveDir() async {
    try {
      if (Platform.isAndroid) {
        final ext = await getExternalStorageDirectory();
        if (ext != null) return Directory('${ext.path}/debug');
      }
    } catch (_) {}
    try {
      final s = await getApplicationSupportDirectory();
      return Directory('${s.path}/debug');
    } catch (_) {}
    return null;
  }

  // -------------------------------------------------------- session marker --

  /// آمار موتور Filament خودرو از Kotlin در Android و پل بومی در iOS.
  Future<String?> filamentStatus() async {
    try {
      if (!kIsWeb && Platform.isIOS) {
        return await const MethodChannel('ir.abtin.abtinmaps/filament_car')
            .invokeMethod<String>('status');
      }
      if (kIsWeb) return null;
      return await _native.invokeMethod<String>('filament');
    } catch (_) {
      return null;
    }
  }

  Future<void> _sampleMemory() async {
    try {
      final m = await _native.invokeMethod<String>('memory');
      if (m != null) _lastMem = m;
    } catch (_) {}
  }

  Future<void> _checkPreviousSession() async {
    final d = _dir;
    if (d == null) return;
    String? nativeExit;
    try {
      nativeExit = await _native.invokeMethod<String>('lastExit');
    } catch (_) {}
    _sessionFile = File('${d.path}/session.json');
    try {
      if (await _sessionFile!.exists()) {
        final j = jsonDecode(await _sessionFile!.readAsString()) as Map<String, dynamic>;
        final state = '${j['state']}';
        final lastBeat = DateTime.tryParse('${j['lastBeat']}');
        final started = DateTime.tryParse('${j['startedAt']}');
        final clean = j['clean'] == true;
        if (!clean) {
          final fg = state == 'resumed' || state == 'inactive';
          final ranFor = (started != null && lastBeat != null)
              ? lastBeat.difference(started)
              : null;
          final userKilled = nativeExit != null &&
              (nativeExit.contains('USER_REQUESTED') ||
                  nativeExit.contains('USER_STOPPED'));
          final detail =
              '(ساعت ${lastBeat?.toLocal()}). آخرین وضعیت اپ: $state. '
              '${ranFor != null ? 'مدت اجرا: ${ranFor.inSeconds}s. ' : ''}'
              '${nativeExit != null ? 'دلیل سیستم‌عامل: $nativeExit. ' : ''}'
              'آخرین مصرف حافظه: ${j['mem'] ?? '-'}';
          if (userKilled && !fg) {
            // کاربر (یا «پاک‌کنندهٔ» MIUI/Xiaomi) اپ را از لیست اخیر بسته؛ خطا نیست.
            previousSessionNote =
                'جلسهٔ قبلی را کاربر یا مدیر حافظهٔ گوشی (MIUI) از لیست اخیر بست؛ کرش نبود $detail';
            log(DbgLevel.info, 'session', 'previous session closed by user/system cleaner: $previousSessionNote');
          } else {
            previousSessionVerdict =
                'جلسهٔ قبلی غیرعادی تموم شده $detail → '
                '${fg ? 'برنامه جلوی صفحه بود؛ احتمال کرش یا کشته‌شدن توسط سیستم' : 'اپ در پس‌زمینه بود؛ احتمالاً سیستم برای آزادکردن منابع بستش'}';
            log(DbgLevel.fatal, 'session', 'PREVIOUS SESSION ENDED ABNORMALLY: $previousSessionVerdict');
          }
        } else {
          log(DbgLevel.info, 'session', 'previous session ended cleanly');
        }
      } else {
        log(DbgLevel.info, 'session', 'first launch (no previous session file)');
      }
    } catch (e) {
      log(DbgLevel.warn, 'session', 'could not read previous session: $e');
    }
    _writeSession();
  }

  String _lastMem = '';

  void _writeSession({bool clean = false}) {
    final f = _sessionFile;
    if (f == null) return;
    try {
      f.writeAsStringSync(jsonEncode({
        'startedAt': startedAt.toIso8601String(),
        'lastBeat': DateTime.now().toIso8601String(),
        'state': lifecycle?.name ?? 'starting',
        'clean': clean,
        'mem': _lastMem,
      }));
    } catch (_) {}
  }

  void _startHeartbeat() {
    var n = 0;
    _heartbeat = Timer.periodic(const Duration(seconds: 5), (_) async {
      n++;
      _writeSession();
      if (n == 1 || n % 2 == 0) {
        try {
          final m = await _native.invokeMethod<String>('memory');
          if (m != null) {
            _lastMem = m;
            log(DbgLevel.debug, 'hb', '${lifecycle?.name ?? '?'} $m');
          }
        } catch (_) {}
        try {
          final p = await _native.invokeMethod<String>('perf');
          if (p != null) {
            log(DbgLevel.debug, 'perf',
                '${lifecycle?.name ?? '?'} $p | ${_takeFrameStats()}');
            _watchFenceLeak(p);
          }
        } catch (_) {}
      }
    });
  }

  bool _fenceWarned = false;

  /// اگر sync_file (fence GPU) دوباره بالا رفت، با وضعیت Filament هشدار بده تا مقصر معلوم شود.
  void _watchFenceLeak(String perfLine) {
    final m = RegExp(r'syncFiles=(\d+)').firstMatch(perfLine);
    final n = m == null ? 0 : int.tryParse(m.group(1) ?? '') ?? 0;
    if (n >= 300 && !_fenceWarned) {
      _fenceWarned = true;
      log(DbgLevel.warn, 'fence',
          'syncFiles=$n (انتظار: کمتر از ~۱۵۰ با Filament). منبع احتمالی: نقشه/دوربین، نه خودرو. '
          'filament: ${perfLine.contains('filament{') ? perfLine.substring(perfLine.indexOf('filament{')) : '-'}');
    } else if (n < 150) {
      _fenceWarned = false;
    }
  }

  // ----------------------------------------------------------------- hooks --

  void _installHooks() {
    if (_hooksInstalled) return;
    _hooksInstalled = true;

    final presentError = FlutterError.presentError;
    FlutterError.onError = (FlutterErrorDetails d) {
      recordError('flutter', d.exception, d.stack,
          extra: d.context?.toDescription() ?? d.library);
      try {
        presentError(d);
      } catch (_) {}
    };

    ui.PlatformDispatcher.instance.onError = (Object e, StackTrace s) {
      recordError('platform', e, s, fatal: true);
      return true;
    };

    try {
      Isolate.current.addErrorListener(RawReceivePort((dynamic pair) {
        final l = pair as List<dynamic>;
        log(DbgLevel.fatal, 'isolate', '${l.first}\n${l.last}');
      }).sendPort);
    } catch (_) {}

    WidgetsBinding.instance.addObserver(_LifecycleObserver(this));

    SchedulerBinding.instance.addTimingsCallback((timings) {
      for (final t in timings) {
        final total = t.totalSpan.inMilliseconds;
        final b = t.buildDuration.inMicroseconds / 1000.0;
        final r = t.rasterDuration.inMicroseconds / 1000.0;
        _fCount++;
        _fBuildSum += b;
        _fRasterSum += r;
        if (b > _fBuildMax) _fBuildMax = b;
        if (r > _fRasterMax) _fRasterMax = r;
        if (t.totalSpan.inMicroseconds > 16700) _fJank++;
        if (total > 200) {
          _slowFrames++;
          if (_slowFrames <= 5 || _slowFrames % 20 == 0) {
            log(DbgLevel.warn, 'frame',
                'slow frame #$_slowFrames total=${total}ms '
                'build=${t.buildDuration.inMilliseconds}ms raster=${t.rasterDuration.inMilliseconds}ms');
          }
        }
      }
    });
  }

  int _slowFrames = 0;

  // Frame statistics for the periodic [perf] line (reset every report).
  int _fCount = 0;
  int _fJank = 0;
  double _fBuildSum = 0, _fBuildMax = 0, _fRasterSum = 0, _fRasterMax = 0;
  DateTime _fSince = DateTime.now();

  String _takeFrameStats() {
    final now = DateTime.now();
    final secs = math.max(0.001, now.difference(_fSince).inMilliseconds / 1000.0);
    final n = _fCount;
    final s = 'frames=$n (${(n / secs).toStringAsFixed(0)}/s) jank=$_fJank '
        'build avg ${n == 0 ? "-" : (_fBuildSum / n).toStringAsFixed(1)} max ${_fBuildMax.toStringAsFixed(0)}ms '
        'raster avg ${n == 0 ? "-" : (_fRasterSum / n).toStringAsFixed(1)} max ${_fRasterMax.toStringAsFixed(0)}ms';
    _fCount = 0;
    _fJank = 0;
    _fBuildSum = _fBuildMax = _fRasterSum = _fRasterMax = 0;
    _fSince = now;
    return s;
  }

  // ------------------------------------------------------------------- API --

  void log(DbgLevel level, String tag, String message) {
    final e = DbgEntry(DateTime.now(), level, tag, message);
    _buffer.addLast(e);
    while (_buffer.length > _maxEntries) {
      _buffer.removeFirst();
    }
    _pending.writeln(e.line);
    if (level.index >= DbgLevel.error.index) {
      _flushPending();
    }
    if (!_revisionScheduled) {
      _revisionScheduled = true;
      Timer(const Duration(milliseconds: 250), () {
        _revisionScheduled = false;
        revision.value++;
      });
    }
  }

  void i(String tag, String msg) => log(DbgLevel.info, tag, msg);
  void w(String tag, String msg) => log(DbgLevel.warn, tag, msg);
  void d(String tag, String msg) => log(DbgLevel.debug, tag, msg);

  void recordError(String tag, Object error, StackTrace? stack,
      {bool fatal = false, String? extra}) {
    errorCount++;
    final st = stack == null
        ? ''
        : '\n${stack.toString().split('\n').take(28).join('\n')}';
    log(fatal ? DbgLevel.fatal : DbgLevel.error, tag,
        '${extra != null ? '($extra) ' : ''}$error$st');
    try {
      _native.invokeMethod<void>('log', {'tag': 'dart-err', 'msg': '$error'});
    } catch (_) {}
  }

  void _flushPending() {
    final raf = _raf;
    if (raf == null || _pending.isEmpty) return;
    try {
      raf.writeStringSync(_pending.toString());
      raf.flushSync();
    } catch (_) {}
    _pending.clear();
  }

  void markClean() {
    _flushPending();
    _writeSession(clean: true);
  }

  Future<void> clear() async {
    _buffer.clear();
    _pending.clear();
    revision.value++;
    try {
      await _raf?.truncate(0);
      await _raf?.setPosition(0);
    } catch (_) {}
    try {
      await _native.invokeMethod<void>('clearNativeLog');
    } catch (_) {}
  }

  // ---------------------------------------------------------- native calls --

  Future<String> nativeSnapshot() => _str('snapshot');
  Future<String> nativeLog() => _str('nativeLog');
  Future<String> logcat([int lines = 1200]) => _str('logcat', {'lines': lines});
  Future<String> lastCrash() async {
    final s = await _str('lastCrash');
    return s == '(unavailable)' ? '' : s;
  }

  Future<void> openBatterySettings() async {
    try {
      await _native.invokeMethod<void>('openBatterySettings');
    } catch (_) {}
  }

  Future<String> _str(String method, [Object? args]) async {
    try {
      final r = await _native.invokeMethod<String>(method, args);
      return r ?? '';
    } on MissingPluginException {
      return '(not available on this platform)';
    } catch (e) {
      return '(unavailable: $e)';
    }
  }

  // ---------------------------------------------------------------- report --

  Future<String> buildReport() async {
    final b = StringBuffer();
    b.writeln('===== ABTIN MAPS DEBUG REPORT =====');
    b.writeln('generated: ${DateTime.now()}');
    b.writeln('app: $appInfo');
    b.writeln('uptime: ${DateTime.now().difference(startedAt)}');
    b.writeln('errors since start: $errorCount');
    b.writeln('previous session: ${previousSessionVerdict ?? previousSessionNote ?? 'OK / unknown'}');
    final fil = await filamentStatus();
    b.writeln('filament (3D car): ${fil ?? 'not started / unavailable'}');
    b.writeln('\n----- ANDROID SNAPSHOT -----');
    b.writeln(await nativeSnapshot());
    final crash = await lastCrash();
    if (crash.isNotEmpty) {
      b.writeln('\n----- LAST NATIVE (JAVA) CRASH -----');
      b.writeln(crash);
    }
    b.writeln('\n----- ANDROID NATIVE LOG (tail) -----');
    b.writeln(await nativeLog());
    b.writeln('\n----- DART LOG (last ${_buffer.length}) -----');
    for (final e in _buffer) {
      b.writeln(e.line);
    }
    b.writeln('\n----- LOGCAT (own app, tail) -----');
    b.writeln(await logcat(900));
    return b.toString();
  }

  Future<String?> saveReport() async {
    try {
      final text = await buildReport();
      final dir = _dir ?? await getTemporaryDirectory();
      await dir.create(recursive: true);
      final stamp = DateTime.now().toIso8601String().replaceAll(RegExp(r'[:.]'), '-');
      final f = File('${dir.path}/report_$stamp.txt');
      await f.writeAsString(text);
      return f.path;
    } catch (e) {
      log(DbgLevel.error, 'debug', 'saveReport failed: $e');
      return null;
    }
  }

  Future<void> shareReport() async {
    final path = await saveReport();
    if (path == null) return;
    try {
      await SharePlus.instance.share(
        ShareParams(files: [XFile(path)], text: 'Abtin Maps debug report'),
      );
    } catch (e) {
      log(DbgLevel.error, 'debug', 'share failed: $e');
    }
  }
}

class _LifecycleObserver with WidgetsBindingObserver {
  _LifecycleObserver(this._d);
  final AppDebugger _d;

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _d.lifecycle = state;
    _d.log(DbgLevel.info, 'lifecycle', state.name);
    _d._writeSession(clean: state == AppLifecycleState.detached);
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      _d._flushPending();
    }
  }

  @override
  void didHaveMemoryPressure() {
    _d.log(DbgLevel.warn, 'memory', 'didHaveMemoryPressure (Flutter)');
  }
}

/// Logs every route change.
class DebugNavigatorObserver extends NavigatorObserver {
  String _n(Route<dynamic>? r) =>
      r?.settings.name ?? r?.settings.runtimeType.toString() ?? '?';

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) =>
      AppDebugger.instance.i('nav', 'push ${_n(route)} (from ${_n(previousRoute)})');

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) =>
      AppDebugger.instance.i('nav', 'pop ${_n(route)} (back to ${_n(previousRoute)})');

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) =>
      AppDebugger.instance.i('nav', 'replace ${_n(oldRoute)} -> ${_n(newRoute)}');
}

/// Logs provider creation / disposal and every provider failure.
base class DebugProviderObserver extends ProviderObserver {
  String _name(ProviderBase<Object?> p) => p.name ?? p.runtimeType.toString();

  @override
  void didAddProvider(
      ProviderBase<Object?> provider, Object? value, ProviderContainer container) {
    AppDebugger.instance.d('provider', 'create ${_name(provider)}');
    if (value is AsyncError) {
      AppDebugger.instance.recordError('provider', value.error, value.stackTrace,
          extra: _name(provider));
    }
  }

  @override
  void didUpdateProvider(ProviderBase<Object?> provider, Object? previousValue,
      Object? newValue, ProviderContainer container) {
    if (newValue is AsyncError &&
        !(previousValue is AsyncError && previousValue.error == newValue.error)) {
      AppDebugger.instance.recordError('provider', newValue.error, newValue.stackTrace,
          extra: _name(provider));
    }
  }

  @override
  void didDisposeProvider(ProviderBase<Object?> provider, ProviderContainer container) {
    AppDebugger.instance.d('provider', 'dispose ${_name(provider)}');
  }

  @override
  void providerDidFail(ProviderBase<Object?> provider, Object error,
      StackTrace stackTrace, ProviderContainer container) {
    AppDebugger.instance.recordError('provider', error, stackTrace,
        extra: _name(provider));
  }
}
