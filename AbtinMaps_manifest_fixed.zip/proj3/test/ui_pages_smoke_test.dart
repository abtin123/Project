import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:abtin_maps/features/routing/presentation/routes_screen.dart';
import 'package:abtin_maps/features/search/presentation/search_screen.dart';
import 'package:abtin_maps/features/settings/presentation/appearance_settings_screen.dart';
import 'package:abtin_maps/features/settings/presentation/marker_settings_screen.dart';
import 'package:abtin_maps/features/routing_settings/presentation/routing_settings_screen.dart';

void main() {
  Future<void> pumpPage(WidgetTester tester, Widget page) async {
    await tester.pumpWidget(
      const ProviderScope(
        child: MaterialApp(
          home: SizedBox.shrink(),
        ),
      ),
    );
    await tester.pumpWidget(
      ProviderScope(
        child: MaterialApp(home: page),
      ),
    );
    await tester.pump(const Duration(milliseconds: 200));
    expect(tester.takeException(), isNull);
  }

  testWidgets('search page builds visible content', (tester) async {
    await pumpPage(tester, const SearchScreen());
    expect(find.text('جستجو'), findsWidgets);
  });

  testWidgets('routing page builds visible content', (tester) async {
    await pumpPage(tester, const RoutesScreen());
    expect(find.text('مسیرها'), findsWidgets);
  });

  testWidgets('appearance page builds visible content', (tester) async {
    await pumpPage(tester, const AppearanceSettingsScreen());
    expect(find.byType(Scaffold), findsOneWidget);
    expect(find.byType(Scrollable), findsWidgets);
    expect(find.byType(Text), findsWidgets);
  });

  testWidgets('routing settings page builds visible content', (tester) async {
    await pumpPage(tester, const RoutingSettingsScreen());
    expect(find.byType(Scaffold), findsOneWidget);
    expect(find.byType(Scrollable), findsWidgets);
    expect(find.byType(Text), findsWidgets);
  });

  testWidgets('vehicle settings page builds visible content', (tester) async {
    await pumpPage(tester, const MarkerSettingsScreen());
    expect(find.byType(Scaffold), findsOneWidget);
    expect(find.byType(Scrollable), findsWidgets);
    expect(find.byType(Text), findsWidgets);
  });

}
