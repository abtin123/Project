import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:interactive_3d/interactive_3d.dart';

import 'vehicle_provider.dart';

double vehicleScreenRotationDegrees(double headingDeg) {
  final normalized = headingDeg.isFinite ? headingDeg : 0.0;
  final value = (normalized + 180.0) % 360.0;
  return value < 0 ? value + 360.0 : value;
}

/// مسیر فایل‌های نورپردازی Filament (Image-Based Lighting + Skybox).
/// این دو فایل باینری (.ktx) با ابزار cmgen از یک HDR ساخته می‌شوند — این
/// مرحله را نمی‌شود از کد Dart جایگزین کرد. تا وقتی این دو فایل داخل
/// assets/models/ قرار نگیرند، خودرو بدون نور (IBL) رندر می‌شود؛ روی
/// Filament این یعنی دقیقاً همون بلوک خاکستری تخت که روی نقشه دیده شد —
/// نه باگ رندر، نبود منبع نور. راه ساخت این دو فایل، دقیقاً همونیه که در
/// README خود پکیج آمده:
///   ۱) یک عکس HDR بردار (مثلاً از polyhaven.com، یا مستقیم همینی که خودِ
///      نمونه‌های رسمی Filament استفاده می‌کنند:
///      https://github.com/google/filament/blob/main/third_party/environments/venetian_crossroads_2k.hdr )
///   ۲) از https://github.com/google/filament/releases باینری Filament را
///      دانلود کن، پوشه‌ی bin را به PATH اضافه کن.
///   ۳) اجرا کن:
///      cmgen --format=ktx --deploy=venetian_crossroads_2k venetian_crossroads_2k.hdr
///   ۴) دو فایل خروجی (…_ibl.ktx و …_skybox.ktx) را دقیقاً با همین دو نام
///      زیر در assets/models/ کپی کن — همین، بدون تغییر کد دیگری روشن
///      می‌شود چون این ویجت خودش وجودشان را چک می‌کند.
const String _iblAssetPath = 'assets/models/venetian_crossroads_2k_ibl.ktx';
const String _skyboxAssetPath =
    'assets/models/venetian_crossroads_2k_skybox.ktx';

/// چون این دو asset ممکن است هنوز اضافه نشده باشند، لود را یک‌بار در ابتدای
/// اپ (نه هر فریم) امتحان می‌کنیم؛ اگر فایل نبود، پارامترهای iblPath را
/// اصلاً پاس نمی‌دهیم — Filament بدون نور رندر می‌کند (باز هم بهتر از
/// throw کردن روی asset نامعتبر) و در Debug کنسول هشدار می‌دهد.
Future<bool>? _iblAssetsAvailable;
Future<bool> _checkIblAssets() {
  return _iblAssetsAvailable ??= Future<bool>(() async {
    try {
      await rootBundle.load(_iblAssetPath);
      await rootBundle.load(_skyboxAssetPath);
      return true;
    } catch (_) {
      return false;
    }
  });
}

/// Native Filament GLB renderer shared by the settings preview and map marker.
/// No WebView or user-facing lighting control is used — rendering is 100%
/// on-device via Google Filament (interactive_3d plugin), not a browser view.
class GlbVehicleMarker extends StatefulWidget {
  const GlbVehicleMarker({
    super.key,
    required this.size,
    required this.modelIndex,
    required this.bodyColor,
    this.headingDeg = 0,
    this.cameraTiltDegrees = 0,
    this.interactive = false,
  });

  final double size;
  final int modelIndex;
  final Color bodyColor;
  final double headingDeg;
  final double cameraTiltDegrees;
  final bool interactive;

  static const _bodyMaterialNames = <List<String>>[
    ['paint', 'body', 'carpaint'],
    ['material', 'body'],
    ['set1', 'body'],
    ['carpaint', 'pearl_paint', 'body'],
  ];

  List<MaterialOverride> _bodyOverrides(int index) {
    final rgba = <double>[
      bodyColor.red / 255.0,
      bodyColor.green / 255.0,
      bodyColor.blue / 255.0,
      bodyColor.alpha / 255.0,
    ];
    return [
      for (final name in _bodyMaterialNames[index.clamp(0, 3)])
        MaterialOverride(
          name: name,
          color: rgba,
          roughness: 0.42,
          metallic: 0.15,
        ),
    ];
  }

  @override
  State<GlbVehicleMarker> createState() => _GlbVehicleMarkerState();
}

class _GlbVehicleMarkerState extends State<GlbVehicleMarker> {
  @override
  Widget build(BuildContext context) {
    final index = widget.modelIndex.clamp(0, vehicleModels.length - 1);
    final angle =
        vehicleScreenRotationDegrees(widget.headingDeg) * math.pi / 180.0;
    return SizedBox.square(
      dimension: widget.size,
      child: Transform.rotate(
        angle: angle,
        child: IgnorePointer(
          ignoring: !widget.interactive,
          child: FutureBuilder<bool>(
            future: _checkIblAssets(),
            builder: (context, snapshot) {
              final hasIbl = snapshot.data ?? false;
              return Interactive3d(
                key: ValueKey(
                  'filament-${vehicleModels[index]}-${widget.bodyColor.value}-$hasIbl',
                ),
                modelPath: vehicleModels[index],
                // شفافیت واقعی روی نقشه: پارامتر مستند پلاگین برای پس‌زمینه
                // شفاف (در حین حفظ نور IBL) دقیقاً همین است، نه backgroundColor
                // که اصلاً چنین پارامتری در API این پلاگین وجود ندارد و اثری
                // روی بافر رندر Filament نداشت — همون چیزی که باعث می‌شد
                // به‌جای مدل شفاف، یک بلوک تخت دیده بشه.
                solidBackgroundColor: const [0, 0, 0, 0],
                iblPath: hasIbl ? _iblAssetPath : null,
                skyboxPath: hasIbl ? _skyboxAssetPath : null,
                defaultZoom: 1.35,
                initialMaterialOverrides: widget._bodyOverrides(index),
                loadingWidget: const SizedBox.shrink(),
              );
            },
          ),
        ),
      ),
    );
  }
}

class ThreeDVehicleMarker extends GlbVehicleMarker {
  const ThreeDVehicleMarker({
    super.key,
    required super.size,
    required super.modelIndex,
    required super.bodyColor,
    super.headingDeg,
    super.cameraTiltDegrees,
    super.interactive,
  });
}
