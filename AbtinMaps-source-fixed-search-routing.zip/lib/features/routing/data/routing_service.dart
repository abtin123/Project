import 'dart:math' as math;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:abtin_maps/core/geo/geo_types.dart';
import '../../../core/localization/app_localizations.dart';

import '../../../shared/providers/abtinmap_providers.dart';
import '../../../shared/providers/app_settings_providers.dart';
import 'abtinmap_routing_provider.dart';
import 'online_routing_provider.dart';
import 'routing_provider.dart';

class RouteInfo {
  const RouteInfo({
    required this.geometry,
    required this.distanceKm,
    required this.durationMin,
    required this.instructions,
    this.alerts = const [],
  });

  final List<LatLng> geometry;
  final double distanceKm;
  final double durationMin;
  final List<RouteInstruction> instructions;
  final List<RouteAlert> alerts;
}

enum RouteAlertType { speedCamera, speedBump, policeCheckpoint, trafficLight }

class RouteAlert {
  const RouteAlert({required this.type, required this.location, this.name});
  final RouteAlertType type;
  final LatLng location;
  final String? name;
}

class RouteInstruction {
  const RouteInstruction({
    required this.text,
    required this.distanceMeters,
    required this.location,
    required this.type,
    this.modifier,
    this.exit,
    this.roundaboutAngleDegrees,
    this.roundaboutExitCount,
    this.roundaboutBranchAngles = const [],
    this.roundaboutEntranceAngles = const [],
    this.roundaboutExitAngles = const [],
    this.roundaboutActiveExitAngle,
    this.drivingSide = 'right',
    this.speedLimit,
    this.maneuverEndLocation,
    this.maneuverAngleDegrees,
  });

  final String text;
  final double distanceMeters;
  final LatLng location;
  final String type;
  final String? modifier;
  final int? exit;
  final double? roundaboutAngleDegrees;

  final int? roundaboutExitCount;

  final List<double> roundaboutBranchAngles;
  final List<double> roundaboutEntranceAngles;
  final List<double> roundaboutExitAngles;
  final double? roundaboutActiveExitAngle;

  final String drivingSide;
  final int? speedLimit;

  final LatLng? maneuverEndLocation;

  final double? maneuverAngleDegrees;
}

class RoutingService {
  RoutingService(this._ref);

  final Ref _ref;
  OnlineRoutingProvider? _onlineProvider;
  String? lastError;

  RoutingEngine get engine => _ref.read(routingEngineProvider);

  final Map<String, AbtinmapRoutingProvider> _abmProviders =
      <String, AbtinmapRoutingProvider>{};

  /// Set by [_offlineProvidersFor] when no installed map can serve the trip.
  String? _coverageError;

  /// Bounding boxes (minLon, minLat, maxLon, maxLat) of installed maps from the
  /// last [_offlineProvidersFor] call; used to chain several maps together.
  List<_MapBox> _lastBoxes = const <_MapBox>[];

  AbtinmapRoutingProvider _abmProviderFor(String mapName) =>
      _abmProviders.putIfAbsent(
        mapName,
        () => AbtinmapRoutingProvider(
          mapService: _ref.read(abmMapServiceProvider),
          vectorMapService: _ref.read(vectorMapServiceProvider),
          mapName: mapName,
          languageCode: () => _ref.read(languageProvider),
        ),
      );

  Future<List<AbtinmapRoutingProvider>> _offlineProvidersFor(
    LatLng origin,
    LatLng destination,
  ) async {
    final sources = await _ref.read(installedOfflineMapSourcesProvider.future);
    if (sources.isEmpty) {
      final activeMap = _ref.read(abmActiveMapNameProvider).trim();
      return <AbtinmapRoutingProvider>[_abmProviderFor(activeMap)];
    }
    final vector = _ref.read(vectorMapServiceProvider);
    _coverageError = null;
    // Small tolerance: the road snap can reach ~9 km beyond a map's bbox edge.
    const tol = 0.08;
    bool inBox(List<double>? b, LatLng p) => b == null
        ? false
        : p.longitude >= b[0] - tol &&
            p.longitude <= b[2] + tol &&
            p.latitude >= b[1] - tol &&
            p.latitude <= b[3] + tol;
    final both = <OfflineMapSource>[];
    final unknown = <OfflineMapSource>[];
    final boxes = <_MapBox>[];
    var anyO = false;
    var anyD = false;
    for (final source in sources) {
      final box = await offlineMapBbox(vector, source);
      if (box == null) {
        unknown.add(source);
        continue;
      }
      final hasO = inBox(box, origin);
      final hasD = inBox(box, destination);
      boxes.add(_MapBox(source, box));
      anyO = anyO || hasO;
      anyD = anyD || hasD;
      if (hasO && hasD) both.add(source);
    }
    _lastBoxes = boxes;
    // A route can only exist inside ONE offline map (the graph is per map).
    // Maps that do not contain both endpoints can never succeed, and each failed
    // attempt used to burn up to the full search budget, so skip them.
    final usable = both.isNotEmpty ? both : unknown;
    if (usable.isEmpty) {
      _coverageError = !anyO && !anyD
          ? 'مبدأ و مقصد هیچ‌کدام داخل نقشه‌های آفلاین نصب‌شده نیستند.'
          : !anyD
              ? 'مقصد داخل نقشه‌های آفلاین نصب‌شده نیست. نقشه‌ی منطقه‌ی مقصد را دانلود کنید.'
              : !anyO
                  ? 'مبدأ داخل نقشه‌های آفلاین نصب‌شده نیست. نقشه‌ی منطقه‌ی مبدأ را دانلود کنید.'
                  : 'مبدأ و مقصد در دو نقشه‌ی جداگانه‌اند و مسیریابی آفلاین فقط داخل '
                      'یک نقشه ممکن است. نقشه‌ای که هر دو را پوشش دهد دانلود کنید.';
      return const <AbtinmapRoutingProvider>[];
    }
    return <AbtinmapRoutingProvider>[
      for (final source in usable) _abmProviderFor(source.fileName),
    ];
  }

  // ---------------------------------------------------------------------------
  // Multi-map routing: when no single installed map contains both endpoints,
  // chain neighbouring maps. Each map is routed separately up to a crossing point
  // inside the overlap of two maps, then the legs are joined into one route.
  // ---------------------------------------------------------------------------
  static const double _stitchTol = 0.08;
  static const double _stitchGap = 0.05;

  static bool _boxHas(List<double> b, LatLng p, double tol) =>
      p.longitude >= b[0] - tol &&
      p.longitude <= b[2] + tol &&
      p.latitude >= b[1] - tol &&
      p.latitude <= b[3] + tol;

  List<int>? _mapChain(LatLng origin, LatLng destination) {
    final boxes = _lastBoxes;
    final n = boxes.length;
    if (n < 2) return null;
    final starts = <int>[];
    final goals = <int>{};
    for (var i = 0; i < n; i++) {
      if (_boxHas(boxes[i].box, origin, _stitchTol)) starts.add(i);
      if (_boxHas(boxes[i].box, destination, _stitchTol)) goals.add(i);
    }
    if (starts.isEmpty || goals.isEmpty) return null;
    bool near(int a, int b) {
      final x = boxes[a].box, y = boxes[b].box;
      return !(x[2] + _stitchGap < y[0] ||
          y[2] + _stitchGap < x[0] ||
          x[3] + _stitchGap < y[1] ||
          y[3] + _stitchGap < x[1]);
    }

    double hop(int a, int b) {
      final dLat = boxes[a].centerLat - boxes[b].centerLat;
      final dLon = boxes[a].centerLon - boxes[b].centerLon;
      return math.sqrt(dLat * dLat + dLon * dLon) + 1.0;
    }

    final dist = List<double>.filled(n, double.infinity);
    final prev = List<int>.filled(n, -1);
    final done = List<bool>.filled(n, false);
    for (final s in starts) {
      dist[s] = 0;
    }
    for (var step = 0; step < n; step++) {
      var u = -1;
      for (var i = 0; i < n; i++) {
        if (!done[i] && (u < 0 || dist[i] < dist[u])) u = i;
      }
      if (u < 0 || dist[u] == double.infinity) break;
      done[u] = true;
      for (var v = 0; v < n; v++) {
        if (done[v] || !near(u, v)) continue;
        final d = dist[u] + hop(u, v);
        if (d < dist[v]) {
          dist[v] = d;
          prev[v] = u;
        }
      }
    }
    int? best;
    for (final g in goals) {
      if (dist[g] == double.infinity) continue;
      if (best == null || dist[g] < dist[best]) best = g;
    }
    if (best == null) return null;
    final chain = <int>[];
    for (var at = best; at >= 0; at = prev[at]) {
      chain.add(at);
    }
    return chain.reversed.toList(growable: false);
  }

  /// Candidate crossing points inside the overlap (or gap) of two maps.
  List<LatLng> _crossingCandidates(
      List<double> a, List<double> b, LatLng from, LatLng to) {
    double lo(double x, double y) => math.min(x, y);
    double hi(double x, double y) => math.max(x, y);
    final minLon = lo(math.max(a[0], b[0]), math.min(a[2], b[2]));
    final maxLon = hi(math.max(a[0], b[0]), math.min(a[2], b[2]));
    final minLat = lo(math.max(a[1], b[1]), math.min(a[3], b[3]));
    final maxLat = hi(math.max(a[1], b[1]), math.min(a[3], b[3]));
    final out = <LatLng>[];
    // Liang-Barsky clip of the straight line from -> to against the overlap box.
    var t0 = 0.0, t1 = 1.0;
    final dx = to.longitude - from.longitude;
    final dy = to.latitude - from.latitude;
    bool clip(double p, double q) {
      if (p == 0) return q >= 0;
      final r = q / p;
      if (p < 0) {
        if (r > t1) return false;
        if (r > t0) t0 = r;
      } else {
        if (r < t0) return false;
        if (r < t1) t1 = r;
      }
      return true;
    }

    final ok = clip(-dx, from.longitude - minLon) &&
        clip(dx, maxLon - from.longitude) &&
        clip(-dy, from.latitude - minLat) &&
        clip(dy, maxLat - from.latitude);
    LatLng at(double t) =>
        LatLng(from.latitude + dy * t, from.longitude + dx * t);
    if (ok && t1 > t0) {
      out.add(at((t0 + t1) / 2));
      out.add(at(t0 + (t1 - t0) * 0.3));
      out.add(at(t0 + (t1 - t0) * 0.7));
    }
    out.add(LatLng((minLat + maxLat) / 2, (minLon + maxLon) / 2));
    return out;
  }

  RouteInstruction _shiftInstruction(RouteInstruction i, double offsetM) =>
      RouteInstruction(
        text: i.text,
        distanceMeters: i.distanceMeters + offsetM,
        location: i.location,
        type: i.type,
        modifier: i.modifier,
        exit: i.exit,
        roundaboutAngleDegrees: i.roundaboutAngleDegrees,
        roundaboutExitCount: i.roundaboutExitCount,
        roundaboutBranchAngles: i.roundaboutBranchAngles,
        roundaboutEntranceAngles: i.roundaboutEntranceAngles,
        roundaboutExitAngles: i.roundaboutExitAngles,
        roundaboutActiveExitAngle: i.roundaboutActiveExitAngle,
        drivingSide: i.drivingSide,
        speedLimit: i.speedLimit,
        maneuverEndLocation: i.maneuverEndLocation,
        maneuverAngleDegrees: i.maneuverAngleDegrees,
      );

  RouteInfo _joinLegs(List<RouteInfo> legs) {
    final geometry = <LatLng>[];
    final instructions = <RouteInstruction>[];
    final alerts = <RouteAlert>[];
    var distanceKm = 0.0;
    var durationMin = 0.0;
    var offsetM = 0.0;
    for (var k = 0; k < legs.length; k++) {
      final leg = legs[k];
      final isFirst = k == 0;
      final isLast = k == legs.length - 1;
      for (final p in leg.geometry) {
        if (geometry.isNotEmpty && geometry.last == p) continue;
        geometry.add(p);
      }
      for (var i = 0; i < leg.instructions.length; i++) {
        final ins = leg.instructions[i];
        if (!isFirst && i == 0 && ins.type == 'depart') continue;
        if (!isLast && i == leg.instructions.length - 1 && ins.type == 'arrive') {
          continue;
        }
        instructions.add(_shiftInstruction(ins, offsetM));
      }
      alerts.addAll(leg.alerts);
      distanceKm += leg.distanceKm;
      durationMin += leg.durationMin;
      offsetM += leg.distanceKm * 1000.0;
    }
    return RouteInfo(
      geometry: geometry,
      distanceKm: distanceKm,
      durationMin: durationMin,
      instructions: instructions,
      alerts: alerts,
    );
  }

  Future<RouteInfo?> _stitchedRoute({
    required LatLng origin,
    required LatLng destination,
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
    bool avoidTrafficZones = false,
    bool avoidHighways = false,
    int routeMode = 0,
  }) async {
    final chain = _mapChain(origin, destination);
    if (chain == null || chain.length < 2) return null;
    final boxes = _lastBoxes;
    final legs = <RouteInfo>[];
    var legStart = origin;
    for (var i = 0; i < chain.length; i++) {
      final provider = _abmProviderFor(boxes[chain[i]].source.fileName);
      final isLast = i == chain.length - 1;
      RouteInfo? leg;
      if (isLast) {
        leg = await provider.calculateRoute(
          origin: legStart,
          destination: destination,
          offlineOnly: true,
          avoidUnpavedRoads: avoidUnpavedRoads,
          avoidTolls: avoidTolls,
          avoidTrafficZones: avoidTrafficZones,
          avoidHighways: avoidHighways,
          routeMode: routeMode,
        );
      } else {
        final candidates = _crossingCandidates(
          boxes[chain[i]].box,
          boxes[chain[i + 1]].box,
          legStart,
          destination,
        );
        for (final wp in candidates) {
          leg = await provider.calculateRoute(
            origin: legStart,
            destination: wp,
            offlineOnly: true,
            avoidUnpavedRoads: avoidUnpavedRoads,
            avoidTolls: avoidTolls,
            avoidTrafficZones: avoidTrafficZones,
            avoidHighways: avoidHighways,
            routeMode: routeMode,
          );
          if (leg != null) break;
        }
      }
      if (leg == null || leg.geometry.length < 2) {
        _coverageError = 'مسیر بین نقشه‌های '
            '${boxes[chain[i]].source.id}'
            '${isLast ? '' : ' و ${boxes[chain[i + 1]].source.id}'} '
            'ساخته نشد. ممکن است جاده‌ی متصل‌کننده‌ی دو نقشه در داده نباشد.';
        return null;
      }
      legs.add(leg);
      legStart = leg.geometry.last;
    }
    return _joinLegs(legs);
  }

  OnlineRoutingProvider get onlineProvider =>
      _onlineProvider ??= OnlineRoutingProvider(
        languageCode: () => _ref.read(languageProvider),
      );

  static List<String> _osrmExclude(bool tolls, bool highways, bool ferries) =>
      [if (tolls) 'toll', if (highways) 'motorway', if (ferries) 'ferry'];

  Future<RouteInfo?> calculateRoute({
    required LatLng origin,
    required LatLng destination,
    bool offlineOnly = false,
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
    bool avoidTrafficZones = false,
    bool avoidHighways = false,
    bool avoidFerries = false,
    int routeMode = 0,
  }) async {
    lastError = null;
    if (!offlineOnly && engine == RoutingEngine.online) {
      final route = await onlineProvider.calculateRoute(
        origin: origin,
        destination: destination,
        exclude: _osrmExclude(avoidTolls, avoidHighways, avoidFerries),
      );
      if (route != null) return route;
      lastError = onlineProvider.lastError ??
          AppStrings.getForLanguage(
              _ref.read(languageProvider), 'route_error_online_failed_generic');
      return null;
    }

    String? offlineError;
    final providers = await _offlineProvidersFor(origin, destination);
    for (final provider in providers) {
      final route = await provider.calculateRoute(
        origin: origin,
        destination: destination,
        offlineOnly: true,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
        avoidTrafficZones: avoidTrafficZones,
        avoidHighways: avoidHighways,
        routeMode: routeMode,
      );
      if (route != null) return route;
      offlineError ??= provider.lastError;
    }
    if (providers.isEmpty) {
      final stitched = await _stitchedRoute(
        origin: origin,
        destination: destination,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
        avoidTrafficZones: avoidTrafficZones,
        avoidHighways: avoidHighways,
        routeMode: routeMode,
      );
      if (stitched != null) return stitched;
    }
    lastError = offlineError ??
        _coverageError ??
        AppStrings.getForLanguage(
            _ref.read(languageProvider), 'route_error_offline_map_missing');
    return null;
  }

  Future<List<RouteInfo>> calculateRoutes({
    required LatLng origin,
    required LatLng destination,
    bool offlineOnly = false,
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
    bool avoidTrafficZones = false,
    bool avoidHighways = false,
    bool avoidFerries = false,
    int routeMode = 0,
  }) async {
    lastError = null;
    if (!offlineOnly && engine == RoutingEngine.online) {
      final routes = await onlineProvider.calculateRoutes(
        origin: origin,
        destination: destination,
        exclude: _osrmExclude(avoidTolls, avoidHighways, avoidFerries),
      );
      if (routes.isEmpty) {
        lastError = onlineProvider.lastError ??
            AppStrings.getForLanguage(_ref.read(languageProvider),
                'route_error_online_failed_generic');
      }
      return routes;
    }

    String? offlineError;
    final providers = await _offlineProvidersFor(origin, destination);
    for (final provider in providers) {
      final routes = await provider.calculateRoutes(
        origin: origin,
        destination: destination,
        offlineOnly: true,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
        avoidTrafficZones: avoidTrafficZones,
        avoidHighways: avoidHighways,
        routeMode: routeMode,
      );
      if (routes.isNotEmpty) return routes;
      offlineError ??= provider.lastError;
    }
    if (providers.isEmpty) {
      final stitched = await _stitchedRoute(
        origin: origin,
        destination: destination,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
        avoidTrafficZones: avoidTrafficZones,
        avoidHighways: avoidHighways,
        routeMode: routeMode,
      );
      if (stitched != null) return <RouteInfo>[stitched];
    }
    lastError =
        offlineError ??
        _coverageError ??
        'برای مسیریابی، ابتدا یک نقشهٔ آفلاین ABM نصب کنید.';
    return const <RouteInfo>[];
  }

  Stream<List<RouteInfo>> calculateRoutesStream({
    required LatLng origin,
    required LatLng destination,
    bool offlineOnly = false,
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
    bool avoidTrafficZones = false,
    bool avoidHighways = false,
    bool avoidFerries = false,
    int routeMode = 0,
  }) async* {
    if (!offlineOnly && engine == RoutingEngine.online) {
      final routes = await calculateRoutes(
        origin: origin,
        destination: destination,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
        avoidTrafficZones: avoidTrafficZones,
        avoidHighways: avoidHighways,
        avoidFerries: avoidFerries,
        routeMode: routeMode,
      );
      yield routes;
      return;
    }
    lastError = null;
    String? offlineError;
    final providers = await _offlineProvidersFor(origin, destination);
    for (final provider in providers) {
      var any = false;
      await for (final routes in provider.calculateRoutesStream(
        origin: origin,
        destination: destination,
        offlineOnly: true,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
        avoidTrafficZones: avoidTrafficZones,
        avoidHighways: avoidHighways,
        routeMode: routeMode,
      )) {
        if (routes.isEmpty) continue;
        any = true;
        yield routes;
      }
      if (any) return;
      offlineError ??= provider.lastError;
    }
    if (providers.isEmpty) {
      final stitched = await _stitchedRoute(
        origin: origin,
        destination: destination,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
        avoidTrafficZones: avoidTrafficZones,
        avoidHighways: avoidHighways,
        routeMode: routeMode,
      );
      if (stitched != null) {
        yield <RouteInfo>[stitched];
        return;
      }
    }
    lastError =
        offlineError ??
        _coverageError ??
        'برای مسیریابی، ابتدا یک نقشهٔ آفلاین ABM نصب کنید.';
    yield const <RouteInfo>[];
  }

  void dispose() {
    _onlineProvider?.dispose();
  }
}

class _MapBox {
  const _MapBox(this.source, this.box);
  final OfflineMapSource source;

  /// minLon, minLat, maxLon, maxLat
  final List<double> box;
  double get centerLat => (box[1] + box[3]) / 2;
  double get centerLon => (box[0] + box[2]) / 2;
}
