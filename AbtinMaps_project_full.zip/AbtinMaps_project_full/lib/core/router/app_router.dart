import 'package:go_router/go_router.dart';
import '../../features/map/presentation/home_screen.dart';
import '../../features/routing/presentation/routes_screen.dart';
import '../../features/settings/presentation/settings_screen.dart';
import '../../features/settings/presentation/map_settings_screen.dart';
import '../../features/settings/presentation/marker_settings_screen.dart';
import '../../features/voice_settings/presentation/voice_settings_screen.dart';
import '../../features/saved_places/presentation/saved_places_screen.dart';
import '../../features/language_settings_hub/language_hub_screen.dart';
import '../../features/debug/presentation/abm_log_screen.dart';

final GoRouter appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(path: '/', builder: (context, state) => const HomeScreen()),
    GoRoute(path: '/routes', builder: (context, state) => const RoutesScreen()),
    GoRoute(
        path: '/settings', builder: (context, state) => const SettingsScreen()),
    GoRoute(
      path: '/map-settings',
      builder: (context, state) => const MapSettingsScreen(),
    ),
    GoRoute(
      path: '/marker-settings',
      builder: (context, state) => const MarkerSettingsScreen(),
    ),
    GoRoute(
      path: '/voice-settings',
      builder: (context, state) => const VoiceSettingsScreen(),
    ),
    GoRoute(
      path: '/saved-places',
      builder: (context, state) => const SavedPlacesScreen(),
    ),
    GoRoute(
      path: '/downloads',
      builder: (context, state) => const LanguageHubScreen(),
    ),
    GoRoute(
      path: '/abm-log',
      builder: (context, state) => const AbmLogScreen(),
    ),
  ],
);
