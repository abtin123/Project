
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:model_viewer_plus/model_viewer_plus.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'vehicle_provider.dart';

/// Used only by the main map. OnlineMapView is re-created (new ValueKey) when the
/// map style / reload key changes; without a GlobalKey that also destroyed the
/// WebView + local HTTP server of the 3D car and built a new one each time.
/// With it Flutter moves the existing State (and its WebView) to the new map.
/// Do NOT use it twice at the same time (e.g. in the settings preview).
final GlobalKey mapCarMarkerKey = GlobalKey(debugLabel: 'map-car-marker');

const _yawCorrectionDegrees = <double>[0.0, 0.0, 0.0, 0.0];

double vehicleModelYawCorrectionDegrees(int modelIndex) {
  return _yawCorrectionDegrees[modelIndex.clamp(0, vehicleModels.length - 1)];
}

double vehicleScreenRotationDegrees(double headingDeg) {
  final normalized = headingDeg.isFinite ? headingDeg : 0.0;
  final value = normalized % 360.0;
  return value < 0 ? value + 360.0 : value;
}

double _orbitTheta(double screenHeadingDeg) =>
    (vehicleScreenRotationDegrees(screenHeadingDeg) + 180.0) % 360.0;

double _orbitPhi(double tiltDegrees) =>
    (tiltDegrees.isFinite ? tiltDegrees : 0.0).clamp(2.0, 78.0).toDouble();

const _carJs = r'''
// model_viewer_plus writes shadow-intensity="0}" (stray brace), which the
// web component parses as NaN. Overwrite it with a clean value.
(function () {
  var m = document.querySelector('model-viewer');
  if (m) {
    m.setAttribute('shadow-intensity', '0');
    m.shadowIntensity = 0;
  }
})();
window.__carApply = function () {
  var m = document.querySelector('model-viewer');
  if (!m || !window.__carLast) return false;
  m.cameraOrbit = window.__carLast;
  if (m.jumpCameraToGoal) m.jumpCameraToGoal();
  return true;
};
window.__carSet = function (theta, phi) {
  window.__carLast = theta + 'deg ' + phi + 'deg auto';
  return window.__carApply();
};
''';



class CarMarker3D extends StatefulWidget {
  const CarMarker3D({
    super.key,
    required this.size,
    required this.modelIndex,
    this.headingDeg = 0,
    this.cameraAngleDegrees = 0,
    this.sizePercent = 80,
    this.interactive = false,
  });

  final double size;
  final int modelIndex;
  final double headingDeg;
  final double cameraAngleDegrees;
  final double sizePercent;
  final bool interactive;

  @override
  State<CarMarker3D> createState() => _CarMarker3DState();
}

class _CarMarker3DState extends State<CarMarker3D> {
  WebViewController? _controller;
  String? _lastSent;
  late String _initialOrbit;
  int _generation = 0;

  // کاهش مصرف باتری: هر فراخوانی JS یک بازرسمِ WebGL در WebView است. چرخشِ ماشین
  // با دقتِ ۱ درجه و حداکثر ~۱۲ بار در ثانیه به مدل فرستاده می‌شود (مقدار آخر
  // همیشه با تأخیرِ کوتاه اعمال می‌شود).
  static const Duration _minPushGap = Duration(milliseconds: 80);
  DateTime _lastPushAt = DateTime.fromMillisecondsSinceEpoch(0);
  Timer? _pendingPush;

  @override
  void dispose() {
    _pendingPush?.cancel();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _initialOrbit = _orbit();
  }

  String _orbit() =>
      '${_orbitTheta(widget.headingDeg).toStringAsFixed(1)}deg '
      '${_orbitPhi(widget.cameraAngleDegrees).toStringAsFixed(1)}deg auto';

  void _push() {
    final c = _controller;
    if (c == null) return;
    final theta = (_orbitTheta(widget.headingDeg).round() % 360).toString();
    final phi = _orbitPhi(widget.cameraAngleDegrees).round().toString();
    final sig = '$theta/$phi';
    if (sig != _lastSent) {
      final since = DateTime.now().difference(_lastPushAt);
      if (since < _minPushGap) {
        _pendingPush ??= Timer(_minPushGap - since, () {
          _pendingPush = null;
          if (mounted) _push();
        });
        return;
      }
      _lastPushAt = DateTime.now();
      _lastSent = sig;
      c.runJavaScript(
        "if(window.__carSet)window.__carSet('$theta','$phi');",
      ).catchError((_) {});
    }
  }

  @override
  void didUpdateWidget(CarMarker3D old) {
    super.didUpdateWidget(old);
    if (old.modelIndex != widget.modelIndex) {
      _pendingPush?.cancel();
      _pendingPush = null;
      _controller = null;
      _lastSent = null;
      _generation++;
    }
    _push();
  }

  @override
  Widget build(BuildContext context) {
    final safeIndex = widget.modelIndex.clamp(0, vehicleModels.length - 1);
    final key = ValueKey<String>('car-$safeIndex-$_generation');
    final viewer = ModelViewer(
      key: key,
      src: vehicleModels[safeIndex],
      alt: 'Vehicle',
      backgroundColor: Colors.transparent,
      cameraOrbit: _initialOrbit,
      minCameraOrbit: 'auto 0deg auto',
      maxCameraOrbit: 'auto 180deg auto',
      cameraControls: widget.interactive,
      disableZoom: !widget.interactive,
      disablePan: true,
      autoRotate: false,
      ar: false,
      loading: Loading.lazy,
      reveal: Reveal.auto,
      // بدون سایهٔ زیر خودرو (کاهش مصرف GPU و ظاهر تمیزتر).
      shadowIntensity: 0,
      exposure: 1.1,
      interactionPrompt: InteractionPrompt.none,
      relatedJs: _carJs,
      onWebViewCreated: (c) {
        _controller = c;
        _lastSent = null;
        _push();
      },
    );

    final visualScale = (widget.sizePercent.clamp(45.0, 150.0) / 100.0);
    return SizedBox.square(
      dimension: widget.size,
      child: IgnorePointer(
        ignoring: !widget.interactive,
        child: Transform.scale(
          scale: visualScale,
          alignment: Alignment.center,
          child: viewer,
        ),
      ),
    );
  }
}
