package ir.abtin.abtin_maps

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
