import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../core/abm_notifier.dart';
import '../../../core/abm_debug_log.dart';
import '../../../core/theme/app_colors.dart';
import '../../../shared/widgets/page_header.dart';

/// صفحهٔ گزارش تشخیصی GPS. این صفحه فقط رخدادهای موقعیت، وضعیت سرویس،
/// مجوزها، تغییر provider و خطاهای GPS را نمایش می‌دهد؛ لاگ‌های رندر/کاشی
/// نقشه عمداً در آن ثبت نمی‌شوند تا گزارش قابل ارسال و قابل تشخیص بماند.
class AbmLogScreen extends StatefulWidget {
  const AbmLogScreen({super.key});

  @override
  State<AbmLogScreen> createState() => _AbmLogScreenState();
}

class _AbmLogScreenState extends State<AbmLogScreen> {
  @override
  void initState() {
    super.initState();
    AbmNotifier.message.addListener(_onNewLine);
  }

  @override
  void dispose() {
    AbmNotifier.message.removeListener(_onNewLine);
    super.dispose();
  }

  void _onNewLine() {
    if (mounted) setState(() {});
  }

  Future<void> _copyAll(BuildContext context) async {
    final text = AbmDebugLog.gpsLogs.join('\n');
    await Clipboard.setData(ClipboardData(text: text));
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('گزارش GPS کپی شد.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final logs = AbmDebugLog.gpsLogs;
    return Scaffold(
      backgroundColor: AppColors.background(context),
      appBar: PageHeader(
        title: 'گزارش تشخیصی GPS',
        backRoute: '/settings',
        actions: [
          IconButton(
            icon: const Icon(Icons.copy_rounded),
            tooltip: 'کپی همه',
            onPressed: logs.isEmpty ? null : () => _copyAll(context),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded),
            tooltip: 'پاک‌کردن',
            onPressed:
                logs.isEmpty ? null : () => setState(AbmDebugLog.clearGps),
          ),
        ],
      ),
      body: logs.isEmpty
          ? const Center(
              child: Text(
                'هنوز رخداد GPS ثبت نشده است.\nپس از باز کردن نقشه، وضعیت سرویس، مجوز و اولین فیکس اینجا نمایش داده می‌شود.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white54),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
              itemCount: logs.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, i) {
                final line = logs[i];
                final isError = line.contains('خطا') || line.contains('ناموفق');
                return Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: isError
                        ? const Color(0x33EB5757)
                        : Colors.white.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: isError
                          ? const Color(0x66EB5757)
                          : Colors.white.withOpacity(0.08),
                    ),
                  ),
                  child: SelectableText(
                    line,
                    style: TextStyle(
                      color: isError ? const Color(0xFFFF8A8A) : Colors.white70,
                      fontSize: 12.5,
                      fontFamily: 'monospace',
                      height: 1.4,
                    ),
                  ),
                );
              },
            ),
    );
  }
}
