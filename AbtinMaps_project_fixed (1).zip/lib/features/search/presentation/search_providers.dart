import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/database/app_database.dart';
import '../../../shared/providers/abtinmap_providers.dart';
import '../data/offline_search_index.dart';
import '../data/search_service.dart';

final databaseProvider = Provider<AppDatabase>((ref) {
  return AppDatabase();
});

/// ایندکسِ آفلاینِ نام خیابان‌ها/مکان‌ها — روی همان AbmMapService که برای
/// دانلود/باز کردنِ نقشه‌های .abm استفاده می‌شود ساخته می‌شود. یک نمونه‌ی
/// واحد برای کل اپ، تا هربار سرچ دوباره کش دیسک را نخواند.
final abmOfflineSearchIndexProvider = Provider<AbmOfflineSearchIndex>((ref) {
  return AbmOfflineSearchIndex(ref.watch(abmMapServiceProvider));
});

final searchServiceProvider = Provider<SearchService>((ref) {
  final database = ref.watch(databaseProvider);
  return SearchService(database);
});

final recentSearchesProvider =
    FutureProvider.autoDispose<List<RecentSearchEntry>>((ref) async {
  final searchService = ref.watch(searchServiceProvider);
  return await searchService.getRecentSearches(limit: 15);
});

final searchQueryProvider = StateProvider<String>((ref) => '');

final searchResultsProvider =
    FutureProvider.autoDispose<List<SearchResult>>((ref) async {
  final query = ref.watch(searchQueryProvider);

  if (query.isEmpty) {
    return [];
  }

  final searchService = ref.watch(searchServiceProvider);
  return await searchService.searchPlaces(query);
});
