import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:abtin_maps/core/geo/geo_types.dart';

import '../../../core/theme/app_colors.dart';
import '../../gps/presentation/gps_providers.dart';
import '../../map/presentation/destination_provider.dart';
import '../../routing/data/routing_provider.dart' show RoutingEngine;
import '../../saved_places/presentation/saved_places_providers.dart';
import '../../../shared/providers/abtinmap_providers.dart' show routingEngineProvider;
import '../../../shared/widgets/bottom_nav.dart';
import '../../../shared/widgets/page_header.dart';
import '../data/online_search_provider.dart';
import '../data/search_service.dart';
import 'search_providers.dart'
    show abmOfflineSearchIndexProvider, recentSearchesProvider, searchServiceProvider;

/// جستجو یک صفحه‌ی مستقل است. فقط پس از انتخاب یک نتیجه، مقصد به provider
/// نقشه منتقل می‌شود؛ خودِ این صفحه هیچ مسیریابی‌ای شروع نمی‌کند.
class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key});

  @override
  ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  final _searchController = TextEditingController();
  final _focusNode = FocusNode();
  List<SearchResult> _results = [];
  bool _isLoading = false;
  Timer? _debounce;
  String? _statusMessage;
  int _searchEpoch = 0;

  @override
  void dispose() {
    _searchController.dispose();
    _focusNode.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  void _onSearchChanged(String query) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), () {
      if (query.trim().length >= 2) {
        _performSearch(query.trim());
      } else if (mounted) {
        _searchEpoch++;
        setState(() {
          _results = [];
          _statusMessage = null;
        });
      }
    });
  }

  Future<void> _performSearch(String query) async {
    final requestEpoch = ++_searchEpoch;
    setState(() {
      _isLoading = true;
      _statusMessage = null;
    });
    final results = <SearchResult>[];
    final myPos = ref.read(vehiclePositionProvider).valueOrNull;

    try {
      final index = ref.read(abmOfflineSearchIndexProvider);
      await index.ensureBuilt();
      final matches = index.search(
        query,
        limit: 20,
        near: myPos == null ? null : (lat: myPos.lat, lng: myPos.lng),
      );
      results.addAll(matches.map((entry) => SearchResult(
            title: entry.name,
            subtitle:
                entry.isPoi ? 'مکان در نقشه آفلاین' : 'خیابان در نقشه آفلاین',
            lat: entry.lat,
            lng: entry.lng,
            isOffline: true,
          )));
    } catch (_) {
      // نتایج آفلاین اختیاری‌اند؛ خطای ایندکس نباید کل جست‌وجو را متوقف کند.
    }

    try {
      final onlineResults = await onlineSearchProvider.search(query);
      results.addAll(onlineResults);
    } catch (_) {
      if (results.isEmpty) {
        if (mounted && requestEpoch == _searchEpoch) {
          setState(() =>
              _statusMessage = 'اتصال اینترنت برقرار نشد؛ نتیجه‌ای یافت نشد.');
        }
      }
    }

    if (myPos != null) {
      results.sort((a, b) =>
          _squaredDistance(myPos.lat, myPos.lng, a.lat, a.lng)
              .compareTo(_squaredDistance(myPos.lat, myPos.lng, b.lat, b.lng)));
    }
    if (!mounted || requestEpoch != _searchEpoch) return;
    final deduped = _dedupe(results);
    setState(() {
      _results = deduped;
      _isLoading = false;
      if (deduped.isEmpty && _statusMessage == null) {
        _statusMessage = 'نتیجه‌ای پیدا نشد.';
      }
    });
  }

  List<SearchResult> _dedupe(List<SearchResult> source) {
    final seen = <String>{};
    return source
        .where((result) => seen.add(
            '${result.title}-${result.lat.toStringAsFixed(5)}-${result.lng.toStringAsFixed(5)}'))
        .toList();
  }

  double _squaredDistance(double lat1, double lng1, double lat2, double lng2) {
    final dLat = lat1 - lat2;
    final dLng = (lng1 - lng2) * math.cos(lat1 * math.pi / 180);
    return dLat * dLat + dLng * dLng;
  }

  void _selectResult(SearchResult result) {
    ref.read(searchServiceProvider).addToHistory(result, result.title);
    ref.read(selectedDestinationProvider.notifier).state = SelectedDestination(
      LatLng(result.lat, result.lng),
      label: result.title,
    );
    context.go('/');
  }

  void _selectRecent(RecentSearchEntry entry) => _selectResult(entry.toSearchResult());

  void _runQuickSearch(String label) {
    _searchController.text = label;
    _focusNode.requestFocus();
    _performSearch(label);
  }

  void _showVoiceComingSoon() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('جستجوی صوتی به‌زودی اضافه می‌شود')),
    );
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<RoutingEngine>(routingEngineProvider, (previous, next) {
      final query = _searchController.text.trim();
      if (previous != next && query.length >= 2) {
        _performSearch(query);
      }
    });

    final hasQuery = _searchController.text.trim().isNotEmpty;

    return Scaffold(
      backgroundColor: AppColors.background(context),
      appBar: PageHeader(
        title: 'جستجو',
        actions: [
          _HeaderIconButton(
            icon: Icons.mic_none_rounded,
            onTap: _showVoiceComingSoon,
          ),
        ],
      ),
      body: SafeArea(
        top: false,
        bottom: false,
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: _SearchInputBar(
                  controller: _searchController,
                  focusNode: _focusNode,
                  loading: _isLoading,
                  onChanged: _onSearchChanged,
                  onClear: () {
                    _searchController.clear();
                    _onSearchChanged('');
                  },
                  onVoiceTap: _showVoiceComingSoon,
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: _QuickFilterRow(
                  onMap: () => context.go('/'),
                  onFavorites: () => context.go('/saved-places'),
                  onWork: () => _runQuickSearch('محل کار'),
                  onHome: () => _runQuickSearch('خانه'),
                ),
              ),
            ),
            if (hasQuery)
              _results.isEmpty && _isLoading
                  ? const SliverFillRemaining(
                      hasScrollBody: false,
                      child: Center(child: CircularProgressIndicator()),
                    )
                  : _results.isEmpty
                      ? SliverFillRemaining(
                          hasScrollBody: false,
                          child: _EmptyResults(message: _statusMessage),
                        )
                      : SliverPadding(
                          padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                          sliver: SliverList.separated(
                            itemCount: _results.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 8),
                            itemBuilder: (context, index) => _ResultTile(
                              result: _results[index],
                              onTap: () => _selectResult(_results[index]),
                            ),
                          ),
                        )
            else ...[
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                  child: _QuickAccessGrid(onTap: _runQuickSearch),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                  child: _CategoriesRow(onTap: _runQuickSearch),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                  child: _RecentSearchesSection(onSelect: _selectRecent),
                ),
              ),
            ],
          ],
        ),
      ),
      bottomNavigationBar: const BottomNav(currentPage: NavKey.search),
    );
  }
}

/// دکمهٔ دایره‌ای هدر — همان ظاهرِ دکمه‌های [PageHeader] (بازگشت/رفرش) اما
/// برای اکشن‌های اضافی صفحه (اینجا: میکروفن).
class _HeaderIconButton extends StatelessWidget {
  const _HeaderIconButton({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.primaryAccent(context);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.glassPanelSoft(context),
            border: Border.all(color: AppColors.glassBorder(context)),
          ),
          child: Icon(icon, color: accent, size: 22),
        ),
      ),
    );
  }
}

class _SearchInputBar extends StatelessWidget {
  const _SearchInputBar({
    required this.controller,
    required this.focusNode,
    required this.loading,
    required this.onChanged,
    required this.onClear,
    required this.onVoiceTap,
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final bool loading;
  final ValueChanged<String> onChanged;
  final VoidCallback onClear;
  final VoidCallback onVoiceTap;

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.primaryAccent(context);
    return Container(
      height: 58,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: AppColors.glassPanelSoft(context),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.glassBorder(context)),
      ),
      child: Row(
        children: [
          Icon(Icons.search_rounded, color: accent, size: 24),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: controller,
              focusNode: focusNode,
              onChanged: onChanged,
              textAlign: TextAlign.right,
              style: TextStyle(color: AppColors.textPrimary(context), fontSize: 15),
              decoration: InputDecoration(
                isCollapsed: true,
                hintText: 'جستجو کنید (مکان، آدرس، نام خیابان، کسب‌وکار...)',
                hintStyle: TextStyle(color: AppColors.textMuted(context), fontSize: 13),
                border: InputBorder.none,
              ),
            ),
          ),
          if (loading)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 8),
              child: SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            )
          else if (controller.text.isNotEmpty)
            IconButton(
              onPressed: onClear,
              icon: const Icon(Icons.close_rounded),
              color: AppColors.textMuted(context),
              visualDensity: VisualDensity.compact,
            ),
          Container(
            width: 1,
            height: 26,
            margin: const EdgeInsets.symmetric(horizontal: 4),
            color: AppColors.glassBorder(context),
          ),
          IconButton(
            onPressed: onVoiceTap,
            icon: const Icon(Icons.mic_none_rounded),
            color: accent,
            visualDensity: VisualDensity.compact,
          ),
        ],
      ),
    );
  }
}

class _QuickFilterRow extends StatelessWidget {
  const _QuickFilterRow({
    required this.onMap,
    required this.onFavorites,
    required this.onWork,
    required this.onHome,
  });

  final VoidCallback onMap;
  final VoidCallback onFavorites;
  final VoidCallback onWork;
  final VoidCallback onHome;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        reverse: true,
        children: [
          _QuickFilterChip(label: 'نقشه', icon: Icons.map_outlined, onTap: onMap),
          const SizedBox(width: 8),
          _QuickFilterChip(
            label: 'علاقه‌مندی‌ها',
            icon: Icons.favorite_border_rounded,
            onTap: onFavorites,
          ),
          const SizedBox(width: 8),
          _QuickFilterChip(
            label: 'محل کار',
            icon: Icons.work_outline_rounded,
            onTap: onWork,
          ),
          const SizedBox(width: 8),
          _QuickFilterChip(label: 'خانه', icon: Icons.home_outlined, onTap: onHome),
        ],
      ),
    );
  }
}

class _QuickFilterChip extends StatelessWidget {
  const _QuickFilterChip({required this.label, required this.icon, required this.onTap});
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: AppColors.glassPanelSoft(context),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.glassBorder(context)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(label,
                  style: TextStyle(
                      color: AppColors.textPrimary(context),
                      fontWeight: FontWeight.w600,
                      fontSize: 13)),
              const SizedBox(width: 8),
              Icon(icon, size: 18, color: AppColors.primaryAccent(context)),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickAccessItem {
  const _QuickAccessItem(this.icon, this.color, this.label);
  final IconData icon;
  final Color color;
  final String label;
}

class _QuickAccessGrid extends StatelessWidget {
  const _QuickAccessGrid({required this.onTap});
  final ValueChanged<String> onTap;

  static const _items = [
    _QuickAccessItem(Icons.local_gas_station_rounded, Color(0xFF8A5CF6), 'پمپ بنزین'),
    _QuickAccessItem(Icons.medical_services_rounded, Color(0xFFE0523F), 'بیمارستان'),
    _QuickAccessItem(Icons.restaurant_rounded, Color(0xFFE0973F), 'رستوران'),
    _QuickAccessItem(Icons.shopping_cart_rounded, Color(0xFF52C24C), 'سوپرمارکت'),
    _QuickAccessItem(Icons.local_cafe_rounded, Color(0xFFE0973F), 'کافه'),
    _QuickAccessItem(Icons.account_balance_rounded, Color(0xFF2F80ED), 'بانک'),
    _QuickAccessItem(Icons.mosque_rounded, Color(0xFF52C24C), 'مسجد'),
    _QuickAccessItem(Icons.local_parking_rounded, Color(0xFF8A3FD0), 'پارکینگ'),
    _QuickAccessItem(Icons.hotel_rounded, Color(0xFF2F6FE0), 'هتل'),
    _QuickAccessItem(Icons.local_pharmacy_rounded, Color(0xFF3FD0E0), 'داروخانه'),
    _QuickAccessItem(Icons.school_rounded, Color(0xFFE0D23F), 'مدرسه'),
    _QuickAccessItem(Icons.local_police_rounded, Color(0xFF2F80ED), 'پلیس'),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.glassPanelSoft(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.glassBorder(context)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(Icons.bolt_rounded, color: AppColors.primaryAccent(context), size: 20),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'دسترسی سریع',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                      color: AppColors.textPrimary(context),
                      fontWeight: FontWeight.w800,
                      fontSize: 15),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _items.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 0.86,
            ),
            itemBuilder: (context, index) {
              final item = _items[index];
              return _QuickAccessTile(item: item, onTap: () => onTap(item.label));
            },
          ),
        ],
      ),
    );
  }
}

class _QuickAccessTile extends StatelessWidget {
  const _QuickAccessTile({required this.item, required this.onTap});
  final _QuickAccessItem item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.surfaceMuted(context),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.glassBorder(context)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(item.icon, color: item.color, size: 26),
              const SizedBox(height: 6),
              Text(
                item.label,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: AppColors.textPrimary(context),
                    fontSize: 11.5,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CategoryItem {
  const _CategoryItem(this.icon, this.label);
  final IconData icon;
  final String label;
}

class _CategoriesRow extends StatelessWidget {
  const _CategoriesRow({required this.onTap});
  final ValueChanged<String> onTap;

  static const _categories = [
    _CategoryItem(Icons.park_rounded, 'تفریح و سرگرمی'),
    _CategoryItem(Icons.fitness_center_rounded, 'ورزش و سلامت'),
    _CategoryItem(Icons.account_balance_rounded, 'خدمات عمومی'),
    _CategoryItem(Icons.build_rounded, 'خدمات خودرو'),
    _CategoryItem(Icons.storefront_rounded, 'مراکز خرید'),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.glassPanelSoft(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.glassBorder(context)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(Icons.grid_view_rounded, color: AppColors.primaryAccent(context), size: 18),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'دسته‌بندی‌ها',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                      color: AppColors.textPrimary(context),
                      fontWeight: FontWeight.w800,
                      fontSize: 15),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 78,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              reverse: true,
              itemCount: _categories.length + 1,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (context, index) {
                if (index == _categories.length) {
                  return _CategoryMoreButton(
                    onTap: () => context.go('/saved-places'),
                  );
                }
                final item = _categories[index];
                return _CategoryBubble(item: item, onTap: () => onTap(item.label));
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _CategoryBubble extends StatelessWidget {
  const _CategoryBubble({required this.item, required this.onTap});
  final _CategoryItem item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 68,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Column(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: AppColors.surfaceMuted(context),
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.glassBorder(context)),
                ),
                child: Icon(item.icon, color: AppColors.primaryAccent(context), size: 22),
              ),
              const SizedBox(height: 6),
              Text(
                item.label,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: AppColors.textSecondary(context), fontSize: 10.5),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CategoryMoreButton extends StatelessWidget {
  const _CategoryMoreButton({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 68,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Column(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: AppColors.surfaceMuted(context),
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.primaryAccent(context)),
                ),
                child: Icon(Icons.chevron_left_rounded,
                    color: AppColors.primaryAccent(context), size: 22),
              ),
              const SizedBox(height: 6),
              Text(
                'بیشتر',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.textSecondary(context), fontSize: 10.5),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RecentSearchesSection extends ConsumerWidget {
  const _RecentSearchesSection({required this.onSelect});
  final ValueChanged<RecentSearchEntry> onSelect;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final recent = ref.watch(recentSearchesProvider);
    return recent.when(
      loading: () => const SizedBox.shrink(),
      error: (_, __) => const SizedBox.shrink(),
      data: (items) {
        if (items.isEmpty) return const SizedBox.shrink();
        return Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.glassPanelSoft(context),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.glassBorder(context)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  TextButton(
                    onPressed: () async {
                      await ref.read(searchServiceProvider).clearHistory();
                      ref.invalidate(recentSearchesProvider);
                    },
                    style: TextButton.styleFrom(
                      foregroundColor: AppColors.primaryAccent(context),
                      padding: EdgeInsets.zero,
                      minimumSize: const Size(0, 0),
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                    child: const Text('پاک کردن'),
                  ),
                  const Spacer(),
                  Text(
                    'جستجوهای اخیر',
                    style: TextStyle(
                        color: AppColors.textPrimary(context),
                        fontWeight: FontWeight.w800,
                        fontSize: 15),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              for (var i = 0; i < items.length; i++) ...[
                if (i > 0) Divider(height: 1, color: AppColors.glassBorder(context)),
                _RecentSearchTile(
                  entry: items[i],
                  onTap: () => onSelect(items[i]),
                  onDelete: () async {
                    await ref.read(searchServiceProvider).deleteHistoryItem(items[i].id);
                    ref.invalidate(recentSearchesProvider);
                  },
                ),
              ],
            ],
          ),
        );
      },
    );
  }
}

class _RecentSearchTile extends StatelessWidget {
  const _RecentSearchTile({
    required this.entry,
    required this.onTap,
    required this.onDelete,
  });

  final RecentSearchEntry entry;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(
          children: [
            IconButton(
              onPressed: onDelete,
              icon: const Icon(Icons.close_rounded),
              color: AppColors.textMuted(context),
              iconSize: 18,
              visualDensity: VisualDensity.compact,
            ),
            const Spacer(),
            Expanded(
              flex: 6,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    entry.title,
                    textAlign: TextAlign.right,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: AppColors.textPrimary(context),
                        fontWeight: FontWeight.w700,
                        fontSize: 14),
                  ),
                  if (entry.subtitle.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(
                      entry.subtitle,
                      textAlign: TextAlign.right,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: AppColors.textMuted(context), fontSize: 12),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.primaryAccent(context)),
              ),
              child: Icon(Icons.history_rounded,
                  color: AppColors.primaryAccent(context), size: 18),
            ),
          ],
        ),
      ),
    );
  }
}

class _ResultTile extends StatelessWidget {
  const _ResultTile({required this.result, required this.onTap});
  final SearchResult result;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.glassPanelSoft(context),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.glassBorder(context)),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: result.poiColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(11),
                  border: Border.all(color: result.poiColor.withOpacity(0.55)),
                ),
                child: Icon(result.poiIcon, color: result.poiColor, size: 22),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      result.title,
                      textAlign: TextAlign.right,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: AppColors.textPrimary(context),
                          fontWeight: FontWeight.w700,
                          fontSize: 14),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      result.subtitle,
                      textAlign: TextAlign.right,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: AppColors.textMuted(context), fontSize: 12),
                    ),
                  ],
                ),
              ),
              if (result.isOffline)
                Icon(Icons.offline_pin_rounded,
                    color: AppColors.textMuted(context), size: 18),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyResults extends StatelessWidget {
  const _EmptyResults({this.message});
  final String? message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.search_off_rounded, size: 40, color: AppColors.textMuted(context)),
            const SizedBox(height: 10),
            Text(
              message ?? 'نتیجه‌ای پیدا نشد.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textMuted(context)),
            ),
          ],
        ),
      ),
    );
  }
}
