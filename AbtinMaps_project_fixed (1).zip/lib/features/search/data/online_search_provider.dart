import 'dart:convert';

import 'package:http/http.dart' as http;

import 'search_service.dart';

/// جست‌وجوی سبک برخط بر پایهٔ Nominatim/OpenStreetMap.
/// درخواست فقط پس از واردکردن حداقل دو نویسه ارسال می‌شود و نتیجه در حافظه نگه‌داری نمی‌شود.
class OnlineSearchProvider {
  OnlineSearchProvider({http.Client? client, this.endpoint = defaultEndpoint})
      : _client = client ?? http.Client(),
        _ownsClient = client == null;

  static const defaultEndpoint = 'https://nominatim.openstreetmap.org/search';

  final http.Client _client;
  final bool _ownsClient;
  final String endpoint;

  Future<List<SearchResult>> search(String query, {int limit = 20}) async {
    final normalized = query.trim();
    if (normalized.length < 2) return const [];

    final uri = Uri.parse(endpoint).replace(queryParameters: {
      'q': normalized,
      'format': 'jsonv2',
      'limit': '$limit',
      'addressdetails': '1',
      'accept-language': 'fa,en',
    });

    final response = await _client.get(uri, headers: const {
      'User-Agent': 'AbtinMaps/0.1 (online-search)',
      'Accept': 'application/json',
    }).timeout(const Duration(seconds: 10));

    if (response.statusCode != 200) {
      throw http.ClientException(
        'جست‌وجوی آنلاین پاسخ معتبر نداد (${response.statusCode})',
        uri,
      );
    }

    final decoded = jsonDecode(response.body);
    if (decoded is! List) return const [];

    return decoded
        .whereType<Map>()
        .map((item) {
          final lat = double.tryParse('${item['lat'] ?? ''}');
          final lng = double.tryParse('${item['lon'] ?? ''}');
          if (lat == null || lng == null) return null;
          final displayName = '${item['display_name'] ?? normalized}'.trim();
          final type = '${item['type'] ?? 'مکان'}'.trim();
          return SearchResult(
            title: displayName.split(',').first.trim(),
            subtitle: '$type · $displayName',
            lat: lat,
            lng: lng,
            isOffline: false,
          );
        })
        .whereType<SearchResult>()
        .toList(growable: false);
  }

  void dispose() {
    if (_ownsClient) _client.close();
  }
}

final onlineSearchProvider = OnlineSearchProvider();
