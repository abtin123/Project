import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../../../abtinmap/abm_file.dart';
import '../../../abtinmap/abm_map_service.dart';
import '../../../abtinmap/abm_models.dart';

/// یک رکورد نام‌دار (نام خیابان یا POI) که از داخل فایل‌های آفلاین .abm
/// استخراج شده — منبع واقعیِ جست‌وجوی آفلاین.
class AbmSearchEntry {
  const AbmSearchEntry({
    required this.name,
    required this.lat,
    required this.lng,
    required this.klass,
    required this.isPoi,
  });

  final String name;
  final double lat;
  final double lng;
  final int klass;
  final bool isPoi;

  Map<String, dynamic> toJson() => {
        'n': name,
        'la': lat,
        'lo': lng,
        'k': klass,
        'p': isPoi ? 1 : 0,
      };

  factory AbmSearchEntry.fromJson(Map<String, dynamic> j) => AbmSearchEntry(
        name: j['n'] as String,
        lat: (j['la'] as num).toDouble(),
        lng: (j['lo'] as num).toDouble(),
        klass: j['k'] as int,
        isPoi: j['p'] == 1,
      );
}

/// ایندکسِ آفلاینِ نام خیابان‌ها/مکان‌ها — از روی همان فایل‌های .abm که برای
/// رندر و مسیریابی روی دستگاه نصب شده‌اند ساخته می‌شود (بدون نیاز به سرور
/// یا دیتابیس جدا). نتیجه‌ی ساخت روی دیسک کش می‌شود تا دفعات بعد فقط
/// خوانده شود، نه دوباره از فایل‌های چندگیگابایتی ساخته شود.
class AbmOfflineSearchIndex {
  AbmOfflineSearchIndex(this._mapService);

  final AbmMapService _mapService;

  final List<AbmSearchEntry> _entries = [];
  final Set<String> _indexedMaps = {};
  bool _building = false;
  Future<void>? _buildFuture;

  bool get isEmpty => _entries.isEmpty;
  int get length => _entries.length;

  Future<Directory> _indexDir() async {
    final base = await getApplicationSupportDirectory();
    final dir = Directory(p.join(base.path, 'abtinmap', 'search_index'));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  /// کلید کش، اندازه و زمان آخرین تغییر فایل منبع را دارد. نسخه قبلی فقط به
  /// اندازه متکی بود؛ یک نقشه‌ی جایگزین با اندازه یکسان می‌توانست ایندکس کهنه
  /// را نگه دارد و باعث نتایج نادرست شود.
  Future<File> _cacheFileFor(String mapName, FileStat sourceStat) async {
    final dir = await _indexDir();
    final modified = sourceStat.modified.millisecondsSinceEpoch;
    return File(
        p.join(dir.path, '$mapName.v3.${sourceStat.size}.$modified.json'));
  }

  /// مطمئن می‌شود همه‌ی نقشه‌های نصب‌شده در ایندکس (حافظه) هستند. اگر کشِ
  /// روی دیسک باشد فقط خوانده می‌شود (سریع)، وگرنه یک‌بار از فایل .abm
  /// ساخته و کش می‌شود (کند‌تر، فقط بار اول برای هر نقشه).
  Future<void> ensureBuilt({void Function(String status)? onProgress}) {
    // اگر چند صفحه/رویداد هم‌زمان درخواست ایندکس کنند، همه باید منتظر
    // همان Future بمانند؛ قبلاً درخواست دوم بلافاصله برمی‌گشت و سرچ آفلاین
    // قبل از آماده‌شدن ایندکس با نتیجهٔ خالی تمام می‌شد.
    final active = _buildFuture;
    if (active != null) return active;

    final future = _buildInternal(onProgress: onProgress);
    _buildFuture = future;
    return future.whenComplete(() {
      if (identical(_buildFuture, future)) {
        _buildFuture = null;
      }
    });
  }

  Future<void> _buildInternal(
      {void Function(String status)? onProgress}) async {
    if (_building) return;
    _building = true;
    try {
      final installed = await _mapService.installedMaps();
      for (final mapName in installed) {
        if (_indexedMaps.contains(mapName)) continue;
        final file = await _mapService.localFile(mapName);
        if (!await file.exists()) continue;
        final sourceStat = await file.stat();
        final cacheFile = await _cacheFileFor(mapName, sourceStat);

        if (await cacheFile.exists()) {
          onProgress?.call('بارگذاری ایندکس آفلاین…');
          final ok = await _loadFromCache(cacheFile);
          if (ok) {
            _indexedMaps.add(mapName);
            continue;
          }
        }

        onProgress?.call('ساخت ایندکس جست‌وجوی آفلاین…');
        final built = await _buildForMap(file);
        if (built != null) {
          _entries.addAll(built);
          await _saveToCache(cacheFile, built);
        }
        _indexedMaps.add(mapName);
      }
    } finally {
      _building = false;
    }
  }

  Future<bool> _loadFromCache(File cacheFile) async {
    try {
      final raw = await cacheFile.readAsString();
      final list = json.decode(raw) as List;
      for (final item in list) {
        _entries.add(AbmSearchEntry.fromJson(item as Map<String, dynamic>));
      }
      return true;
    } catch (_) {
      // کش خراب/ناسازگار — پاکش می‌کنیم تا دفعه‌ی بعد از نو ساخته شود.
      try {
        await cacheFile.delete();
      } catch (_) {}
      return false;
    }
  }

  Future<void> _saveToCache(
      File cacheFile, List<AbmSearchEntry> entries) async {
    try {
      final list = entries.map((e) => e.toJson()).toList();
      await cacheFile.writeAsString(json.encode(list));
    } catch (_) {
      // کش کردن اختیاری است؛ اگر شکست بخورد فقط دفعه‌ی بعد دوباره ساخته می‌شود.
    }
  }

  /// خواندنِ همه‌ی کاشی‌های زوم پایه (کامل‌ترین داده) و جمع‌آوریِ نام‌دارها.
  Future<List<AbmSearchEntry>?> _buildForMap(File file) async {
    AbmFile? abm;
    try {
      abm = await AbmFile.open(file);
      final out = <AbmSearchEntry>[];
      const lowBitsMask = 0xFFFFFFFFFFF; // 44 بیت پایین (x<<22 | y)
      const yMask = 0x3FFFFF; // 22 بیت پایین (y)

      for (var i = 0; i < abm.tileIds.length; i++) {
        final id = abm.tileIds[i];
        final z = id >> 44;
        if (z != abm.baseZoom)
          continue; // فقط زوم پایه، تا هر نام یک‌بار دیده شود
        final rem = id & lowBitsMask;
        final x = rem >> 22;
        final y = rem & yMask;

        final tile = await abm.tile(z, x, y);
        if (tile == null) continue;

        for (final poi in tile.pois) {
          // قبلاً POIهای بی‌نام (مثل اکثر پمپ‌بنزین‌ها در OSM ایران که فقط
          // amenity=fuel دارند و name ندارند) کلاً ایندکس نمی‌شدند؛ همین باعث
          // می‌شد سرچِ دسته‌بندی (پمپ بنزین/داروخانه/...) عملاً چیزی پیدا نکند.
          // این‌ها را با نامِ نمایشیِ فارسیِ دسته نگه می‌داریم تا هم با کلیک
          // روی نتیجه قابل مشاهده باشند هم زیرِ سرچِ دسته‌بندی بیایند.
          final rawName = poi.name.trim();
          final name = rawName.isNotEmpty ? rawName : _categoryLabel(poi.klass);
          if (name.isEmpty) continue;
          out.add(AbmSearchEntry(
            name: name,
            lat: poi.point.lat,
            lng: poi.point.lon,
            klass: poi.klass,
            isPoi: true,
          ));
        }
        for (final way in tile.ways) {
          final name = way.name.trim();
          if (name.isEmpty || way.refs.isEmpty) continue;
          final mid = tile.nodeAt(way.refs[way.refs.length ~/ 2]);
          out.add(AbmSearchEntry(
            name: name,
            lat: mid.lat,
            lng: mid.lon,
            klass: way.klass,
            isPoi: false,
          ));
        }

        // این حلقه روی نقشه‌ی کل یک کشور می‌تواند هزاران کاشی داشته باشد؛
        // هر چند صد کاشی یک نفس به UI می‌دهیم تا کاملاً فریز نکند.
        if (i % 200 == 0) {
          await Future<void>.delayed(Duration.zero);
        }
      }
      return out;
    } catch (_) {
      return null;
    } finally {
      await abm?.close();
    }
  }

  /// جست‌وجوی substring مستقل از بزرگی/کوچکیِ حروف و چند تفاوتِ رایجِ
  /// عربی/فارسی (ی/ي، ک/ك و ...)، به‌علاوه‌ی جست‌وجوی دسته‌ای: اگر عبارت با
  /// یکی از کلیدواژه‌های یک دسته (پمپ‌بنزین، داروخانه، بانک و...) یکی باشد
  /// یا با آن شروع شود، همه‌ی POIهای همان دسته هم برگردانده می‌شوند — نه فقط
  /// آن‌هایی که دقیقاً همین عبارت را در نامشان دارند. اگر [near] داده شود
  /// نتایج نزدیک‌تر به آن اول می‌آیند.
  List<AbmSearchEntry> search(
    String query, {
    int limit = 15,
    ({double lat, double lng})? near,
  }) {
    final q = _normalize(query);
    if (q.isEmpty) return const [];

    final matchedKlasses = _matchCategoryKlasses(q);
    final matches = <AbmSearchEntry>[];
    // یک راه/POI ممکن است در چند کاشی پایه ثبت شود. برابری شیء برای
    // AbmSearchEntry تعریف نشده، پس Set<AbmSearchEntry> تکراری‌ها را حذف
    // نمی‌کرد و کاربر چند نتیجه مشابه می‌دید.
    final seen = <String>{};
    // باگ واقعیِ «نزدیک‌ترین مکان درست پیدا نمی‌شود / همیشه از یک شعاع
    // ثابت (~۱۴ کیلومتر) میاد»: اسکن با سقفِ limit*6 (مثلاً ۶۰ تا با
    // limit=10) زود break می‌کرد. چون ترتیبِ _entries بر اساسِ کاشیِ
    // جغرافیایی است نه فاصله از GPS، آن ۶۰ تای اول معمولاً همه از یک
    // ناحیه/شعاعِ محدودِ اطرافِ اولین کاشی‌های ایندکس‌شده می‌آیند — نه
    // لزوماً نزدیک‌ترین‌ها به کاربر. نتیجه‌سازی/مرتب‌سازیِ نزدیک‌ترین روی
    // همین زیرمجموعه‌ی ناقص انجام می‌شد. وقتی near داده شده، باید کل
    // ایندکس اسکن شود تا واقعاً نزدیک‌ترین‌ها پیدا شوند؛ سقفِ زودهنگام فقط
    // وقتی near نداریم (که ترتیب مهم نیست) معنا دارد.
    final earlyBreakAllowed = near == null;
    for (final e in _entries) {
      final isNameMatch = _normalize(e.name).contains(q);
      final isCategoryMatch = matchedKlasses.contains(e.klass);
      if (isNameMatch || isCategoryMatch) {
        final key =
            '${_normalize(e.name)}:${e.lat.toStringAsFixed(6)}:${e.lng.toStringAsFixed(6)}:${e.klass}';
        if (seen.add(key)) matches.add(e);
        if (earlyBreakAllowed && matches.length >= limit * 6) break;
      }
    }
    // اگر کاربر عبارت چندبخشی وارد کند (مثل «تهران آزادی»)،
    // احتمالاً مقصدی در شهر دیگری را مشخص کرده است؛ در این حالت
    // جستجو را به GPS فعلی محدود نمی‌کنیم. جستجوی تک‌عبارتی همچنان
    // نزدیک‌ترین نتایج به کاربر را اول می‌آورد.
    final hasExplicitArea =
        q.length > 0 && query.trim().split(RegExp(r'\\s+')).length > 1;
    if (near != null && !hasExplicitArea) {
      matches.sort((a, b) => _sqDist(near, a).compareTo(_sqDist(near, b)));
    }
    return matches.take(limit).toList();
  }

  /// کلیدواژه‌های فارسیِ هر دسته → کد klass. عبارتِ سرچ اگر با یکی از
  /// این‌ها برابر باشد یا با آن شروع شود (پیشوندی)، دسته‌ی متناظر فعال می‌شود
  /// («پمپ بنزین»، «بنزین» و «پمپ‌بنزین» همه باید یک نتیجه بدهند).
  static final Map<int, List<String>> _categoryKeywords = {
    AbmKlass.poiFuel: [
      'پمپ بنزین',
      'پمپ‌بنزین',
      'بنزین',
      'جایگاه سوخت',
      'پمپ گاز',
      'سوخت'
    ],
    AbmKlass.poiParking: ['پارکینگ'],
    AbmKlass.poiHospital: ['بیمارستان', 'درمانگاه'],
    AbmKlass.poiPharmacy: ['داروخانه'],
    AbmKlass.poiPolice: ['کلانتری', 'پلیس'],
    AbmKlass.poiSchool: ['مدرسه'],
    AbmKlass.poiRestaurant: ['رستوران'],
    AbmKlass.poiCafe: ['کافه', 'کافی شاپ'],
    AbmKlass.poiBank: ['بانک', 'عابربانک', 'خودپرداز'],
    AbmKlass.poiHotel: ['هتل'],
    AbmKlass.poiSupermarket: ['سوپرمارکت', 'فروشگاه'],
    AbmKlass.poiMosque: ['مسجد'],
    AbmKlass.poiToilets: ['سرویس بهداشتی', 'دستشویی'],
    AbmKlass.poiBusStation: ['ایستگاه اتوبوس', 'ترمینال'],
    AbmKlass.poiAirport: ['فرودگاه'],
    AbmKlass.poiPark: ['پارک'],
  }.map((k, v) => MapEntry(k, v.map(_normalize).toList()));

  static String _categoryLabel(int klass) => _displayLabels[klass] ?? '';

  static const Map<int, String> _displayLabels = {
    AbmKlass.poiFuel: 'پمپ بنزین',
    AbmKlass.poiParking: 'پارکینگ',
    AbmKlass.poiHospital: 'بیمارستان',
    AbmKlass.poiPharmacy: 'داروخانه',
    AbmKlass.poiPolice: 'کلانتری',
    AbmKlass.poiSchool: 'مدرسه',
    AbmKlass.poiRestaurant: 'رستوران',
    AbmKlass.poiCafe: 'کافه',
    AbmKlass.poiBank: 'بانک',
    AbmKlass.poiHotel: 'هتل',
    AbmKlass.poiSupermarket: 'فروشگاه',
    AbmKlass.poiMosque: 'مسجد',
    AbmKlass.poiToilets: 'سرویس بهداشتی',
    AbmKlass.poiBusStation: 'ایستگاه اتوبوس',
    AbmKlass.poiAirport: 'فرودگاه',
    AbmKlass.poiPark: 'پارک',
  };

  /// کدهای klass ای که عبارتِ نرمال‌شده‌ی [q] به‌عنوان یک جست‌وجوی دسته‌ای
  /// با آن‌ها مطابقت دارد.
  static Set<int> _matchCategoryKlasses(String q) {
    final out = <int>{};
    for (final entry in _categoryKeywords.entries) {
      for (final kw in entry.value) {
        if (kw.isEmpty) continue;
        if (q == kw || q.startsWith(kw) || kw.startsWith(q)) {
          out.add(entry.key);
          break;
        }
      }
    }
    return out;
  }

  double _sqDist(({double lat, double lng}) from, AbmSearchEntry e) {
    final dLat = from.lat - e.lat;
    final dLng = from.lng - e.lng;
    return dLat * dLat + dLng * dLng;
  }

  static String _normalize(String s) {
    var out = s.trim().toLowerCase();
    out = out
        .replaceAll('ي', 'ی')
        .replaceAll('ى', 'ی')
        .replaceAll('ك', 'ک')
        .replaceAll('ة', 'ه')
        .replaceAll('ۀ', 'ه')
        .replaceAll('ؤ', 'و')
        .replaceAll('ئ', 'ی')
        .replaceAll('أ', 'ا')
        .replaceAll('إ', 'ا')
        .replaceAll('آ', 'ا')
        .replaceAll('ـ', '')
        .replaceAll('‌', '') // نیم‌فاصله
        .replaceAll(' ', '');

    // اعداد فارسی/عربی را به ASCII تبدیل می‌کنیم تا «میدان ۲» و «میدان 2»
    // یک جست‌وجو محسوب شوند.
    const fa = '۰۱۲۳۴۵۶۷۸۹';
    const ar = '٠١٢٣٤٥٦٧٨٩';
    final b = StringBuffer();
    for (final ch in out.runes) {
      final c = String.fromCharCode(ch);
      final fi = fa.indexOf(c);
      if (fi >= 0) {
        b.write(fi);
        continue;
      }
      final ai = ar.indexOf(c);
      if (ai >= 0) {
        b.write(ai);
        continue;
      }
      b.write(c);
    }
    return b.toString();
  }
}
