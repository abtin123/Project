import 'package:flutter/material.dart';

import '../../../core/database/app_database.dart';

class SearchResult {
  const SearchResult({
    required this.title,
    required this.subtitle,
    required this.lat,
    required this.lng,
    required this.isOffline,
  });

  final String title;
  final String subtitle;
  final double lat;
  final double lng;
  final bool isOffline;

  bool samePlace(SearchResult other) =>
      (lat - other.lat).abs() < 0.00001 && (lng - other.lng).abs() < 0.00001;

  String get _searchText => '$title $subtitle'
      .toLowerCase()
      .replaceAll('ي', 'ی')
      .replaceAll('ك', 'ک');

  IconData get poiIcon {
    if (_searchText.contains('پمپ') ||
        _searchText.contains('بنزین') ||
        _searchText.contains('سوخت')) {
      return Icons.local_gas_station_rounded;
    }
    if (_searchText.contains('دارو')) return Icons.local_pharmacy_rounded;
    if (_searchText.contains('بیمار') || _searchText.contains('درمان')) {
      return Icons.local_hospital_rounded;
    }
    if (_searchText.contains('پارک')) return Icons.local_parking_rounded;
    if (_searchText.contains('اتوبوس') || _searchText.contains('پایانه')) {
      return Icons.directions_bus_rounded;
    }
    if (_searchText.contains('رستوران')) return Icons.restaurant_rounded;
    if (_searchText.contains('کافه')) return Icons.local_cafe_rounded;
    if (_searchText.contains('بانک')) return Icons.account_balance_rounded;
    if (_searchText.contains('هتل')) return Icons.hotel_rounded;
    return Icons.place_rounded;
  }

  Color get poiColor {
    if (poiIcon == Icons.local_gas_station_rounded) {
      return const Color(0xFFFF5A5F);
    }
    if (poiIcon == Icons.local_hospital_rounded ||
        poiIcon == Icons.local_pharmacy_rounded) {
      return const Color(0xFF44D9A6);
    }
    if (poiIcon == Icons.directions_bus_rounded) {
      return const Color(0xFF64B7FF);
    }
    if (poiIcon == Icons.restaurant_rounded ||
        poiIcon == Icons.local_cafe_rounded) {
      return const Color(0xFFFFB94C);
    }
    return const Color(0xFFAA9BFF);
  }
}

/// یک ردیفِ «جستجوهای اخیر» — برخلاف [SearchResult] که نتیجهٔ زندهٔ
/// جست‌وجو (آفلاین/آنلاین) است و ردیف پایگاه‌داده ندارد، این کلاس دقیقاً به
/// یک ردیف در جدول [SearchHistory] اشاره می‌کند تا بشود آن را جداگانه (با
/// دکمهٔ × کنار هر آیتم) حذف کرد.
class RecentSearchEntry {
  const RecentSearchEntry({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.lat,
    required this.lng,
  });

  final int id;
  final String title;
  final String subtitle;
  final double lat;
  final double lng;

  SearchResult toSearchResult() => SearchResult(
        title: title,
        subtitle: subtitle,
        lat: lat,
        lng: lng,
        isOffline: true,
      );
}

/// سرویس legacy جست‌وجو. lookup واقعی در [OfflineSearchIndex] انجام می‌شود؛
/// این کلاس فقط سابقهٔ محلی را نگه می‌دارد و هیچ مسیر شبکه‌ای ندارد.
class SearchService {
  SearchService(this.database);

  final AppDatabase database;

  Future<List<SearchResult>> searchPlaces(String query) async => const [];

  Future<List<RecentSearchEntry>> getRecentSearches({int limit = 10}) async {
    try {
      final searches = await database.getRecentSearches(limit: limit);
      return searches
          .map((s) => RecentSearchEntry(
                id: s.id,
                title: s.title,
                subtitle: s.subtitle ?? '',
                lat: s.latitude,
                lng: s.longitude,
              ))
          .toList();
    } catch (_) {
      return const [];
    }
  }

  Future<void> addToHistory(SearchResult result, String query) async {
    await database.addSearchToHistory(
      query: query,
      title: result.title,
      subtitle: result.subtitle,
      latitude: result.lat,
      longitude: result.lng,
      isOffline: true,
    );
  }

  Future<void> deleteHistoryItem(int id) =>
      database.deleteSearchHistoryItem(id);

  Future<void> clearHistory() => database.clearSearchHistory();

  Future<List<SearchResult>> searchByCategory(String category) async =>
      const [];
}
