import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../shared/widgets/bottom_nav.dart';
import '../../../shared/widgets/glass_panel.dart';
import '../../../shared/widgets/page_header.dart' show PageHeader;

enum RouteLineStyle { solid, dotted, dashed, double_, variable }

enum RoutePlanType { economic, fastest, optimal }

class RoutingSettingsState {
  const RoutingSettingsState({
    this.colorIndex = 0,
    this.lineStyle = RouteLineStyle.solid,
    this.thickness = 6,
    this.planType = RoutePlanType.fastest,
    this.avoidTraffic = true,
    this.avoidTolls = true,
    this.avoidHighways = false,
    this.multiDestination = false,
    this.showSummary = true,
    this.speedWarning = true,
    this.avoidSpecialAreas = false,
  });

  final int colorIndex;
  final RouteLineStyle lineStyle;
  final double thickness;
  final RoutePlanType planType;
  final bool avoidTraffic;
  final bool avoidTolls;
  final bool avoidHighways;
  final bool multiDestination;
  final bool showSummary;
  final bool speedWarning;
  final bool avoidSpecialAreas;

  RoutingSettingsState copyWith({
    int? colorIndex,
    RouteLineStyle? lineStyle,
    double? thickness,
    RoutePlanType? planType,
    bool? avoidTraffic,
    bool? avoidTolls,
    bool? avoidHighways,
    bool? multiDestination,
    bool? showSummary,
    bool? speedWarning,
    bool? avoidSpecialAreas,
  }) {
    return RoutingSettingsState(
      colorIndex: colorIndex ?? this.colorIndex,
      lineStyle: lineStyle ?? this.lineStyle,
      thickness: thickness ?? this.thickness,
      planType: planType ?? this.planType,
      avoidTraffic: avoidTraffic ?? this.avoidTraffic,
      avoidTolls: avoidTolls ?? this.avoidTolls,
      avoidHighways: avoidHighways ?? this.avoidHighways,
      multiDestination: multiDestination ?? this.multiDestination,
      showSummary: showSummary ?? this.showSummary,
      speedWarning: speedWarning ?? this.speedWarning,
      avoidSpecialAreas: avoidSpecialAreas ?? this.avoidSpecialAreas,
    );
  }
}

class RoutingSettingsNotifier extends StateNotifier<RoutingSettingsState> {
  RoutingSettingsNotifier() : super(const RoutingSettingsState());

  void update(RoutingSettingsState Function(RoutingSettingsState) fn) =>
      state = fn(state);
}

final routingSettingsProvider = StateNotifierProvider.autoDispose<
    RoutingSettingsNotifier, RoutingSettingsState>(
  (ref) => RoutingSettingsNotifier(),
);

const List<Color> kRouteSwatchColors = [
  Color(0xFF8A3FD0),
  Color(0xFF2F6FD6),
  Color(0xFF3FD0E0),
  Color(0xFF3FA64C),
  Color(0xFFFF8A2B),
  Color(0xFFE5544B),
  Color(0xFFE0459A),
];

class RoutingSettingsScreen extends ConsumerWidget {
  const RoutingSettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notifier = ref.read(routingSettingsProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.background(context),
      appBar: PageHeader(
        title: 'تنظیمات مسیر یابی',
        backRoute: '/settings',
        onRefresh: () => notifier.update((_) => const RoutingSettingsState()),
      ),
      body: SafeArea(
        top: false,
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
          children: const [
            _RouteColorCard(),
            SizedBox(height: 16),
            _LineTypeCard(),
            SizedBox(height: 16),
            _ThicknessCard(),
            SizedBox(height: 16),
            _RouteTypeCard(),
            SizedBox(height: 16),
            _RouteTogglesCard(),
          ],
        ),
      ),
      bottomNavigationBar: const BottomNav(currentPage: NavKey.settings),
    );
  }
}

// ── عناصر مشترک این صفحه ────────────────────────────────────────────────

class _BadgeIcon extends StatelessWidget {
  const _BadgeIcon({required this.icon, required this.color, this.size = 40});

  final IconData icon;
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color.withOpacity(0.16),
        border: Border.all(color: color.withOpacity(0.45)),
      ),
      child: Icon(icon, color: color, size: size * 0.5),
    );
  }
}

class _CardHeaderRow extends StatelessWidget {
  const _CardHeaderRow({
    required this.title,
    required this.subtitle,
    this.icon,
    this.iconColor,
  });

  final String title;
  final String subtitle;
  final IconData? icon;
  final Color? iconColor;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: AppColors.textPrimary(context),
                      fontWeight: FontWeight.w800,
                    ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: TextStyle(color: AppColors.textMuted(context)),
              ),
            ],
          ),
        ),
        if (icon != null) _BadgeIcon(icon: icon!, color: iconColor!, size: 40),
      ],
    );
  }
}

// ── کارت رنگ مسیر ───────────────────────────────────────────────────────

class _RouteColorCard extends ConsumerWidget {
  const _RouteColorCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(routingSettingsProvider);
    final notifier = ref.read(routingSettingsProvider.notifier);
    const accent = Color(0xFF8A3FD0);

    return GlassPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _CardHeaderRow(
            title: 'رنگ مسیر',
            subtitle: 'رنگ مورد نظر برای نمایش مسیر را انتخاب کنید',
            icon: Icons.palette_rounded,
            iconColor: accent,
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              for (var i = 0; i < kRouteSwatchColors.length; i++)
                _ColorSwatch(
                  color: kRouteSwatchColors[i],
                  selected: state.colorIndex == i,
                  onTap: () => notifier.update((s) => s.copyWith(colorIndex: i)),
                ),
              _RainbowSwatch(
                selected: state.colorIndex == -1,
                onTap: () => notifier.update((s) => s.copyWith(colorIndex: -1)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ColorSwatch extends StatelessWidget {
  const _ColorSwatch({
    required this.color,
    required this.selected,
    required this.onTap,
  });

  final Color color;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      customBorder: const CircleBorder(),
      child: Container(
        width: 44,
        height: 44,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: selected ? Border.all(color: color, width: 2.4) : null,
        ),
        child: Container(
          width: selected ? 32 : 36,
          height: selected ? 32 : 36,
          decoration: BoxDecoration(shape: BoxShape.circle, color: color),
          child: selected
              ? const Icon(Icons.check_rounded, color: Colors.white, size: 18)
              : null,
        ),
      ),
    );
  }
}

class _RainbowSwatch extends StatelessWidget {
  const _RainbowSwatch({required this.selected, required this.onTap});

  final bool selected;
  final VoidCallback onTap;

  static const _gradient = SweepGradient(colors: [
    Color(0xFFFF4D4D),
    Color(0xFFFFC24D),
    Color(0xFF4DFF88),
    Color(0xFF4DD9FF),
    Color(0xFF7C4DFF),
    Color(0xFFFF4D4D),
  ]);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      customBorder: const CircleBorder(),
      child: Container(
        width: 44,
        height: 44,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: selected
              ? Border.all(color: AppColors.textPrimary(context), width: 2.4)
              : null,
        ),
        child: Container(
          width: selected ? 32 : 36,
          height: selected ? 32 : 36,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            gradient: _gradient,
          ),
          child: selected
              ? const Icon(Icons.check_rounded, color: Colors.white, size: 18)
              : null,
        ),
      ),
    );
  }
}

// ── کارت نوع خط مسیر ────────────────────────────────────────────────────

class _LineTypeCard extends ConsumerWidget {
  const _LineTypeCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(routingSettingsProvider);
    final notifier = ref.read(routingSettingsProvider.notifier);
    const accent = Color(0xFF8A3FD0);

    final options = <(RouteLineStyle, String)>[
      (RouteLineStyle.solid, 'خط صاف'),
      (RouteLineStyle.dotted, 'خط نقطه چین'),
      (RouteLineStyle.dashed, 'خط تیره'),
      (RouteLineStyle.double_, 'خط دوگانه'),
      (RouteLineStyle.variable, 'خط متغیر'),
    ];

    return GlassPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _CardHeaderRow(
            title: 'نوع خط مسیر',
            subtitle: 'نوع خط مورد استفاده برای نمایش مسیر',
            icon: Icons.route_rounded,
            iconColor: accent,
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              for (final option in options) ...[
                Expanded(
                  child: _LineTypeBox(
                    style: option.$1,
                    label: option.$2,
                    color: accent,
                    selected: state.lineStyle == option.$1,
                    onTap: () =>
                        notifier.update((s) => s.copyWith(lineStyle: option.$1)),
                  ),
                ),
                if (option != options.last) const SizedBox(width: 8),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

class _LineTypeBox extends StatelessWidget {
  const _LineTypeBox({
    required this.style,
    required this.label,
    required this.color,
    required this.selected,
    required this.onTap,
  });

  final RouteLineStyle style;
  final String label;
  final Color color;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? color : AppColors.glassBorder(context),
            width: selected ? 1.6 : 1,
          ),
          color: selected
              ? color.withOpacity(0.10)
              : AppColors.glassPanelSoft(context),
        ),
        child: Column(
          children: [
            SizedBox(
              width: 40,
              height: 14,
              child: CustomPaint(
                painter: _LinePreviewPainter(
                  style: style,
                  color: selected ? color : AppColors.textMuted(context),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.textPrimary(context),
                fontWeight: FontWeight.w600,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LinePreviewPainter extends CustomPainter {
  _LinePreviewPainter({required this.style, required this.color});

  final RouteLineStyle style;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round;
    final midY = size.height / 2;

    switch (style) {
      case RouteLineStyle.solid:
        canvas.drawLine(Offset(0, midY), Offset(size.width, midY), paint);
        break;
      case RouteLineStyle.dotted:
        _drawDashed(canvas, paint, midY, size.width, dash: 2, gap: 4);
        break;
      case RouteLineStyle.dashed:
        _drawDashed(canvas, paint, midY, size.width, dash: 7, gap: 4);
        break;
      case RouteLineStyle.double_:
        canvas.drawLine(
            Offset(0, midY - 2.5), Offset(size.width, midY - 2.5), paint);
        canvas.drawLine(
            Offset(0, midY + 2.5), Offset(size.width, midY + 2.5), paint);
        break;
      case RouteLineStyle.variable:
        final path = Path()..moveTo(0, midY);
        const steps = 24;
        for (var i = 1; i <= steps; i++) {
          final x = size.width * i / steps;
          final y = midY + (i.isEven ? -3.5 : 3.5);
          path.lineTo(x, y);
        }
        canvas.drawPath(path, paint..strokeJoin = StrokeJoin.round);
        break;
    }
  }

  void _drawDashed(Canvas canvas, Paint paint, double y, double width,
      {required double dash, required double gap}) {
    var x = 0.0;
    while (x < width) {
      final end = (x + dash).clamp(0, width);
      canvas.drawLine(Offset(x, y), Offset(end.toDouble(), y), paint);
      x += dash + gap;
    }
  }

  @override
  bool shouldRepaint(covariant _LinePreviewPainter oldDelegate) =>
      oldDelegate.style != style || oldDelegate.color != color;
}

// ── کارت ضخامت مسیر ─────────────────────────────────────────────────────

class _ThicknessCard extends ConsumerWidget {
  const _ThicknessCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(routingSettingsProvider);
    final notifier = ref.read(routingSettingsProvider.notifier);
    const accent = Color(0xFF8A3FD0);
    const min = 2.0;
    const max = 14.0;

    return GlassPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _CardHeaderRow(
            title: 'ضخامت مسیر',
            subtitle: 'ضخامت خط مسیر روی نقشه',
            icon: Icons.tune_rounded,
            iconColor: accent,
          ),
          const SizedBox(height: 22),
          _BubbleSlider(
            value: state.thickness,
            min: min,
            max: max,
            color: accent,
            label: '${state.thickness.round()} پیکسل',
            onChanged: (v) => notifier.update((s) => s.copyWith(thickness: v)),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('نازک', style: TextStyle(color: AppColors.textMuted(context))),
              Text('ضخیم', style: TextStyle(color: AppColors.textMuted(context))),
            ],
          ),
        ],
      ),
    );
  }
}

class _BubbleSlider extends StatelessWidget {
  const _BubbleSlider({
    required this.value,
    required this.min,
    required this.max,
    required this.color,
    required this.label,
    required this.onChanged,
  });

  final double value;
  final double min;
  final double max;
  final Color color;
  final String label;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    final fraction = ((value - min) / (max - min)).clamp(0.0, 1.0);

    return LayoutBuilder(
      builder: (context, constraints) {
        const bubbleWidth = 64.0;
        final trackWidth = constraints.maxWidth;
        final bubbleLeft =
            (trackWidth * fraction - bubbleWidth / 2).clamp(0.0, trackWidth - bubbleWidth);

        return Stack(
          clipBehavior: Clip.none,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 30),
              child: SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  trackHeight: 5,
                  activeTrackColor: color,
                  inactiveTrackColor: AppColors.glassBorder(context),
                  thumbColor: Colors.white,
                  overlayColor: color.withOpacity(0.18),
                  thumbShape:
                      const RoundSliderThumbShape(enabledThumbRadius: 9),
                ),
                child: Slider(
                  value: value.clamp(min, max),
                  min: min,
                  max: max,
                  onChanged: onChanged,
                ),
              ),
            ),
            Positioned(
              top: 0,
              left: bubbleLeft,
              child: Container(
                width: bubbleWidth,
                padding:
                    const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

// ── کارت انتخاب نوع مسیر ────────────────────────────────────────────────

class _RouteTypeCard extends ConsumerWidget {
  const _RouteTypeCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(routingSettingsProvider);
    final notifier = ref.read(routingSettingsProvider.notifier);
    const accent = Color(0xFF8A3FD0);

    return GlassPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _CardHeaderRow(
            title: 'انتخاب نوع مسیر',
            subtitle: 'نوع مسیر مورد نظر را انتخاب کنید',
            icon: Icons.track_changes_rounded,
            iconColor: accent,
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                child: _RouteTypeBox(
                  icon: Icons.eco_rounded,
                  iconColor: const Color(0xFF3FA64C),
                  title: 'اقتصادی ترین',
                  desc: 'کمترین مصرف سوخت\nو هزینه',
                  selected: state.planType == RoutePlanType.economic,
                  onTap: () => notifier
                      .update((s) => s.copyWith(planType: RoutePlanType.economic)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _RouteTypeBox(
                  icon: Icons.speed_rounded,
                  iconColor: accent,
                  title: 'سریع ترین',
                  desc: 'کمترین زمان\nرسیدن',
                  selected: state.planType == RoutePlanType.fastest,
                  onTap: () => notifier
                      .update((s) => s.copyWith(planType: RoutePlanType.fastest)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _RouteTypeBox(
                  icon: Icons.balance_rounded,
                  iconColor: const Color(0xFF2F6FD6),
                  title: 'بهینه ترین',
                  desc: 'ترکیب بهینه زمان\nو هزینه',
                  selected: state.planType == RoutePlanType.optimal,
                  onTap: () => notifier
                      .update((s) => s.copyWith(planType: RoutePlanType.optimal)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _RouteTypeBox extends StatelessWidget {
  const _RouteTypeBox({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.desc,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final Color iconColor;
  final String title;
  final String desc;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? iconColor : AppColors.glassBorder(context),
            width: selected ? 1.6 : 1,
          ),
          color: selected
              ? iconColor.withOpacity(0.08)
              : AppColors.glassPanelSoft(context),
        ),
        child: Column(
          children: [
            Icon(icon, color: iconColor, size: 26),
            const SizedBox(height: 10),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.textPrimary(context),
                fontWeight: FontWeight.w800,
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              desc,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.textMuted(context),
                fontSize: 11,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 10),
            Container(
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: selected ? iconColor : Colors.transparent,
                border: Border.all(
                  color: selected ? iconColor : AppColors.glassBorder(context),
                  width: 1.4,
                ),
              ),
              child: selected
                  ? const Icon(Icons.check_rounded,
                      color: Colors.white, size: 14)
                  : null,
            ),
          ],
        ),
      ),
    );
  }
}

// ── کارت تنظیمات مسیر (سوییچ‌ها) ────────────────────────────────────────

class _RouteTogglesCard extends ConsumerWidget {
  const _RouteTogglesCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(routingSettingsProvider);
    final notifier = ref.read(routingSettingsProvider.notifier);

    final rows = <_ToggleRowSpec>[
      _ToggleRowSpec(
        icon: Icons.directions_car_filled_rounded,
        color: const Color(0xFF8A3FD0),
        label: 'پرهیز از ترافیک',
        desc: 'مسیرهایی با ترافیک کمتر را انتخاب کنید',
        value: state.avoidTraffic,
        onChanged: (v) => notifier.update((s) => s.copyWith(avoidTraffic: v)),
      ),
      _ToggleRowSpec(
        icon: Icons.toll_rounded,
        color: const Color(0xFF8A3FD0),
        label: 'پرهیز از عوارضی',
        desc: 'از مسیرهای دارای عوارضی جلوگیری شود',
        value: state.avoidTolls,
        onChanged: (v) => notifier.update((s) => s.copyWith(avoidTolls: v)),
      ),
      _ToggleRowSpec(
        icon: Icons.add_road_rounded,
        color: const Color(0xFF8A3FD0),
        label: 'پرهیز از بزرگراه‌ها',
        desc: 'از بزرگراه‌ها استفاده نشود',
        value: state.avoidHighways,
        onChanged: (v) => notifier.update((s) => s.copyWith(avoidHighways: v)),
      ),
      _ToggleRowSpec(
        icon: Icons.alt_route_rounded,
        color: const Color(0xFF8A3FD0),
        label: 'مسیرهای دارای چند مقصد',
        desc: 'امکان اضافه کردن چندین مقصد در مسیر',
        value: state.multiDestination,
        onChanged: (v) =>
            notifier.update((s) => s.copyWith(multiDestination: v)),
      ),
      _ToggleRowSpec(
        icon: Icons.info_rounded,
        color: const Color(0xFF8A3FD0),
        label: 'نمایش خلاصه مسیر',
        desc: 'نمایش اطلاعات کامل مسیر قبل از شروع',
        value: state.showSummary,
        onChanged: (v) => notifier.update((s) => s.copyWith(showSummary: v)),
      ),
      _ToggleRowSpec(
        icon: Icons.speed_rounded,
        color: const Color(0xFF8A3FD0),
        label: 'هشدار سرعت',
        desc: 'هشدار در صورت تجاوز از سرعت مجاز',
        value: state.speedWarning,
        onChanged: (v) => notifier.update((s) => s.copyWith(speedWarning: v)),
      ),
      _ToggleRowSpec(
        icon: Icons.crop_free_rounded,
        color: const Color(0xFF8A3FD0),
        label: 'پرهیز از مناطق خاص',
        desc: 'انتخاب مناطقی که تمایل ندارید از آن عبور کنید',
        value: state.avoidSpecialAreas,
        onChanged: (v) =>
            notifier.update((s) => s.copyWith(avoidSpecialAreas: v)),
      ),
    ];

    return GlassPanel(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(12, 6, 12, 10),
            child: _CardHeaderRow(
              title: 'تنظیمات مسیر',
              subtitle: 'تنظیمات اضافی مسیریابی',
            ),
          ),
          for (var i = 0; i < rows.length; i++) ...[
            _ToggleRow(spec: rows[i]),
            if (i != rows.length - 1)
              Divider(
                  height: 1,
                  indent: 12,
                  endIndent: 12,
                  color: AppColors.glassBorder(context)),
          ],
          const SizedBox(height: 4),
        ],
      ),
    );
  }
}

class _ToggleRowSpec {
  _ToggleRowSpec({
    required this.icon,
    required this.color,
    required this.label,
    required this.desc,
    required this.value,
    required this.onChanged,
  });

  final IconData icon;
  final Color color;
  final String label;
  final String desc;
  final bool value;
  final ValueChanged<bool> onChanged;
}

class _ToggleRow extends StatelessWidget {
  const _ToggleRow({required this.spec});

  final _ToggleRowSpec spec;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      child: Row(
        children: [
          _BadgeIcon(icon: spec.icon, color: spec.color, size: 38),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  spec.label,
                  style: TextStyle(
                    color: AppColors.textPrimary(context),
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  spec.desc,
                  style: TextStyle(
                    color: AppColors.textMuted(context),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Switch(
            value: spec.value,
            activeColor: spec.color,
            onChanged: spec.onChanged,
          ),
        ],
      ),
    );
  }
}
