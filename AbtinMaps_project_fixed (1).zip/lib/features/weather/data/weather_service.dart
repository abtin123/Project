import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class WeatherData {
  final double temp;
  final String condition;
  final String iconCode;
  final String city;

  const WeatherData({
    required this.temp,
    required this.condition,
    required this.iconCode,
    required this.city,
  });

  WeatherData copyWith({String? city}) {
    return WeatherData(
      temp: temp,
      condition: condition,
      iconCode: iconCode,
      city: city ?? this.city,
    );
  }

  /// آیکونِ متناسب با کدِ وضعیتِ هوای WMO (همان کدهایی که Open-Meteo برمی‌گرداند).
  IconData get icon {
    final code = int.tryParse(iconCode) ?? 0;
    if (code == 0) return Icons.wb_sunny_rounded;
    if (code <= 3) return Icons.wb_cloudy_rounded;
    if (code <= 48) return Icons.foggy;
    if (code <= 57) return Icons.grain_rounded;
    if (code <= 67) return Icons.water_drop_rounded;
    if (code <= 77) return Icons.ac_unit_rounded;
    if (code <= 82) return Icons.beach_access_rounded;
    if (code <= 86) return Icons.cloudy_snowing;
    if (code <= 99) return Icons.thunderstorm_rounded;
    return Icons.wb_sunny_rounded;
  }

  /// رنگِ متناسب با آیکون، هم‌راستا با پالتِ چیپِ پیش‌نمایشِ تنظیمات.
  Color get iconColor {
    final code = int.tryParse(iconCode) ?? 0;
    if (code == 0) return const Color(0xFFF2B93B);
    if (code <= 3) return const Color(0xFFB8C2CC);
    if (code <= 48) return const Color(0xFF9AA5B1);
    if (code <= 67 || (code >= 80 && code <= 82)) {
      return const Color(0xFF5AA9E6);
    }
    if (code <= 77 || (code >= 85 && code <= 86)) {
      return const Color(0xFFDCE7F2);
    }
    return const Color(0xFFE0B84B);
  }
}

class WeatherService {
  // Open-Meteo: رایگان، بدون نیاز به کلید API.
  static Future<WeatherData?> getWeather(double lat, double lng) async {
    try {
      final url = Uri.parse(
        'https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lng&current_weather=true',
      );
      final response = await http.get(url).timeout(const Duration(seconds: 12));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final current = data['current_weather'];
        return WeatherData(
          temp: (current['temperature'] as num).toDouble(),
          condition: _getConditionText(current['weathercode'] as int),
          iconCode: current['weathercode'].toString(),
          city: '',
        );
      }
    } catch (e) {
      debugPrint('Weather Error: $e');
    }
    return null;
  }

  /// نام شهر از روی مختصات GPS (reverse geocoding رایگان، بدون کلید API).
  static Future<String?> getCityName(double lat, double lng) async {
    try {
      final url = Uri.parse(
        'https://api.bigdatacloud.net/data/reverse-geocode-client'
        '?latitude=$lat&longitude=$lng&localityLanguage=fa',
      );
      final response = await http.get(url).timeout(const Duration(seconds: 12));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final city = (data['city'] as String?)?.trim();
        final locality = (data['locality'] as String?)?.trim();
        final principal = (data['principalSubdivision'] as String?)?.trim();
        final name = [city, locality, principal]
            .firstWhere((v) => v != null && v.isNotEmpty, orElse: () => null);
        return name;
      }
    } catch (e) {
      debugPrint('Reverse geocoding error: $e');
    }
    return null;
  }

  static String _getConditionText(int code) {
    if (code == 0) return 'صاف';
    if (code <= 3) return 'نیمه ابری';
    if (code <= 48) return 'مه‌آلود';
    if (code <= 55) return 'باران ریز';
    if (code <= 65) return 'بارانی';
    if (code <= 75) return 'برفی';
    if (code <= 82) return 'رگبار';
    if (code <= 99) return 'طوفانی';
    return 'نامشخص';
  }
}
