import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../settings/presentation/appearance_settings_providers.dart';
import 'weather_chip.dart';
import 'weather_settings_providers.dart';

/// ویجت شناور آب‌وهوا روی نقشه‌ی اصلی.
///
/// موقعیت/اندازه/پس‌زمینه از تنظیمات ظاهری خوانده می‌شود. وقتی غیرفعال
/// است، [WeatherChip] اصلاً ساخته نمی‌شود — یعنی [weatherProvider] (که
/// GPS و API آب‌وهوا را صدا می‌زند) هم ساخته نمی‌شود، پس بدون فعال‌سازی
/// دستی کاربر هیچ درخواست شبکه‌ای اجرا نمی‌شود.
class WeatherMapOverlay extends ConsumerWidget {
  const WeatherMapOverlay({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final enabled = ref.watch(weatherEnabledProvider);
    if (!enabled) return const SizedBox.shrink();

    final verticalPercent = ref.watch(weatherWidgetVerticalPercentProvider);
    final horizontalPercent = ref.watch(weatherWidgetHorizontalPercentProvider);
    final scale = ref.watch(weatherWidgetSizeProvider) / 100.0;
    final bgColor = ref.watch(weatherWidgetBgColorProvider);
    final bgOpacity = ref.watch(weatherWidgetBgOpacityProvider);

    final safe = MediaQuery.of(context).padding;
    final vertical = verticalPercent.clamp(0.0, 100.0).toDouble();
    final horizontal = horizontalPercent.clamp(0.0, 100.0).toDouble();

    return Positioned.fill(
      child: Padding(
        padding: EdgeInsets.fromLTRB(12, safe.top + 12, 12, safe.bottom + 12),
        child: Align(
          alignment: Alignment(
            (horizontal / 50.0) - 1,
            (vertical / 50.0) - 1,
          ),
          child: WeatherChip(
            scale: scale,
            background: bgColor.withOpacity(bgOpacity),
          ),
        ),
      ),
    );
  }
}
