import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'weather_providers.dart';

/// چیپِ آب‌وهوای واقعی که روی نقشه نمایش داده می‌شود — همان طراحیِ چیپِ
/// دموی صفحه‌ی تنظیمات (_WeatherChip)، اما با داده‌ی واقعی: شهر از GPS و
/// دما/وضعیت از weatherProvider که هر ۱ ساعت خودکار رفرش می‌شود.
class WeatherChip extends ConsumerWidget {
  /// [scale]: ضریب اندازه (۱٫۰ = پیش‌فرض). [background]: رنگ کامل پس‌زمینه
  /// (شفافیت هم داخل همین رنگ اعمال می‌شود، نه جدا).
  const WeatherChip({
    super.key,
    this.scale = 1.0,
    this.background = const Color(0x8C000000), // black @ ~55%
  });

  final double scale;
  final Color background;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(weatherProvider);
    final data = state.data;

    // تا وقتی هیچ داده‌ای (نه فعلی و نه قبلی) در دسترس نیست، فقط در حینِ
    // اولین درخواست یک اسپینرِ کوچک نشان می‌دهیم؛ نه قبل از آن (که هنوز
    // GPS آماده نیست) و نه بعدِ خطا (که چیزی برای نمایش نیست).
    if (data == null && !state.loading) {
      return const SizedBox.shrink();
    }

    return Transform.scale(
      scale: scale,
      alignment: Alignment.center,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: background,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (data == null)
              const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white70,
                ),
              )
            else
              Icon(data.icon, color: data.iconColor, size: 18),
            const SizedBox(width: 6),
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  data != null ? '${data.temp.round()}°C' : '—',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 1),
                Text(
                  data != null && data.city.isNotEmpty ? data.city : '…',
                  style: const TextStyle(
                    color: Color(0xFFDFE4EA),
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                if (data != null) ...[
                  const SizedBox(height: 1),
                  Text(
                    data.condition,
                    style: const TextStyle(
                      color: Color(0xFF96A1B0),
                      fontSize: 9,
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
