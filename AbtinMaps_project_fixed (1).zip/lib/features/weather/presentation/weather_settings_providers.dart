import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../settings/data/settings_repository.dart';
import '../../settings/presentation/settings_repository_provider.dart';

/// وضعیت فعال/غیرفعال بودن قابلیت آب‌وهوا (پیش‌فرض: غیرفعال).
///
/// نکته‌ی معماری مهم: خواندن این provider هرگز چیزی از GPS یا شبکه صدا
/// نمی‌زند — فقط یک bool از دیتابیس تنظیمات می‌خواند. weatherProvider
/// (که واقعاً GPS/API را صدا می‌زند) فقط داخل WeatherScreen خوانده
/// می‌شود، نه در Map — پس تا وقتی کاربر وارد صفحه‌ی آب‌وهوا نشده، هیچ
/// درخواستی اجرا نمی‌شود، صرف‌نظر از این‌که این فلگ روشن است یا خاموش.
class WeatherEnabledNotifier extends StateNotifier<bool> {
  final Ref ref;

  WeatherEnabledNotifier(this.ref) : super(false) {
    _load();
  }

  Future<void> _load() async {
    final repo = ref.read(settingsRepositoryProvider);
    state = await repo.getBool(SettingsRepository.keyWeatherEnabled,
        fallback: false);
  }

  Future<void> setEnabled(bool value) async {
    state = value;
    final repo = ref.read(settingsRepositoryProvider);
    await repo.setBool(SettingsRepository.keyWeatherEnabled, value);
  }
}

final weatherEnabledProvider =
    StateNotifierProvider<WeatherEnabledNotifier, bool>((ref) {
  return WeatherEnabledNotifier(ref);
});
