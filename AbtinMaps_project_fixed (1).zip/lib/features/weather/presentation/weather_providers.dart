import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../gps/presentation/gps_providers.dart';
import '../../gps/data/location_service.dart';
import '../data/weather_service.dart';

/// وضعیتِ ویجتِ آب‌وهوا: خودِ داده، زمانِ آخرین به‌روزرسانی، و لودینگ/خطا —
/// تا ویجت بتواند اسکلتون/خطا را جدا از دادهٔ قدیمیِ قبلی نشان دهد.
class WeatherState {
  final WeatherData? data;
  final DateTime? lastUpdated;
  final bool loading;
  final bool hasError;

  const WeatherState({
    this.data,
    this.lastUpdated,
    this.loading = false,
    this.hasError = false,
  });

  WeatherState copyWith({
    WeatherData? data,
    DateTime? lastUpdated,
    bool? loading,
    bool? hasError,
  }) {
    return WeatherState(
      data: data ?? this.data,
      lastUpdated: lastUpdated ?? this.lastUpdated,
      loading: loading ?? this.loading,
      hasError: hasError ?? this.hasError,
    );
  }
}

/// آب‌وهوای زنده — شهر از GPS خوانده می‌شود و هر ۱ ساعت یک‌بار خودکار
/// رفرش می‌شود (نه با هر تیکِ GPS، که قبلاً باعث صدها فراخوانیِ غیرضروریِ
/// API در دقیقه می‌شد).
class WeatherNotifier extends StateNotifier<WeatherState> {
  final Ref ref;
  Timer? _hourlyTimer;
  bool _initialFetchDone = false;

  WeatherNotifier(this.ref) : super(const WeatherState()) {
    _start();
  }

  void _start() {
    final current = ref.read(vehiclePositionProvider).value;
    if (current != null) {
      _initialFetchDone = true;
      unawaited(refresh());
    } else {
      // هنوز هیچ فیکسِ GPS نرسیده؛ منتظرِ اولین موقعیتِ واقعی می‌مانیم و
      // فقط همان یک‌بار برای شروع رفرش می‌کنیم — پرچمِ _initialFetchDone
      // مانع از رفرشِ دوباره با هر تیکِ بعدیِ GPS می‌شود.
      ref.listen<AsyncValue<VehiclePosition>>(
        vehiclePositionProvider,
        (previous, next) {
          if (_initialFetchDone) return;
          final pos = next.value;
          if (pos != null) {
            _initialFetchDone = true;
            unawaited(refresh());
          }
        },
      );
    }

    _hourlyTimer = Timer.periodic(const Duration(hours: 1), (_) {
      refresh();
    });
  }

  Future<void> refresh() async {
    final pos = ref.read(vehiclePositionProvider).value;
    if (pos == null) return;

    state = state.copyWith(loading: true, hasError: false);
    try {
      // هر دو درخواست (آب‌وهوا و نامِ شهر) هم‌زمان شروع می‌شوند، نه
      // پشتِ‌سرِهم، تا رفرشِ ساعتی سریع‌تر تمام شود.
      final weatherFuture = WeatherService.getWeather(pos.lat, pos.lng);
      final cityFuture = WeatherService.getCityName(pos.lat, pos.lng);
      final weather = await weatherFuture;
      final city = await cityFuture;

      if (weather == null) {
        state = state.copyWith(loading: false, hasError: true);
        return;
      }

      state = WeatherState(
        data: weather.copyWith(city: city ?? weather.city),
        lastUpdated: DateTime.now(),
        loading: false,
        hasError: false,
      );
    } catch (_) {
      state = state.copyWith(loading: false, hasError: true);
    }
  }

  @override
  void dispose() {
    _hourlyTimer?.cancel();
    super.dispose();
  }
}

final weatherProvider =
    StateNotifierProvider<WeatherNotifier, WeatherState>((ref) {
  return WeatherNotifier(ref);
});
