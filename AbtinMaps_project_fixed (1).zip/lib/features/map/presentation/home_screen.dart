import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show PlatformException;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:maplibre_gl/maplibre_gl.dart' as native_maplibre;
import 'package:go_router/go_router.dart';
import 'package:abtin_maps/core/geo/geo_types.dart';

import '../../../abtinmap/abm_models.dart';
import '../../routing/data/routing_provider.dart';
import '../../../core/deep_link/deep_link_service.dart';
import '../../../core/permissions/location_permission_flow.dart';
import '../../../core/theme/app_colors.dart';
import '../../../shared/providers/app_settings_providers.dart';
import '../../../shared/providers/app_notice_provider.dart';
import '../../../shared/providers/map_style_providers.dart';
import '../../../shared/providers/abm_poi_visibility_providers.dart';
import '../../../shared/providers/abtinmap_providers.dart';
import '../../../core/abm_debug_log.dart';
import '../../settings/presentation/settings_repository_provider.dart';
import '../../settings/presentation/appearance_settings_providers.dart'
    show
        appearanceSettingsProvider,
        carSizePercentProvider,
        mapTiltProvider,
        navigationCameraTiltProvider,
        pinColorProvider,
        pinSizeProvider,
        routeColorHexProvider,
        routeLineStyleProvider;
import '../../../shared/widgets/bottom_nav.dart';
import '../../../shared/widgets/glass_notice.dart';
import '../../gps/data/location_service.dart';
import '../../gps/presentation/gps_providers.dart';
import '../../offline_maps/presentation/offline_maps_providers.dart';
import 'online_map_view.dart';
import '../../routing/data/routing_service.dart';
import '../../routing/presentation/routing_providers.dart';
import '../../vehicle/presentation/modern_speedometer.dart';
import '../../vehicle/presentation/vehicle_provider.dart';
import '../../voice_settings/data/voice_pack_fa.dart';
import '../../voice_settings/presentation/tts_providers.dart';
import 'destination_provider.dart';
import '../../../shared/providers/share_service.dart';
import '../../../core/localization/app_localizations.dart';
import '../../saved_places/presentation/saved_places_providers.dart';
import '../../settings/data/settings_repository.dart';
import '../../weather/presentation/weather_map_overlay.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _RouteSample {
  const _RouteSample(this.point, this.headingDeg, this.progressMeters);
  final LatLng point;
  final double headingDeg;
  final double progressMeters;
}

class _SegmentProjection {
  const _SegmentProjection({
    required this.t,
    required this.segmentMeters,
    required this.distanceMeters,
  });
  final double t;
  final double segmentMeters;
  final double distanceMeters;
}

class _RouteMatch {
  const _RouteMatch({required this.segmentIndex, required this.projection});
  final int segmentIndex;
  final _SegmentProjection projection;
  double get distanceMeters => projection.distanceMeters;
}

class _HomeScreenState extends ConsumerState<HomeScreen>
    with WidgetsBindingObserver {
  bool _cameraFollowsVehicle = true;
  int _gpsFocusRequest = 0;
  bool _didCenterOnFirstFix = false;
  bool _arrivalHandled = false;
  int _lastSpokenInstructionIndex = -1;

  /// مرحله‌های اعلام‌شده برای هر مانور (کلید: index*10 + stage) تا هر پیام
  /// دقیقاً یک‌بار و در فاصلهٔ درست گفته شود، نه زودتر و نه دیرتر.
  final Set<int> _spokenStages = <int>{};

  int _offRouteStrikeCount = 0;
  bool _isRerouting = false;
  DateTime? _lastRerouteAt;

  bool _styleLoaded = false;
  bool _showMapRetry = false;
  Timer? _mapLoadTimeoutTimer;
  int _mapReloadKey = 0;

  // --- واچ‌داگِ «فیکس اول GPS» --------------------------------------------
  // باگ قبلی: وقتی سرویس مکان و مجوزها هر دو «ready» بودند اما به هر دلیلی
  // (داخل ساختمان، تراشه‌ی GPS کند، یا خطای بی‌صدای استریم که در
  // location_service.dart هم رفع شد) هیچ فیکسی هرگز نمی‌رسید، بنرِ بالای
  // نقشه چیزی نشان نمی‌داد (چون readiness == ready یعنی «مشکلی نیست»). از
  // نظر کاربر برنامه فقط برای همیشه ساکت می‌ماند — نه خطا، نه نشانه‌ای از
  // تلاش. این تایمر بعد از ۲۰ ثانیه انتظارِ بی‌نتیجه یک بنرِ راهنما نشان
  // می‌دهد و با ضربه، سرویس مکان را دوباره استارت می‌کند.
  bool _hasReceivedGpsFix = false;
  bool _showGpsStuckBanner = false;
  Timer? _gpsAcquireWatchdog;

  void _armGpsAcquireWatchdog() {
    if (_hasReceivedGpsFix || _gpsAcquireWatchdog != null) return;
    _gpsAcquireWatchdog = Timer(const Duration(seconds: 20), () {
      if (mounted && !_hasReceivedGpsFix) {
        setState(() => _showGpsStuckBanner = true);
      }
    });
  }

  void _onFirstGpsFixReceived() {
    if (_hasReceivedGpsFix) return;
    _hasReceivedGpsFix = true;
    _gpsAcquireWatchdog?.cancel();
    _gpsAcquireWatchdog = null;
    if (_showGpsStuckBanner && mounted) {
      setState(() => _showGpsStuckBanner = false);
    }
  }

  void _retryGpsAcquire() {
    AbmDebugLog.addGps('GPS: کاربر درخواست تلاش دوباره داد');
    setState(() => _showGpsStuckBanner = false);
    _gpsAcquireWatchdog?.cancel();
    _gpsAcquireWatchdog = null;
    ref.read(locationRepositoryProvider).start();
    _armGpsAcquireWatchdog();
  }

  Timer? _persistCameraDebounceTimer;

  /// آخرین موقعیت دوربینِ شناخته‌شده. وقتی resolvedMapStyleProvider عوض
  /// می‌شود (مثلاً درست بعد از اتمام دانلود نقشه: از استایل آنلاینِ فالبک به
  /// استایل آفلاینِ resolve‌شده)، چون این مقدار در key ویجت MapLibreMap هم
  /// هست، کل ویجت/کنترلر از نو ساخته می‌شود. بدون این فیلد،
  /// initialCameraPosition همیشه به‌طور ثابت روی تهران می‌افتاد — یعنی درست
  /// لحظه‌ی اتمام دانلود، دوربین از موقعیت واقعی کاربر می‌پرید تهران تا هر
  /// وقت GPS دوباره تصحیحش کند (و اگر _cameraFollowsVehicle در آن لحظه false
  /// بود، اصلاً تصحیح نمی‌شد).
  CameraPosition? _lastKnownCamera;
  final ValueNotifier<double> _mapBearingDegrees = ValueNotifier<double>(0);

  // نمای اولیه را روی کل ایران می‌گذاریم تا حتی قبل از GPS هم کاربر یک
  // نمای سراسریِ قابل‌فهم ببیند، نه یک نمای خیلی نزدیکِ ثابت روی تهران.
  static const CameraPosition _initialCamera = CameraPosition(
    target: LatLng(32.5, 54.0),
    zoom: 5.1,
    tilt: 0,
    bearing: 0,
  );

  Future<void> _restoreSavedMapCamera() async {
    final repo = ref.read(settingsRepositoryProvider);
    final lat = await repo.getDouble(
      SettingsRepository.keyLastMapCenterLat,
      fallback: _initialCamera.target.latitude,
    );
    final lng = await repo.getDouble(
      SettingsRepository.keyLastMapCenterLng,
      fallback: _initialCamera.target.longitude,
    );
    final zoom = await repo.getDouble(
      SettingsRepository.keyLastMapZoom,
      fallback: _initialCamera.zoom,
    );
    final bearing = await repo.getDouble(
      SettingsRepository.keyLastMapBearing,
      fallback: _initialCamera.bearing,
    );
    final tilt = await repo.getDouble(
      SettingsRepository.keyLastMapTilt,
      fallback: _initialCamera.tilt,
    );
    final followsVehicle = await repo.getBool(
      SettingsRepository.keyLastMapFollowVehicle,
      fallback: true,
    );

    final restored = CameraPosition(
      target: LatLng(lat, lng),
      zoom: zoom.clamp(2.0, 19.0).toDouble(),
      bearing: bearing,
      tilt: tilt.clamp(0.0, 60.0).toDouble(),
    );

    _lastKnownCamera = restored;
    _mapBearingDegrees.value = restored.bearing;
    _cameraFollowsVehicle = followsVehicle;
    if (!followsVehicle) {
      _didCenterOnFirstFix = true;
    }
    if (mounted) setState(() {});
  }

  CameraPosition _currentLogicalCamera() => _lastKnownCamera ?? _initialCamera;

  void _persistMapCameraSoon() {
    _persistCameraDebounceTimer?.cancel();
    _persistCameraDebounceTimer =
        Timer(const Duration(milliseconds: 450), _persistMapCameraNow);
  }

  Future<void> _persistMapCameraNow() async {
    final repo = ref.read(settingsRepositoryProvider);
    final camera = _currentLogicalCamera();
    await repo.setDouble(
      SettingsRepository.keyLastMapCenterLat,
      camera.target.latitude,
    );
    await repo.setDouble(
      SettingsRepository.keyLastMapCenterLng,
      camera.target.longitude,
    );
    await repo.setDouble(SettingsRepository.keyLastMapZoom, camera.zoom);
    await repo.setDouble(SettingsRepository.keyLastMapBearing, camera.bearing);
    await repo.setDouble(SettingsRepository.keyLastMapTilt, camera.tilt);
    await repo.setBool(
      SettingsRepository.keyLastMapFollowVehicle,
      _cameraFollowsVehicle,
    );
  }

  /// فقط فیکس زندهٔ pipeline GPS برای marker معتبر است. آخرین موقعیت
  /// ذخیره‌شده یا مرکز اولیه صرفاً برای دوربین‌اند؛ نمایش آن‌ها به‌عنوان خودرو
  /// علت مستقیم marker گمشده/شناور در مکان اشتباه بود.
  VehiclePosition? _resolveVehiclePosition(AsyncValue<VehiclePosition> live) {
    return live.valueOrNull;
  }

  // --- کش map-matching (نگاه کنید به _matchPositionToRoute) ---
  // geometry فقط برای تشخیصِ «مسیر عوض شده» (reroute) نگه داشته می‌شود؛
  // چون هر بار مسیرِ جدید محاسبه می‌شود یک List تازه است، مقایسه‌ی identical
  // کافی است — نیازی به مقایسه‌ی محتوا نیست.
  List<LatLng>? _routeMatchGeometry;
  List<double>? _routeMatchCumulativeM;
  int? _routeMatchLastSegment;
  double? _routeMatchLastProgressM;

  // LocationService افت کوتاه GPS را با کالمن مدیریت می‌کند. در شکاف طولانی
  // فقط روی هندسهٔ مسیر فعال جلو می‌رویم؛ پیش‌بینی آزاد در صفحه ممنوع است.
  Timer? _longTunnelWatchTimer;
  VehiclePosition? _lastNavigationSignal;
  DateTime? _lastNavigationSignalAt;
  VehiclePosition? _tunnelEstimatedPosition;
  DateTime? _tunnelEstimateStartedAt;
  DateTime? _lastTunnelEstimateAt;
  double _tunnelRouteProgressM = 0;
  bool _longTunnelEstimateExhausted = false;
  static const Duration _longTunnelSilenceBeforeStart = Duration(seconds: 5);
  static const Duration _maxLongTunnelEstimate = Duration(seconds: 25);
  static const double _minimumTunnelEstimateSpeedKmh = 8;

  void _startMapLoadWatchdog() {
    _mapLoadTimeoutTimer?.cancel();
    _showMapRetry = false;
    _mapLoadTimeoutTimer = Timer(const Duration(seconds: 20), () {
      if (mounted && !_styleLoaded) {
        setState(() => _showMapRetry = true);
      }
    });
  }

  void _retryMapLoad() {
    setState(() {
      _styleLoaded = false;
      _showMapRetry = false;
      _mapReloadKey++;
    });
    _startMapLoadWatchdog();
  }

  void _markMapStyleLoaded() {
    _mapLoadTimeoutTimer?.cancel();
    if (!mounted || (_styleLoaded && !_showMapRetry)) return;
    setState(() {
      _styleLoaded = true;
      _showMapRetry = false;
    });
  }

  void _onNativeCameraPosition(native_maplibre.CameraPosition camera) {
    final bearing = camera.bearing.isFinite ? camera.bearing % 360.0 : 0.0;
    _lastKnownCamera = CameraPosition(
      target: LatLng(camera.target.latitude, camera.target.longitude),
      zoom: camera.zoom,
      bearing: bearing,
      tilt: camera.tilt,
    );
    if ((_mapBearingDegrees.value - bearing).abs() > 0.05) {
      _mapBearingDegrees.value = bearing;
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _startMapLoadWatchdog();
    _drivingModeSubscription = null;
    unawaited(_restoreSavedMapCamera());
    _longTunnelWatchTimer = Timer.periodic(
      const Duration(milliseconds: 200),
      (_) => _advanceLongTunnelEstimate(),
    );
  }

  StreamSubscription? _drivingModeSubscription;

  // باگ واقعیِ «لوکیشن اصلاً پیدا نمی‌شود»: locationReadinessProvider فقط
  // یک‌بار در build اول چک می‌شود و بعد فقط با
  // Geolocator.getServiceStatusStream() (که روی خیلی گوشی‌ها/OEMها وقتی
  // کاربر از داخل صفحه‌ی تنظیماتِ سیستم GPS/مجوز را روشن می‌کند و برمی‌گردد
  // به اپ، اصلاً trigger نمی‌شود) دوباره چک می‌شود. نتیجه: کاربر GPS یا
  // مجوز را در تنظیمات روشن می‌کند، به اپ برمی‌گردد، و LocationService.start()
  // هرگز صدا زده نمی‌شود — نقشه برای همیشه در حالت «waiting» بدون فیکس
  // می‌ماند. حالا با هر resume اپ (didChangeAppLifecycleState) وضعیت
  // readiness دوباره چک می‌شود، مستقل از این‌که سیستم‌عامل استریمِ سرویس
  // را trigger کرده باشد یا نه.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      ref.read(locationLifecycleTickProvider.notifier).state++;
    }
  }

  @override
  Widget build(BuildContext context) {
    final readiness = ref.watch(locationReadinessProvider);
    // هر چیزی که روی نقشه دیده می‌شود از یک جریان واحد و ۶۰fps می‌آید. پیش
    // از این، خودرو از GPS نرم‌شده اما دوربین از فیکس‌های گسسته حرکت می‌کرد؛
    // در نتیجه ماشین آرام می‌رفت ولی پس‌زمینه هر یک تا دو ثانیه می‌پرید.
    final vehiclePositionAsync = ref.watch(navigationPositionProvider);
    final destination = ref.watch(selectedDestinationProvider);
    final activeNav = ref.watch(activeNavigationProvider);
    final routeCandidatesAsync = ref.watch(calculateRoutesProvider);
    // وقتی مقصد/ناوبری لغو می‌شود، provider ممکن است برای یک فریم مقدار
    // قبلی را نگه دارد؛ overlay نباید در این فاصله خط مسیر را دوباره رسم کند.
    final routeCandidates = activeNav == null && destination != null
        ? (routeCandidatesAsync.valueOrNull ?? const <RouteInfo>[])
        : const <RouteInfo>[];
    final routeOptionsLoading = activeNav == null &&
        destination != null &&
        routeCandidatesAsync.isLoading;
    final selectedRouteCandidateIndex =
        ref.watch(selectedRouteCandidateIndexProvider);
    final selectedRouteIndex = routeCandidates.isEmpty
        ? 0
        : selectedRouteCandidateIndex.clamp(0, routeCandidates.length - 1);
    final liveVehiclePosition = _resolveVehiclePosition(vehiclePositionAsync);
    // Rendering must use the single 60fps navigation stream. The raw GPS
    // listener below is intentionally kept only for route progress; using its
    // value here reintroduced the exact 1Hz/2Hz position jumps we were trying
    // to eliminate. در حین ناوبری، همین جریانِ نرم روی هندسهٔ مسیر فعال
    // match می‌شود تا خودرو و پیکان دقیقاً روی همان مسیر و با جهت قطعهٔ جاده
    // نمایش داده شوند؛ نه فقط دوربین.
    final baseVehiclePosition = _tunnelEstimatedPosition ?? liveVehiclePosition;
    // در navigation، raw GPS فقط وقتی روی نقشه نمایش داده می‌شود که به خود
    // geometry route وصل شود. اگر فیکس خارج از مسیر/کم‌دقت باشد، سرعت‌سنج
    // همچنان دادهٔ زنده دارد ولی marker و camera به نقطهٔ ساختگی نمی‌پرند.
    final vehiclePosition = activeNav == null || baseVehiclePosition == null
        ? baseVehiclePosition
        : _matchPositionToRoute(baseVehiclePosition, activeNav.route.geometry);
    final canFollowVehicle = _cameraFollowsVehicle && vehiclePosition != null;
    final routingEngine = ref.watch(routingEngineProvider);
    final bool isDarkMap =
        ref.watch(mapStyleModeProvider) == MapStyleMode.night;
    final bool requestedOffline = routingEngine != RoutingEngine.online;
    final offlinePmtilesStylePath = requestedOffline
        ? ref.watch(offlinePmtilesStylePathProvider(isDarkMap)).valueOrNull
        : null;
    // ورود همیشه مستقیم به نقشه است: PMTiles محلی فقط وقتی فعال می‌شود که
    // graph ABM و هر دو style/آرشیو برداری کامل نصب باشند؛ در غیر این صورت
    // نقشهٔ آنلاین MapLibre نمایش می‌یابد، نه کره یا Atlas raster ناقص.
    final bool isOfflineMode =
        requestedOffline && offlinePmtilesStylePath != null;
    final String currentMapStyle = isOfflineMode
        ? 'offline-$offlinePmtilesStylePath'
        : (isDarkMap ? 'online-night' : 'online-day');
    _mapLoadTimeoutTimer?.cancel();
    final routeColorIndex = ref.watch(routeColorIndexProvider);
    final routeWidth = ref.watch(routeWidthProvider);
    final mapPerspective = ref.watch(mapPerspectiveProvider);
    final idleMapTilt = ref.watch(mapTiltProvider);
    final mapCameraTilt = activeNav != null
        ? ref.watch(navigationCameraTiltProvider).clamp(0.0, 60.0).toDouble()
        : (mapPerspective == MapPerspective.threeD
            ? idleMapTilt.clamp(0.0, 60.0).toDouble()
            : 0.0);
    final offlineMapPalette = ref.watch(currentOfflineMapPaletteProvider);
    ref.listen<AsyncValue<DeepLinkDestination>>(deepLinkDestinationProvider,
        (prev, next) {
      next.whenData((dest) {
        final point = LatLng(dest.lat, dest.lng);
        // نکته: دیگر اینجا دوربین را جابه‌جا نمی‌کنیم — همین کار حالا برای
        // هر مبدأِ مقصدی (جستجو، مکان‌های ذخیره‌شده، دیپ‌لینک) به‌صورت
        // متمرکز در listener مربوط به selectedDestinationProvider انجام می‌شود.
        ref.read(selectedDestinationProvider.notifier).state =
            SelectedDestination(point, label: dest.label);
      });
    });

    ref.listen<AsyncValue<VehiclePosition>>(vehiclePositionProvider,
        (prev, next) {
      next.whenData((pos) {
        final navigation = ref.read(activeNavigationProvider);
        final roadMatched = navigation == null
            ? pos
            : (_matchPositionToRoute(pos, navigation.route.geometry) ?? pos);
        _acceptNavigationSignal(roadMatched);
        _onFirstGpsFixReceived();
        if (!_didCenterOnFirstFix) {
          _didCenterOnFirstFix = true;
          if (mounted) setState(() => _gpsFocusRequest++);
        }
        if (navigation != null) {
          _updateNavigationProgress(roadMatched, navigation);
        }
      });
    });

    ref.listen<AsyncValue<LocationReadiness>>(locationReadinessProvider,
        (prev, next) {
      next.whenData((state) {
        if (state == LocationReadiness.ready) {
          _armGpsAcquireWatchdog();
        } else {
          // مجوز/سرویس دیگر ready نیست؛ بنر «هنوز فیکس نرسیده» معنایی
          // ندارد، چون بنر خطای مجوز/سرویس همین الان جایگزینش می‌شود.
          _gpsAcquireWatchdog?.cancel();
          _gpsAcquireWatchdog = null;
          if (_showGpsStuckBanner) {
            _showGpsStuckBanner = false;
          }
        }
      });
    });

    // وقتی مقصد جدیدی انتخاب می‌شود (از جستجو، مکان‌های ذخیره‌شده، و...)
    // دوربین باید به آن نقطه برود، وگرنه پین ممکن است کاملاً بیرون از
    // ناحیه‌ی دیدِ فعلی دوربین محاسبه شود و کاربر هیچ‌چیزی روی نقشه نبیند
    // (باگ قبلی: فقط دیپ‌لینک‌ها دوربین را جابه‌جا می‌کردند، نتیجه‌ی جستجو نه).
    ref.listen<SelectedDestination?>(selectedDestinationProvider, (prev, next) {
      if (next != null && prev?.point != next.point) {
        ref.read(selectedRouteCandidateIndexProvider.notifier).state = 0;
        setState(() => _cameraFollowsVehicle = false);
        _persistMapCameraSoon();
      }
      // مسیریابی خودکار وقتی مقصد از «مکان‌های ذخیره‌شده» با autoStart انتخاب می‌شود.
      if (next != null && next.autoStart && prev?.point != next.point) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && ref.read(activeNavigationProvider) == null) {
            _startNavigation();
          }
        });
      }
    });

    final canPopHome = destination == null && activeNav == null;

    return PopScope(
      canPop: canPopHome,
      onPopInvoked: (didPop) {
        if (didPop) return;
        if (activeNav != null) {
          _stopNavigation();
        } else if (destination != null) {
          ref.read(selectedDestinationProvider.notifier).state = null;
        }
      },
      child: Scaffold(
        backgroundColor: AppColors.frameBackground(context),
        body: Stack(
          children: [
            Positioned.fill(
              child: OnlineMapView(
                key: ValueKey('maplibre-$currentMapStyle'),
                vehiclePosition: vehiclePosition,
                vehicle: ref.watch(selectedVehicleProvider),
                modelIndex: ref.watch(selectedVehicleIndexProvider),
                isDark: isDarkMap,
                followVehicle: canFollowVehicle,
                drivingMode: activeNav != null,
                markerColor: ref.watch(pinColorProvider),
                vehicleColor: ref.watch(vehicleColorProvider),
                pinSizePercent: ref.watch(pinSizeProvider),
                carSizePercent: ref.watch(carSizePercentProvider),
                cameraTiltDegrees: mapCameraTilt,
                locationFocusRequest: _gpsFocusRequest,
                palette: offlineMapPalette,
                visiblePoiKlasses: ref.watch(abmPoiVisibilityProvider),
                localStylePath: offlinePmtilesStylePath,
                routeGeometry: activeNav?.route.geometry,
                routeOverlays: destination != null &&
                        activeNav == null &&
                        routeCandidates.isNotEmpty
                    ? [
                        for (var index = 0;
                            index < routeCandidates.length && index < 3;
                            index++)
                          OnlineRouteOverlay(
                            geometry: routeCandidates[index].geometry,
                            color: index == selectedRouteIndex
                                ? const Color(0xFF2FE6C4)
                                : const Color(0xFF99B4C1)
                                    .withValues(alpha: 0.62),
                            width: index == selectedRouteIndex
                                ? routeWidth + 2
                                : routeWidth,
                          ),
                      ]
                    : null,
                routeColor: routeColorIndex < 0
                    ? _hexToColorOrDefault(
                        ref.watch(routeColorHexProvider),
                        kRouteColorHexes[0],
                      )
                    : Color(int.parse(
                        'FF${kRouteColorHexes[routeColorIndex.clamp(0, kRouteColorHexes.length - 1)].substring(1)}',
                        radix: 16,
                      )),
                routeWidth: routeWidth,
                destination: destination?.point,
                onLongPress: (point) {
                  ref.read(selectedDestinationProvider.notifier).state =
                      SelectedDestination(point);
                  _takeManualCameraControl();
                },
                onRouteTap: (index) => ref
                    .read(selectedRouteCandidateIndexProvider.notifier)
                    .state = index,
                onUserGestureStart: _takeManualCameraControl,
                onCameraIdle: _persistMapCameraSoon,
                onCameraPositionChanged: _onNativeCameraPosition,
                onStyleLoaded: _markMapStyleLoaded,
              ),
            ),

            // ویجت شناور آب‌وهوا — فقط وقتی از تنظیمات ظاهری فعال شده باشد
            // ساخته می‌شود (WeatherMapOverlay خودش این شرط را چک می‌کند)، پس
            // تا وقتی کاربر فعالش نکرده هیچ درخواست GPS/API آب‌وهوایی اجرا
            // نمی‌شود و باز شدنِ Map/اولین فیکسِ Location کند نمی‌شود.
            const WeatherMapOverlay(),

            // این بنر فقط برای نقشه‌ی آنلاین (MapLibre) معنا دارد؛ چون
            // _styleLoaded فقط داخل onStyleLoadedCallback نقشه‌ی آنلاین ست
            // می‌شود و در حالت آفلاین آن ویجت اصلاً ساخته نمی‌شود، بدون این
            // شرطِ اضافه، واچ‌داگ ۲۰ثانیه‌ای همیشه (حتی وقتی نقشه‌ی آفلاین
            // کاملاً درست کار می‌کند) این بنر را برای همیشه روی نقشه نگه می‌داشت.
            if (_showMapRetry && !_styleLoaded)
              Positioned(
                top: MediaQuery.of(context).padding.top +
                    5 +
                    (activeNav != null
                        ? 140
                        : (destination != null
                            ? 108
                            : (readiness.valueOrNull != null &&
                                    readiness.valueOrNull !=
                                        LocationReadiness.ready
                                ? 64
                                : 12))),
                left: 24,
                right: 24,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: AppColors.glassPanel(context),
                        borderRadius: BorderRadius.circular(16),
                        border:
                            Border.all(color: Colors.white.withOpacity(.12)),
                        boxShadow: const [
                          BoxShadow(
                              color: Colors.black45,
                              blurRadius: 16,
                              offset: Offset(0, 6)),
                        ],
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.cloud_off_rounded,
                              color: Colors.white70, size: 16),
                          const SizedBox(width: 8),
                          const Expanded(
                            child: Text(
                              'اتصال نقشه کند است…',
                              style:
                                  TextStyle(color: Colors.white, fontSize: 12),
                            ),
                          ),
                          GestureDetector(
                            onTap: _retryMapLoad,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                gradient: AppColors.primaryGradient(context),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Text(
                                'تلاش دوباره',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 11),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

            Positioned(
              top: MediaQuery.of(context).padding.top +
                  5 +
                  (activeNav != null ? 140 : (destination != null ? 108 : 12)),
              left: 24,
              right: 24,
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                transitionBuilder: (child, anim) => FadeTransition(
                  opacity: anim,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, -0.3),
                      end: Offset.zero,
                    ).animate(anim),
                    child: child,
                  ),
                ),
                child: readiness.when(
                  data: (state) => state != LocationReadiness.ready
                      ? _GpsWarningBanner(
                          key: ValueKey('gps-$state'), state: state)
                      : (_showGpsStuckBanner
                          ? _GpsStuckBanner(
                              key: const ValueKey('gps-stuck'),
                              onRetry: _retryGpsAcquire,
                            )
                          : (activeNav != null &&
                                  _tunnelEstimatedPosition != null
                              ? const _EstimatedLocationBanner(
                                  key: ValueKey('location-estimated'),
                                )
                              : const SizedBox.shrink(
                                  key: ValueKey('gps-ok')))),
                  loading: () =>
                      const SizedBox.shrink(key: ValueKey('gps-loading')),
                  error: (_, __) =>
                      const SizedBox.shrink(key: ValueKey('gps-error')),
                ),
              ),
            ),

            if (destination != null && activeNav == null)
              Positioned(
                top: MediaQuery.of(context).padding.top + 10,
                left: 16,
                right: 16,
                child: _DestinationCard(
                  destination: destination,
                  onClear: () {
                    ref.read(selectedDestinationProvider.notifier).state = null;
                    _clearRoute();
                  },
                  onStartNavigation: routeOptionsLoading
                      ? null
                      : () => _startNavigation(
                            selectedRoute: routeCandidates.isEmpty
                                ? null
                                : routeCandidates[selectedRouteIndex],
                          ),
                ),
              ),

            if (destination != null &&
                activeNav == null &&
                routeCandidates.isNotEmpty)
              Positioned(
                top: MediaQuery.of(context).padding.top + 148,
                left: 16,
                right: 16,
                child: _RouteChoiceStrip(
                  routes: routeCandidates.take(3).toList(growable: false),
                  selectedIndex: selectedRouteIndex,
                  onSelect: (index) => ref
                      .read(selectedRouteCandidateIndexProvider.notifier)
                      .state = index,
                ),
              ),

            // Compass & Floating Actions (Moved to Bottom Right)
            Positioned(
              bottom: 120,
              right: 16,
              child: Column(
                children: [
                  ValueListenableBuilder<double>(
                    valueListenable: _mapBearingDegrees,
                    builder: (context, bearing, _) =>
                        _Compass(mapBearingDeg: bearing),
                  ),
                  const SizedBox(height: 12),
                  _RoundIconButton(
                    icon: Icons.my_location_rounded,
                    onTap: () {
                      // درخواست تمرکز فقط به view واقعی MapLibre می‌رود؛ همان
                      // view زنجیرهٔ GPS زنده، آخرین موقعیت ذخیره‌شده و دوربین
                      // اولیه را مدیریت می‌کند.
                      setState(() {
                        _cameraFollowsVehicle = true;
                        _gpsFocusRequest++;
                      });
                      _persistMapCameraSoon();
                    },
                  ),
                ],
              ),
            ),

            // Speed Cluster (Speedometer + Speed Limit Sign) — ریسپانسیو
            // نسبت‌ها دقیقاً از index.html مرجع می‌آیند تا در هر سایز صفحه‌ای
            // یکسان به‌نظر برسند (به‌جای پیکسل ثابت که در صفحه‌های کوچک جابه‌جا می‌شد):
            //   .speed-cluster      { bottom:11.5%; left:2%; width:32%; height:15% }  (نسبت به صفحه)
            //   .speedometer        { left:0; bottom:0; width:66%; aspect-ratio:1/1 } (نسبت به کلاستر)
            //   .speed-limit-sign   { left:50%; bottom:35%; width:44%; aspect-ratio:1/1 } (نسبت به کلاستر)
            //
            // چرا Consumer جدا: قبلاً currentSpeed از vehiclePositionAsync ای
            // می‌آمد که در بالای build() این صفحه (۳۰۰۰+ خط) با ref.watch
            // خوانده شده بود. یعنی هر تیکِ ۶۰fps انیماتورِ موقعیت، کل ساب‌تریِ
            // صفحه (نقشه، دوربین، لایه‌های POI و...) را از نو می‌ساخت — کاری
            // که فریم را عقب می‌انداخت و نتیجه‌اش دقیقاً همان چیزی بود که
            // گزارش شد: عدد سرعت هر ۱-۲ ثانیه یک‌باره می‌پرید، نه هر ۱۶ms
            // نرم. با یک Consumer مجزا، فقط همین ویجت کوچک روی هر فیکسِ
            // انیماتور rebuild می‌شود و بقیه‌ی صفحه دست‌نخورده می‌ماند.
            Builder(builder: (context) {
              final screenSize = MediaQuery.of(context).size;
              final clusterWidth = screenSize.width * 0.32;
              final clusterHeight = screenSize.height * 0.15;
              final clusterBottom = screenSize.height * 0.115;
              final clusterLeft = screenSize.width * 0.02;
              final speedometerSize = clusterWidth * 0.66;
              final signSize = clusterWidth * 0.44;

              return Positioned(
                bottom: clusterBottom,
                left: clusterLeft,
                width: clusterWidth,
                height: clusterHeight,
                child: Consumer(builder: (context, ref, _) {
                  final currentSpeed = _tunnelEstimatedPosition?.speedKmh ??
                      ref
                          .watch(navigationPositionProvider)
                          .valueOrNull
                          ?.speedKmh ??
                      0;
                  final speedLimit = activeNav?.currentInstruction.speedLimit;
                  // تابلوی محدودیت سرعت فقط وقتی نمایش داده شود که سرعت فعلی
                  // به محدودیت مجاز نزدیک شده یا از آن گذشته باشد (نه همیشه که
                  // یک محدودیت سرعت روی جاده تعریف شده)؛ ۱۰ کیلومتر بر ساعت
                  // حاشیه‌ی هشدار پیش از رسیدن به سقف مجاز است.
                  final showSpeedLimit =
                      speedLimit != null && currentSpeed >= speedLimit - 10;
                  return Stack(
                    clipBehavior: Clip.none,
                    children: [
                      // تابلوی محدودیت سرعت زیرِ سرعت‌سنج قرار می‌گیرد (z-index
                      // پایین‌تر)؛ به همین دلیل باید قبل از سرعت‌سنج در Stack
                      // اضافه شود.
                      if (showSpeedLimit)
                        Positioned(
                          left: clusterWidth * 0.50,
                          bottom: clusterHeight * 0.35,
                          width: signSize,
                          height: signSize,
                          child: _SpeedLimitSign(
                            value: speedLimit.toString(),
                          ),
                        ),
                      Positioned(
                        left: 0,
                        bottom: 0,
                        width: speedometerSize,
                        height: speedometerSize,
                        child: ModernSpeedometer(speedKmh: currentSpeed),
                      ),
                    ],
                  );
                }),
              );
            }),

            const BottomNav(currentPage: NavKey.home, isHomePage: true),

            if (activeNav != null)
              Positioned(
                top: MediaQuery.of(context).padding.top + 10,
                left: 16,
                right: 16,
                child: _ActiveNavigationCard(
                  navigation: activeNav,
                  onClose: () => _stopNavigation(),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _mapLoadTimeoutTimer?.cancel();
    _persistCameraDebounceTimer?.cancel();
    _longTunnelWatchTimer?.cancel();
    _drivingModeSubscription?.cancel();
    _gpsAcquireWatchdog?.cancel();
    _mapBearingDegrees.dispose();
    super.dispose();
  }

  void _showGlassNotice(
    String message, {
    required IconData icon,
    required List<Color> colors,
    Duration duration = const Duration(seconds: 3),
  }) {
    if (!mounted) return;
    final level = colors.contains(Colors.red)
        ? AppNoticeLevel.error
        : colors.contains(Colors.orange)
            ? AppNoticeLevel.warning
            : AppNoticeLevel.info;
    unawaited(
      ref.read(appNoticeProvider.notifier).show(
            title: 'آبتین مپس',
            message: message,
            level: level,
          ),
    );
    showGlassNotice(context, message,
        icon: icon, colors: colors, duration: duration);
  }

  Future<void> _startNavigation({RouteInfo? selectedRoute}) async {
    final destination = ref.read(selectedDestinationProvider);
    final vehiclePosition = ref.read(vehiclePositionProvider).value;

    if (destination == null || vehiclePosition == null) return;

    final origin = LatLng(vehiclePosition.lat, vehiclePosition.lng);
    // اگر مقصد (مثلاً یک مکان ذخیره‌شده) عملاً همان نقطه‌ی فعلی GPS باشد،
    // مسیریابی یک مسیر صفر-متری بی‌معنی برمی‌گرداند. به‌جای تلاش برای
    // «مسیریابی» به همان‌جا، پیام ساده نشان می‌دهیم.
    if (AbmTileMath.haversineMeters(
          AbmPoint(origin.longitude, origin.latitude),
          AbmPoint(destination.point.longitude, destination.point.latitude),
        ) <
        20) {
      _showGlassNotice(
        'شما همین الان در مقصد هستید.',
        icon: Icons.flag_rounded,
        colors: const [Colors.teal, Colors.green],
      );
      return;
    }

    _arrivalHandled = false;
    _offRouteStrikeCount = 0;
    _spokenStages.clear();

    try {
      final route =
          selectedRoute ?? await _computeRoute(origin, destination.point);
      if (!mounted) return;

      await _drawRoute(route.geometry);
      ref.read(activeNavigationProvider.notifier).setNavigation(
            ActiveNavigation(
              route: route,
              state: NavigationState.navigating,
              remainingDistanceKm: route.distanceKm,
            ),
          );

      _showGlassNotice(
        'مسیریابی آغاز شد',
        icon: Icons.navigation_rounded,
        colors: const [Color(0xFF22C55E), Color(0xFF0EA5E9)],
      );

      if (route.instructions.isNotEmpty && ref.read(ttEnabledProvider)) {
        _lastSpokenInstructionIndex = 0;
        // پیام شروع، خودِ مرحلهٔ دور اولین مانور است؛ دوباره تکرار نشود.
        _spokenStages.addAll(const [0, 1]);
        final voice = ref.read(ttsServiceProvider)
          ..setVolume(ref.read(ttsVolumeProvider))
          ..setPlaybackRate(ref.read(ttsRateProvider));
        voice.playCue('route_found');
      }

      // فعال کردن follow mode: دوربین پیکان را دنبال می‌کند
      setState(() => _cameraFollowsVehicle = true);

      // فعال‌کردن حالت رانندگی
      ref.read(drivingModeProvider.notifier).state = true;
    } catch (e) {
      _showGlassNotice('خطا در محاسبه مسیر: $e',
          icon: Icons.error_outline_rounded,
          colors: [Colors.red, Colors.orange]);
    }
  }

  Future<RouteInfo> _computeRoute(LatLng origin, LatLng destination) async {
    // فقط موتور انتخاب‌شده‌ی فعلی اجرا می‌شود. در حالت آفلاین، هیچ fallback
    // آنلاینی مجاز نیست؛ اگر مسیر معتبر روی گراف واقعی .abm پیدا نشود، همان
    // خطای واقعی به کاربر نشان داده می‌شود.
    final service = ref.read(routingServiceProvider);
    final route = await service.calculateRoute(
      origin: origin,
      destination: destination,
      avoidUnpavedRoads: ref.read(appearanceSettingsProvider).avoidUnpavedRoads,
      avoidTolls: ref.read(appearanceSettingsProvider).avoidTolls,
    );
    if (route != null) return route;
    throw Exception(
        service.lastError ?? 'مسیری روی شبکهٔ واقعی جاده‌ها پیدا نشد');
  }

  void _rerouteOffPath(double deviationMeters) async {
    if (_isRerouting) return;
    _isRerouting = true;
    _lastRerouteAt = DateTime.now();

    final destination = ref.read(selectedDestinationProvider);
    final vehiclePosition = ref.read(vehiclePositionProvider).value;

    if (destination == null || vehiclePosition == null) {
      _isRerouting = false;
      return;
    }

    if (ref.read(alertsVoiceEnabledProvider)) {
      final voice = ref.read(ttsServiceProvider)
        ..setVolume(ref.read(ttsVolumeProvider))
        ..setPlaybackRate(ref.read(ttsRateProvider));
      voice.playCue('off_route');
    }
    _showGlassNotice(
      'از مسیر خارج شدید؛ مسیر جدید در حال محاسبه است',
      icon: Icons.alt_route_rounded,
      colors: const [Color(0xFFF59E0B), Color(0xFFEF4444)],
      duration: const Duration(seconds: 4),
    );

    try {
      final origin = LatLng(vehiclePosition.lat, vehiclePosition.lng);
      final route = await _computeRoute(origin, destination.point);

      if (!mounted || ref.read(activeNavigationProvider) == null) return;

      await _drawRoute(route.geometry);

      ref.read(activeNavigationProvider.notifier).setNavigation(
            ActiveNavigation(
              route: route,
              state: NavigationState.navigating,
              remainingDistanceKm: route.distanceKm,
            ),
          );

      _showGlassNotice(
        'مسیر جدید آماده است',
        icon: Icons.route_rounded,
        colors: const [Color(0xFF8B5CF6), Color(0xFF3B82F6)],
      );

      _arrivalHandled = false;
      _lastSpokenInstructionIndex = -1;
      _spokenStages.clear();
      if (route.instructions.isNotEmpty && ref.read(ttEnabledProvider)) {
        _lastSpokenInstructionIndex = 0;
        // پیام شروع، خودِ مرحلهٔ دور اولین مانور است؛ دوباره تکرار نشود.
        _spokenStages.addAll(const [0, 1]);
        final voice = ref.read(ttsServiceProvider)
          ..setVolume(ref.read(ttsVolumeProvider))
          ..setPlaybackRate(ref.read(ttsRateProvider));
        voice.playCue('recalculating_route');
      }
    } finally {
      _isRerouting = false;
    }
  }

  /// مسیر را فقط برای لایهٔ مسیر نرم می‌کند؛ هندسهٔ خودِ نقشه و خیابان‌ها
  /// دست‌نخورده می‌مانند. فقط رأس‌هایی که واقعاً بیانگر یک قوسِ ملایمِ خیابان
  /// هستند smooth می‌شوند (زاویهٔ تغییر جهت کوچک)؛ رأس‌های تیز — تقاطع‌ها،
  /// گوشه‌های میدان، پیچ‌های واقعی خیابان — دست‌نخورده و کاملاً گوشه‌دار
  /// می‌مانند تا شکلِ رسم‌شده دقیقاً منطبق با دیتای واقعیِ نقشه بماند.
  List<LatLng> _smoothRouteGeometry(List<LatLng> geometry) {
    if (geometry.length < 3) return geometry;

    // فقط بندهای کوتاه (نمایانگر یک نقطهٔ داخلیِ زنجیرهٔ ادغام‌شده، نه یک
    // خیابان مجزا) و با زاویهٔ بازِ کافی (پیچِ ملایم، نه تقاطع/گوشهٔ تیز)
    // کاندید smoothing هستند.
    const maxSegmentMeters = 35.0; // طول بند برای واجد شرایط بودن
    const minAngleDegForSmoothing = 150.0; // زاویهٔ بازتر یعنی پیچ ملایم‌تر
    const samples = 6;

    double distMeters(LatLng a, LatLng b) {
      const R = 6371000.0;
      final dLat = (b.latitude - a.latitude) * math.pi / 180.0;
      final dLon = (b.longitude - a.longitude) * math.pi / 180.0;
      final lat1 = a.latitude * math.pi / 180.0;
      final lat2 = b.latitude * math.pi / 180.0;
      final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
          math.cos(lat1) *
              math.cos(lat2) *
              math.sin(dLon / 2) *
              math.sin(dLon / 2);
      return 2 * R * math.atan2(math.sqrt(h), math.sqrt(1 - h));
    }

    // زاویهٔ داخلیِ رأس b بین a→b→c؛ 180 یعنی کاملاً مستقیم، هرچه کمتر یعنی تیزتر.
    double interiorAngleDeg(LatLng a, LatLng b, LatLng c) {
      final v1x = a.longitude - b.longitude;
      final v1y = a.latitude - b.latitude;
      final v2x = c.longitude - b.longitude;
      final v2y = c.latitude - b.latitude;
      final dot = v1x * v2x + v1y * v2y;
      final mag1 = math.sqrt(v1x * v1x + v1y * v1y);
      final mag2 = math.sqrt(v2x * v2x + v2y * v2y);
      if (mag1 == 0 || mag2 == 0) return 180.0;
      final cosA = (dot / (mag1 * mag2)).clamp(-1.0, 1.0);
      return math.acos(cosA) * 180.0 / math.pi;
    }

    LatLng mid(LatLng a, LatLng b) => LatLng(
          (a.latitude + b.latitude) / 2.0,
          (a.longitude + b.longitude) / 2.0,
        );

    final out = <LatLng>[geometry.first];

    for (var i = 1; i < geometry.length - 1; i++) {
      final prev = geometry[i - 1];
      final control = geometry[i];
      final next = geometry[i + 1];

      final segIn = distMeters(prev, control);
      final segOut = distMeters(control, next);
      final angle = interiorAngleDeg(prev, control, next);

      final eligible = segIn <= maxSegmentMeters &&
          segOut <= maxSegmentMeters &&
          angle >= minAngleDegForSmoothing;

      if (!eligible) {
        // رأس تیز/تقاطع: دقیقاً همان نقطهٔ واقعیِ نقشه را نگه می‌داریم.
        out.add(control);
        continue;
      }

      final start = mid(prev, control);
      final end = mid(control, next);

      for (var j = 1; j <= samples; j++) {
        final t = j / samples;
        final mt = 1.0 - t;
        out.add(LatLng(
          mt * mt * start.latitude +
              2 * mt * t * control.latitude +
              t * t * end.latitude,
          mt * mt * start.longitude +
              2 * mt * t * control.longitude +
              t * t * end.longitude,
        ));
      }
    }

    out.add(geometry.last);
    return out;
  }

  Future<void> _drawRoute(List<LatLng> geometry) async {
    // خط مسیر روی Canvas آفلاین توسط routeGeometry رسم می‌شود. MapLibre و
    // GeoJSON source آنلاین از این build حذف شده‌اند.
  }

  Map<String, dynamic> _lineStringFrom(List<LatLng> geometry) => {
        'type': 'FeatureCollection',
        'features': [
          {
            'type': 'Feature',
            'properties': <String, dynamic>{},
            'geometry': {
              'type': 'LineString',
              'coordinates':
                  geometry.map((p) => [p.longitude, p.latitude]).toList(),
            },
          },
        ],
      };

  Future<void> _clearRoute() async {
    // فقط تغییر مقصد کافی نیست؛ شاخص route انتخاب‌شده و خود widget نقشه
    // نیز باید در همان frame به وضعیت بدون مسیر برگردند.
    ref.read(selectedRouteCandidateIndexProvider.notifier).state = 0;
    if (ref.read(selectedDestinationProvider) != null) {
      ref.read(selectedDestinationProvider.notifier).state = null;
    }
    if (mounted) setState(() {});
  }

  void _takeManualCameraControl() {
    if (!_cameraFollowsVehicle) return;
    setState(() => _cameraFollowsVehicle = false);
    _persistMapCameraSoon();
    // دوربین دیگر پیکان را دنبال نمی‌کند تا کاربر دوباره روی دکمه my_location بزند
  }

  void _acceptNavigationSignal(VehiclePosition pos) {
    _lastNavigationSignal = pos;
    _lastNavigationSignalAt = DateTime.now();
    _longTunnelEstimateExhausted = false;
    final nav = ref.read(activeNavigationProvider);
    if (nav != null) {
      _tunnelRouteProgressM =
          _projectRouteProgressMeters(pos, nav.route.geometry);
    }
    if (_tunnelEstimatedPosition != null) {
      _clearLongTunnelEstimate(notify: true);
      AbmDebugLog.addGps('GPS: فیکس بازگشت — پایان برآورد تونل');
    }
  }

  void _advanceLongTunnelEstimate() {
    if (!mounted) return;
    final nav = ref.read(activeNavigationProvider);
    final last = _lastNavigationSignal;
    final lastAt = _lastNavigationSignalAt;
    if (nav == null ||
        last == null ||
        lastAt == null ||
        nav.route.geometry.length < 2 ||
        last.isEstimated ||
        last.speedKmh < _minimumTunnelEstimateSpeedKmh) {
      _clearLongTunnelEstimate();
      return;
    }

    final now = DateTime.now();
    if (_longTunnelEstimateExhausted) return;
    final silence = now.difference(lastAt);
    if (silence < _longTunnelSilenceBeforeStart) return;

    _tunnelEstimateStartedAt ??= now;
    final estimatedFor = now.difference(_tunnelEstimateStartedAt!);
    if (estimatedFor > _maxLongTunnelEstimate) {
      if (_tunnelEstimatedPosition != null) {
        AbmDebugLog.add(
            'تونل: سقف ۲۵ ثانیهٔ تخمین رسید — توقف و حذف موقعیت تخمینی');
        // نگه‌داشتن آخرین نقطهٔ ساختگی باعث می‌شد banner «موقعیت تخمینی»
        // تا بازگشت GPS برای همیشه دیده شود. پس از سقف مجاز، marker به
        // جریان عادی موقعیت برمی‌گردد و فقط از ساخت estimate بعدی جلوگیری
        // می‌کنیم.
        _clearLongTunnelEstimate();
        _longTunnelEstimateExhausted = true;
        if (mounted) setState(() {});
      }
      return;
    }

    final previousAt = _lastTunnelEstimateAt ?? lastAt;
    final deltaSeconds = now.difference(previousAt).inMilliseconds / 1000.0;
    if (deltaSeconds <= 0) return;
    _lastTunnelEstimateAt = now;

    // پس از بیست ثانیه، سرعت را به‌آرامی کم می‌کنیم. بدون odometer/IMU
    // کالیبره‌شده نباید تا انتهای تونل با سرعت آخرین GPS کورکورانه برویم.
    final seconds = estimatedFor.inMilliseconds / 1000.0;
    final speedFactor = (seconds <= 20
            ? 1.0
            : (1.0 - ((seconds - 20) / 100) * 0.7).clamp(0.3, 1.0))
        .toDouble();
    final speedKmh = (last.speedKmh * speedFactor).clamp(0.0, 130.0).toDouble();
    final nextProgress =
        _tunnelRouteProgressM + (speedKmh / 3.6) * deltaSeconds;
    final sample = _routeSampleAtMeters(nav.route.geometry, nextProgress);
    if (sample == null) return;
    _tunnelRouteProgressM = sample.progressMeters;
    final estimated = VehiclePosition(
      lat: sample.point.latitude,
      lng: sample.point.longitude,
      headingDeg: sample.headingDeg,
      speedKmh: speedKmh,
      // به UI و map matching نشان می‌دهیم که با گذر زمان اطمینان کم می‌شود.
      accuracyM: (last.accuracyM + seconds * 5).clamp(8.0, 500.0).toDouble(),
      isEstimated: true,
    );

    final firstEstimate = _tunnelEstimatedPosition == null;
    _tunnelEstimatedPosition = estimated;
    if (firstEstimate) {
      AbmDebugLog.addGps(
          'GPS: افت طولانی سیگنال — برآورد محدود مسیرمحور فعال شد');
    }
    _updateNavigationProgress(estimated, nav, estimated: true);
    setState(() {});
  }

  void _clearLongTunnelEstimate({bool notify = false}) {
    final hadEstimate = _tunnelEstimatedPosition != null;
    _tunnelEstimatedPosition = null;
    _tunnelEstimateStartedAt = null;
    _lastTunnelEstimateAt = null;
    _longTunnelEstimateExhausted = false;
    if (notify && hadEstimate && mounted) setState(() {});
  }

  double _projectRouteProgressMeters(
      VehiclePosition position, List<LatLng> geometry) {
    if (geometry.length < 2) return 0;
    var bestDistance = double.infinity;
    var bestProgress = 0.0;
    var prefix = 0.0;
    for (var i = 0; i < geometry.length - 1; i++) {
      final a = geometry[i];
      final b = geometry[i + 1];
      final projected = _projectOnSegment(position.lat, position.lng, a, b);
      if (projected.distanceMeters < bestDistance) {
        bestDistance = projected.distanceMeters;
        bestProgress = prefix + projected.segmentMeters * projected.t;
      }
      prefix += projected.segmentMeters;
    }
    return bestProgress;
  }

  /// Snap دائمی خودرو به نزدیک‌ترین قطعهٔ خیابان مسیر. زاویه از خودِ قطعه
  /// استخراج می‌شود تا تکان قطب‌نما یا heading خام GPS نتواند خودرو را به
  /// پهلو بچرخاند. بیرون از حریم 45 متری مسیر، دادهٔ خام حفظ می‌شود تا
  /// تشخیص خروج از مسیر همچنان ممکن باشد.
  ///
  /// باگِ قبلی («خودرو هنگام مسیریابی می‌پرد»): این تابع هر بار (تا با نرخ
  /// ۶۰fps از navigationPositionProvider) نزدیک‌ترین نقطه را با یک
  /// جست‌وجوی *سراسری* روی کل segmentهای مسیر پیدا می‌کرد — بدون هیچ
  /// حافظه‌ای از پیشرفتِ قبلی. در هر مسیری که از نزدیکیِ خودش دوباره رد
  /// می‌شود (لِینِ برگشت، دوربرگردان، رمپِ بزرگراه، دو خیابانِ موازیِ
  /// نزدیک به هم)، یک فیکسِ GPS با چند متر خطا کافی بود که نزدیک‌ترین‌نقطه
  /// یک‌دفعه از segmentِ درستِ جلوی خودرو به segmentِ دیگری (جلوتر یا حتی
  /// عقب‌تر روی مسیر) عوض شود — یعنی همان پرشِ گزارش‌شده، چون هم مارکر و
  /// هم دوربینِ دنبال‌کننده مستقیماً از خروجیِ همین تابع تغذیه می‌کنند.
  ///
  /// راه‌حل: بعد از اولین تطبیق، فقط در یک پنجره‌ی محدود (بر حسب متر، نه
  /// ایندکس) حولِ آخرین پیشرفتِ شناخته‌شده جست‌وجو می‌کنیم — پیشرفتِ مسیر
  /// نمی‌تواند در یک تیک به بخشِ کاملاً دیگری از مسیر بپرد. فقط اگر داخلِ
  /// همان پنجره چیزِ نزدیکی (کمتر از ۴۵ متر) پیدا نشد (فیکس گم شده،
  /// دوباره‌مسیریابی، شروعِ ناوبری) به جست‌وجوی کاملِ مسیر برمی‌گردیم.
  VehiclePosition? _matchPositionToRoute(
      VehiclePosition position, List<LatLng> geometry) {
    if (geometry.length < 2) return null;
    // موقعیت شبکه‌ای/فیکس کم‌دقت را به‌زور به مسیر نمی‌چسبانیم؛ این کار به‌ویژه
    // پس از بازگشت از تونل باعث انتخاب شاخهٔ موازی و پرش بزرگ خودرو می‌شد.
    final maxAccuracyM = position.isEstimated ? 120.0 : 30.0;
    if (!position.accuracyM.isFinite || position.accuracyM > maxAccuracyM) {
      return null;
    }

    if (!identical(_routeMatchGeometry, geometry)) {
      _routeMatchGeometry = geometry;
      _routeMatchCumulativeM = _buildCumulativeDistances(geometry);
      _routeMatchLastSegment = null;
      _routeMatchLastProgressM = null;
    }
    final cumulative = _routeMatchCumulativeM!;
    final lastSegmentCount = geometry.length - 2;

    const backWindowM = 80.0;
    const aheadWindowM = 500.0;
    var startIdx = 0;
    var endIdx = lastSegmentCount;
    final lastIdx = _routeMatchLastSegment;
    if (lastIdx != null && lastIdx >= 0 && lastIdx <= lastSegmentCount) {
      final lastProgress = cumulative[lastIdx];
      final lo = lastProgress - backWindowM;
      final hi = lastProgress + aheadWindowM;
      var s = lastIdx;
      while (s > 0 && cumulative[s] > lo) s--;
      var e = lastIdx;
      while (e < lastSegmentCount && cumulative[e] < hi) e++;
      startIdx = s;
      endIdx = e;
    }

    var best = _bestSegmentMatch(position, geometry, startIdx, endIdx);
    if (best == null || best.distanceMeters > 45) {
      // پنجره چیزِ نزدیکی نداشت — بازگشت به جست‌وجوی کاملِ مسیر.
      best = _bestSegmentMatch(position, geometry, 0, lastSegmentCount);
    }
    if (best == null || best.distanceMeters > 45) {
      return null;
    }

    final progressM = cumulative[best.segmentIndex] +
        best.projection.segmentMeters * best.projection.t;
    final lastProgressM = _routeMatchLastProgressM;
    // وقتی مسیر از نزدیک خودش عبور می‌کند یا GPS یک فیکس عقب می‌فرستد، نزدیک‌ترین
    // قطعه می‌تواند ده‌ها متر پشت خودرو باشد. این مقدار نباید مستقیم به marker
    // برگردد، زیرا animation این مرحله را پشت سر گذاشته است. پس فقط نوسان کوچک
    // ۱۵ متری مجاز است؛ برگشت بزرگ تا فیکس/مسیر معتبر بعدی نگه داشته می‌شود.
    if (lastProgressM != null && progressM < lastProgressM - 15.0) {
      final held = _routeSampleAtMeters(geometry, lastProgressM);
      if (held != null) {
        return VehiclePosition(
          lat: held.point.latitude,
          lng: held.point.longitude,
          headingDeg: held.headingDeg,
          speedKmh: position.speedKmh,
          accuracyM: position.accuracyM,
          isEstimated: position.isEstimated,
        );
      }
      return null;
    }

    _routeMatchLastSegment = best.segmentIndex;
    _routeMatchLastProgressM = progressM;
    final a = geometry[best.segmentIndex];
    final b = geometry[best.segmentIndex + 1];
    final t = best.projection.t;
    return VehiclePosition(
      lat: a.latitude + (b.latitude - a.latitude) * t,
      lng: a.longitude + (b.longitude - a.longitude) * t,
      headingDeg: _bearingBetween(a, b),
      speedKmh: position.speedKmh,
      accuracyM: position.accuracyM,
      isEstimated: position.isEstimated,
    );
  }

  _RouteMatch? _bestSegmentMatch(VehiclePosition position,
      List<LatLng> geometry, int startIdx, int endIdx) {
    var bestDistance = double.infinity;
    _RouteMatch? best;
    for (var i = startIdx; i <= endIdx; i++) {
      final a = geometry[i];
      final b = geometry[i + 1];
      final projection = _projectOnSegment(position.lat, position.lng, a, b);
      if (projection.distanceMeters < bestDistance) {
        bestDistance = projection.distanceMeters;
        best = _RouteMatch(segmentIndex: i, projection: projection);
      }
    }
    return best;
  }

  List<double> _buildCumulativeDistances(List<LatLng> geometry) {
    final cumulative = List<double>.filled(geometry.length, 0);
    for (var i = 1; i < geometry.length; i++) {
      cumulative[i] =
          cumulative[i - 1] + _calculateDistance(geometry[i - 1], geometry[i]);
    }
    return cumulative;
  }

  _RouteSample? _routeSampleAtMeters(List<LatLng> geometry, double meters) {
    if (geometry.length < 2) return null;
    var remaining = meters.clamp(0.0, double.infinity).toDouble();
    var prefix = 0.0;
    for (var i = 0; i < geometry.length - 1; i++) {
      final a = geometry[i];
      final b = geometry[i + 1];
      final segment = _calculateDistance(a, b);
      if (segment <= 0.01) continue;
      if (remaining <= segment || i == geometry.length - 2) {
        final t = (remaining / segment).clamp(0.0, 1.0).toDouble();
        return _RouteSample(
          LatLng(
            a.latitude + (b.latitude - a.latitude) * t,
            a.longitude + (b.longitude - a.longitude) * t,
          ),
          _bearingBetween(a, b),
          prefix + segment * t,
        );
      }
      remaining -= segment;
      prefix += segment;
    }
    final last = geometry.last;
    return _RouteSample(last, 0.0, prefix);
  }

  _SegmentProjection _projectOnSegment(
      double lat, double lng, LatLng a, LatLng b) {
    const metersPerDegree = 111320.0;
    final cosLat = math.cos(((a.latitude + b.latitude) / 2) * math.pi / 180);
    final bx = (b.longitude - a.longitude) * metersPerDegree * cosLat;
    final by = (b.latitude - a.latitude) * metersPerDegree;
    final px = (lng - a.longitude) * metersPerDegree * cosLat;
    final py = (lat - a.latitude) * metersPerDegree;
    final segmentSquared = bx * bx + by * by;
    final t = (segmentSquared <= 0
            ? 0.0
            : ((px * bx + py * by) / segmentSquared).clamp(0.0, 1.0))
        .toDouble();
    final dx = px - bx * t;
    final dy = py - by * t;
    return _SegmentProjection(
      t: t,
      segmentMeters: math.sqrt(segmentSquared),
      distanceMeters: math.sqrt(dx * dx + dy * dy),
    );
  }

  double _bearingBetween(LatLng a, LatLng b) {
    final y = (b.longitude - a.longitude) *
        math.cos((a.latitude + b.latitude) * math.pi / 360);
    final x = b.latitude - a.latitude;
    return (math.atan2(y, x) * 180 / math.pi + 360) % 360;
  }

  Future<void> _stopNavigation() async {
    // نخست source نیتیو را خالی می‌کنیم؛ حذف state نباید باعث باقی‌ماندن
    // خط مسیر روی MapLibre شود.
    await _clearRoute();
    ref.read(activeNavigationProvider.notifier).clear();
    ref.read(selectedDestinationProvider.notifier).state = null;
    await ref.read(ttsServiceProvider).stop();
    _offRouteStrikeCount = 0;
    _isRerouting = false;
    _lastRerouteAt = null;
    _clearLongTunnelEstimate();
    _routeMatchGeometry = null;
    _routeMatchCumulativeM = null;
    _routeMatchLastSegment = null;
    _routeMatchLastProgressM = null;

    // غیرفعال کردن حالت رانندگی
    ref.read(drivingModeProvider.notifier).state = false;

    setState(() {});
  }

  void _updateNavigationProgress(
    VehiclePosition pos,
    ActiveNavigation nav, {
    bool estimated = false,
  }) {
    final currentLoc = LatLng(pos.lat, pos.lng);

    if (!estimated &&
        nav.state == NavigationState.navigating &&
        !_isRerouting) {
      final distFromRoute =
          _distanceToRouteMeters(currentLoc, nav.route.geometry);
      const offRouteThresholdM = 45.0;
      if (distFromRoute > offRouteThresholdM) {
        _offRouteStrikeCount++;
      } else {
        _offRouteStrikeCount = 0;
      }

      const requiredStrikes = 5;
      final cooldownOk = _lastRerouteAt == null ||
          DateTime.now().difference(_lastRerouteAt!) >
              const Duration(seconds: 8);

      if (_offRouteStrikeCount >= requiredStrikes && cooldownOk) {
        _rerouteOffPath(distFromRoute);
        return;
      }
    }

    final lastIndex = nav.route.instructions.length - 1;
    int nearestInstructionIndex = nav.currentInstructionIndex;
    double minDistance = double.infinity;

    for (int i = nav.currentInstructionIndex;
        i < nav.route.instructions.length;
        i++) {
      final instruction = nav.route.instructions[i];
      final distance = _calculateDistance(currentLoc, instruction.location);

      if (distance < minDistance) {
        minDistance = distance;
        nearestInstructionIndex = i;
      }

      if (distance < 30 && i < lastIndex) {
        nearestInstructionIndex = math.min(i + 1, lastIndex);
      }
    }

    double remainingDistance = 0;
    for (int i = nearestInstructionIndex;
        i < nav.route.instructions.length;
        i++) {
      remainingDistance += nav.route.instructions[i].distanceMeters;
    }

    final nextLoc = nav.route.instructions[nearestInstructionIndex].location;
    final distToNext = _calculateDistance(currentLoc, nextLoc);
    final distToDestination =
        _calculateDistance(currentLoc, nav.route.instructions.last.location);

    ref.read(activeNavigationProvider.notifier).updateProgress(
          nearestInstructionIndex,
          remainingDistance / 1000,
          distanceToNextManeuverM: distToNext,
        );

    // ---- زمان‌بندی اعلام‌های صوتی ----
    // پیش‌تر فقط با «عوض‌شدن ایندکس مانور» یک‌بار حرف زده می‌شد؛ برای همین
    // پیام‌ها گاهی خیلی زود (وقتی هنوز صدها متر مانده) یا خیلی دیر (وقتی از
    // پیچ رد شده بودی) پخش می‌شدند. حالا اعلام‌ها بر اساس فاصلهٔ واقعی تا
    // مانور و سرعت خودرو در مرحله‌های استاندارد پخش می‌شوند.
    if (nearestInstructionIndex != _lastSpokenInstructionIndex) {
      _lastSpokenInstructionIndex = nearestInstructionIndex;
      // مرحله‌های مانورهای گذشته دیگر لازم نیستند.
      _spokenStages.removeWhere((key) => key ~/ 10 < nearestInstructionIndex);
    }

    if (ref.read(ttEnabledProvider)) {
      final instr = nav.route.instructions[nearestInstructionIndex];
      final speedKmh =
          ref.read(navigationPositionProvider).value?.speedKmh ?? 0;
      final speedMs = (speedKmh / 3.6).clamp(0.0, 60.0);

      // فاصلهٔ «اعلام فوری» با سرعت بالا می‌رود تا صدا دقیقاً قبل از پیچ
      // تمام شود (تقریباً ۶ ثانیه جلوتر، حداقل ۴۰ و حداکثر ۱۵۰ متر).
      final imminentAt = (speedMs * 6).clamp(40.0, 150.0);
      final firstAlert =
          ref.read(voiceFirstAlertDistanceProvider).clamp(50.0, 1000.0);
      final stages = <int, double>{
        0: firstAlert,
        1: (firstAlert * 0.5).clamp(50.0, firstAlert),
        2: (firstAlert * 0.2).clamp(40.0, firstAlert),
        3: imminentAt.clamp(40.0, firstAlert),
      };

      int? stageToSpeak;
      for (final entry in stages.entries) {
        final key = nearestInstructionIndex * 10 + entry.key;
        if (_spokenStages.contains(key)) continue;
        if (distToNext <= entry.value) {
          // مرحله‌های دورتری که رد شده‌ایم را بدون حرف‌زدن مصرف‌شده می‌کنیم.
          _spokenStages.add(key);
          stageToSpeak = entry.key;
        }
      }

      // فقط نزدیک‌ترین مرحلهٔ فعال گفته می‌شود (نه چند پیام پشت‌سرهم).
      if (stageToSpeak != null) {
        final voice = ref.read(ttsServiceProvider)
          ..setVolume(ref.read(ttsVolumeProvider))
          ..setPlaybackRate(ref.read(ttsRateProvider));

        voice.playCue(VoicePackFa.cueForManeuver(
          type: instr.type,
          modifier: instr.modifier,
          exit: instr.exit,
        ));
      }
    }

    if (!_arrivalHandled &&
        distToDestination < 20 &&
        nearestInstructionIndex >= lastIndex) {
      _arrivalHandled = true;
      _onArrived();
    }
  }

  double _distanceToRouteMeters(LatLng p, List<LatLng> geometry) {
    if (geometry.isEmpty) return double.infinity;
    if (geometry.length == 1) return _calculateDistance(p, geometry.first);

    double minDist = double.infinity;
    for (var i = 0; i < geometry.length - 1; i++) {
      final d = _distanceToSegmentMeters(p, geometry[i], geometry[i + 1]);
      if (d < minDist) minDist = d;
    }
    return minDist;
  }

  double _distanceToSegmentMeters(LatLng p, LatLng a, LatLng b) {
    const metersPerDegLat = 111320.0;
    final metersPerDegLng = 111320.0 * math.cos(degToRad(p.latitude));

    double toX(LatLng q) => (q.longitude - a.longitude) * metersPerDegLng;
    double toY(LatLng q) => (q.latitude - a.latitude) * metersPerDegLat;

    const ax = 0.0, ay = 0.0;
    final bx = toX(b), by = toY(b);
    final px = toX(p), py = toY(p);

    final dx = bx - ax, dy = by - ay;
    final lenSq = dx * dx + dy * dy;
    var t = lenSq == 0 ? 0.0 : ((px - ax) * dx + (py - ay) * dy) / lenSq;
    t = t.clamp(0.0, 1.0);
    final projX = ax + t * dx, projY = ay + t * dy;
    final ddx = px - projX, ddy = py - projY;
    return math.sqrt(ddx * ddx + ddy * ddy);
  }

  double _calculateDistance(LatLng point1, LatLng point2) {
    const earthRadius = 6371000.0;

    final lat1 = degToRad(point1.latitude);
    final lat2 = degToRad(point2.latitude);
    final dLat = degToRad(point2.latitude - point1.latitude);
    final dLng = degToRad(point2.longitude - point1.longitude);

    final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1) *
            math.cos(lat2) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);

    final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));

    return earthRadius * c;
  }

  void _onArrived() {
    _showGlassNotice(
      'به مقصد رسیدید!',
      icon: Icons.flag_rounded,
      colors: const [AppColors.speedLow, Color(0xFF10D15C)],
    );
    if (ref.read(ttEnabledProvider)) {
      final voice = ref.read(ttsServiceProvider);
      voice.playCue(VoicePackFa.arrived);
    }

    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        _stopNavigation();
      }
    });
  }
}

class _GpsWarningBanner extends ConsumerWidget {
  final LocationReadiness state;
  const _GpsWarningBanner({super.key, required this.state});

  String get _message {
    switch (state) {
      case LocationReadiness.serviceDisabled:
        return 'GPS دستگاه خاموش است. لطفاً آن را روشن کنید.';
      case LocationReadiness.permissionDenied:
        return 'برای ناوبری به مجوز موقعیت مکانی نیاز است. (ضربه بزنید تا دوباره بپرسیم)';
      case LocationReadiness.permissionDeniedForever:
        return 'مجوز موقعیت مکانی رد شده. برای فعال‌سازی از تنظیمات، ضربه بزنید.';
      case LocationReadiness.ready:
        return '';
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: state == LocationReadiness.ready
          ? null
          : () => ref.read(retryLocationPermissionProvider)(),
      child: _buildContent(),
    );
  }

  Widget _buildContent() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.fromLTRB(10, 10, 16, 10),
          decoration: BoxDecoration(
            color: const Color(0xFF1B1712).withOpacity(.72),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFFFB84D).withOpacity(.35)),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFF8A00).withOpacity(.22),
                blurRadius: 22,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [Color(0xFFFFB84D), Color(0xFFFF7A00)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: const Icon(Icons.gps_off_rounded,
                    color: Colors.white, size: 18),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  _message,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                    height: 1.3,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// وقتی مجوز و سرویس مکان هر دو آماده‌اند اما بعد از مدتی معقول هنوز هیچ
/// فیکس GPS نرسیده (به‌جای سکوت کامل قبلی — نگاه کنید به
/// [_HomeScreenState._armGpsAcquireWatchdog]).
class _EstimatedLocationBanner extends StatelessWidget {
  const _EstimatedLocationBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xE6233B55),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF75D6FF).withOpacity(.55)),
      ),
      child: const Row(
        children: [
          Icon(Icons.network_check_rounded, color: Color(0xFF9FE7FF), size: 19),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'موقعیت تخمینی است؛ در انتظار بازگشت GPS',
              style: TextStyle(color: Colors.white, fontSize: 12.5),
            ),
          ),
        ],
      ),
    );
  }
}

class _GpsStuckBanner extends StatelessWidget {
  final VoidCallback onRetry;
  const _GpsStuckBanner({super.key, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onRetry,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
          child: Container(
            padding: const EdgeInsets.fromLTRB(10, 10, 16, 10),
            decoration: BoxDecoration(
              color: const Color(0xFF1B1712).withOpacity(.72),
              borderRadius: BorderRadius.circular(18),
              border:
                  Border.all(color: const Color(0xFFFFB84D).withOpacity(.35)),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF8A00).withOpacity(.22),
                  blurRadius: 22,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [Color(0xFFFFB84D), Color(0xFFFF7A00)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: const Icon(Icons.gps_not_fixed_rounded,
                      color: Colors.white, size: 18),
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    'دریافت موقعیت GPS بیش از حد معمول طول کشیده. مطمئن شوید در فضای باز هستید، سپس برای تلاش دوباره ضربه بزنید.',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                      height: 1.3,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _RouteChoiceStrip extends StatelessWidget {
  const _RouteChoiceStrip({
    required this.routes,
    required this.selectedIndex,
    required this.onSelect,
  });

  final List<RouteInfo> routes;
  final int selectedIndex;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) => DecoratedBox(
        decoration: BoxDecoration(
          color: AppColors.frameBackground(context).withValues(alpha: 0.92),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(6),
          child: Row(
            children: [
              for (var index = 0; index < routes.length; index++)
                Expanded(
                  child: GestureDetector(
                    onTap: () => onSelect(index),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 160),
                      margin: EdgeInsets.only(
                          right: index == 0 ? 4 : 0,
                          left: index == routes.length - 1 ? 4 : 0),
                      padding: const EdgeInsets.symmetric(
                          vertical: 8, horizontal: 4),
                      decoration: BoxDecoration(
                        color: index == selectedIndex
                            ? const Color(0xFF2FE6C4).withValues(alpha: 0.22)
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(11),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            index == selectedIndex
                                ? 'مسیر انتخاب‌شده'
                                : 'مسیر ${index + 1}',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: index == selectedIndex
                                  ? const Color(0xFF2FE6C4)
                                  : Colors.white70,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '${routes[index].durationMin.round()} دقیقه',
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 12),
                          ),
                          Text(
                            '${routes[index].distanceKm.toStringAsFixed(1)} کیلومتر',
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                color: Colors.white60, fontSize: 10),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
}

class _DestinationCard extends ConsumerWidget {
  final SelectedDestination destination;
  final VoidCallback onClear;
  final VoidCallback? onStartNavigation;

  const _DestinationCard({
    required this.destination,
    required this.onClear,
    required this.onStartNavigation,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.glassPanel(context),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppColors.glassBorder(context)),
            boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 30)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.danger.withOpacity(.15),
                      ),
                      child: const Icon(Icons.location_on_rounded,
                          color: AppColors.danger, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            AppStrings.get(
                                context, ref, 'selected_destination'),
                            style: TextStyle(
                                color: AppColors.textSecondary(context),
                                fontSize: 12),
                          ),
                          Text(
                            destination.label ??
                                AppStrings.get(context, ref, 'point_on_map'),
                            textAlign: TextAlign.right,
                            style: TextStyle(
                                color: AppColors.textPrimary(context),
                                fontSize: 16,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      icon: Icon(Icons.close_rounded,
                          color: AppColors.textMuted(context)),
                      onPressed: onClear,
                    ),
                  ],
                ),
              ),
              Divider(
                  color: AppColors.textMuted(context).withOpacity(.15),
                  height: 1),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: GestureDetector(
                        onTap: onStartNavigation,
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: onStartNavigation == null
                                ? const LinearGradient(
                                    colors: [
                                      Color(0xFF475569),
                                      Color(0xFF334155)
                                    ],
                                  )
                                : AppColors.primaryGradient(context),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.navigation_rounded,
                                  color: Colors.white, size: 18),
                              const SizedBox(width: 8),
                              Text(
                                onStartNavigation == null
                                    ? AppStrings.get(
                                        context,
                                        ref,
                                        'finding_route_options',
                                      )
                                    : AppStrings.get(
                                        context, ref, 'start_routing'),
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    _ActionIconButton(
                      icon: Icons.star_border_rounded,
                      onTap: () =>
                          _showSavePointDialog(context, ref, destination),
                    ),
                    const SizedBox(width: 10),
                    _ActionIconButton(
                      icon: Icons.share_rounded,
                      onTap: () {
                        final uri =
                            'https://www.google.com/maps/search/?api=1&query=${destination.point.latitude},${destination.point.longitude}';
                        ref.read(shareServiceProvider).share(
                              uri,
                              subject:
                                  destination.label ?? 'مکان اشتراک‌گذاری شده',
                            );
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  void _showSavePointDialog(
      BuildContext context, WidgetRef ref, SelectedDestination destination) {
    final nameController = TextEditingController(text: destination.label ?? '');
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.background(context),
        title: Text(AppStrings.get(context, ref, 'add_current_location_title'),
            style: const TextStyle(color: Colors.white)),
        content: TextField(
          controller: nameController,
          autofocus: true,
          textAlign: TextAlign.right,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: AppStrings.get(context, ref, 'place_name_hint2'),
            hintStyle: TextStyle(color: AppColors.textMuted(context)),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(AppStrings.get(context, ref, 'cancel'))),
          TextButton(
            onPressed: () async {
              final name = nameController.text.trim();
              if (name.isEmpty) return;
              await ref.read(savedPlacesRepositoryProvider).add(
                    name: name,
                    latitude: destination.point.latitude,
                    longitude: destination.point.longitude,
                    category: 'favorite',
                  );
              if (ctx.mounted) Navigator.pop(ctx);
              if (context.mounted) {
                final message =
                    AppStrings.get(context, ref, 'point_saved_snackbar');
                unawaited(
                  ref.read(appNoticeProvider.notifier).show(
                        title: 'آبتین مپس',
                        message: message,
                        level: AppNoticeLevel.success,
                      ),
                );
                showGlassNotice(
                  context,
                  message,
                  icon: Icons.favorite_rounded,
                  colors: const [Color(0xFF7AD8A8), Color(0xFF3FAE73)],
                );
              }
            },
            child: Text(AppStrings.get(context, ref, 'save_label')),
          ),
        ],
      ),
    );
  }
}

class _ActionIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _ActionIconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          color: AppColors.surfaceMuted(context),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.glassBorder(context)),
        ),
        child: Icon(icon, color: AppColors.textSecondary(context), size: 22),
      ),
    );
  }
}

class _Compass extends StatelessWidget {
  final double mapBearingDeg;
  const _Compass({required this.mapBearingDeg});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 56,
      height: 56,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.black.withOpacity(.4),
        border: Border.all(color: Colors.white.withOpacity(.15)),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Transform.rotate(
            angle: -mapBearingDeg * 3.1415926535 / 180,
            child: CustomPaint(
                size: const Size(56, 56), painter: _CompassTicksPainter()),
          ),
          // برچسبِ «N» عمداً بیرونِ Transform.rotate بالا رسم می‌شود: قبلاً
          // همراهِ کل صفحه‌ی تیک‌ها می‌چرخید، یعنی خودِ حرفِ N هم دور محورش
          // می‌چرخید و در زوایای نزدیکِ ۹۰/۲۷۰ درجه کاملاً واژگون/ناخوانا
          // (شبیهِ حرفِ Z) دیده می‌شد. اینجا فقط *موقعیتِ* برچسب دور دایره
          // با هدینگ عوض می‌شود، ولی خودِ حرف همیشه ایستاده/خوانا می‌ماند —
          // دقیقاً رفتار قطب‌نمای اپ‌های ناوبری استاندارد.
          CustomPaint(
            size: const Size(56, 56),
            painter: _CompassNorthLabelPainter(mapBearingDeg: mapBearingDeg),
          ),
          Transform.rotate(
            angle: -mapBearingDeg * 3.1415926535 / 180,
            child: CustomPaint(
              size: const Size(30, 30),
              painter: _CompassNeedlePainter(
                southColor: AppColors.textSecondary(context),
              ),
            ),
          ),
          Container(
            width: 5,
            height: 5,
            decoration: const BoxDecoration(
                shape: BoxShape.circle, color: Colors.white),
          ),
        ],
      ),
    );
  }
}

class _CompassNorthLabelPainter extends CustomPainter {
  final double mapBearingDeg;
  _CompassNorthLabelPainter({required this.mapBearingDeg});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;
    final angle = -mapBearingDeg * 3.1415926535 / 180;
    final pos = Offset(
      center.dx + radius * math.sin(angle),
      center.dy - radius * math.cos(angle),
    );
    final textPainter = TextPainter(
      text: const TextSpan(
        text: 'N',
        style: TextStyle(
            color: AppColors.danger, fontSize: 10, fontWeight: FontWeight.bold),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    textPainter.paint(
      canvas,
      Offset(pos.dx - textPainter.width / 2, pos.dy - textPainter.height / 2),
    );
  }

  @override
  bool shouldRepaint(covariant _CompassNorthLabelPainter oldDelegate) =>
      oldDelegate.mapBearingDeg != mapBearingDeg;
}

class _CompassNeedlePainter extends CustomPainter {
  final Color southColor;
  _CompassNeedlePainter({required this.southColor});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final tip = size.height / 2 - 2;
    final tail = size.height / 2 - 2;
    const halfWidth = 4.0;

    final northPaint = Paint()..color = AppColors.danger;
    final southPaint = Paint()..color = southColor;

    final northPath = Path()
      ..moveTo(center.dx, center.dy - tip)
      ..lineTo(center.dx - halfWidth, center.dy)
      ..lineTo(center.dx + halfWidth, center.dy)
      ..close();

    final southPath = Path()
      ..moveTo(center.dx, center.dy + tail)
      ..lineTo(center.dx - halfWidth, center.dy)
      ..lineTo(center.dx + halfWidth, center.dy)
      ..close();

    canvas.drawPath(northPath, northPaint);
    canvas.drawPath(southPath, southPaint);
  }

  @override
  bool shouldRepaint(covariant _CompassNeedlePainter oldDelegate) =>
      oldDelegate.southColor != southColor;
}

class _CompassTicksPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;
    final tickPaint = Paint()
      ..color = Colors.white.withOpacity(.6)
      ..strokeWidth = 1.5;

    for (var i = 0; i < 4; i++) {
      final angle = (i * 90) * 3.1415926535 / 180;
      final outer = Offset(
        center.dx + radius * math.sin(angle),
        center.dy - radius * math.cos(angle),
      );
      final inner = Offset(
        center.dx + (radius - 5) * math.sin(angle),
        center.dy - (radius - 5) * math.cos(angle),
      );
      canvas.drawLine(inner, outer, tickPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  const _RoundIconButton(
      {required this.icon, required this.onTap, this.onLongPress});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: AppColors.primaryAccentDark(context),
          border: Border.all(color: AppColors.glassBorder(context)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.22),
              blurRadius: 14,
            ),
          ],
        ),
        child: Icon(
          icon,
          color: AppColors.primaryOnAccent(context),
          size: 22,
        ),
      ),
    );
  }
}

class _SpeedometerDial extends StatelessWidget {
  final double value;
  const _SpeedometerDial({required this.value});

  @override
  Widget build(BuildContext context) {
    const size = 96.0;
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.black.withOpacity(.6),
              border: Border.all(color: Colors.white.withOpacity(.1), width: 1),
              boxShadow: const [
                BoxShadow(color: Colors.black87, blurRadius: 12)
              ],
            ),
          ),
          CustomPaint(
            size: const Size(size, size),
            painter: _GradientArcPainter(
              progress: (value / 180).clamp(0, 1),
              colors: [Colors.green, Colors.yellow, Colors.red],
            ),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                value.round().toString(),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 34,
                  fontWeight: FontWeight.w800,
                  shadows: [
                    Shadow(
                        color: Colors.black87,
                        blurRadius: 8,
                        offset: Offset(0, 2))
                  ],
                ),
              ),
              Text(
                'km/h',
                style: TextStyle(
                  color: AppColors.textPrimary(context),
                  fontSize: 13,
                  shadows: const [
                    Shadow(
                        color: Colors.black87,
                        blurRadius: 6,
                        offset: Offset(0, 2))
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SpeedLimitSign extends StatelessWidget {
  final String value;
  const _SpeedLimitSign({required this.value});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final maxW =
            constraints.maxWidth.isFinite ? constraints.maxWidth : 67.0;
        final maxH =
            constraints.maxHeight.isFinite ? constraints.maxHeight : 67.0;
        final size = math.min(maxW, maxH) > 0 ? math.min(maxW, maxH) : 67.0;
        final scale = size / 67.0;

        return Stack(
          alignment: Alignment.center,
          children: [
            // عکسِ اصلیِ تابلو — بدون هیچ ColorFilter/تینتِ قرمزی رویش،
            // دقیقاً همان‌طور که در assets/images/speed-limit.webp ذخیره شده.
            Image.asset(
              'assets/images/speed-limit.webp',
              width: size,
              height: size,
              fit: BoxFit.contain,
            ),
            Text(
              value,
              style: TextStyle(
                color: Colors.black87,
                fontSize: 20 * scale,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        );
      },
    );
  }
}

class _GradientArcPainter extends CustomPainter {
  final double progress;
  final List<Color> colors;
  final double thickness;

  _GradientArcPainter({
    required this.progress,
    required this.colors,
    this.thickness = 6,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(thickness / 2, thickness / 2,
        size.width - thickness, size.height - thickness);
    const startAngle = 0.75 * math.pi;
    const sweepAngle = 1.5 * math.pi;

    final backgroundPaint = Paint()
      ..color = Colors.white.withOpacity(.05)
      ..style = PaintingStyle.stroke
      ..strokeWidth = thickness
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(rect, startAngle, sweepAngle, false, backgroundPaint);

    if (progress > 0) {
      final gradient = SweepGradient(
        startAngle: 0,
        endAngle: sweepAngle,
        colors: colors,
        transform: const GradientRotation(startAngle),
      );

      final paint = Paint()
        ..shader = gradient.createShader(rect)
        ..style = PaintingStyle.stroke
        ..strokeWidth = thickness
        ..strokeCap = StrokeCap.round;

      canvas.drawArc(rect, startAngle, sweepAngle * progress, false, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GradientArcPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

class _ActiveNavigationCard extends StatelessWidget {
  final ActiveNavigation navigation;
  final VoidCallback onClose;
  const _ActiveNavigationCard(
      {required this.navigation, required this.onClose});

  @override
  Widget build(BuildContext context) {
    final instruction = navigation.currentInstruction;
    final remainingKm = navigation.remainingDistanceKm;
    final remainingMin = navigation.route.distanceKm > 0
        ? (navigation.route.durationMin *
                (remainingKm / navigation.route.distanceKm))
            .round()
        : 0;
    final dNext = navigation.distanceToNextManeuverM;
    final nextText = dNext >= 1000
        ? '${(dNext / 1000).toStringAsFixed(1)} کیلومتر'
        : '${dNext.round()} متر';

    final eta = DateTime.now().add(Duration(minutes: remainingMin));
    final etaText =
        '${eta.hour.toString().padLeft(2, '0')}:${eta.minute.toString().padLeft(2, '0')}';

    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
          decoration: BoxDecoration(
            color: const Color(0x80182541), // Higher transparency (0x80 = 50%)
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white.withOpacity(.15)),
            boxShadow: const [
              BoxShadow(
                  color: Colors.black45, blurRadius: 26, offset: Offset(0, 10)),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  SizedBox(
                    width: 64,
                    height: 64,
                    child: Icon(
                      _getInstructionIcon(
                          instruction.type, instruction.modifier),
                      color: AppColors.speedLow,
                      size: 48,
                      shadows: [
                        Shadow(
                            color: AppColors.speedLow.withOpacity(.5),
                            blurRadius: 20),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        if (dNext > 0)
                          Text(
                            nextText,
                            textAlign: TextAlign.right,
                            style: const TextStyle(
                              color: AppColors.speedLow,
                              fontSize: 26, // Reduced from 32
                              fontWeight: FontWeight.w900,
                              letterSpacing: -0.5,
                            ),
                          ),
                        Text(
                          instruction.text,
                          textAlign: TextAlign.right,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15, // Reduced from 18
                            fontWeight: FontWeight.w600,
                            height: 1.2,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _NavStat(label: 'رسیدن', value: etaText),
                          _NavStat(
                              label: 'باقی‌مانده',
                              value:
                                  '${remainingKm.toStringAsFixed(1)} کیلومتر'),
                          _NavStat(label: 'زمان', value: '$remainingMin دقیقه'),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    GestureDetector(
                      onTap: onClose,
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white.withOpacity(.1),
                        ),
                        child: const Icon(Icons.close_rounded,
                            color: Colors.white70, size: 16),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  IconData _getInstructionIcon(String type, String? modifier) {
    switch (type) {
      case 'turn':
      case 'continue':
      case 'new name':
      case 'end of road':
        final m = modifier ?? '';
        if (m.contains('uturn')) {
          return m.contains('right')
              ? Icons.u_turn_right_rounded
              : Icons.u_turn_left_rounded;
        }
        if (m.contains('left')) return Icons.turn_left_rounded;
        if (m.contains('right')) return Icons.turn_right_rounded;
        if (m.contains('straight')) return Icons.straight_rounded;
        return Icons.arrow_upward_rounded;
      case 'arrive':
        return Icons.flag_rounded;
      case 'depart':
        return Icons.navigation_rounded;
      case 'merge':
        return Icons.merge_rounded;
      case 'roundabout':
      case 'rotary':
        return Icons.roundabout_right_rounded;
      default:
        return Icons.arrow_upward_rounded;
    }
  }
}

class _NavStat extends StatelessWidget {
  final String label;
  final String value;
  const _NavStat({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          value,
          style: TextStyle(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: 12,
              fontWeight: FontWeight.bold),
        ),
        Text(
          label,
          style: TextStyle(
              color: (Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black)
                  .withOpacity(.5),
              fontSize: 9),
        ),
      ],
    );
  }
}

double degToRad(double deg) => deg * (math.pi / 180.0);

/// اعتبارسنجی هگزِ ذخیره‌شده در [routeColorHexProvider] — اگر خراب/ناقص
/// باشد به [fallbackHex] برمی‌گردد تا رنگ سفارشیِ نامعتبر باعث کرش رندر
/// مسیر نشود.
String _normalizeHex(String hex, String fallbackHex) {
  final h = hex.trim();
  if (RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(h)) return h;
  return fallbackHex;
}

Color _hexToColorOrDefault(String hex, String fallbackHex) {
  final h = _normalizeHex(hex, fallbackHex).substring(1);
  return Color(int.parse('FF$h', radix: 16));
}
