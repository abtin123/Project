import 'dart:async';
import 'dart:math' as math;
import '../../../abtinmap/abm_graph.dart';
import '../../../abtinmap/abm_models.dart';
import '../data/location_service.dart';
import 'vehicle_position_animator.dart';

/// آخرین لایه‌ی pipeline موقعیت‌یابیِ ناوبری:
///
///   Raw GPS → Accuracy Check → Kalman Filter → Map Matching → Navigation Position
///
/// دو مرحله‌ی اول («Raw GPS» و «Accuracy Check + Kalman Filter») داخل
/// [LocationService] انجام می‌شوند (به [LocationRepository] نگاه کنید).
/// این کلاس فقط مرحله‌ی «Map Matching» (snap به نزدیک‌ترین یالِ گراف
/// جاده‌ی آفلاین) و تحویل نتیجه به [VehiclePositionAnimator] (که خروجیِ
/// نهاییِ ۶۰fps برای Map UI را می‌سازد) را اضافه می‌کند. UI نباید مستقیم
/// stream خام LocationService را بخواند — باید از [positionStream] این
/// کلاس (یا از animatedVehiclePositionProvider که این را wrap می‌کند)
/// استفاده کند.
class NavigationPositionController {
  final AbmGraph? _graph;
  final VehiclePositionAnimator _animator = VehiclePositionAnimator();
  StreamSubscription<VehiclePosition>? _sub;
  int _latestFixSequence = 0;

  /// دقتِ گزارش‌شده‌ی GPS بالاتر از این حد، برای map matching به‌عنوانِ
  /// نامعتبر در نظر گرفته می‌شود — snap کردنِ یک فیکسِ ۱۰۰ متری خطا روی
  /// جاده می‌تواند بدتر از نمایشِ خامِ آن باشد.
  static const double _maxAccuracyForSnapM = 30.0;
  static const double _maxEstimatedAccuracyForSnapM = 120.0;

  /// اگر نزدیک‌ترین یال بیش از این فاصله دارد، یعنی احتمالاً ماشین توی
  /// پارکینگ/محوطه‌ای خارج از گراف است — snap نکن، موقعیتِ خام را نگه دار.
  static const double _maxSnapDistanceM = 25.0;
  static const double _maxEstimatedSnapDistanceM = 35.0;

  NavigationPositionController({AbmGraph? graph}) : _graph = graph;

  Stream<VehiclePosition> get positionStream => _animator.stream;

  void attach(Stream<VehiclePosition> rawFiltered) {
    // graph.snap ناهم‌زمان است. با اتصال به stream تازه، همهٔ snapshotهای
    // در حال پردازش از اتصال قبلی را نامعتبر می‌کنیم؛ وگرنه پاسخ دیررسِ آن‌ها
    // می‌تواند پس از بازشدن مجدد نقشه/تغییر گراف، خودرو را به جای قبلی بپراند.
    _latestFixSequence++;
    _sub?.cancel();
    _sub = rawFiltered.listen(_onFiltered);
  }

  void _onFiltered(VehiclePosition pos) {
    final sequence = ++_latestFixSequence;
    final graph = _graph;
    final maxAccuracy =
        pos.isEstimated ? _maxEstimatedAccuracyForSnapM : _maxAccuracyForSnapM;
    if (graph == null || pos.accuracyM > maxAccuracy) {
      _animator.onRawFix(pos);
      return;
    }

    // Speed must not wait for an offline graph lookup. A slow tile/graph snap
    // used to leave the whole navigation stream silent, so the speedometer
    // stayed at zero even though LocationService had a live GPS fix. Emit the
    // filtered fix immediately; the async snap below may only refine its
    // position after the fact and preserves the same speed value.
    _animator.onRawFix(pos);

    final maxSnapDistance =
        pos.isEstimated ? _maxEstimatedSnapDistanceM : _maxSnapDistanceM;
    unawaited(_snapThenFeed(pos, sequence, maxSnapDistance));
  }

  Future<void> _snapThenFeed(
      VehiclePosition pos, int sequence, double maxSnapDistance) async {
    try {
      final snap = await graphSnap(pos, maxMeters: maxSnapDistance);
      // graph.snap ناهم‌زمان است. اگر فیکس جدیدتری در این فاصله رسیده باشد،
      // خروجی قدیمی را وارد animator نمی‌کنیم؛ ترتیب برعکس فیکس‌ها علت مستقیم
      // حرکت رو به عقب و پرش خودرو بود.
      if (sequence != _latestFixSequence) return;
      if (snap == null) {
        _animator.onRawFix(pos);
        return;
      }
      final distM =
          _haversine(pos.lat, pos.lng, snap.point.lat, snap.point.lon);
      if (distM > maxSnapDistance) {
        _animator.onRawFix(pos);
        return;
      }
      _animator.onRawFix(VehiclePosition(
        lat: snap.point.lat,
        lng: snap.point.lon,
        headingDeg: pos.headingDeg,
        speedKmh: pos.speedKmh,
        accuracyM: pos.accuracyM,
        isEstimated: pos.isEstimated,
      ));
    } catch (_) {
      if (sequence != _latestFixSequence) return;
      // Map matching هرگز نباید ناوبری را متوقف کند — هر خطا (کاشیِ
      // بارگذاری‌نشده، گراف در حال ساخت و ...) یعنی فقط از موقعیتِ خامِ
      // فیلترشده استفاده می‌کنیم، دقیقاً همان‌طور که پیش از این pipeline
      // کار می‌کرد.
      _animator.onRawFix(pos);
    }
  }

  Future<AbmSnap?> graphSnap(VehiclePosition pos,
      {double maxMeters = _maxSnapDistanceM}) {
    final graph = _graph;
    if (graph == null) return Future.value(null);
    return graph.snap(AbmPoint(pos.lng, pos.lat), maxMeters: maxMeters);
  }

  double _haversine(double lat1, double lng1, double lat2, double lng2) {
    const earthRadius = 6371000.0;
    final dLat = (lat2 - lat1) * math.pi / 180;
    final dLng = (lng2 - lng1) * math.pi / 180;
    final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1 * math.pi / 180) *
            math.cos(lat2 * math.pi / 180) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
    return earthRadius * c;
  }

  void dispose() {
    _latestFixSequence++;
    _sub?.cancel();
    _animator.dispose();
  }
}
