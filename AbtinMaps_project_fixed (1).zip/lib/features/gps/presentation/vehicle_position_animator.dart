import 'dart:async';
import 'dart:math' as math;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/location_service.dart';
import 'gps_providers.dart';

class _Fix {
  final double lat;
  final double lng;
  final double headingDeg;
  final double speedKmh;
  final double accuracyM;
  final bool isEstimated;
  final DateTime receivedAt;

  const _Fix({
    required this.lat,
    required this.lng,
    required this.headingDeg,
    required this.speedKmh,
    required this.accuracyM,
    required this.isEstimated,
    required this.receivedAt,
  });
}

/// Turns discrete location fixes into one continuous visual stream.
///
/// There is deliberately only one speed integrator here.  A new GPS speed is
/// a TARGET, never a value that is assigned directly to the UI.  This prevents
/// 10 -> 40 -> 70 km/h jumps and, importantly, gives braking its own continuous
/// path all the way to zero.
class VehiclePositionAnimator {
  // These are presentation limits, not GPS physics. They only prevent a bad
  // fix from becoming a one-frame jump. Braking is intentionally faster but
  // still continuous all the way to zero.
  static const double _maxAccelerationKmhPerSec = 36.0;
  // 54 km/h/s (حدود 1.5g) در سرعت‌های پایین حتی در یک یا دو فریم سرعت را
  // صفر می‌کرد و سرعت‌سنج به‌جای ترمز پیوسته، سقوط پله‌ای نشان می‌داد. 24
  // km/h/s معادل حدود 0.68g است: برای ترمز واقعی سریع می‌ماند، اما حتی
  // سرعت‌های کوچک نیز در چند فریم به صفر می‌رسند.
  static const double _maxBrakingKmhPerSec = 24.0;
  static const double _maxSpeedKmh = 240.0;

  _Fix? _prev;
  _Fix? _curr;
  DateTime? _segmentStartedAt;

  double _renderedSpeedKmh = 0;
  DateTime? _lastSpeedTick;
  int _estimatedIntervalMs = 1000;

  final _controller = StreamController<VehiclePosition>.broadcast();
  Timer? _ticker;
  bool _disposed = false;

  Stream<VehiclePosition> get stream => _controller.stream;

  void onRawFix(VehiclePosition pos) {
    if (_disposed) return;
    final now = DateTime.now();

    if (_curr == null) {
      _curr = _toFix(pos, now);
      _prev = null;
      _segmentStartedAt = now;
      // فیکس تخمینی/cache نباید سرعت قدیمی را نشان دهد، اما نخستین فیکس واقعی
      // با سرعت GNSS معتبر هم نباید چند ثانیه از صفر مصنوعی ramp شود. در این
      // حالت خود مقدار واقعی نقطهٔ شروع سرعت‌سنج است؛ فیلتر بعدی همچنان جهش‌ها
      // را با rate-limit کنترل می‌کند.
      _renderedSpeedKmh = pos.isEstimated ? 0 : _sanitizeSpeed(pos.speedKmh);
      _lastSpeedTick = now;
      _ticker ??=
          Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
      return;
    }

    final oldCurr = _curr!;
    // bootstrap اولیه عمداً estimated و با سرعت صفر است. ورود اولین فیکس
    // GNSS واقعی باید آن را جایگزین کند، نه این‌که سرعت رانندگی را دوباره از
    // صفر مصنوعی بالا ببرد.
    if (oldCurr.isEstimated && !pos.isEstimated && pos.speedKmh >= 2.5) {
      _renderedSpeedKmh = _sanitizeSpeed(pos.speedKmh);
    }
    final gapMs = now.difference(oldCurr.receivedAt).inMilliseconds;
    if (gapMs >= 250 && gapMs <= 3000) {
      _estimatedIntervalMs = ((_estimatedIntervalMs * 0.70) + (gapMs * 0.30))
          .round()
          .clamp(250, 1500)
          .toInt();
    }

    // Bring the previous segment up to the instant the new fix arrived.
    final currentOutput = _sampleAt(now);
    final startLat = currentOutput?.lat ?? _curr!.lat;
    final startLng = currentOutput?.lng ?? _curr!.lng;

    // A late GPS fix is allowed to correct the marker, but never by moving it
    // backwards.  If the new fix is behind the rendered point, hold the point
    // until a subsequent fix catches up instead of interpolating backwards.
    final distanceM = _distanceMeters(startLat, startLng, pos.lat, pos.lng);
    final targetIsBehind = _isBehind(startLat, startLng, pos.lat, pos.lng,
        currentOutput?.headingDeg ?? _curr!.headingDeg);
    final holdPosition = targetIsBehind && distanceM > 2.0;

    _prev = _Fix(
      lat: startLat,
      lng: startLng,
      headingDeg: currentOutput?.headingDeg ?? _curr!.headingDeg,
      speedKmh: _renderedSpeedKmh,
      accuracyM: currentOutput?.accuracyM ?? _curr!.accuracyM,
      isEstimated: currentOutput?.isEstimated ?? _curr!.isEstimated,
      receivedAt: now,
    );

    _curr = _toFix(
      holdPosition
          ? VehiclePosition(
              lat: startLat,
              lng: startLng,
              headingDeg: pos.headingDeg,
              speedKmh: pos.speedKmh,
              accuracyM: pos.accuracyM,
              isEstimated: pos.isEstimated,
            )
          : pos,
      now,
    );
    _segmentStartedAt = now;
    _lastSpeedTick ??= now;
    _ticker ??=
        Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  void _tick() {
    if (_disposed) return;
    final now = DateTime.now();
    final sample = _sampleAt(now);
    if (sample == null) return;

    final dt = _lastSpeedTick == null
        ? 1 / 60
        : (now.difference(_lastSpeedTick!).inMicroseconds / 1e6)
            .clamp(0.001, 0.1);
    _lastSpeedTick = now;

    final targetSpeed = _sanitizeSpeed(_curr!.speedKmh);
    final delta = targetSpeed - _renderedSpeedKmh;
    final maxStep =
        (delta >= 0 ? _maxAccelerationKmhPerSec : _maxBrakingKmhPerSec) * dt;
    if (delta.abs() <= maxStep) {
      _renderedSpeedKmh = targetSpeed;
    } else {
      _renderedSpeedKmh += delta.sign * maxStep;
    }

    final output = VehiclePosition(
      lat: sample.lat,
      lng: sample.lng,
      headingDeg: sample.headingDeg,
      speedKmh: _renderedSpeedKmh.clamp(0.0, _maxSpeedKmh).toDouble(),
      accuracyM: sample.accuracyM,
      isEstimated: sample.isEstimated,
    );
    _emit(output);
  }

  VehiclePosition? _sampleAt(DateTime now) {
    final curr = _curr;
    if (curr == null) return null;

    final start = _segmentStartedAt ?? curr.receivedAt;
    final elapsedMs = now.difference(start).inMilliseconds;
    final intervalMs = _estimatedIntervalMs.clamp(250, 1500);
    final prev = _prev;

    if (prev == null) {
      return VehiclePosition(
        lat: curr.lat,
        lng: curr.lng,
        headingDeg: curr.headingDeg,
        speedKmh: _renderedSpeedKmh,
        accuracyM: curr.accuracyM,
        isEstimated: curr.isEstimated,
      );
    }

    if (elapsedMs <= intervalMs) {
      final t = (elapsedMs / intervalMs).clamp(0.0, 1.0);
      return VehiclePosition(
        lat: _lerp(prev.lat, curr.lat, t),
        lng: _lerp(prev.lng, curr.lng, t),
        headingDeg: _lerpAngle(prev.headingDeg, curr.headingDeg, t),
        speedKmh: _renderedSpeedKmh,
        accuracyM: curr.accuracyM,
        isEstimated: curr.isEstimated,
      );
    }

    // Do not keep extrapolating indefinitely.  Long dead-reckoning is what
    // makes a late GPS correction visible as a large backward jump.
    final extraMs = math.min(elapsedMs - intervalMs, 350);
    if (extraMs <= 0) {
      return VehiclePosition(
        lat: curr.lat,
        lng: curr.lng,
        headingDeg: curr.headingDeg,
        speedKmh: _renderedSpeedKmh,
        accuracyM: curr.accuracyM,
        isEstimated: curr.isEstimated,
      );
    }

    final distanceM =
        (_sanitizeSpeed(curr.speedKmh) / 3.6) * (extraMs / 1000.0);
    final headingRad = curr.headingDeg * math.pi / 180.0;
    final dLat = (distanceM * math.cos(headingRad)) / 111320.0;
    final cosLat = math.cos(curr.lat * math.pi / 180.0).abs().clamp(0.2, 1.0);
    final dLng = (distanceM * math.sin(headingRad)) / (111320.0 * cosLat);

    return VehiclePosition(
      lat: curr.lat + dLat,
      lng: curr.lng + dLng,
      headingDeg: curr.headingDeg,
      speedKmh: _renderedSpeedKmh,
      accuracyM: curr.accuracyM,
      isEstimated: true,
    );
  }

  _Fix _toFix(VehiclePosition p, DateTime now) => _Fix(
        lat: p.lat,
        lng: p.lng,
        headingDeg: p.headingDeg,
        speedKmh: _sanitizeSpeed(p.speedKmh),
        accuracyM: p.accuracyM,
        isEstimated: p.isEstimated,
        receivedAt: now,
      );

  double _sanitizeSpeed(double value) {
    if (!value.isFinite) return 0;
    return value.clamp(0.0, _maxSpeedKmh).toDouble();
  }

  bool _isBehind(double fromLat, double fromLng, double toLat, double toLng,
      double headingDeg) {
    final d = _distanceMeters(fromLat, fromLng, toLat, toLng);
    if (d <= 0.01) return false;
    final bearing = _bearing(fromLat, fromLng, toLat, toLng);
    final diff = ((_normalize(bearing - headingDeg + 180) - 180).abs());
    return diff > 100;
  }

  double _distanceMeters(double lat1, double lng1, double lat2, double lng2) {
    const r = 6371000.0;
    final dLat = (lat2 - lat1) * math.pi / 180;
    final dLng = (lng2 - lng1) * math.pi / 180;
    final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1 * math.pi / 180) *
            math.cos(lat2 * math.pi / 180) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    return r * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
  }

  double _bearing(double lat1, double lng1, double lat2, double lng2) {
    final p1 = lat1 * math.pi / 180;
    final p2 = lat2 * math.pi / 180;
    final dl = (lng2 - lng1) * math.pi / 180;
    final y = math.sin(dl) * math.cos(p2);
    final x = math.cos(p1) * math.sin(p2) -
        math.sin(p1) * math.cos(p2) * math.cos(dl);
    return _normalize(math.atan2(y, x) * 180 / math.pi);
  }

  double _normalize(double deg) => (deg % 360 + 360) % 360;

  double _lerp(double a, double b, double t) => a + (b - a) * t;

  double _lerpAngle(double a, double b, double t) {
    final diff = (b - a + 540) % 360 - 180;
    return (a + diff * t + 360) % 360;
  }

  void _emit(VehiclePosition value) {
    if (_disposed || _controller.isClosed) return;
    _controller.add(value);
  }

  void dispose() {
    if (_disposed) return;
    _disposed = true;
    _ticker?.cancel();
    _ticker = null;
    _controller.close();
  }
}

final animatedVehiclePositionProvider = StreamProvider<VehiclePosition>((ref) {
  final animator = VehiclePositionAnimator();
  ref.onDispose(animator.dispose);

  final sub = ref.watch(vehiclePositionProvider.stream).listen(
        animator.onRawFix,
        onError: (_, __) {},
      );
  ref.onDispose(sub.cancel);

  return animator.stream;
});
