import 'dart:convert';
import 'package:flutter/material.dart';

/// نوع خط مسیریابی: پیوسته، نقطه‌ای، بریده، نقطه‌بریده.
enum RouteLineStyle { solid, dotted, dashed, dotDash }

/// تب فعال در ستون پیش‌نمایش (خودرو / پیکان).
enum AppearanceTab { car, pin }

/// زاویهٔ نمایش نقشه: سه‌بعدی (شیب‌دار) یا دوبعدی (از بالا).
enum MapPerspective { threeD, twoD }

/// گوشه‌ی قدیمیِ نمایش ویجت شناور آب‌وهوا روی نقشه. برای سازگاری با
/// تنظیمات ذخیره‌شده‌ی نسخه‌های قبل نگه داشته شده است؛ جایگاه جدید با دو
/// درصد مستقلِ افقی و عمودی ذخیره می‌شود.
enum WeatherWidgetPosition { topLeft, topRight, bottomLeft, bottomRight }

/// نام پرست‌های آماده. [custom] یعنی کاربر دستی چیزی را عوض کرده و دیگر
/// دقیقاً منطبق با هیچ پرستی نیست.
enum AppearancePreset { minimal, neon, classic, custom }

/// مدل واحد و غیرقابل‌تغییرِ همه‌ی تنظیمات ظاهری اپ.
///
/// این کلاس جایگزینِ ده‌ها StateProvider جدا شده: یک state، یک کلید JSON
/// در SettingsRepository، یک نقطه‌ی load در appSettingsInitProvider.
/// افزودنِ فیلد جدید یعنی: یک سطر اینجا + یک سطر در copyWith/JSON —
/// نه یک Provider و یک کلید مجزا در جای دیگر.
enum RoutePlanningMode { economic, fastest, shortest }

@immutable
class AppearanceSettings {
  const AppearanceSettings({
    this.preset = AppearancePreset.custom,
    // --- خودرو/پیکان ---
    this.activeTab = AppearanceTab.car,
    this.carBodyColor = const Color(0xFFFFFFFF),
    this.vehicleModelIndex = 0,
    this.carSizePercent = 80.0,
    this.navigationCameraTiltDegrees = 42.0,
    this.pinColor = const Color(0xFF8A3FD0),
    this.pinShadowEnabled = true,
    this.pinSize = 100.0,
    // --- مسیر ---
    this.routeColorIndex = 0,
    this.routeColorHex = '#8a3fd0',
    this.routeColorGlowHex = '#9d4fe0',
    this.routeWidth = 8.0,
    this.routeGlowEnabled = true,
    this.routeGlowIntensity = 0.8,
    this.routeLineStyle = RouteLineStyle.solid,
    this.avoidTolls = false,
    this.avoidTraffic = false,
    this.avoidUnpavedRoads = false,
    this.routePlanningMode = RoutePlanningMode.fastest,
    // --- نمای نقشه ---
    this.mapPerspective = MapPerspective.threeD,
    this.mapTilt = 45.0,
    // --- آستانه‌ی زوم المان‌ها ---
    this.elementMainRoadMinZoom = 14,
    this.elementSubRoadMinZoom = 9,
    this.elementAlleyMinZoom = 6,
    // --- ویجت آب‌وهوا ---
    this.weatherPosition = WeatherWidgetPosition.topRight,
    this.weatherVerticalPercent = 0.0,
    this.weatherHorizontalPercent = 100.0,
    this.weatherSize = 100.0,
    this.weatherBgColor = Colors.black,
    this.weatherBgOpacity = 0.55,
    // --- ظاهر کلی اپ ---
    this.themeMode = ThemeMode.dark,
    this.primaryColor = const Color(0xFF8A3FD0),
  });

  final AppearancePreset preset;

  final AppearanceTab activeTab;
  final Color carBodyColor;
  final int vehicleModelIndex;
  final double carSizePercent;

  /// زاویهٔ عمودی دوربین در ناوبری: ۰ یعنی نمای کاملاً بالا و ۹۰ یعنی نمای
  /// پشت خودرو. جهت افقی نقشه مستقل است و همیشه از heading GPS می‌آید.
  final double navigationCameraTiltDegrees;

  final Color pinColor;
  final bool pinShadowEnabled;
  final double pinSize;

  final int routeColorIndex;
  final String routeColorHex;
  final String routeColorGlowHex;
  final double routeWidth;
  final bool routeGlowEnabled;
  final double routeGlowIntensity;
  final RouteLineStyle routeLineStyle;
  final bool avoidTolls;
  final bool avoidTraffic;
  final bool avoidUnpavedRoads;
  final RoutePlanningMode routePlanningMode;

  final MapPerspective mapPerspective;
  final double mapTilt;

  final int elementMainRoadMinZoom;
  final int elementSubRoadMinZoom;
  final int elementAlleyMinZoom;

  final WeatherWidgetPosition weatherPosition;
  final double weatherVerticalPercent;
  final double weatherHorizontalPercent;
  final double weatherSize;
  final Color weatherBgColor;
  final double weatherBgOpacity;

  final ThemeMode themeMode;
  final Color primaryColor;

  AppearanceSettings copyWith({
    AppearancePreset? preset,
    AppearanceTab? activeTab,
    Color? carBodyColor,
    int? vehicleModelIndex,
    double? carSizePercent,
    double? navigationCameraTiltDegrees,
    Color? pinColor,
    bool? pinShadowEnabled,
    double? pinSize,
    int? routeColorIndex,
    String? routeColorHex,
    String? routeColorGlowHex,
    double? routeWidth,
    bool? routeGlowEnabled,
    double? routeGlowIntensity,
    RouteLineStyle? routeLineStyle,
    bool? avoidTolls,
    bool? avoidTraffic,
    bool? avoidUnpavedRoads,
    RoutePlanningMode? routePlanningMode,
    MapPerspective? mapPerspective,
    double? mapTilt,
    int? elementMainRoadMinZoom,
    int? elementSubRoadMinZoom,
    int? elementAlleyMinZoom,
    WeatherWidgetPosition? weatherPosition,
    double? weatherVerticalPercent,
    double? weatherHorizontalPercent,
    double? weatherSize,
    Color? weatherBgColor,
    double? weatherBgOpacity,
    ThemeMode? themeMode,
    Color? primaryColor,
  }) {
    return AppearanceSettings(
      preset: preset ?? this.preset,
      activeTab: activeTab ?? this.activeTab,
      carBodyColor: carBodyColor ?? this.carBodyColor,
      vehicleModelIndex: vehicleModelIndex ?? this.vehicleModelIndex,
      carSizePercent: carSizePercent ?? this.carSizePercent,
      navigationCameraTiltDegrees:
          navigationCameraTiltDegrees ?? this.navigationCameraTiltDegrees,
      pinColor: pinColor ?? this.pinColor,
      pinShadowEnabled: pinShadowEnabled ?? this.pinShadowEnabled,
      pinSize: pinSize ?? this.pinSize,
      routeColorIndex: routeColorIndex ?? this.routeColorIndex,
      routeColorHex: routeColorHex ?? this.routeColorHex,
      routeColorGlowHex: routeColorGlowHex ?? this.routeColorGlowHex,
      routeWidth: routeWidth ?? this.routeWidth,
      routeGlowEnabled: routeGlowEnabled ?? this.routeGlowEnabled,
      routeGlowIntensity: routeGlowIntensity ?? this.routeGlowIntensity,
      routeLineStyle: routeLineStyle ?? this.routeLineStyle,
      avoidTolls: avoidTolls ?? this.avoidTolls,
      avoidTraffic: avoidTraffic ?? this.avoidTraffic,
      avoidUnpavedRoads: avoidUnpavedRoads ?? this.avoidUnpavedRoads,
      routePlanningMode: routePlanningMode ?? this.routePlanningMode,
      mapPerspective: mapPerspective ?? this.mapPerspective,
      mapTilt: mapTilt ?? this.mapTilt,
      elementMainRoadMinZoom:
          elementMainRoadMinZoom ?? this.elementMainRoadMinZoom,
      elementSubRoadMinZoom:
          elementSubRoadMinZoom ?? this.elementSubRoadMinZoom,
      elementAlleyMinZoom: elementAlleyMinZoom ?? this.elementAlleyMinZoom,
      weatherPosition: weatherPosition ?? this.weatherPosition,
      weatherVerticalPercent:
          weatherVerticalPercent ?? this.weatherVerticalPercent,
      weatherHorizontalPercent:
          weatherHorizontalPercent ?? this.weatherHorizontalPercent,
      weatherSize: weatherSize ?? this.weatherSize,
      weatherBgColor: weatherBgColor ?? this.weatherBgColor,
      weatherBgOpacity: weatherBgOpacity ?? this.weatherBgOpacity,
      themeMode: themeMode ?? this.themeMode,
      primaryColor: primaryColor ?? this.primaryColor,
    );
  }

  // ============================================================
  // JSON — یک کلید واحد در SettingsRepository (keyAppearanceSettings).
  // ============================================================

  Map<String, dynamic> toJson() => {
        'activeTab': activeTab.name,
        'carBodyColor': carBodyColor.value,
        'vehicleModelIndex': vehicleModelIndex,
        'carSizePercent': carSizePercent,
        'navigationCameraTiltDegrees': navigationCameraTiltDegrees,
        'pinColor': pinColor.value,
        'pinShadowEnabled': pinShadowEnabled,
        'pinSize': pinSize,
        'routeColorIndex': routeColorIndex,
        'routeColorHex': routeColorHex,
        'routeColorGlowHex': routeColorGlowHex,
        'routeWidth': routeWidth,
        'routeGlowEnabled': routeGlowEnabled,
        'routeGlowIntensity': routeGlowIntensity,
        'routeLineStyle': routeLineStyle.name,
        'avoidTolls': avoidTolls,
        'avoidTraffic': avoidTraffic,
        'avoidUnpavedRoads': avoidUnpavedRoads,
        'routePlanningMode': routePlanningMode.name,
        'mapPerspective': mapPerspective.name,
        'mapTilt': mapTilt,
        'elementMainRoadMinZoom': elementMainRoadMinZoom,
        'elementSubRoadMinZoom': elementSubRoadMinZoom,
        'elementAlleyMinZoom': elementAlleyMinZoom,
        'weatherPosition': weatherPosition.name,
        'weatherVerticalPercent': weatherVerticalPercent,
        'weatherHorizontalPercent': weatherHorizontalPercent,
        'weatherSize': weatherSize,
        'weatherBgColor': weatherBgColor.value,
        'weatherBgOpacity': weatherBgOpacity,
        'themeMode': themeMode.name,
        'primaryColor': primaryColor.value,
        // preset عمداً ذخیره نمی‌شود: هر بار از روی مقادیر واقعی
        // دوباره تشخیص داده می‌شود (نگاه کنید به [AppearancePresets.detect]).
      };

  factory AppearanceSettings.fromJson(Map<String, dynamic> json) {
    const fallback = AppearanceSettings();
    T enumOr<T>(List<T> values, dynamic raw, T fallback) {
      if (raw is! String) return fallback;
      for (final v in values) {
        if ((v as Enum).name == raw) return v;
      }
      return fallback;
    }

    double numOr(dynamic raw, double fallback) =>
        raw is num ? raw.toDouble() : fallback;
    int intOr(dynamic raw, int fallback) => raw is int ? raw : fallback;
    Color colorOr(dynamic raw, Color fallback) =>
        raw is int ? Color(raw) : fallback;
    final legacyWeatherPosition = enumOr(WeatherWidgetPosition.values,
        json['weatherPosition'], fallback.weatherPosition);
    double legacyVertical(WeatherWidgetPosition position) =>
        position == WeatherWidgetPosition.bottomLeft ||
                position == WeatherWidgetPosition.bottomRight
            ? 100.0
            : 0.0;
    double legacyHorizontal(WeatherWidgetPosition position) =>
        position == WeatherWidgetPosition.topRight ||
                position == WeatherWidgetPosition.bottomRight
            ? 100.0
            : 0.0;

    return AppearanceSettings(
      activeTab:
          enumOr(AppearanceTab.values, json['activeTab'], fallback.activeTab),
      carBodyColor: colorOr(json['carBodyColor'], fallback.carBodyColor),
      vehicleModelIndex:
          intOr(json['vehicleModelIndex'], fallback.vehicleModelIndex),
      carSizePercent: numOr(json['carSizePercent'], fallback.carSizePercent)
          .clamp(50.0, 150.0)
          .toDouble(),
      // مقدار قدیمیِ زاویهٔ افقی مدل خودرو عمداً دیگر به کنترل دوربین منتقل
      // نمی‌شود؛ معنای آن متفاوت بود. نصب‌های قدیمی با نمای استانداردِ پشت
      // خودرو (۴۲ درجه) شروع می‌شوند.
      navigationCameraTiltDegrees: numOr(json['navigationCameraTiltDegrees'],
              fallback.navigationCameraTiltDegrees)
          .clamp(0.0, 90.0)
          .toDouble(),
      pinColor: colorOr(json['pinColor'], fallback.pinColor),
      pinShadowEnabled:
          json['pinShadowEnabled'] as bool? ?? fallback.pinShadowEnabled,
      pinSize: numOr(json['pinSize'], fallback.pinSize),
      routeColorIndex: intOr(json['routeColorIndex'], fallback.routeColorIndex),
      routeColorHex: json['routeColorHex'] as String? ?? fallback.routeColorHex,
      routeColorGlowHex:
          json['routeColorGlowHex'] as String? ?? fallback.routeColorGlowHex,
      routeWidth: numOr(json['routeWidth'], fallback.routeWidth),
      routeGlowEnabled:
          json['routeGlowEnabled'] as bool? ?? fallback.routeGlowEnabled,
      routeGlowIntensity:
          numOr(json['routeGlowIntensity'], fallback.routeGlowIntensity),
      routeLineStyle: enumOr(RouteLineStyle.values, json['routeLineStyle'],
          fallback.routeLineStyle),
      avoidTolls: json['avoidTolls'] as bool? ?? fallback.avoidTolls,
      avoidTraffic: json['avoidTraffic'] as bool? ?? fallback.avoidTraffic,
      avoidUnpavedRoads:
          json['avoidUnpavedRoads'] as bool? ?? fallback.avoidUnpavedRoads,
      routePlanningMode: enumOr(RoutePlanningMode.values,
          json['routePlanningMode'], fallback.routePlanningMode),
      mapPerspective: enumOr(MapPerspective.values, json['mapPerspective'],
          fallback.mapPerspective),
      mapTilt: numOr(json['mapTilt'], fallback.mapTilt),
      elementMainRoadMinZoom: intOr(
          json['elementMainRoadMinZoom'], fallback.elementMainRoadMinZoom),
      elementSubRoadMinZoom:
          intOr(json['elementSubRoadMinZoom'], fallback.elementSubRoadMinZoom),
      elementAlleyMinZoom:
          intOr(json['elementAlleyMinZoom'], fallback.elementAlleyMinZoom),
      weatherPosition: legacyWeatherPosition,
      weatherVerticalPercent: numOr(
        json['weatherVerticalPercent'],
        legacyVertical(legacyWeatherPosition),
      ).clamp(0.0, 100.0).toDouble(),
      weatherHorizontalPercent: numOr(
        json['weatherHorizontalPercent'],
        legacyHorizontal(legacyWeatherPosition),
      ).clamp(0.0, 100.0).toDouble(),
      weatherSize: numOr(json['weatherSize'], fallback.weatherSize),
      weatherBgColor: colorOr(json['weatherBgColor'], fallback.weatherBgColor),
      weatherBgOpacity:
          numOr(json['weatherBgOpacity'], fallback.weatherBgOpacity),
      themeMode:
          enumOr(ThemeMode.values, json['themeMode'], fallback.themeMode),
      primaryColor: colorOr(json['primaryColor'], fallback.primaryColor),
    );
  }

  String serialize() => jsonEncode(toJson());

  static AppearanceSettings deserialize(String? raw) {
    if (raw == null || raw.isEmpty) return const AppearanceSettings();
    try {
      final map = jsonDecode(raw) as Map<String, dynamic>;
      return AppearanceSettings.fromJson(map);
    } catch (_) {
      return const AppearanceSettings();
    }
  }
}

/// پرست‌های آماده — هر کدام یک [AppearanceSettings.copyWith] با مقادیرِ
/// ظاهریِ هماهنگ (رنگ مسیر/گلو/پیکان/تیلت) روی تنظیماتِ فعلی اعمال
/// می‌کند. فیلدهایی که به پرست ربطی ندارند (مدل خودرو، آستانه‌ی زوم،
/// موقعیت ویجت آب‌وهوا و ...) دست‌نخورده می‌مانند.
class AppearancePresets {
  const AppearancePresets._();

  static AppearanceSettings apply(
      AppearanceSettings base, AppearancePreset preset) {
    switch (preset) {
      case AppearancePreset.minimal:
        return base.copyWith(
          preset: AppearancePreset.minimal,
          routeColorIndex: 2,
          routeColorHex: '#2F6FD6',
          routeColorGlowHex: '#2F6FD6',
          routeGlowEnabled: false,
          routeGlowIntensity: 0.0,
          routeLineStyle: RouteLineStyle.solid,
          pinColor: const Color(0xFF2F6FD6),
          pinShadowEnabled: false,
          pinSize: 90,
        );
      case AppearancePreset.neon:
        return base.copyWith(
          preset: AppearancePreset.neon,
          routeColorIndex: 5,
          routeColorHex: '#3FD0E0',
          routeColorGlowHex: '#3FD0E0',
          routeGlowEnabled: true,
          routeGlowIntensity: 1.0,
          routeLineStyle: RouteLineStyle.solid,
          pinColor: const Color(0xFF3FD0E0),
          pinShadowEnabled: true,
          pinSize: 110,
        );
      case AppearancePreset.classic:
        return base.copyWith(
          preset: AppearancePreset.classic,
          routeColorIndex: 0,
          routeColorHex: '#8a3fd0',
          routeColorGlowHex: '#9d4fe0',
          routeGlowEnabled: true,
          routeGlowIntensity: 0.8,
          routeLineStyle: RouteLineStyle.solid,
          pinColor: const Color(0xFF8A3FD0),
          pinShadowEnabled: true,
          pinSize: 100,
        );
      case AppearancePreset.custom:
        return base.copyWith(preset: AppearancePreset.custom);
    }
  }

  /// آیا [s] دقیقاً منطبق با فیلدهای «ظاهری»ِ یکی از پرست‌هاست؟ برای
  /// نمایشِ صحیحِ تیکِ انتخاب روی کارتِ پرست، حتی وقتی preset ذخیره‌شده
  /// custom است ولی کاربر خودش دستی همان مقادیر را وارد کرده.
  static AppearancePreset detect(AppearanceSettings s) {
    for (final p in [
      AppearancePreset.minimal,
      AppearancePreset.neon,
      AppearancePreset.classic,
    ]) {
      final applied = apply(s, p);
      if (applied.routeColorHex == s.routeColorHex &&
          applied.routeColorGlowHex == s.routeColorGlowHex &&
          applied.routeGlowEnabled == s.routeGlowEnabled &&
          applied.routeGlowIntensity == s.routeGlowIntensity &&
          applied.routeLineStyle == s.routeLineStyle &&
          applied.pinColor.value == s.pinColor.value &&
          applied.pinShadowEnabled == s.pinShadowEnabled &&
          applied.pinSize == s.pinSize) {
        return p;
      }
    }
    return AppearancePreset.custom;
  }
}
