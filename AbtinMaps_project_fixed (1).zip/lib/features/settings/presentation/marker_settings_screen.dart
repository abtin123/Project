import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/localization/app_localizations.dart';
import '../../../core/theme/app_colors.dart';
import '../../../shared/widgets/bottom_nav.dart';
import '../../../shared/widgets/page_header.dart' show PageHeader;
import 'appearance/pages/marker_page.dart';

/// تنظیمات مستقل مکان‌نما؛ خودرو و پیکان جزو تنظیمات ظاهر اپ نیستند.
class MarkerSettingsScreen extends ConsumerWidget {
  const MarkerSettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: AppColors.background(context),
      appBar: PageHeader(
        title: AppStrings.get(context, ref, 'appearance_marker_title'),
        backRoute: '/settings',
      ),
      body: const SafeArea(
        top: false,
        bottom: false,
        child: MarkerPage(),
      ),
      bottomNavigationBar: const BottomNav(currentPage: NavKey.settings),
    );
  }
}
