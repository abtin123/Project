import 'package:flutter/material.dart';

import 'marker_page.dart' show MarkerCard;
import 'routing_page.dart' show RoutingCard;

/// صفحه‌ی «تنظیمات مسیر و نشانگر» — ادغامِ کارتِ مسیریابی (رنگ/عرض/گلو/
/// سبکِ خط) و کارتِ نشانگر (خودرو/پیکان) در یک صفحه‌ی مستقل، به‌جای دو
/// تبِ جداگانه‌ی قبلی («مسیر» و «خودرو و پیکان»). مطابقِ طرحِ جدیدِ
/// اکاردیونیِ صفحه‌ی تنظیمات ظاهری.
class RoutingMarkerPage extends StatelessWidget {
  const RoutingMarkerPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(16, 12, 16, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          RoutingCard(),
          SizedBox(height: 12),
          MarkerCard(),
        ],
      ),
    );
  }
}
