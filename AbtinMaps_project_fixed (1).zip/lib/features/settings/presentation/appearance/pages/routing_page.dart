import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../core/localization/app_localizations.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../shared/providers/abtinmap_providers.dart';
import '../../../../../shared/providers/map_style_providers.dart';
import '../../../../routing/data/routing_provider.dart';
import '../../../../../shared/widgets/glass_panel.dart' show GlassPanel;
import '../../../data/settings_repository.dart';
import '../../appearance_settings_providers.dart';
import '../../settings_repository_provider.dart';
import '../shared_widgets.dart';

/// یک [Color] را به رشته‌ی هگزِ `#RRGGBB` تبدیل می‌کند (بدون آلفا).
String _colorToHex(Color c) {
  return '#${(c.value & 0xFFFFFF).toRadixString(16).padLeft(6, '0').toUpperCase()}';
}

/// طرفِ مقابلِ [_colorToHex] — رشته‌ی هگز (با/بدون `#`، ۶ یا ۸ رقمی) را
/// به [Color] تبدیل می‌کند.
Color _hexToColor(String hex) {
  final h = hex.replaceFirst('#', '');
  final value = int.parse(h.length == 6 ? 'FF$h' : h, radix: 16);
  return Color(value);
}

/// تبِ «مسیر»: رنگ/عرض/گلو/سبک خط مسیریابی.
class RoutingPage extends StatelessWidget {
  const RoutingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(16, 12, 16, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          RoutingCard(),
        ],
      ),
    );
  }
}

class RoutingCard extends ConsumerWidget {
  const RoutingCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedIndex = ref.watch(routeColorIndexProvider);
    final routeColorHex = ref.watch(routeColorHexProvider);
    final width = ref.watch(routeWidthProvider);
    final glowOn = ref.watch(routeGlowEnabledProvider);
    final glowIntensity = ref.watch(routeGlowIntensityProvider);
    final lineStyle = ref.watch(routeLineStyleProvider);
    final appearance = ref.watch(appearanceSettingsProvider);
    final routingEngine = ref.watch(routingEngineProvider);
    final offlineRouting = routingEngine == RoutingEngine.abtinmap;
    final repo = ref.read(settingsRepositoryProvider);

    const routeColors = <({Color c, Color glow, int index})>[
      (index: 0, c: Color(0xFF8A3FD0), glow: Color(0xFF9D4FE0)),
      (index: 1, c: Color(0xFFFF8A2B), glow: Color(0xFFFF8A2B)),
      (index: 2, c: Color(0xFF2F6FD6), glow: Color(0xFF2F6FD6)),
      (index: 3, c: Color(0xFFD63B3B), glow: Color(0xFFD63B3B)),
      (index: 4, c: Color(0xFF3FA64C), glow: Color(0xFF3FA64C)),
      (index: 5, c: Color(0xFF3FD0E0), glow: Color(0xFF3FD0E0)),
    ];

    return GlassPanel(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          CardHeader(
            title: AppStrings.get(context, ref, 'as_routing_title'),
            icon: Icons.alt_route_rounded,
          ),
          const SizedBox(height: 6),
          Text(
            AppStrings.get(context, ref, 'as_route_color_default'),
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppColors.textSecondary(context),
                ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            alignment: WrapAlignment.center,
            children: [
              for (final entry in routeColors)
                AppColorSwatch(
                  color: entry.c,
                  selected: selectedIndex == entry.index,
                  onTap: () {
                    ref.read(appearanceSettingsProvider.notifier).update(
                          (s) => s.copyWith(
                            routeColorIndex: entry.index,
                            routeColorHex: _colorToHex(entry.c),
                            routeColorGlowHex: _colorToHex(entry.glow),
                          ),
                        );
                    repo.setValue(
                      SettingsRepository.keyRouteColor,
                      entry.index.toString(),
                    );
                    repo.setValue(
                      SettingsRepository.keyRouteColorHex,
                      _colorToHex(entry.c),
                    );
                    repo.setValue(
                      SettingsRepository.keyRouteColorGlowHex,
                      _colorToHex(entry.glow),
                    );
                  },
                ),
              RainbowSwatch(
                selected: selectedIndex < 0,
                onTap: () async {
                  final c = await ColorPickerSheet.show(
                      context, _hexToColor(routeColorHex));
                  if (c == null || !context.mounted) return;
                  final hex = _colorToHex(c);
                  final glowHex =
                      _colorToHex(Color.lerp(c, Colors.white, 0.18) ?? c);
                  ref.read(appearanceSettingsProvider.notifier).update(
                        (s) => s.copyWith(
                          routeColorIndex: -1,
                          routeColorHex: hex,
                          routeColorGlowHex: glowHex,
                        ),
                      );
                  repo.setValue(SettingsRepository.keyRouteColor, '-1');
                  repo.setValue(SettingsRepository.keyRouteColorHex, hex);
                  repo.setValue(
                      SettingsRepository.keyRouteColorGlowHex, glowHex);
                },
              ),
            ],
          ),
          const SizedBox(height: 12),
          StepperValueRow(
            label: AppStrings.get(context, ref, 'as_route_width'),
            value: width,
            min: 4,
            max: 30,
            step: 1,
            onChanged: (v) {
              ref
                  .read(appearanceSettingsProvider.notifier)
                  .update((s) => s.copyWith(routeWidth: v));
              repo.setDouble(SettingsRepository.keyRouteWidth, v);
            },
            valueBuilder: (v) => '${v.round()} PX',
          ),
          const SizedBox(height: 4),
          ToggleRow(
            label: AppStrings.get(context, ref, 'as_route_glow_effect'),
            value: glowOn,
            onChanged: (v) {
              ref
                  .read(appearanceSettingsProvider.notifier)
                  .update((s) => s.copyWith(routeGlowEnabled: v));
              repo.setBool(SettingsRepository.keyRouteGlowEnabled, v);
            },
          ),
          const SizedBox(height: 4),
          StepperValueRow(
            label: AppStrings.get(context, ref, 'as_glow_intensity'),
            value: glowIntensity,
            min: 0,
            max: 100,
            step: 5,
            onChanged: glowOn
                ? (v) {
                    ref
                        .read(appearanceSettingsProvider.notifier)
                        .update((s) => s.copyWith(routeGlowIntensity: v));
                    repo.setDouble(SettingsRepository.keyRouteGlowIntensity, v);
                  }
                : null,
            valueBuilder: (v) =>
                '${v.round()}${AppStrings.get(context, ref, 'percent_sign')}',
          ),
          const SizedBox(height: 12),
          SectionLabel(AppStrings.get(context, ref, 'as_route_line_type')),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              RouteLineStyleChip(
                label: AppStrings.get(context, ref, 'as_line_continuous'),
                style: RouteLineStyle.solid,
                selected: lineStyle == RouteLineStyle.solid,
                onTap: () {
                  ref.read(appearanceSettingsProvider.notifier).update(
                      (s) => s.copyWith(routeLineStyle: RouteLineStyle.solid));
                  repo.setValue(SettingsRepository.keyRouteLineStyle, 'solid');
                },
              ),
              RouteLineStyleChip(
                label: AppStrings.get(context, ref, 'as_line_dotted'),
                style: RouteLineStyle.dotted,
                selected: lineStyle == RouteLineStyle.dotted,
                onTap: () {
                  ref.read(appearanceSettingsProvider.notifier).update(
                      (s) => s.copyWith(routeLineStyle: RouteLineStyle.dotted));
                  repo.setValue(SettingsRepository.keyRouteLineStyle, 'dotted');
                },
              ),
              RouteLineStyleChip(
                label: AppStrings.get(context, ref, 'as_line_dashed'),
                style: RouteLineStyle.dashed,
                selected: lineStyle == RouteLineStyle.dashed,
                onTap: () {
                  ref.read(appearanceSettingsProvider.notifier).update(
                      (s) => s.copyWith(routeLineStyle: RouteLineStyle.dashed));
                  repo.setValue(SettingsRepository.keyRouteLineStyle, 'dashed');
                },
              ),
              RouteLineStyleChip(
                label: AppStrings.get(context, ref, 'as_line_dot_dash'),
                style: RouteLineStyle.dotDash,
                selected: lineStyle == RouteLineStyle.dotDash,
                onTap: () {
                  ref.read(appearanceSettingsProvider.notifier).update((s) =>
                      s.copyWith(routeLineStyle: RouteLineStyle.dotDash));
                  repo.setValue(
                      SettingsRepository.keyRouteLineStyle, 'dotDash');
                },
              ),
            ],
          ),
          const SizedBox(height: 20),
          SectionLabel(AppStrings.get(context, ref, 'route_choice_settings')),
          const SizedBox(height: 6),
          ToggleRow(
            label: AppStrings.get(context, ref, 'route_avoid_tolls'),
            value: appearance.avoidTolls,
            onChanged: offlineRouting
                ? (value) => ref
                    .read(appearanceSettingsProvider.notifier)
                    .update((settings) => settings.copyWith(avoidTolls: value))
                : null,
          ),
          const SizedBox(height: 4),
          ToggleRow(
            label:
                AppStrings.get(context, ref, 'route_avoid_traffic_unavailable'),
            value: appearance.avoidTraffic,
            onChanged: null,
          ),
          const SizedBox(height: 4),
          ToggleRow(
            label: AppStrings.get(context, ref, 'route_avoid_unpaved'),
            value: appearance.avoidUnpavedRoads,
            onChanged: offlineRouting
                ? (value) => ref
                    .read(appearanceSettingsProvider.notifier)
                    .update((settings) =>
                        settings.copyWith(avoidUnpavedRoads: value))
                : null,
          ),
          const SizedBox(height: 8),
          Text(
            AppStrings.get(
              context,
              ref,
              offlineRouting ? 'route_policy_offline' : 'route_policy_online',
            ),
            textAlign: TextAlign.right,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Colors.white60,
                  height: 1.45,
                ),
          ),
          const SizedBox(height: 12),
          SectionLabel(AppStrings.get(context, ref, 'route_default_mode')),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              for (final mode in RoutePlanningMode.values)
                ChoiceChip(
                  label: Text(AppStrings.get(
                      context,
                      ref,
                      switch (mode) {
                        RoutePlanningMode.economic => 'route_mode_economic',
                        RoutePlanningMode.fastest => 'route_mode_fastest',
                        RoutePlanningMode.shortest => 'route_mode_shortest',
                      })),
                  selected: appearance.routePlanningMode == mode,
                  selectedColor:
                      const Color(0xFF2FE6C4).withValues(alpha: 0.24),
                  onSelected: (_) => ref
                      .read(appearanceSettingsProvider.notifier)
                      .update((settings) =>
                          settings.copyWith(routePlanningMode: mode)),
                ),
            ],
          ),
          const SizedBox(height: 16),
          ReadonlyRow(
              label: AppStrings.get(context, ref, 'as_alt_lines_color'),
              swatchColor: const Color(0xFF8FC4F2)),
          const RowDivider(),
          ReadonlyRow(
              label: AppStrings.get(context, ref, 'as_heavy_traffic_color'),
              swatchColor: const Color(0xFFD63B3B)),
          const RowDivider(),
          ReadonlyRow(
              label: AppStrings.get(context, ref, 'as_medium_traffic_color'),
              swatchColor: const Color(0xFFFF8A2B)),
          const RowDivider(),
          ReadonlyRow(
              label: AppStrings.get(context, ref, 'as_light_traffic_color'),
              swatchColor: const Color(0xFF3FA64C)),
        ],
      ),
    );
  }
}
