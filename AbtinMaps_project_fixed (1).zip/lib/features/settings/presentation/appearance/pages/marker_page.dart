import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../../core/localization/app_localizations.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../shared/widgets/glass_panel.dart' show GlassPanel;
import '../../../../vehicle/presentation/glb_vehicle_marker.dart';
import '../../../../vehicle/presentation/nav_arrow_painter.dart';
import '../../../../vehicle/presentation/vehicle_provider.dart';
import '../../../data/settings_repository.dart';
import '../../appearance_settings_providers.dart';
import '../../settings_repository_provider.dart';
import '../shared_widgets.dart';

/// تبِ «خودرو و پیکان»: سوییچِ تبِ خودرو/پیکان + تنظیماتِ هرکدام
/// (رنگ بدنه/مدلِ سه‌بعدی خودرو، رنگ/سایه/اندازه‌ی پیکان).
class MarkerPage extends StatelessWidget {
  const MarkerPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(16, 12, 16, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          MarkerCard(),
        ],
      ),
    );
  }
}

class MarkerCard extends ConsumerWidget {
  const MarkerCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GlassPanel(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          CardHeader(
            title: AppStrings.get(context, ref, 'as_marker_title'),
            icon: Icons.navigation_outlined,
          ),
          const SizedBox(height: 10),
          const _VehiclePinTabs(),
        ],
      ),
    );
  }
}

class _VehiclePinTabs extends ConsumerWidget {
  const _VehiclePinTabs();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final active = ref.watch(activeAppearanceTabProvider);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: AppColors.background(context).withOpacity(0.55),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.glassBorder(context)),
          ),
          child: Row(
            children: [
              Expanded(
                child: TabRadio(
                  label: AppStrings.get(context, ref, 'as_tab_pin'),
                  selected: active == AppearanceTab.pin,
                  onTap: () {
                    ref.read(activeAppearanceTabProvider.notifier).state =
                        AppearanceTab.pin;
                    ref.read(selectedVehicleProvider.notifier).state =
                        VehicleType.arrow;
                    ref.read(settingsRepositoryProvider).setValue(
                          SettingsRepository.keyVehicleType,
                          'arrow',
                        );
                  },
                ),
              ),
              Expanded(
                child: TabRadio(
                  label: AppStrings.get(context, ref, 'as_tab_car'),
                  selected: active == AppearanceTab.car,
                  onTap: () {
                    ref.read(activeAppearanceTabProvider.notifier).state =
                        AppearanceTab.car;
                    ref.read(selectedVehicleProvider.notifier).state =
                        VehicleType.bmwI8;
                    ref.read(settingsRepositoryProvider).setValue(
                          SettingsRepository.keyVehicleType,
                          'bmwI8',
                        );
                  },
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        if (active == AppearanceTab.car)
          const _CarTabBody()
        else
          const _PinTabBody(),
      ],
    );
  }
}

/// تب خودرو — فقط رنگ بدنه (بدون تنظیم سقف، مطابق درخواست کاربر).
class _CarTabBody extends ConsumerWidget {
  const _CarTabBody();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selected = ref.watch(vehicleColorProvider);
    final vehicleIndex = ref.watch(selectedVehicleIndexProvider);

    const palette = <Color>[
      Color(0xFFF2932E),
      Color(0xFF111418),
      Color(0xFFF4F6F8),
      Color(0xFF7D8794),
      Color(0xFF2F6FD6),
      Color(0xFFD63B3B),
    ];

    return GlassPanel(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            height: 260,
            child: Center(
              child: _CarPreview3d(
                key: ValueKey(vehicleModels[
                    vehicleIndex.clamp(0, vehicleModels.length - 1)]),
                modelIndex: vehicleIndex,
                color: selected,
                sizePercent: 100,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.chevron_left),
                onPressed: () {
                  final next = (vehicleIndex + vehicleModels.length - 1) %
                      vehicleModels.length;
                  ref.read(selectedVehicleIndexProvider.notifier).state = next;
                  ref.read(appearanceSettingsProvider.notifier).update(
                        (settings) =>
                            settings.copyWith(vehicleModelIndex: next),
                      );
                },
              ),
              const SizedBox(width: 20),
              Text(
                vehicleModelNames[
                    vehicleIndex.clamp(0, vehicleModelNames.length - 1)],
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(width: 20),
              IconButton(
                icon: const Icon(Icons.chevron_right),
                onPressed: () {
                  final next = (vehicleIndex + 1) % vehicleModels.length;
                  ref.read(selectedVehicleIndexProvider.notifier).state = next;
                  ref.read(appearanceSettingsProvider.notifier).update(
                        (settings) =>
                            settings.copyWith(vehicleModelIndex: next),
                      );
                },
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            AppStrings.get(context, ref, 'as_body_color'),
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppColors.textSecondary(context),
                ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            alignment: WrapAlignment.center,
            children: [
              for (final c in palette)
                AppColorSwatch(
                  color: c,
                  selected: c.value == selected.value,
                  onTap: () {
                    ref.read(vehicleColorProvider.notifier).state = c;
                    ref.read(appearanceSettingsProvider.notifier).update(
                          (settings) => settings.copyWith(carBodyColor: c),
                        );
                  },
                ),
              RainbowSwatch(
                selected: !palette.any((c) => c.value == selected.value),
                onTap: () async {
                  final c = await ColorPickerSheet.show(context, selected);
                  if (c == null || !context.mounted) return;
                  ref.read(vehicleColorProvider.notifier).state = c;
                  ref.read(appearanceSettingsProvider.notifier).update(
                        (settings) => settings.copyWith(carBodyColor: c),
                      );
                },
              ),
            ],
          ),
          // تنظیمات خودرو عمداً فقط مدل و رنگ بدنه است؛ نورپردازی، سایه،
          // اندازه و زاویه از UI حذف شده‌اند.
        ],
      ),
    );
  }
}

/// پیش‌نمایشِ زندهٔ مدل واقعی GLB. این ویجت دقیقاً همان renderer و همان
/// override بدنهٔ نقشه‌های آنلاین و آفلاین را مصرف می‌کند؛ بنابراین رنگی که
/// کاربر در این صفحه می‌بیند، همان رنگ material روی marker واقعی است.
class _CarPreview3d extends StatelessWidget {
  const _CarPreview3d({
    super.key,
    required this.modelIndex,
    required this.color,
    required this.sizePercent,
  });

  final int modelIndex;
  final Color color;
  final double sizePercent;

  @override
  Widget build(BuildContext context) {
    final previewSize =
        (188 * (sizePercent / 100.0)).clamp(130.0, 235.0).toDouble();
    return SizedBox(
      width: 310,
      height: 250,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
            bottom: 18,
            child: Container(
              width: 180,
              height: 12,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(999),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x77000000),
                    blurRadius: 16,
                    spreadRadius: 2,
                    offset: Offset(0, 8),
                  ),
                ],
              ),
            ),
          ),
          GlbVehicleMarker(
            size: previewSize,
            modelIndex: modelIndex,
            bodyColor: color,
            // preview همیشه از بالا است؛ کنترل «نمای دوربین ناوبری» فقط باید
            // camera نقشه را عوض کند، نه این‌که زیر خودرو را در Settings نشان دهد.
            cameraTiltDegrees: 0,
            interactive: false,
          ),
        ],
      ),
    );
  }
}

class _CarControlSlider extends StatelessWidget {
  const _CarControlSlider({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.valueLabel,
    required this.onChanged,
  });

  final String label;
  final double value;
  final double min;
  final double max;
  final String valueLabel;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.primaryAccent(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Text(valueLabel,
                style: Theme.of(context).textTheme.labelMedium?.copyWith(
                      color: accent,
                      fontWeight: FontWeight.w800,
                    )),
            const Spacer(),
            Text(label,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppColors.textSecondary(context),
                    )),
          ],
        ),
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            activeTrackColor: accent,
            inactiveTrackColor: AppColors.surfaceMuted(context),
            thumbColor: Colors.white,
            overlayColor: accent.withOpacity(0.15),
            trackHeight: 4,
          ),
          child: Slider(
            value: value.clamp(min, max).toDouble(),
            min: min,
            max: max,
            divisions: (max - min).round(),
            onChanged: onChanged,
          ),
        ),
      ],
    );
  }
}

/// تب پیکان — فقط رنگ خود پیکان (سایه و گلو مستقل).
class _PinTabBody extends ConsumerWidget {
  const _PinTabBody();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final pinColor = ref.watch(pinColorProvider);
    final pinSize = ref.watch(pinSizeProvider);
    final repo = ref.read(settingsRepositoryProvider);

    const palette = <Color>[
      Color(0xFF8A3FD0),
      Color(0xFFFF8A2B),
      Color(0xFF2F6FD6),
      Color(0xFFD63B3B),
      Color(0xFF3FA64C),
      Color(0xFFF4F6F8),
    ];

    return GlassPanel(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            height: 110,
            child: Center(
              child: _PinPreviewImage(
                pinColor: pinColor,
                sizePercent: pinSize,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Center(
            child: Text(
              AppStrings.get(context, ref, 'as_pin_preview_label'),
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppColors.textMuted(context),
                  ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            AppStrings.get(context, ref, 'as_pin_color'),
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppColors.textSecondary(context),
                ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            alignment: WrapAlignment.center,
            children: [
              for (final c in palette)
                AppColorSwatch(
                  color: c,
                  selected: c.value == pinColor.value,
                  onTap: () {
                    ref
                        .read(appearanceSettingsProvider.notifier)
                        .update((s) => s.copyWith(pinColor: c));
                    repo.setValue(
                      SettingsRepository.keyPinColor,
                      c.value.toString(),
                    );
                  },
                ),
              RainbowSwatch(
                selected: !palette.any((c) => c.value == pinColor.value),
                onTap: () async {
                  final c = await ColorPickerSheet.show(context, pinColor);
                  if (c == null || !context.mounted) return;
                  ref
                      .read(appearanceSettingsProvider.notifier)
                      .update((s) => s.copyWith(pinColor: c));
                  repo.setValue(
                    SettingsRepository.keyPinColor,
                    c.value.toString(),
                  );
                },
              ),
            ],
          ),
          const SizedBox(height: 14),
          StepperValueRow(
            label: AppStrings.get(context, ref, 'as_pin_size'),
            value: pinSize,
            min: 40,
            max: 130,
            step: 5,
            onChanged: (v) {
              ref.read(pinSizeProvider.notifier).state = v;
              repo.setDouble(SettingsRepository.keyPinSize, v);
            },
            valueBuilder: (v) =>
                '${v.round()}${AppStrings.get(context, ref, 'percent_sign')}',
          ),
        ],
      ),
    );
  }
}

class _PinPreviewImage extends StatelessWidget {
  final Color pinColor;
  final double sizePercent;
  const _PinPreviewImage({
    required this.pinColor,
    required this.sizePercent,
  });
  @override
  Widget build(BuildContext context) {
    final base = 78.0 * (sizePercent / 100.0);
    return SizedBox(
      width: 130,
      height: 110,
      child: Center(
        child: Stack(
          alignment: Alignment.center,
          children: [
            const GpsLocationDot(size: 16),
            NavArrow(size: base, color: pinColor, glow: false),
          ],
        ),
      ),
    );
  }
}
