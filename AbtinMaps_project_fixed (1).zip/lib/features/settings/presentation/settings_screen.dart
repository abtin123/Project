import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/localization/app_localizations.dart';
import '../../../core/theme/app_colors.dart';
import '../../../shared/widgets/bottom_nav.dart';
import 'legal_screens.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: AppColors.background(context),
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.15,
            colors: [
              AppColors.primaryAccent(context).withOpacity(0.13),
              AppColors.background(context),
            ],
          ),
        ),
        child: SafeArea(
          bottom: false,
          child: Stack(
            children: [
              Column(
                children: [
                  const _SettingsBrandHeader(),
                  Expanded(
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: AppColors.frameBackground(context)
                            .withOpacity(0.94),
                        borderRadius: const BorderRadius.vertical(
                            top: Radius.circular(26)),
                        border: Border(
                          top:
                              BorderSide(color: AppColors.glassBorder(context)),
                        ),
                      ),
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.fromLTRB(16, 16, 16, 110),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            _SectionHeader(
                                title: AppStrings.get(
                                    context, ref, 'general_settings')),
                            _MenuRow(
                              icon: Icons.volume_up_rounded,
                              label: AppStrings.get(
                                  context, ref, 'voice_settings'),
                              desc: AppStrings.get(
                                  context, ref, 'voice_settings_desc'),
                              iconColor: AppColors.primaryAccent(context),
                              onTap: () => context.push('/voice-settings'),
                            ),
                            _MenuRow(
                              icon: Icons.palette_rounded,
                              label: AppStrings.get(
                                  context, ref, 'appearance_settings'),
                              desc: AppStrings.get(
                                  context, ref, 'appearance_desc'),
                              iconColor: const Color(0xFFE0459A),
                              onTap: () => context.push('/appearance-settings'),
                            ),
                            _MenuRow(
                              icon: Icons.layers_rounded,
                              label:
                                  AppStrings.get(context, ref, 'map_settings'),
                              desc: AppStrings.get(
                                  context, ref, 'map_settings_desc'),
                              iconColor: const Color(0xFF4EC3E8),
                              onTap: () => context.push('/map-settings'),
                            ),
                            _MenuRow(
                              icon: Icons.language_rounded,
                              label: AppStrings.get(
                                  context, ref, 'language_program'),
                              desc: AppStrings.get(
                                  context, ref, 'language_program_desc'),
                              iconColor: const Color(0xFF9B87F5),
                              onTap: () => context.push('/downloads'),
                            ),
                            _MenuRow(
                              icon: Icons.videocam_outlined,
                              label: 'داش‌کم و کمک‌راننده',
                              desc: 'دوربین آفلاین، ضبط ویدیو و نمایشگر هدآپ',
                              iconColor: const Color(0xFF7C4DFF),
                              onTap: () => context.push('/dashcam-settings'),
                            ),
                            const SizedBox(height: 16),
                            _SectionHeader(
                                title: AppStrings.get(
                                    context, ref, 'vehicle_routing_section')),
                            _MenuRow(
                              icon: Icons.navigation_rounded,
                              label: AppStrings.get(
                                  context, ref, 'appearance_marker_title'),
                              desc: AppStrings.get(
                                  context, ref, 'appearance_marker_desc'),
                              iconColor: const Color(0xFFAF7BFF),
                              onTap: () => context.push('/marker-settings'),
                            ),
                            _MenuRow(
                              icon: Icons.alt_route_rounded,
                              label: 'تنظیمات مسیر یابی',
                              desc: 'رنگ، ضخامت، نوع خط و انتخاب نوع مسیر',
                              iconColor: const Color(0xFF8A3FD0),
                              onTap: () => context.push('/routing-settings'),
                            ),
                            _MenuRow(
                              icon: Icons.location_on_rounded,
                              label:
                                  AppStrings.get(context, ref, 'saved_places'),
                              desc: AppStrings.get(
                                  context, ref, 'saved_places_desc'),
                              iconColor: const Color(0xFF2FA5E6),
                              onTap: () => context.push('/saved-places'),
                            ),
                            const SizedBox(height: 16),
                            _SectionHeader(
                                title: AppStrings.get(
                                    context, ref, 'support_section')),
                            _MenuRow(
                              icon: Icons.info_outline_rounded,
                              label: AppStrings.get(context, ref, 'about_app'),
                              desc: AppStrings.get(
                                  context, ref, 'about_app_desc'),
                              iconColor: const Color(0xFF8B5CF6),
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => const AboutAppScreen()),
                              ),
                            ),
                            _MenuRow(
                              icon: Icons.bug_report_rounded,
                              label: AppStrings.get(
                                  context, ref, 'offline_report_title'),
                              desc: AppStrings.get(
                                  context, ref, 'offline_report_desc'),
                              iconColor: const Color(0xFFEB5757),
                              onTap: () => context.push('/abm-log'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const BottomNav(currentPage: NavKey.settings),
            ],
          ),
        ),
      ),
    );
  }
}

class _SettingsBrandHeader extends ConsumerWidget {
  const _SettingsBrandHeader();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SizedBox(
      height: 228,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
            top: -194,
            child: Container(
              width: 510,
              height: 510,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                    color: AppColors.primaryAccent(context).withOpacity(0.16)),
              ),
            ),
          ),
          Positioned(
            top: 12,
            right: 20,
            child: Text(
              AppStrings.get(context, ref, 'settings_page_title'),
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: AppColors.textPrimary(context),
                    fontWeight: FontWeight.w800,
                  ),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 82,
                height: 82,
                clipBehavior: Clip.antiAlias,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primaryAccent(context).withOpacity(0.32),
                      blurRadius: 30,
                      spreadRadius: 3,
                    ),
                  ],
                ),
                child: Image.asset(
                  'assets/images/abtinmaps_settings_logo.png',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => ColoredBox(
                    color: AppColors.primaryAccent(context),
                    child: const Icon(
                      Icons.map_rounded,
                      color: Colors.white,
                      size: 42,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                AppStrings.get(context, ref, 'app_name'),
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      color: AppColors.textPrimary(context),
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: 3),
              Text(
                AppStrings.get(context, ref, 'settings_brand_tagline'),
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppColors.textSecondary(context),
                    ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.title});
  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, right: 4),
      child: Text(
        title,
        textAlign: TextAlign.right,
        style: Theme.of(context).textTheme.labelLarge?.copyWith(
              color: AppColors.textSecondary(context),
            ),
      ),
    );
  }
}

class _MenuRow extends StatelessWidget {
  const _MenuRow({
    required this.icon,
    required this.label,
    required this.desc,
    required this.iconColor,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final String desc;
  final Color iconColor;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(15),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.glassPanelSoft(context),
              borderRadius: BorderRadius.circular(15),
              border:
                  Border.all(color: AppColors.glassBorder(context), width: 0.5),
            ),
            child: Row(
              children: [
                Icon(Icons.chevron_left_rounded,
                    color: AppColors.textMuted(context), size: 20),
                const Spacer(),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        label,
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  color: AppColors.textPrimary(context),
                                  fontWeight: FontWeight.w600,
                                ),
                      ),
                      const SizedBox(height: 2),
                      Text(desc,
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(
                                  color: AppColors.textSecondary(context))),
                    ],
                  ),
                ),
                const SizedBox(width: 14),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                      color: iconColor.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10)),
                  child: Icon(icon, color: iconColor, size: 20),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
