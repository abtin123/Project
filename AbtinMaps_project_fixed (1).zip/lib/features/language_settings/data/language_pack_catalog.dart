library;

import '../../../core/localization/locale_flags.dart';

/// مانیفست و فایل‌های زبان در یک release مستقل منتشر می‌شوند. بسته‌ها فقط
/// رشته‌های رابط را دارند؛ هیچ دادهٔ نقشه، نام مکان یا برچسب جغرافیایی در آن‌ها
/// قرار نمی‌گیرد.
const String kLangPacksManifestUrl =
    'https://github.com/abtin123/Make-langueg/releases/download/langpacks-latest/manifest.json';

class LanguagePack {
  const LanguagePack({
    required this.code,
    required this.name,
    required this.flag,
    this.direction = 'ltr',
    this.sizeBytes = 0,
    this.stringCount = 0,
    this.version = '',
    this.sha256 = '',
    String? downloadUrl,
  }) : _downloadUrl = downloadUrl;

  final String code;
  final String name;
  final String flag;
  final String direction;
  final int sizeBytes;
  final int stringCount;
  final String version;
  final String sha256;
  final String? _downloadUrl;
  String get downloadUrl =>
      _downloadUrl ??
      'https://github.com/abtin123/Make-langueg/releases/download/langpacks-latest/lang_$code.abl';

  String get localFileName => 'lang_$code.json';

  factory LanguagePack.fromManifestJson(Map<String, dynamic> json) {
    final code = json['language_code'];
    final url = json['download_url'];
    if (code is! String || code.isEmpty || url is! String || url.isEmpty) {
      throw const FormatException('رکورد زبان، کد یا لینک دانلود معتبر ندارد.');
    }
    return LanguagePack(
      code: code,
      // نام زبان از مانیفست ممکن است اضافاتی مثل «فارسی (fa)» یا «English -
      // en» همراه داشته باشد؛ چون کدِ زبان و پرچم جدا نمایش داده می‌شوند، این
      // اضافات از نام حذف می‌شود.
      name: json['language'] is String
          ? cleanLocalizedLabel(json['language'] as String)
          : code,
      flag: flagAssetForLanguageCode(code),
      direction: json['direction'] == 'rtl' ? 'rtl' : 'ltr',
      sizeBytes: (json['size'] as num?)?.toInt() ?? 0,
      stringCount: (json['string_count'] as num?)?.toInt() ?? 0,
      version: json['version'] is String ? json['version'] as String : '',
      sha256: json['sha256'] is String ? json['sha256'] as String : '',
      downloadUrl: url,
    );
  }
}

final List<LanguagePack> builtInLanguages = [
  LanguagePack(
      code: 'fa',
      name: 'فارسی',
      flag: flagAssetForLanguageCode('fa'),
      direction: 'rtl'),
  LanguagePack(
      code: 'en', name: 'English', flag: flagAssetForLanguageCode('en')),
];
