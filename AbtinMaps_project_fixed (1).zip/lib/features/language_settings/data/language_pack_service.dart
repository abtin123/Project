import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import '../../../core/localization/app_localizations.dart';
import 'language_pack_catalog.dart';

class LanguagePackException implements Exception {
  const LanguagePackException(this.message);
  final String message;
  @override
  String toString() => message;
}

class LanguageDownloadProgress {
  const LanguageDownloadProgress({
    required this.receivedBytes,
    required this.totalBytes,
    required this.resuming,
  });

  final int receivedBytes;
  final int totalBytes;
  final bool resuming;

  double get fraction => totalBytes <= 0
      ? 0
      : (receivedBytes / totalBytes).clamp(0.0, 1.0).toDouble();
}

/// نصب‌کنندهٔ زبان با دانلود resumable. دادهٔ ناقص در `*.part` باقی می‌ماند
/// و فقط پس از checksum و اعتبارسنجی کامل، JSON نهایی را به‌شکل اتمیک جایگزین
/// می‌کند؛ بنابراین قطع اینترنت هرگز کاربر را به شروع از صفر برنمی‌گرداند.
class LanguagePackService {
  List<LanguagePack>? _memory;

  /// حداکثر «تازگیِ» کشِ محلیِ مانیفستِ زبان — مثل [MapCatalogService]: تا
  /// وقتی کش قدیمی‌تر از این مدت نشده، به شبکه سر زده نمی‌شود؛ فقط دکمهٔ
  /// «تازه‌سازی» دستی این کش را دور می‌زند. فهرست زبان‌ها به‌ندرت تغییر
  /// می‌کند، پس چک‌کردنش با هر بار خروج و ورود به صفحهٔ زبان غیرضروری است.
  static const Duration _maxCacheAge = Duration(days: 1);

  Future<Directory> _packsDir() async {
    final base = await getApplicationSupportDirectory();
    final dir = Directory('${base.path}/language_packs');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<File> _manifestCacheFile() async =>
      File('${(await _packsDir()).path}/.manifest_cache.json');

  Future<File> _fileFor(LanguagePack pack) async =>
      File('${(await _packsDir()).path}/${pack.localFileName}');

  Future<File> _partFor(LanguagePack pack) async =>
      File('${(await _packsDir()).path}/.${pack.code}.abl.part');

  Map<String, String> _validateCompleteValues(
    Object? decoded, {
    required String languageCode,
  }) {
    if (decoded is! Map<String, dynamic>) {
      throw LanguagePackException(
          'بستهٔ زبان «$languageCode» ساختار JSON معتبر ندارد.');
    }
    final values = decoded.map((key, value) => MapEntry(key, value.toString()));
    final expected = AppStrings.baseKeys.toSet();
    // بسته می‌تواند کلیدهای اضافه هم داشته باشد (مثلاً نسخهٔ جدیدتر از
    // مانیفست نسبت به اپِ نصب‌شده)؛ آن کلیدهای اضافه نادیده گرفته می‌شوند.
    // فقط کمبودِ کلیدهای موردنیازِ نسخهٔ فعلی رابط، بسته را ناقص می‌کند.
    if (!values.keys.toSet().containsAll(expected) ||
        expected.any((key) => (values[key] ?? '').trim().isEmpty)) {
      throw LanguagePackException(
        'بستهٔ زبان «$languageCode» کامل نیست؛ باید همهٔ ${expected.length} کلید رابط را داشته باشد.',
      );
    }
    return values;
  }

  Future<bool> isDownloaded(LanguagePack pack) async =>
      (await _fileFor(pack)).exists();

  Future<LanguageDownloadProgress> pendingProgress(LanguagePack pack) async {
    final part = await _partFor(pack);
    final received = await part.exists() ? await part.length() : 0;
    return LanguageDownloadProgress(
      receivedBytes: received,
      totalBytes: pack.sizeBytes > 0 ? pack.sizeBytes : received,
      resuming: received > 0,
    );
  }

  Future<void> download(
    LanguagePack pack, {
    void Function(LanguageDownloadProgress progress)? onProgress,
  }) async {
    final part = await _partFor(pack);
    var received = await part.exists() ? await part.length() : 0;
    final bytes = await _downloadToPart(pack, part, received, onProgress);

    if (pack.sha256.isNotEmpty &&
        sha256.convert(bytes).toString() != pack.sha256) {
      throw const LanguagePackException(
          'هش فایل زبان با مانیفست سازگار نیست. دانلود ناقص حفظ شد؛ دوباره ادامه دهید.');
    }

    final Map<String, String> values;
    try {
      final raw = GZipDecoder().decodeBytes(bytes);
      values = _validateCompleteValues(
        jsonDecode(utf8.decode(raw)),
        languageCode: pack.code,
      );
    } on LanguagePackException {
      rethrow;
    } catch (_) {
      throw const LanguagePackException(
          'فایل زبان دریافت‌شده معتبر یا فشرده نیست.');
    }

    final file = await _fileFor(pack);
    final temporary = File('${file.path}.tmp');
    await temporary.writeAsString(jsonEncode(values), flush: true);
    if (await file.exists()) await file.delete();
    await temporary.rename(file.path);
    if (await part.exists()) await part.delete();
    AppStrings.registerDownloadedLanguage(pack.code, values);
  }

  Future<List<int>> _downloadToPart(
    LanguagePack pack,
    File part,
    int received,
    void Function(LanguageDownloadProgress progress)? onProgress,
  ) async {
    final request = http.Request('GET', Uri.parse(pack.downloadUrl));
    if (received > 0) request.headers['Range'] = 'bytes=$received-';
    final client = http.Client();
    try {
      final response = await client.send(request);
      final canResume = received > 0 && response.statusCode == 206;
      if (response.statusCode != 200 && response.statusCode != 206) {
        throw LanguagePackException(
            'دانلود بستهٔ زبان «${pack.name}» ناموفق بود (کد ${response.statusCode}).');
      }
      if (!canResume) {
        received = 0;
        await part.writeAsBytes(const [], flush: true);
      }
      final total = response.contentLength == null
          ? (pack.sizeBytes > 0 ? pack.sizeBytes : 0)
          : received + response.contentLength!;
      final sink =
          part.openWrite(mode: received > 0 ? FileMode.append : FileMode.write);
      try {
        await for (final chunk in response.stream) {
          sink.add(chunk);
          received += chunk.length;
          onProgress?.call(LanguageDownloadProgress(
            receivedBytes: received,
            totalBytes: total,
            resuming: canResume,
          ));
        }
        await sink.flush();
      } finally {
        await sink.close();
      }
    } finally {
      client.close();
    }
    return part.readAsBytes();
  }

  Future<List<LanguagePack>> fetchManifest({bool forceRefresh = false}) async {
    if (!forceRefresh && _memory != null) return _memory!;

    final cache = await _manifestCacheFile();
    if (!forceRefresh) {
      try {
        if (await cache.exists()) {
          final age = DateTime.now().difference(await cache.lastModified());
          if (age < _maxCacheAge) {
            final cached = await cache.readAsString(encoding: utf8);
            return _memory = _parseManifest(jsonDecode(cached));
          }
        }
      } catch (_) {
        // کش خراب است؛ به مسیر شبکه ادامه می‌دهیم.
      }
    }

    try {
      final res = await http
          .get(Uri.parse(kLangPacksManifestUrl))
          .timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) {
        throw LanguagePackException(
            'دریافت فهرست زبان‌ها ناموفق بود (کد ${res.statusCode}).');
      }
      final bodyUtf8 = utf8.decode(res.bodyBytes);
      final parsed = _parseManifest(jsonDecode(bodyUtf8));
      await cache.writeAsString(bodyUtf8, flush: true, encoding: utf8);
      return _memory = parsed;
    } on LanguagePackException catch (_) {
      final fallback = await _cachedManifestOrNull(cache);
      if (fallback != null) return _memory = fallback;
      rethrow;
    } catch (_) {
      final fallback = await _cachedManifestOrNull(cache);
      if (fallback != null) return _memory = fallback;
      throw const LanguagePackException(
        'فهرست زبان‌ها در دسترس نیست. اتصال اینترنت یا انتشار بسته‌های زبان را بررسی کنید.',
      );
    }
  }

  Future<List<LanguagePack>?> _cachedManifestOrNull(File cache) async {
    try {
      if (await cache.exists()) {
        return _parseManifest(
            jsonDecode(await cache.readAsString(encoding: utf8)));
      }
    } catch (_) {
      // کشِ قدیمی هم خراب است.
    }
    return null;
  }

  List<LanguagePack> _parseManifest(Object? decoded) {
    if (decoded is! Map<String, dynamic> ||
        decoded['schema_version'] != 2 ||
        decoded['app_strings'] != 'non-map-ui' ||
        decoded['languages'] is! List) {
      throw const LanguagePackException('مانیفست زبان معتبر نیست.');
    }
    final expectedCount = decoded['string_count'];
    final requiredCount = AppStrings.baseKeys.length;
    // مانیفست می‌تواند کلید بیشتری از نسخهٔ فعلی رابط داشته باشد (نسخهٔ‌
    // زبان جلوتر از اپِ نصب‌شده)؛ فقط کمبود، ناسازگار حساب می‌شود.
    if (expectedCount is! num || expectedCount.toInt() < requiredCount) {
      throw LanguagePackException(
        'مانیفست با نسخهٔ رابط فعلی سازگار نیست؛ باید حداقل $requiredCount کلید داشته باشد.',
      );
    }
    try {
      final packs = (decoded['languages'] as List)
          .whereType<Map<String, dynamic>>()
          .map(LanguagePack.fromManifestJson)
          .toList();
      if (packs.isEmpty ||
          packs.any((pack) => pack.stringCount < requiredCount)) {
        throw LanguagePackException(
          'فهرست زبان شامل بستهٔ ناقص است؛ همهٔ زبان‌ها باید حداقل $requiredCount کلید داشته باشند.',
        );
      }
      return packs;
    } on FormatException catch (_) {
      throw const LanguagePackException(
          'یکی از رکوردهای زبان در مانیفست نامعتبر است.');
    }
  }

  Future<void> delete(LanguagePack pack) async {
    final file = await _fileFor(pack);
    if (await file.exists()) await file.delete();
    final part = await _partFor(pack);
    if (await part.exists()) await part.delete();
    AppStrings.unregisterDownloadedLanguage(pack.code);
  }

  Future<Set<String>> loadAllDownloaded() async {
    final loaded = <String>{};

    final dir = await _packsDir();
    if (!await dir.exists()) return loaded;

    final staleCodes = <String>[];
    for (final entity in dir.listSync()) {
      final name = entity.uri.pathSegments.last;
      final match = RegExp(r'^lang_([a-zA-Z-]+)\.json$').firstMatch(name);
      if (match == null || entity is! File) continue;
      final code = match.group(1)!;
      try {
        final values = _validateCompleteValues(
          jsonDecode(await entity.readAsString()),
          languageCode: code,
        );
        AppStrings.registerDownloadedLanguage(code, values);
        loaded.add(code);
      } on LanguagePackException {
        // کلیدهای فایل با نسخهٔ فعلی رابط یکی نیست (بستهٔ قدیمی/ناقص)؛ حذف
        // می‌شود و پایین‌تر از مانیفست دوباره دانلود می‌شود.
        try {
          await entity.delete();
        } catch (_) {}
        staleCodes.add(code);
      } catch (_) {
        // فایل خراب بدون مداخلهٔ کاربر نادیده گرفته می‌شود.
      }
    }

    if (staleCodes.isNotEmpty) {
      try {
        final manifest = await fetchManifest();
        for (final code in staleCodes) {
          LanguagePack? pack;
          for (final p in manifest) {
            if (p.code == code) {
              pack = p;
              break;
            }
          }
          if (pack == null) continue;
          try {
            await download(pack);
            loaded.add(code);
          } catch (_) {
            // دانلود دوباره ناموفق بود؛ این زبان تا اقدام بعدی کاربر
            // نصب‌نشده باقی می‌ماند.
          }
        }
      } catch (_) {
        // مانیفست در دسترس نیست؛ بسته‌های ناقص حذف‌شده بدون جایگزین می‌مانند.
      }
    }

    return loaded;
  }
}
