import 'package:abtin_maps/core/geo/geo_types.dart';

import '../../../abtinmap/abm_file.dart';
import '../../../abtinmap/abm_map_service.dart';
import '../../../abtinmap/abm_models.dart';
import '../../../abtinmap/abm_router.dart';
import '../../voice_settings/data/voice_pack_fa.dart';
import 'routing_provider.dart';
import 'routing_service.dart';

/// پیاده‌سازی ABTINMAP: مسیریابی کاملاً آفلاین روی فایل .abm
/// (A* با هزینه‌ی travel-time، دستورهای فارسی، محدودیت سرعت و دوربین‌ها).
class AbtinmapRoutingProvider implements RoutingProvider {
  AbtinmapRoutingProvider({
    required AbmMapService mapService,
    this.mapName = 'IR.abm',
  }) : _mapService = mapService;

  final AbmMapService _mapService;
  final String mapName;

  AbmRouter? _router;

  @override
  RoutingEngine get engine => RoutingEngine.abtinmap;

  @override
  String get displayName => 'آبتین‌مپ (آفلاین)';

  @override
  bool get isOffline => true;

  @override
  String? lastError;

  @override
  Future<bool> isReady() => _mapService.isInstalled(mapName);

  Future<AbmRouter?> _ensureRouter() async {
    if (_router != null) return _router;
    final AbmFile? file = await _mapService.openMap(mapName);
    if (file == null) {
      lastError =
          'نقشهٔ آفلاین ABTINMAP نصب نشده است. از بخش «نقشه‌های آفلاین» فایل $mapName را دانلود کنید.';
      return null;
    }
    return _router = AbmRouter(file);
  }

  @override
  Future<RouteInfo?> calculateRoute({
    required LatLng origin,
    required LatLng destination,
    bool offlineOnly = false,
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
  }) async {
    lastError = null;
    final router = await _ensureRouter();
    if (router == null) return null;

    try {
      final route = await router.route(
        AbmPoint(origin.longitude, origin.latitude),
        AbmPoint(destination.longitude, destination.latitude),
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
      );
      if (route == null) {
        lastError = router.lastError ?? 'مسیری روی نقشهٔ آفلاین پیدا نشد.';
        return null;
      }
      return RouteInfo(
        geometry: route.points
            .map((p) => LatLng(p.lat, p.lon))
            .toList(growable: false),
        distanceKm: route.distanceKm,
        durationMin: route.durationMin,
        instructions: route.maneuvers
            .map(
              (m) => RouteInstruction(
                text: VoicePackFa.textForCue(VoicePackFa.cueForManeuver(
                    type: m.type, modifier: m.modifier)),
                distanceMeters: m.distanceMeters,
                location: LatLng(m.point.lat, m.point.lon),
                type: m.type,
                modifier: m.modifier,
                speedLimit: m.speedLimitKmh,
              ),
            )
            .toList(growable: false),
        alerts: route.roadAlerts
            .map(
              (poi) => RouteAlert(
                type: poi.isSpeedBump
                    ? RouteAlertType.speedBump
                    : RouteAlertType.speedCamera,
                location: LatLng(poi.point.lat, poi.point.lon),
                name: poi.name.isEmpty ? null : poi.name,
              ),
            )
            .toList(growable: false),
      );
    } catch (error) {
      lastError = 'خطا در مسیریابی آفلاین ABTINMAP: $error';
      return null;
    }
  }

  /// چند مسیر واقعی آفلاین؛ ترتیب خروجی: کوتاه‌ترین زمان، سپس گزینه‌های
  /// متفاوتی که با جریمهٔ نرم راه‌های مسیر قبلی ساخته شده‌اند.
  Future<List<RouteInfo>> calculateRoutes({
    required LatLng origin,
    required LatLng destination,
    bool offlineOnly = false,
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
  }) async {
    lastError = null;
    final router = await _ensureRouter();
    if (router == null) return const [];
    try {
      final routes = await router.routeAlternatives(
        AbmPoint(origin.longitude, origin.latitude),
        AbmPoint(destination.longitude, destination.latitude),
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
      );
      if (routes.isEmpty) {
        lastError = router.lastError ?? 'مسیری روی نقشهٔ آفلاین پیدا نشد.';
      }
      return routes.map(_toRouteInfo).toList(growable: false);
    } catch (error) {
      lastError = 'خطا در ساخت مسیرهای جایگزین آفلاین ABTINMAP: $error';
      return const [];
    }
  }

  RouteInfo _toRouteInfo(AbmRoute route) => RouteInfo(
        geometry: route.points
            .map((p) => LatLng(p.lat, p.lon))
            .toList(growable: false),
        distanceKm: route.distanceKm,
        durationMin: route.durationMin,
        instructions: route.maneuvers
            .map((m) => RouteInstruction(
                  text: VoicePackFa.textForCue(VoicePackFa.cueForManeuver(
                      type: m.type, modifier: m.modifier)),
                  distanceMeters: m.distanceMeters,
                  location: LatLng(m.point.lat, m.point.lon),
                  type: m.type,
                  modifier: m.modifier,
                  speedLimit: m.speedLimitKmh,
                ))
            .toList(growable: false),
        alerts: route.roadAlerts
            .map((poi) => RouteAlert(
                  type: poi.isSpeedBump
                      ? RouteAlertType.speedBump
                      : RouteAlertType.speedCamera,
                  location: LatLng(poi.point.lat, poi.point.lon),
                  name: poi.name.isEmpty ? null : poi.name,
                ))
            .toList(growable: false),
      );

  /// آزادسازی نقشه‌ی باز (مثلاً بعد از آپدیت فایل).
  Future<void> reset() async {
    _router = null;
    await _mapService.closeMap();
  }
}
