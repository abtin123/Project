// مسیر سازگاری قدیمی: renderer واقعی GLB اکنون Google Filament native است.
// renderer native قبلی عمداً از درخت build حذف شده تا crash سطح پایین روی
// برخی گوشی‌های Android دوباره وارد فرایند اپ نشود.
export 'glb_vehicle_marker.dart';
