import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

enum VehicleType { arrow, bmwI8, suv, taxi }

/// مدل‌های واقع‌گرایانهٔ انتخاب‌شدهٔ کاربر برای marker ناوبری.
/// همهٔ مدل‌ها GLB هستند و رنگ بدنه با material override واقعی در نقشهٔ آنلاین
/// و آفلاین اعمال می‌شود.
final vehicleModels = [
  'assets/models/bmw_i8.glb',
  'assets/models/acura_rsx.glb',
  'assets/models/nissan_patrol.glb',
  'assets/models/nissan_4x4.glb',
];

/// نام نمایشی هر مدل — هم‌ترازِ ایندکسِ [vehicleModels].
final vehicleModelNames = [
  'BMW i8',
  'Acura RSX',
  'Nissan Patrol',
  'Nissan 4x4',
];

final selectedVehicleIndexProvider = StateProvider<int>((ref) => 0);

final selectedVehicleProvider =
    StateProvider<VehicleType>((ref) => VehicleType.arrow);

final vehicleColorProvider =
    StateProvider<Color>((ref) => const Color(0xFFFFFFFF));
