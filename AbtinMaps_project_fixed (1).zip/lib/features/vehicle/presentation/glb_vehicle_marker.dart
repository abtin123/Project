import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:interactive_3d/interactive_3d.dart';

import 'vehicle_provider.dart';

double vehicleScreenRotationDegrees(double headingDeg) {
  final normalized = headingDeg.isFinite ? headingDeg : 0.0;
  final value = (normalized + 180.0) % 360.0;
  return value < 0 ? value + 360.0 : value;
}

/// Native Filament GLB renderer shared by the settings preview and map marker.
/// No WebView or user-facing lighting control is used.
class GlbVehicleMarker extends StatelessWidget {
  const GlbVehicleMarker({
    super.key,
    required this.size,
    required this.modelIndex,
    required this.bodyColor,
    this.headingDeg = 0,
    this.cameraTiltDegrees = 0,
    this.interactive = false,
  });

  final double size;
  final int modelIndex;
  final Color bodyColor;
  final double headingDeg;
  final double cameraTiltDegrees;
  final bool interactive;

  static const _bodyMaterialNames = <List<String>>[
    ['paint', 'body', 'carpaint'],
    ['material', 'body'],
    ['set1', 'body'],
    ['carpaint', 'pearl_paint', 'body'],
  ];

  List<MaterialOverride> _bodyOverrides(int index) {
    final rgba = <double>[
      bodyColor.red / 255.0,
      bodyColor.green / 255.0,
      bodyColor.blue / 255.0,
      bodyColor.alpha / 255.0,
    ];
    return [
      for (final name in _bodyMaterialNames[index.clamp(0, 3)])
        MaterialOverride(
          name: name,
          color: rgba,
          roughness: 0.42,
          metallic: 0.15,
        ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final index = modelIndex.clamp(0, vehicleModels.length - 1);
    final angle = vehicleScreenRotationDegrees(headingDeg) * math.pi / 180.0;
    return SizedBox.square(
      dimension: size,
      child: Transform.rotate(
        angle: angle,
        child: IgnorePointer(
          ignoring: !interactive,
          child: Interactive3d(
            key:
                ValueKey('filament-${vehicleModels[index]}-${bodyColor.value}'),
            modelPath: vehicleModels[index],
            backgroundColor: Colors.transparent,
            defaultZoom: 1.35,
            initialMaterialOverrides: _bodyOverrides(index),
            loadingWidget: const SizedBox.shrink(),
          ),
        ),
      ),
    );
  }
}

class ThreeDVehicleMarker extends GlbVehicleMarker {
  const ThreeDVehicleMarker({
    super.key,
    required super.size,
    required super.modelIndex,
    required super.bodyColor,
    super.headingDeg,
    super.cameraTiltDegrees,
    super.interactive,
  });
}
