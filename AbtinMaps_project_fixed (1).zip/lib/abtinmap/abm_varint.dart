import 'dart:typed_data';

/// خواننده‌ی بایت با پشتیبانی uvarint/svarint — دقیقاً منطبق با
/// `read_uvarint` / `read_svarint` در abtinmap_inspect.py (خواننده‌ی مرجع).
class ByteCursor {
  ByteCursor(this.bytes, [this.p = 0]);

  final Uint8List bytes;
  int p;

  bool get atEnd => p >= bytes.length;

  int u8() => bytes[p++];

  /// LEB128 بدون علامت.
  int uvarint() {
    var shift = 0;
    var val = 0;
    while (true) {
      final b = bytes[p++];
      val |= (b & 0x7F) << shift;
      if ((b & 0x80) == 0) return val;
      shift += 7;
    }
  }

  /// zig-zag با علامت.
  int svarint() {
    final v = uvarint();
    return (v & 1) == 0 ? (v >> 1) : -((v + 1) >> 1);
  }
}
