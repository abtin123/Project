import 'dart:typed_data';

import 'package:zstandard/zstandard.dart';

/// رمزگشای zstd برای بلوک‌های فایل .abm.
///
/// در Dart پکیج «خالص‌دارتِ» قابل‌اعتمادی برای zstd وجود ندارد؛ بهترین گزینه‌ی
/// موجود پلاگین `zstandard` است که کتابخانه‌ی بومی libzstd را برای اندروید/iOS
/// و دسکتاپ همراه دارد. این کلاس یک لایه‌ی نازک روی آن است تا اگر روزی پیاده‌سازی
/// دیگری (FFI یا خالص‌دارت) اضافه شد، فقط همین فایل عوض شود.
abstract class AbmZstd {
  Future<Uint8List> decompress(Uint8List input, {int? expectedSize});
}

class PluginAbmZstd implements AbmZstd {
  PluginAbmZstd() : _zstd = Zstandard();

  final Zstandard _zstd;

  @override
  Future<Uint8List> decompress(Uint8List input, {int? expectedSize}) async {
    final out = await _zstd.decompress(input);
    if (out == null) {
      throw const AbmZstdException('رمزگشایی zstd شکست خورد (بلوک خراب است).');
    }
    if (expectedSize != null && out.length != expectedSize) {
      throw AbmZstdException(
        'اندازه‌ی بلوک رمزگشایی‌شده ($expectedSize انتظار، ${out.length} واقعی) '
        'با هدر فایل هم‌خوان نیست.',
      );
    }
    return out;
  }
}

class AbmZstdException implements Exception {
  const AbmZstdException(this.message);
  final String message;
  @override
  String toString() => 'AbmZstdException: $message';
}
