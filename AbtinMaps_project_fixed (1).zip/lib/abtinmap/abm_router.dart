import 'dart:math' as math;

import 'abm_file.dart';
import 'abm_graph.dart';
import 'abm_models.dart';

/// دستور راهنمایی مسیر (خروجی خنثی؛ لایه‌ی adapter آن را به RouteInstruction اپ می‌برد).
class AbmManeuver {
  AbmManeuver({
    required this.text,
    required this.distanceMeters,
    required this.point,
    required this.type,
    this.modifier,
    this.speedLimitKmh,
    this.roadName,
  });

  final String text;
  final double distanceMeters;
  final AbmPoint point;

  /// depart | turn | continue | roundabout | arrive
  final String type;
  final String? modifier;
  final int? speedLimitKmh;
  final String? roadName;
}

class AbmRoute {
  AbmRoute({
    required this.points,
    required this.seconds,
    required this.meters,
    required this.maneuvers,
    required this.roadAlerts,
    required this.expandedNodes,
    required this.usedWays,
  });

  final List<AbmPoint> points;
  final double seconds;
  final double meters;
  final List<AbmManeuver> maneuvers;

  /// دوربین‌های کنترل سرعت (klass=70) و سرعت‌گیرهای فیزیکی (klass=71)
  /// نزدیک مسیر — همان چیزی که در Neshan/Magic Earth حین رانندگی هشدار
  /// داده می‌شود. مرتب‌شده نیست؛ ترتیبِ نزدیکی روی مسیر را لایه‌ی مصرف‌کننده
  /// (مثلاً حین ناوبری زنده) باید خودش با فاصله از موقعیت لحظه‌ای بسنجد.
  final List<AbmPoi> roadAlerts;
  final int expandedNodes;

  /// راه‌های استفاده‌شده فقط برای ساخت گزینه‌های جایگزین در همان اجرای router
  /// نگه‌داری می‌شوند و هیچ‌وقت به لایهٔ UI منتقل نمی‌شوند.
  final Set<AbmWay> usedWays;

  double get distanceKm => meters / 1000.0;
  double get durationMin => seconds / 60.0;
}

/// موتور مسیریابی لوکال: A* روی گراف weighted فایل .abm با هزینه‌ی travel-time.
class AbmRouter {
  AbmRouter(this.file) : graph = AbmGraph(file);

  AbmRouter.withGraph(this.file, this.graph);

  final AbmFile file;
  final AbmGraph graph;

  /// سقف گره‌های بازشده — محافظ حافظه/زمان روی موبایل.
  int maxExpanded = 400000;

  /// اگر مقداردهی شود، یال‌هایی که [AbmWay.estimatedWidthMeters] آن‌ها
  /// کمتر از این آستانه است اصلاً در جست‌وجو شرکت نمی‌کنند (مثلاً برای
  /// پروفایل «ون/کامیون» که نباید از کوچه‌های خیلی باریک رد شود).
  /// null (پیش‌فرض) یعنی بدون محدودیت عرض — رفتار فعلی بدون تغییر می‌ماند.
  /// توجه: این عرض *تخمینی* است (نگاه کنید به [AbmWidthEstimate])، نه
  /// اندازه‌ی واقعیِ نقشه‌برداری‌شده.
  double? minRoadWidthMeters;

  String? lastError;

  /// جریمه‌ی نرم (نه ممنوعیت مطلق) برای دور زدن ۱۸۰ درجه سرِ جا روی همان
  /// یالی که لحظاتی پیش از آن آمده‌ایم. داده‌ی .abm فعلاً حاوی turn-restriction
  /// واقعیِ OSM نیست (فقط جهت‌داریِ یک‌طرفه/دوطرفه در سطح یال ذخیره شده)،
  /// پس نمی‌توان U-turn را در تقاطع‌های *مشخصاً ممنوع* به‌طور قطعی تشخیص داد؛
  /// این جریمه فقط رفتار A* را واقع‌بینانه‌تر می‌کند (از این‌که کوتاه‌ترین مسیر
  /// محاسباتی با چرخیدن سرجا روی یک خیابان کوتاه انجام شود جلوگیری می‌کند)
  /// بدون این‌که مسیرهای واقعاً لازم (مثلاً بازگشت از یک بن‌بست) را غیرممکن کند.
  static const double _uTurnPenaltySeconds = 20.0;

  /// جریمهٔ نرم راه دارای برچسب واقعی toll در OSM. این جریمه، مانند راه
  /// خاکی، مسیر غیرعوارضی را مقدم می‌کند اما مقصدهای بدون مسیر جایگزین را
  /// غیرقابل دسترس نمی‌سازد.
  static const double _tollPenaltyMultiplier = 4.0;

  /// کوچه‌ها و service roadها برای دسترسی محلی لازم‌اند، اما مسیر بین دو نقطه
  /// نباید صرفاً با چند متر کوتاه‌ترشدن از آن‌ها به‌عنوان میان‌بُر استفاده کند.
  /// این ضرایب نرم هستند: اگر تنها اتصال مبدأ یا مقصد یک کوچه باشد، A* همچنان
  /// آن را انتخاب می‌کند؛ اما خیابان‌های collector و اصلی در شرایط معمول مقدم‌اند.
  static List<double> alternativePenaltyScalesFor(int alternativeIndex) =>
      alternativeIndex <= 0
          ? const <double>[0]
          : const <double>[0.20, 0.45, 0.75, 1.10];

  static double roadClassCostMultiplier(AbmWay way) {
    if (way.isLink) return 1.0;
    switch (way.klass) {
      case AbmKlass.service:
        return 3.5;
      case AbmKlass.track:
        return 4.0;
      case AbmKlass.residential:
        return way.estimatedWidthMeters < 5.0 ? 2.2 : 1.9;
      case AbmKlass.unclassified:
        return way.estimatedWidthMeters < 5.0 ? 1.6 : 1.3;
      case AbmKlass.tertiary:
        return 1.08;
      default:
        return 1.0;
    }
  }

  /// وقتی فعال باشد، راه‌های سطح خاکی بر اساس metadata واقعی ABM به‌شدت
  /// جریمه می‌شوند؛ ولی ممنوع مطلق نیستند تا مقصدهای واقعاً در راه خاکی
  /// همچنان قابل‌دسترسی باقی بمانند.
  Future<AbmRoute?> route(
    AbmPoint start,
    AbmPoint goal, {
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
  }) async {
    lastError = null;
    if (!file.containsPoint(start.lon, start.lat) ||
        !file.containsPoint(goal.lon, goal.lat)) {
      lastError =
          'مبدأ یا مقصد خارج از محدودهٔ نقشهٔ آفلاین (${file.region}) است.';
      return null;
    }

    // مبدأ باید روی یالی snap شود که واقعاً بشه از آن حرکت کرد (خروجی دارد)؛
    // مقصد این محدودیت را ندارد چون رسیدن به ته یک بن‌بست کاملاً مجاز است.
    // توجه: snap اکنون edge-based است (نه صرفاً نزدیک‌ترین گره) — نقطه دقیقاً
    // روی نزدیک‌ترین قسمتِ قابل‌عبورِ یالِ واقعی می‌نشیند، نه لزوماً یک تقاطع.
    final s = await graph.snap(start, requireOutgoing: true);
    final g = await graph.snap(goal, requireIncoming: true);
    if (s == null || g == null) {
      if (s != null) graph.releaseSnap(s.key);
      if (g != null) graph.releaseSnap(g.key);
      lastError = 'نزدیک مبدأ یا مقصد جادهٔ قابل مسیریابی پیدا نشد.';
      return null;
    }

    try {
      return await _search(
        s,
        g,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
      );
    } finally {
      // یال‌های موقتِ گره‌ی مجازی باید همیشه پاک شوند — چه مسیر پیدا شود چه نه —
      // وگرنه در reroute بعدی (مثلاً هدایت زنده‌ی GPS) به‌اشتباه به‌عنوان یال
      // واقعی باقی می‌مانند.
      graph.releaseSnap(s.key);
      graph.releaseSnap(g.key);
    }
  }

  /// تا سه مسیر واقعاً متفاوت می‌سازد. پس از هر جست‌وجو، راه‌های مسیر منتخب
  /// قبلی ممنوع نمی‌شوند؛ فقط هزینهٔ آن‌ها بالا می‌رود تا در نبود راه جایگزین
  /// مسیر اصلی همچنان قابل انتخاب باشد.
  Future<List<AbmRoute>> routeAlternatives(
    AbmPoint start,
    AbmPoint goal, {
    int maxAlternatives = 3,
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
  }) async {
    lastError = null;
    if (!file.containsPoint(start.lon, start.lat) ||
        !file.containsPoint(goal.lon, goal.lat)) {
      lastError =
          'مبدأ یا مقصد خارج از محدودهٔ نقشهٔ آفلاین (${file.region}) است.';
      return const [];
    }
    final s = await graph.snap(start, requireOutgoing: true);
    final g = await graph.snap(goal, requireIncoming: true);
    if (s == null || g == null) {
      if (s != null) graph.releaseSnap(s.key);
      if (g != null) graph.releaseSnap(g.key);
      lastError = 'نزدیک مبدأ یا مقصد جادهٔ قابل مسیریابی پیدا نشد.';
      return const [];
    }

    try {
      final out = <AbmRoute>[];
      final penalizedWays = <AbmWay>{};
      final count = maxAlternatives.clamp(1, 3).toInt();
      for (var index = 0; index < count; index++) {
        // نخست مسیر با کمترین هزینهٔ واقعی گرفته می‌شود. برای گزینه‌های بعدی،
        // اگر تلاش اول تقریباً همان مسیر قبلی بود، جریمه را مرحله‌به‌مرحله بالا
        // می‌بریم؛ break کردن در همان تلاش اول علت رایجِ نمایش فقط یک گزینه بود.
        final penaltyScales = alternativePenaltyScalesFor(index);
        AbmRoute? selected;
        for (final penaltyScale in penaltyScales) {
          final candidate = await _search(
            s,
            g,
            penalizedWays: penalizedWays,
            alternatePenaltyMultiplier: penaltyScale,
            avoidUnpavedRoads: avoidUnpavedRoads,
            avoidTolls: avoidTolls,
          );
          if (candidate == null) continue;
          if (out.any((previous) => _isNearDuplicate(previous, candidate))) {
            continue;
          }
          selected = candidate;
          break;
        }
        // اگر با هیچ جریمه‌ای مسیر واقعاً متفاوت وجود نداشت، یک مسیر صادقانه
        // بهتر از سه گزینهٔ تکراری است.
        if (selected == null) break;
        out.add(selected);
        penalizedWays.addAll(selected.usedWays);
      }
      return out;
    } finally {
      graph.releaseSnap(s.key);
      graph.releaseSnap(g.key);
    }
  }

  bool _isNearDuplicate(AbmRoute a, AbmRoute b) {
    if (a.usedWays.isEmpty || b.usedWays.isEmpty) return false;
    final shared = a.usedWays.intersection(b.usedWays).length;
    final smaller = math.min(a.usedWays.length, b.usedWays.length);
    return smaller > 0 && shared / smaller >= 0.92;
  }

  Future<AbmRoute?> _search(
    AbmSnap s,
    AbmSnap g, {
    Set<AbmWay> penalizedWays = const {},
    double alternatePenaltyMultiplier = 0.0,
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
  }) async {
    double heuristic(AbmPoint p) {
      final dx = (p.lon - g.point.lon) * 88000;
      final dy = (p.lat - g.point.lat) * 111000;
      // سقف خوش‌بینانه ۱۲۰km/h ⇒ ۳۳ متر بر ثانیه (مانند خواننده‌ی مرجع)
      return math.sqrt(dx * dx + dy * dy) / 33.0;
    }

    final open = _MinHeap();
    // bestG: هزینه‌ی *اولویت‌بندیِ* A* (شامل جریمه‌ی U-turn) — فقط برای مرتب‌سازی صف.
    // زمان واقعیِ سفر (بدون این جریمه‌ی مصنوعی) در _Node.actual جدا نگه داشته
    // می‌شود و همان چیزی است که در ETA نهایی نمایش داده می‌شود.
    final bestG = <int, double>{s.key: 0.0};
    final cameFrom = <int, _Trace>{};
    open.push(_Node(heuristic(s.point), 0, 0, s.key, s.point));

    var expanded = 0;
    final closed = <int>{};

    while (!open.isEmpty) {
      final node = open.pop();
      if (!closed.add(node.key)) continue;
      expanded++;
      if (expanded > maxExpanded) {
        lastError = 'مسیر بیش از حد طولانی است (محدودیت پردازش دستگاه).';
        return null;
      }

      if (node.key == g.key) {
        return _build(s, g, cameFrom, node.actual, expanded);
      }

      // گره‌های مرزی ⇒ کاشی‌های همسایه هم باید بارگذاری شوند تا گراف پیوسته بماند.
      if (graph.neighbors(node.key).isEmpty || graph.isBorderNode(node.key)) {
        await graph.ensureAround(node.point);
      }

      final incoming = cameFrom[node.key];
      final neighborArcs = graph.neighbors(node.key);
      for (final arc in neighborArcs) {
        // فیلتر عرض (اختیاری) — یال‌های باریک‌تر از حد مجاز اصلاً بررسی
        // نمی‌شوند، مگر این‌که تنها راه رسیدن به مقصد باشند (چون این یک
        // تخمین است، نباید کل مسیر را غیرممکن کند؛ اگر جست‌وجو با این
        // فیلتر مسیری پیدا نکرد، فراخوان می‌تواند بدون فیلتر دوباره تلاش کند).
        if (minRoadWidthMeters != null &&
            arc.way.estimatedWidthMeters < minRoadWidthMeters!) {
          continue;
        }
        var penalty = 0.0;
        // اگر این یال دقیقاً همان یالی است که یک لحظه پیش از آن آمدیم (یعنی
        // برمی‌گردیم به همان fromKey، روی همان way) ⇒ این یک U-turn سرجاست؛
        // جریمه‌اش می‌کنیم مگر این‌که واقعاً تنها گزینه باشد (بن‌بست).
        if (incoming != null &&
            arc.toKey == incoming.fromKey &&
            identical(arc.way, incoming.arc.way) &&
            neighborArcs.length > 1) {
          penalty = _uTurnPenaltySeconds;
        }
        // مسیرهای قبلی با ضریب هزینهٔ نرم دوباره قابل‌استفاده‌اند، اما A*
        // ابتدا خیابان‌های واقعاً متفاوت را ترجیح می‌دهد.
        // مسیرهای جایگزین باید واقعاً متفاوت باشند، اما جریمهٔ بیش‌ازحد
        // خیابان اصلی، router را به میان‌بُرهای کوچه‌ای غیرمنطقی می‌فرستاد.
        final alternatePenalty = penalizedWays.contains(arc.way)
            ? arc.seconds * alternatePenaltyMultiplier
            : 0.0;
        final localRoadPenalty =
            arc.seconds * (roadClassCostMultiplier(arc.way) - 1.0);
        // surfaceUnpaved در فایل ABM یک صفت واقعی راه است. جریمهٔ نرم از
        // قطع اتصال مقصدهای خاکی جلوگیری می‌کند، اما راه آسفالته را مقدم
        // می‌دارد.
        final unpavedPenalty = avoidUnpavedRoads && arc.way.isSurfaceUnpaved
            ? arc.seconds * 4.0
            : 0.0;
        final tollPenalty = avoidTolls && arc.way.isToll
            ? arc.seconds * _tollPenaltyMultiplier
            : 0.0;
        final ng = node.g +
            arc.seconds +
            penalty +
            alternatePenalty +
            localRoadPenalty +
            unpavedPenalty +
            tollPenalty;
        if (ng + 1e-9 >= (bestG[arc.toKey] ?? double.infinity)) continue;
        bestG[arc.toKey] = ng;
        final actual = node.actual + arc.seconds;
        cameFrom[arc.toKey] = _Trace(node.key, arc);
        open.push(_Node(
            ng + heuristic(arc.toPoint), ng, actual, arc.toKey, arc.toPoint));
      }
    }

    lastError = 'مسیری بین مبدأ و مقصد در نقشهٔ آفلاین پیدا نشد.';
    return null;
  }

  AbmRoute _build(AbmSnap s, AbmSnap g, Map<int, _Trace> cameFrom,
      double seconds, int expanded) {
    // بازسازی مسیر از مقصد به مبدأ
    final arcs = <AbmArc>[];
    final points = <AbmPoint>[g.point];
    var key = g.key;
    while (key != s.key) {
      final trace = cameFrom[key];
      if (trace == null) break;
      arcs.add(trace.arc);
      // points در جهتِ goal→start ساخته می‌شود؛ چون trace.arc.shape از
      // fromKey به‌سمتِ toKey (یعنی start→goal) مرتب شده، اینجا باید
      // برعکس اضافه شود تا بعدِ .reversed پایینی، به ترتیبِ درستِ
      // start→goal برگردد.
      if (trace.arc.shape.isNotEmpty) {
        points.addAll(trace.arc.shape.reversed);
      }
      final prevPoint = graph.positionOf(trace.fromKey);
      if (prevPoint != null) points.add(prevPoint);
      key = trace.fromKey;
    }
    final geometry = points.reversed.toList();
    final orderedArcs = arcs.reversed.toList();

    var meters = 0.0;
    for (final a in orderedArcs) {
      meters += a.meters;
    }

    return AbmRoute(
      points: geometry,
      seconds: seconds,
      meters: meters,
      maneuvers: _maneuvers(geometry, orderedArcs),
      roadAlerts: _alertsNear(geometry),
      expandedNodes: expanded,
      usedWays: orderedArcs.map((arc) => arc.way).toSet(),
    );
  }

  /// ساخت دستورهای فارسی از تغییر نام جاده و زاویه‌ی چرخش.
  List<AbmManeuver> _maneuvers(List<AbmPoint> geometry, List<AbmArc> arcs) {
    final out = <AbmManeuver>[];
    if (geometry.length < 2 || arcs.isEmpty) return out;

    final firstWay = arcs.first.way;
    out.add(AbmManeuver(
      text:
          firstWay.name.isEmpty ? 'حرکت کنید' : 'حرکت کنید در ${firstWay.name}',
      distanceMeters: 0,
      point: geometry.first,
      type: 'depart',
      speedLimitKmh: firstWay.speedLimitKmh,
      roadName: firstWay.name.isEmpty ? null : firstWay.name,
    ));

    var legMeters = arcs.first.meters;
    for (var i = 1; i < arcs.length; i++) {
      final prev = arcs[i - 1];
      final cur = arcs[i];
      final at = geometry[i];
      final bearingIn = AbmTileMath.bearing(geometry[i - 1], at);
      final bearingOut = AbmTileMath.bearing(
          at, geometry[i + 1 < geometry.length ? i + 1 : i]);
      var delta = (bearingOut - bearingIn + 540) % 360 - 180;

      final nameChanged = cur.way.name != prev.way.name &&
          (cur.way.name.isNotEmpty || prev.way.name.isNotEmpty);
      final significant = delta.abs() >= 25;

      if (cur.way.isRoundabout && !prev.way.isRoundabout) {
        out.add(AbmManeuver(
          text: cur.way.name.isEmpty
              ? 'وارد میدان شوید'
              : 'وارد میدان شوید به ${cur.way.name}',
          distanceMeters: legMeters,
          point: at,
          type: 'roundabout',
          speedLimitKmh: cur.way.speedLimitKmh,
          roadName: cur.way.name.isEmpty ? null : cur.way.name,
        ));
        legMeters = cur.meters;
        continue;
      }

      if (significant || (nameChanged && legMeters > 60)) {
        final modifier = _modifier(delta);
        final direction = _directionFa(delta);
        final nameText = cur.way.name.isEmpty ? '' : ' به ${cur.way.name}';
        final action = significant
            ? (delta.abs() > 150 ? 'دور بزنید' : 'بپیچید')
            : 'ادامه دهید';
        final text = significant && delta.abs() > 150
            ? 'دور بزنید$nameText'
            : '$action $direction$nameText'.trim();
        out.add(AbmManeuver(
          text: text,
          distanceMeters: legMeters,
          point: at,
          type: significant ? 'turn' : 'continue',
          modifier: modifier,
          speedLimitKmh: cur.way.speedLimitKmh,
          roadName: cur.way.name.isEmpty ? null : cur.way.name,
        ));
        legMeters = cur.meters;
      } else {
        legMeters += cur.meters;
      }
    }

    out.add(AbmManeuver(
      text: 'به مقصد رسیدید',
      distanceMeters: legMeters,
      point: geometry.last,
      type: 'arrive',
      speedLimitKmh: arcs.last.way.speedLimitKmh,
    ));
    return out;
  }

  String? _modifier(double delta) {
    if (delta.abs() < 25) return 'straight';
    if (delta.abs() > 150) return 'uturn';
    final side = delta > 0 ? 'right' : 'left';
    if (delta.abs() > 100) return 'sharp $side';
    if (delta.abs() < 45) return 'slight $side';
    return side;
  }

  String _directionFa(double delta) {
    if (delta.abs() < 25) return 'مستقیم';
    final right = delta > 0;
    if (delta.abs() > 150) return '';
    if (delta.abs() > 100) return right ? 'کاملاً به راست' : 'کاملاً به چپ';
    if (delta.abs() < 45) return right ? 'کمی به راست' : 'کمی به چپ';
    return right ? 'به راست' : 'به چپ';
  }

  /// دوربین‌های سرعت (klass=70) و سرعت‌گیرهای فیزیکی (klass=71) در فاصله‌ی
  /// حداکثر ۶۰ متری از مسیر — graph.pois از قبل به همین دو نوع فیلتر شده
  /// (نگاه کنید به AbmGraph.ensureTile: isSpeedAlert).
  List<AbmPoi> _alertsNear(List<AbmPoint> geometry, {double meters = 60}) {
    final out = <AbmPoi>[];
    for (final alert in graph.pois) {
      for (final p in geometry) {
        if (AbmTileMath.haversineMeters(alert.point, p) <= meters) {
          out.add(alert);
          break;
        }
      }
    }
    return out;
  }
}

class _Trace {
  const _Trace(this.fromKey, this.arc);
  final int fromKey;
  final AbmArc arc;
}

class _Node {
  _Node(this.f, this.g, this.actual, this.key, this.point);
  final double f;

  /// هزینه‌ی اولویت‌بندی (شامل جریمه‌ی نرم U-turn).
  final double g;

  /// زمان واقعیِ سفر تا این گره (بدون جریمه) — برای ETA نهایی.
  final double actual;
  final int key;
  final AbmPoint point;
}

/// هیپ دودویی کمینه — صف اولویت A*.
class _MinHeap {
  final List<_Node> _items = [];

  bool get isEmpty => _items.isEmpty;

  void push(_Node n) {
    _items.add(n);
    var i = _items.length - 1;
    while (i > 0) {
      final parent = (i - 1) >> 1;
      if (_items[parent].f <= _items[i].f) break;
      final tmp = _items[parent];
      _items[parent] = _items[i];
      _items[i] = tmp;
      i = parent;
    }
  }

  _Node pop() {
    final top = _items.first;
    final last = _items.removeLast();
    if (_items.isNotEmpty) {
      _items[0] = last;
      var i = 0;
      while (true) {
        final l = 2 * i + 1;
        final r = l + 1;
        var smallest = i;
        if (l < _items.length && _items[l].f < _items[smallest].f) smallest = l;
        if (r < _items.length && _items[r].f < _items[smallest].f) smallest = r;
        if (smallest == i) break;
        final tmp = _items[smallest];
        _items[smallest] = _items[i];
        _items[i] = tmp;
        i = smallest;
      }
    }
    return top;
  }
}
