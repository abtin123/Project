import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'features/gps/presentation/gps_providers.dart';
import 'shared/providers/app_settings_providers.dart';
import 'core/deep_link/deep_link_service.dart';
import 'features/map/presentation/destination_provider.dart';
import 'features/routing/presentation/routing_providers.dart';
import 'package:abtin_maps/core/geo/geo_types.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      statusBarBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarIconBrightness: Brightness.light,
      systemNavigationBarDividerColor: Colors.transparent,
    ),
  );
  runApp(const ProviderScope(child: AbtinApp()));
}

class AbtinApp extends ConsumerStatefulWidget {
  const AbtinApp({super.key});

  @override
  ConsumerState<AbtinApp> createState() => _AbtinAppState();
}

class _AbtinAppState extends ConsumerState<AbtinApp>
    with WidgetsBindingObserver {
  bool _locationSuspendedForBackground = false;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final locationService = ref.read(locationServiceProvider);
    final navigationActive = ref.read(activeNavigationProvider) != null;
    if (state == AppLifecycleState.resumed) {
      ref.read(locationLifecycleTickProvider.notifier).state++;
      if (_locationSuspendedForBackground) {
        _locationSuspendedForBackground = false;
        locationService.start();
      }
      return;
    }
    if ((state == AppLifecycleState.inactive ||
            state == AppLifecycleState.paused ||
            state == AppLifecycleState.hidden) &&
        !navigationActive) {
      // خارج از ناوبری فعال، نگه‌داشتن GPS، دو سنسور و foreground service در
      // پس‌زمینه مصرف بی‌دلیل CPU/باتری است. شروع مجدد فقط در resumed رخ می‌دهد.
      locationService.stop();
      _locationSuspendedForBackground = true;
    }
  }

  @override
  Widget build(BuildContext context) {
    final initAsync = ref.watch(appSettingsInitProvider);

    // بدون این watch، jointKalmanEnabledEffectProvider هیچ‌وقت ساخته نمی‌شود
    // و در نتیجه setJointKalmanEnabled() هرگز صدا زده نمی‌شد — فیلتر کالمن
    // مشترک با وجود پیاده‌سازی کامل، عملاً کال نمی‌شد.
    ref.watch(jointKalmanEnabledEffectProvider);

    // Listen to deep links
    ref.listen(deepLinkDestinationProvider, (previous, next) {
      next.whenData((dest) {
        ref.read(selectedDestinationProvider.notifier).state =
            SelectedDestination(
          LatLng(dest.lat, dest.lng),
          label: dest.label,
        );
        appRouter.go('/');
      });
    });

    return initAsync.when(
      data: (_) => _buildApp(context, ref),
      loading: () => const _SplashApp(),
      error: (_, __) => _buildApp(context, ref),
    );
  }

  Widget _buildApp(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);
    final lang = ref.watch(languageProvider);
    final primaryColor = ref.watch(primaryColorProvider);

    return MaterialApp.router(
      title: 'آبتین مپس',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.build(Brightness.light, primaryColor),
      darkTheme: AppTheme.build(Brightness.dark, primaryColor),
      themeMode: themeMode,
      routerConfig: appRouter,
      locale: Locale(lang),
      supportedLocales: const [
        Locale('fa'),
        Locale('en'),
        Locale('ar'),
        Locale('cs'),
        Locale('da'),
        Locale('de'),
        Locale('el'),
        Locale('es'),
        Locale('fi'),
        Locale('fr'),
        Locale('he'),
        Locale('hi'),
        Locale('hu'),
        Locale('id'),
        Locale('it'),
        Locale('ja'),
        Locale('ko'),
        Locale('nl'),
        Locale('no'),
        Locale('pl'),
        Locale('pt'),
        Locale('ro'),
        Locale('ru'),
        Locale('sv'),
        Locale('th'),
        Locale('tr'),
        Locale('uk'),
        Locale('ur'),
        Locale('vi'),
        Locale('zh'),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final overlayStyle = SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
          statusBarBrightness: isDark ? Brightness.dark : Brightness.light,
          systemNavigationBarColor: Colors.transparent,
          systemNavigationBarIconBrightness:
              isDark ? Brightness.light : Brightness.dark,
          systemNavigationBarDividerColor: Colors.transparent,
        );
        return AnnotatedRegion<SystemUiOverlayStyle>(
          value: overlayStyle,
          child: MediaQuery(
            // مقیاس فونت سیستم (مثلاً «اندازه‌ی فونت» بزرگ در تنظیمات MIUI)
            // بدون محدودسازی باعث می‌شد layoutهای با عرض ثابت (مثل ردیف
            // دانلود نقشه) بشکنند و متن‌ها به‌جای کنار هم، زیر هم بیفتند.
            data: MediaQuery.of(context).copyWith(
              textScaler: MediaQuery.of(context)
                  .textScaler
                  .clamp(minScaleFactor: 0.85, maxScaleFactor: 1.15),
            ),
            child: Directionality(
              textDirection: const {'fa', 'ar', 'he', 'ur'}.contains(lang)
                  ? TextDirection.rtl
                  : TextDirection.ltr,
              child: child ?? const SizedBox.shrink(),
            ),
          ),
        );
      },
    );
  }
}

/// Minimal splash shown only for the brief moment it takes to read the
/// persisted language/theme from the local database on cold start.
class _SplashApp extends StatelessWidget {
  const _SplashApp();

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Color(0xFF0A0D12),
        body: Center(
          child: CircularProgressIndicator(color: Color(0xFF2FE6C4)),
        ),
      ),
    );
  }
}
