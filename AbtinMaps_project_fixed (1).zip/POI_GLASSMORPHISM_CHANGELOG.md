# تغییرات POI داخل اپ

آیکون‌های `assets/sprites/abtin.png` و `abtin@2x.png` از تصویر مرجع ارسالی استخراج شده‌اند و همان دایره‌های شیشه‌ای نئونی، رنگ‌ها و glyphهای مرجع را حفظ می‌کنند. JSONهای atlas نیز با نام‌های قبلی باقی مانده‌اند تا styleهای MapLibre بدون تغییر نام لایه‌ها و icon-imageها کار کنند.

در `lib/abtinmap/abm_style_assets.dart` مسیر cache به `abm_style/glass-v2` تغییر کرده است. این تغییر ضروری است تا نسخه‌های نصب‌شده‌ای که sprite قدیمی را در Application Support ذخیره کرده‌اند، بعد از آپدیت دوباره asset قبلی را سرو نکنند.

Flutter SDK در محیط فعلی موجود نیست؛ بنابراین `flutter analyze` و `flutter test` باید در CI یا سیستم توسعه‌ای دارای Flutter اجرا شوند.
