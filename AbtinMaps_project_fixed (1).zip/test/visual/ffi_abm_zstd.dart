import 'dart:ffi';
import 'dart:typed_data';

import 'package:abtin_maps/abtinmap/abm_zstd.dart';
import 'package:ffi/ffi.dart';

/// فقط برای تست تصویری Linux. اپ موبایل همچنان از PluginAbmZstd استفاده می‌کند.
class FfiAbmZstd implements AbmZstd {
  FfiAbmZstd() : _lib = DynamicLibrary.open('libzstd.so.1') {
    _decompress =
        _lib.lookupFunction<_ZstdDecompressNative, _ZstdDecompressDart>(
      'ZSTD_decompress',
    );
    _isError = _lib.lookupFunction<_ZstdIsErrorNative, _ZstdIsErrorDart>(
      'ZSTD_isError',
    );
  }

  final DynamicLibrary _lib;
  late final _ZstdDecompressDart _decompress;
  late final _ZstdIsErrorDart _isError;

  @override
  Future<Uint8List> decompress(Uint8List input, {int? expectedSize}) async {
    if (expectedSize == null || expectedSize <= 0) {
      throw const AbmZstdException(
          'اندازهٔ خام بلوک ABM برای تست تصویری مشخص نیست.');
    }
    final src = calloc<Uint8>(input.length);
    final dst = calloc<Uint8>(expectedSize);
    try {
      src.asTypedList(input.length).setAll(0, input);
      final written = _decompress(dst, expectedSize, src, input.length);
      if (_isError(written) != 0 || written != expectedSize) {
        throw AbmZstdException(
          'رمزگشایی zstd تست تصویری ناموفق بود: expected=$expectedSize actual=$written',
        );
      }
      return Uint8List.fromList(dst.asTypedList(written));
    } finally {
      calloc.free(src);
      calloc.free(dst);
    }
  }
}

typedef _ZstdDecompressNative = Size Function(
  Pointer<Uint8> dst,
  Size dstCapacity,
  Pointer<Uint8> src,
  Size srcSize,
);
typedef _ZstdDecompressDart = int Function(
  Pointer<Uint8> dst,
  int dstCapacity,
  Pointer<Uint8> src,
  int srcSize,
);
typedef _ZstdIsErrorNative = Uint32 Function(Size code);
typedef _ZstdIsErrorDart = int Function(int code);
