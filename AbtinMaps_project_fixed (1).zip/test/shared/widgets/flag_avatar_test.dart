import 'package:abtin_maps/core/localization/locale_flags.dart';
import 'package:abtin_maps/shared/widgets/flag_avatar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('flag asset mapping', () {
    test('maps supported language and country codes to standard SVG assets',
        () {
      expect(flagAssetForLanguageCode('fa'), 'assets/images/flags/ir.svg');
      expect(flagAssetForLanguageCode('en'), 'assets/images/flags/gb.svg');
      expect(flagAssetForCountryCode('DE'), 'assets/images/flags/de.svg');
    });

    test('uses the UN SVG asset as a predictable fallback', () {
      expect(flagAssetForLanguageCode(''), 'assets/images/flags/un.svg');
      expect(flagAssetForCountryCode('ZZ'), 'assets/images/flags/un.svg');
    });
  });

  group('FlagAvatar', () {
    testWidgets('renders a 4:3 rectangular SVG flag without circle cropping',
        (tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: FlagAvatar.rectangle(
              flag: 'assets/images/flags/ir.svg',
              size: 36,
            ),
          ),
        ),
      );

      expect(find.byType(SvgPicture), findsOneWidget);
      expect(
        find.byWidgetPredicate(
          (widget) =>
              widget is SizedBox && widget.width == 48 && widget.height == 36,
        ),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
    });

    testWidgets('keeps the full SVG inside a circular compact frame',
        (tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: FlagAvatar.circle(
              flag: 'assets/images/flags/gb.svg',
              size: 36,
            ),
          ),
        ),
      );

      expect(find.byType(SvgPicture), findsOneWidget);
      expect(
        find.byWidgetPredicate(
          (widget) =>
              widget is SizedBox && widget.width == 36 && widget.height == 36,
        ),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
    });
  });
}
