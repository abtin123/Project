import 'package:abtin_maps/features/settings/domain/appearance_settings.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('AppearanceSettings vehicle camera perspective', () {
    test('defaults to the controlled vertical navigation view', () {
      const settings = AppearanceSettings();
      expect(settings.navigationCameraTiltDegrees, 42.0);
    });

    test('persists the vertical top-to-rear camera position', () {
      const settings = AppearanceSettings(navigationCameraTiltDegrees: 90.0);
      final restored = AppearanceSettings.fromJson(settings.toJson());
      expect(restored.navigationCameraTiltDegrees, 90.0);
    });

    test('clamps the vertical camera position between top and rear', () {
      final top = AppearanceSettings.fromJson(
        const <String, dynamic>{'navigationCameraTiltDegrees': -20.0},
      );
      final rear = AppearanceSettings.fromJson(
        const <String, dynamic>{'navigationCameraTiltDegrees': 120.0},
      );
      expect(top.navigationCameraTiltDegrees, 0.0);
      expect(rear.navigationCameraTiltDegrees, 90.0);
    });

    test('ignores legacy horizontal preview yaw without persisting it', () {
      final restored = AppearanceSettings.fromJson(
        const <String, dynamic>{'vehiclePreviewYawDegrees': 270.0},
      );
      expect(restored.navigationCameraTiltDegrees, 42.0);
      expect(
          restored.toJson().containsKey('vehiclePreviewYawDegrees'), isFalse);
    });
  });
}
