import 'dart:convert';

import 'package:abtin_maps/features/offline_maps/data/map_catalog.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('maps-v3 manifest compatibility', () {
    test('parses the published IR country entry and preserves its asset URL',
        () {
      const manifest = '''
{
  "schema": 1,
  "release_tag": "maps-v3",
  "countries": [
    {
      "code": "IR",
      "name_fa": "ایران",
      "name_en": "Iran",
      "country_code": "IR",
      "country_name_fa": "ایران",
      "country_name_en": "Iran",
      "region_name_fa": "ایران",
      "region_name_en": "Iran",
      "enabled": true,
      "bbox": [44.0161863, 25.0631433, 64.3179533, 46.4725314],
      "files": [
        {
          "name": "IR.abm",
          "size": 418791731,
          "sha256": "d8161296e4916dc28d07529bfb68660b1b3fba7608ab85cbde880b646d4d9eaf"
        }
      ],
      "total_size": 418791731,
      "sha256": "d8161296e4916dc28d07529bfb68660b1b3fba7608ab85cbde880b646d4d9eaf",
      "download_base": "https://github.com/abtin123/abtin-maps/releases/download/maps-v3/"
    }
  ]
}
''';
      final decoded = jsonDecode(manifest) as Map<String, dynamic>;
      final country =
          (decoded['countries'] as List).single as Map<String, dynamic>;
      final region = MapRegion.fromJson(
        country,
        defaultDownloadBase:
            'https://github.com/abtin123/abtin-maps/releases/download/maps-v3/',
      );

      expect(decoded['release_tag'], 'maps-v3');
      expect(region.id, 'IR');
      expect(region.abmFileName, 'IR.abm');
      expect(region.files, hasLength(1));
      expect(region.files.single.name, 'IR.abm');
      expect(region.files.single.size, 418791731);
      expect(region.version,
          'd8161296e4916dc28d07529bfb68660b1b3fba7608ab85cbde880b646d4d9eaf');
      expect(region.effectiveDownloadBase,
          'https://github.com/abtin123/abtin-maps/releases/download/maps-v3/');
    });

    test('uses maps-v3 as the safe fallback release for incomplete manifests',
        () {
      const fallbackUrl =
          'https://github.com/abtin123/abtin-maps/releases/download/maps-v3/';
      final region = MapRegion.fromJson(
        <String, dynamic>{
          'code': 'IR',
          'bbox': <double>[44, 25, 64, 46],
          'files': <Map<String, dynamic>>[
            <String, dynamic>{'name': 'IR.abm', 'size': 1},
          ],
        },
        defaultDownloadBase: fallbackUrl,
      );

      expect(region.effectiveDownloadBase, fallbackUrl);
    });
  });
}
