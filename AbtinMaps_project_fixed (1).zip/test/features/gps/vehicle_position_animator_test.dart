import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_maps/features/gps/data/location_service.dart';
import 'package:abtin_maps/features/gps/presentation/vehicle_position_animator.dart';

VehiclePosition _pos({
  required double lat,
  required double lng,
  double heading = 0,
  double speedKmh = 0,
  double accuracyM = 5,
  bool isEstimated = false,
}) =>
    VehiclePosition(
      lat: lat,
      lng: lng,
      headingDeg: heading,
      speedKmh: speedKmh,
      accuracyM: accuracyM,
      isEstimated: isEstimated,
    );

void main() {
  group('VehiclePositionAnimator', () {
    late VehiclePositionAnimator animator;

    setUp(() {
      animator = VehiclePositionAnimator();
    });

    tearDown(() {
      animator.dispose();
    });

    test('stationary fix (speed < 2km/h) is emitted exactly, no drift',
        () async {
      animator.onRawFix(_pos(lat: 35.7, lng: 51.4, speedKmh: 0));

      final emitted =
          await animator.stream.first.timeout(const Duration(seconds: 1));

      expect(emitted.lat, 35.7);
      expect(emitted.lng, 51.4);
      expect(emitted.speedKmh, 0);
    });

    test('first real moving fix after estimated bootstrap keeps its speed',
        () async {
      final events = <VehiclePosition>[];
      final sub = animator.stream.listen(events.add);

      animator.onRawFix(
        _pos(lat: 35.7, lng: 51.4, isEstimated: true, speedKmh: 0),
      );
      await Future<void>.delayed(const Duration(milliseconds: 40));
      animator.onRawFix(
        _pos(lat: 35.7001, lng: 51.4, speedKmh: 42),
      );
      await Future<void>.delayed(const Duration(milliseconds: 40));

      expect(events, isNotEmpty);
      expect(events.last.speedKmh, closeTo(42, 1.0));
      await sub.cancel();
    });

    test('two moving fixes interpolate lat/lng between them', () async {
      animator.onRawFix(_pos(lat: 35.700, lng: 51.400, speedKmh: 40));
      await Future<void>.delayed(const Duration(milliseconds: 120));
      animator.onRawFix(_pos(lat: 35.701, lng: 51.401, speedKmh: 40));

      final events = <VehiclePosition>[];
      final sub = animator.stream.listen(events.add);
      await Future<void>.delayed(const Duration(milliseconds: 60));
      await sub.cancel();

      expect(events, isNotEmpty);
      final mid = events.last;
      // باید بینِ دو فیکس باشد، نه دقیقاً برابرِ یکی از آن‌ها (یعنی واقعاً
      // interpolate شده، نه snap به فیکس آخر یا اول).
      expect(mid.lat, greaterThanOrEqualTo(35.700));
      expect(mid.lat, lessThanOrEqualTo(35.701));
      expect(mid.lng, greaterThanOrEqualTo(51.400));
      expect(mid.lng, lessThanOrEqualTo(51.401));
    });

    test('estimated interval adapts toward the real gap between fixes',
        () async {
      animator.onRawFix(_pos(lat: 0, lng: 0, speedKmh: 10));
      await Future<void>.delayed(const Duration(milliseconds: 200));
      animator.onRawFix(_pos(lat: 0.0001, lng: 0.0001, speedKmh: 10));
      await Future<void>.delayed(const Duration(milliseconds: 200));
      animator.onRawFix(_pos(lat: 0.0002, lng: 0.0002, speedKmh: 10));

      // فقط عدم-کرش/عدم-throw را تأیید می‌کنیم؛ _estimatedIntervalMs
      // خصوصی است و مستقیم قابل‌خواندن نیست، اما اگر منطق EMA خراب بود
      // (مثلاً تقسیم بر صفر یا NaN) استریم دیگر مقدار معتبر نمی‌داد.
      final last =
          await animator.stream.first.timeout(const Duration(seconds: 1));
      expect(last.lat.isFinite, isTrue);
      expect(last.lng.isFinite, isTrue);
    });

    test('large acceleration is rate limited instead of jumping 10 -> 40 -> 70',
        () async {
      final events = <VehiclePosition>[];
      final sub = animator.stream.listen(events.add);

      animator.onRawFix(_pos(lat: 35.7, lng: 51.4, speedKmh: 10));
      await Future<void>.delayed(const Duration(milliseconds: 120));
      animator.onRawFix(_pos(lat: 35.7001, lng: 51.4001, speedKmh: 40));
      await Future<void>.delayed(const Duration(milliseconds: 120));

      expect(events, isNotEmpty);
      // At 16 km/h/s, 120 ms cannot turn 10 into 40.
      expect(events.last.speedKmh, lessThan(20));

      animator.onRawFix(_pos(lat: 35.7002, lng: 51.4002, speedKmh: 70));
      await Future<void>.delayed(const Duration(milliseconds: 120));
      expect(events.last.speedKmh, lessThan(30));

      await sub.cancel();
    });

    test('braking is continuous and reaches zero without a <2 km/h snap',
        () async {
      final events = <VehiclePosition>[];
      final sub = animator.stream.listen(events.add);

      animator.onRawFix(_pos(lat: 35.7, lng: 51.4, speedKmh: 40));
      await Future<void>.delayed(const Duration(milliseconds: 120));
      animator.onRawFix(_pos(lat: 35.7001, lng: 51.4001, speedKmh: 0));
      await Future<void>.delayed(const Duration(milliseconds: 120));

      expect(events, isNotEmpty);
      expect(events.last.speedKmh, greaterThan(0));

      // از ۴۰km/h با سقف ترمز ۲۴km/h/s رسیدن پیوسته به صفر حداقل
      // ۱.۶۷ ثانیه زمان می‌خواهد. به‌جای زمان ثابت شکننده، تا صفرشدن
      // واقعی با یک سقف زمانی معقول صبر می‌کنیم.
      final deadline = DateTime.now().add(const Duration(seconds: 3));
      while (events.last.speedKmh > 0.5 && DateTime.now().isBefore(deadline)) {
        await Future<void>.delayed(const Duration(milliseconds: 40));
      }
      expect(events.last.speedKmh, closeTo(0, 0.5));

      await sub.cancel();
    });

    test('dispose() closes the stream — no further events, no throw', () async {
      animator.onRawFix(_pos(lat: 1, lng: 1, speedKmh: 0));
      await animator.stream.first.timeout(const Duration(seconds: 1));

      final doneCompleter = Completer<void>();
      animator.stream.listen(null, onDone: doneCompleter.complete);

      animator.dispose();
      await doneCompleter.future.timeout(const Duration(seconds: 1));

      // dispose دوباره نباید throw کند (StreamController.close دوباره خطا
      // می‌دهد اگر محافظت نشده باشد) — این دقیقاً چیزی است که تست lifecycle
      // (باز/بسته‌شدنِ مکرر Map) روی آن تکیه می‌کند.
      expect(() => animator.dispose(), returnsNormally);
    });
  });
}
