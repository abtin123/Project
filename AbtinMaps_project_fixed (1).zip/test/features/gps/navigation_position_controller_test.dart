import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_maps/features/gps/data/location_service.dart';
import 'package:abtin_maps/features/gps/presentation/navigation_position_controller.dart';

VehiclePosition _pos({
  required double lat,
  required double lng,
  double speedKmh = 0,
  double accuracyM = 5,
}) =>
    VehiclePosition(
      lat: lat,
      lng: lng,
      headingDeg: 0,
      speedKmh: speedKmh,
      accuracyM: accuracyM,
    );

void main() {
  group('NavigationPositionController (graph: null — pass-through)', () {
    // این تست‌ها فقط رفتارِ «بدون گراف» را می‌پوشانند — یعنی همان چیزی که
    // navigationPositionControllerProvider تا وقتی abmFileProvider هنوز
    // بارگذاری نشده (یا نقشه نصب نیست) واقعاً می‌سازد. مسیرِ map-matching
    // واقعی (graph غیر-null) به یک AbmFile واقعی نیاز دارد که constructor
    // خصوصی‌اش اجازه‌ی ساختِ فیک/موکِ سبک در unit test را نمی‌دهد — پوششِ
    // آن مسیر باید از طریق تستِ روی دستگاه/داده‌ی واقعیِ .abm انجام شود،
    // نه اینجا.

    test('raw stationary fix passes straight through unchanged', () async {
      final controller = NavigationPositionController();
      final upstream = StreamController<VehiclePosition>.broadcast();
      controller.attach(upstream.stream);

      upstream.add(_pos(lat: 35.7, lng: 51.4, speedKmh: 0));

      final out = await controller.positionStream.first
          .timeout(const Duration(seconds: 1));
      expect(out.lat, 35.7);
      expect(out.lng, 51.4);

      await upstream.close();
      controller.dispose();
    });

    test('re-attach cancels the previous subscription (no duplicate emissions)',
        () async {
      final controller = NavigationPositionController();
      final first = StreamController<VehiclePosition>.broadcast();
      final second = StreamController<VehiclePosition>.broadcast();

      controller.attach(first.stream);
      controller.attach(second.stream); // باید اشتراکِ اول را cancel کند

      final events = <VehiclePosition>[];
      final sub = controller.positionStream.listen(events.add);

      first.add(_pos(lat: 1, lng: 1, speedKmh: 0));
      second.add(_pos(lat: 2, lng: 2, speedKmh: 0));

      await Future<void>.delayed(const Duration(milliseconds: 100));
      await sub.cancel();
      await first.close();
      await second.close();
      controller.dispose();

      // فقط استریمِ دوم باید اثر داشته باشد؛ اگر اشتراکِ اول cancel نشده
      // بود، هر دو فیکس به‌طور هم‌زمان به آنیماتور می‌رسیدند و نتیجه‌ی
      // غیرقابل‌پیش‌بینی/رقابتی می‌داد.
      expect(events.any((p) => p.lat == 1), isFalse);
      expect(events.any((p) => p.lat == 2), isTrue);
    });

    test(
        'dispose() cancels the subscription — further upstream events are silently dropped',
        () async {
      final controller = NavigationPositionController();
      final upstream = StreamController<VehiclePosition>.broadcast();
      controller.attach(upstream.stream);

      controller.dispose();

      // نباید throw کند — دقیقاً سناریوی «Map بسته شد در حالی که هنوز
      // فیکس‌های GPS می‌رسند» که در طراحیِ اصلی (بخش سوم/دهم) خواسته شده
      // بود که کرش نکند.
      expect(() => upstream.add(_pos(lat: 9, lng: 9, speedKmh: 0)),
          returnsNormally);

      await upstream.close();
    });
  });
}
