import 'dart:async';

import 'package:fake_async/fake_async.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:geolocator/geolocator.dart';
import 'package:mocktail/mocktail.dart';
import 'package:plugin_platform_interface/plugin_platform_interface.dart';

import 'package:abtin_maps/features/gps/data/location_service.dart';

/// این فایل دقیقاً همان TODOی باز شده‌ی آیتم ۱۱ در TODO_LOCATION_ENGINE.md
/// را می‌بندد: مکِ GeolocatorPlatform.instance تا منطقِ
/// restart/backoff/state-transition دورن LocationService بدونِ دستگاه یا
/// GPS واقعی، به‌صورتِ قطعی (نه با Timerهای واقعی و صبرکردن) تست شود.
///
/// چیزی که این فایل عمداً تست نمی‌کند: مسیرِ واقعیِ پلتفرم (Geolocator
/// channel)، سناریوهای سطحِ OS (کشته‌شدنِ اپ، خاموش/روشن‌شدنِ GPS، پس‌زمینه/
/// پیش‌زمینه) — این‌ها طبق همان یادداشت، ذاتاً نیازمندِ دستگاه/شبیه‌ساز
/// واقعی هستند و باید با integration_test یا اجرای دستی روی دستگاه پوشش
/// داده شوند، نه یک تست واحد.
class _MockGeolocatorPlatform extends Mock
    with MockPlatformInterfaceMixin
    implements GeolocatorPlatform {}

Position _fixAt({
  double lat = 35.7,
  double lng = 51.4,
  double accuracy = 10,
  double speed = 0,
  double heading = 0,
}) {
  return Position(
    latitude: lat,
    longitude: lng,
    timestamp: DateTime.now(),
    accuracy: accuracy,
    altitude: 0,
    altitudeAccuracy: 0,
    heading: heading,
    headingAccuracy: 0,
    speed: speed,
    speedAccuracy: 0,
    floor: null,
    isMocked: false,
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late _MockGeolocatorPlatform mockPlatform;
  late StreamController<Position> positionStreamController;

  setUpAll(() {
    registerFallbackValue(const LocationSettings());
  });

  setUp(() {
    mockPlatform = _MockGeolocatorPlatform();
    GeolocatorPlatform.instance = mockPlatform;
    positionStreamController = StreamController<Position>.broadcast();

    when(
      () => mockPlatform.getPositionStream(
        locationSettings: any(named: 'locationSettings'),
      ),
    ).thenAnswer((_) => positionStreamController.stream);

    // getCurrentPosition (فیکسِ تقریبیِ سریع) و getLastKnownPosition (کشِ
    // آخرین موقعیت) عمداً موک نشده‌اند: هر دو در LocationService داخلِ
    // try/catch مستقل صدا زده می‌شوند و فقط _controller (نه _onPosition/
    // stateStream) را تغذیه می‌کنند، پس با MissingStubError هم بی‌خطر
    // catch می‌شوند — دقیقاً همان مسیرِ خطای واقعی («این سرویس‌ها در
    // دسترس نیستند») را بدونِ نیاز به دانستنِ امضای دقیقِ هرکدام تمرین
    // می‌کند.
  });

  tearDown(() async {
    await positionStreamController.close();
  });

  group('LocationState transitions', () {
    test('waiting -> active on the first real fix', () {
      fakeAsync((async) {
        final service = LocationService();
        final states = <LocationState>[];
        service.stateStream.listen(states.add);

        service.start();
        expect(service.state, LocationState.waiting);

        positionStreamController.add(_fixAt());
        async.flushMicrotasks();

        expect(service.state, LocationState.active);
        expect(states, contains(LocationState.active));

        service.dispose();
      });
    });

    test('stays out of "unavailable" before the 4th consecutive failure', () {
      fakeAsync((async) {
        final service = LocationService();
        service.start();

        for (var i = 0; i < 3; i++) {
          positionStreamController.addError('platform error $i');
          async.flushMicrotasks();
          async.elapse(const Duration(seconds: 10));
        }

        expect(service.state, isNot(LocationState.unavailable));
        service.dispose();
      });
    });

    test(
        'flips to "unavailable" on the 4th consecutive failure with no fix yet',
        () {
      fakeAsync((async) {
        final service = LocationService();
        service.start();

        for (var i = 0; i < 3; i++) {
          positionStreamController.addError('platform error $i');
          async.flushMicrotasks();
          async.elapse(const Duration(seconds: 10));
        }

        // حالت unavailable همان لحظهٔ خطای چهارم ثبت می‌شود؛ بعد از پایان
        // backoff، تلاش بعدی state را دوباره به waiting می‌برد.
        positionStreamController.addError('platform error 3');
        async.flushMicrotasks();

        expect(service.state, LocationState.unavailable);
        service.dispose();
      });
    });

    test(
        'recovers from "unavailable" back to "active" the moment a fix arrives',
        () {
      fakeAsync((async) {
        final service = LocationService();
        service.start();

        for (var i = 0; i < 3; i++) {
          positionStreamController.addError('platform error $i');
          async.flushMicrotasks();
          async.elapse(const Duration(seconds: 10));
        }
        positionStreamController.addError('platform error 3');
        async.flushMicrotasks();
        expect(service.state, LocationState.unavailable);

        positionStreamController.add(_fixAt());
        async.flushMicrotasks();

        expect(service.state, LocationState.active);
        service.dispose();
      });
    });
  });

  group('restart / exponential backoff', () {
    test('does not resubscribe before the ~2s first-retry delay elapses', () {
      fakeAsync((async) {
        final service = LocationService();
        service.start();
        async.flushMicrotasks();
        verify(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        ).called(1);

        positionStreamController.addError('boom');
        async.flushMicrotasks();

        // اولین backoff = min(1 << 1, 10) = 2 ثانیه.
        async.elapse(const Duration(milliseconds: 1900));
        verifyNever(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        );

        async.elapse(const Duration(milliseconds: 200));
        verify(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        ).called(1);

        service.dispose();
      });
    });

    test('backoff grows and is capped at 10 seconds across repeated failures',
        () {
      fakeAsync((async) {
        final service = LocationService();
        service.start();

        // دنباله‌ی واقعیِ backoff: ۲، ۴، ۸، ۱۰، ۱۰، ۱۰... ثانیه — یعنی
        // صبرکردنِ ۱۰ ثانیه بعدِ هر خطا همیشه کافی است تا اتصالِ بعدی
        // انجام شده باشد، حتی وقتی سقف هنوز نرسیده.
        for (var i = 0; i < 6; i++) {
          positionStreamController.addError('boom $i');
          async.flushMicrotasks();
          async.elapse(const Duration(seconds: 10));
        }

        verify(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        ).called(greaterThanOrEqualTo(6));

        service.dispose();
      });
    });

    test(
        'a successful fix resets the attempt counter (next failure backs off from ~2s again)',
        () {
      fakeAsync((async) {
        final service = LocationService();
        service.start();

        // چند شکستِ متوالی برای بالابردنِ شمارنده — با ۱۰ ثانیه صبر بعدِ
        // هرکدام (که همیشه از سقفِ backoff بیشتر است)، هر شکست دقیقاً یک
        // اتصالِ مجدد تولید می‌کند: ۱ اتصالِ اولیه + ۳ اتصالِ مجدد = ۴.
        for (var i = 0; i < 3; i++) {
          positionStreamController.addError('boom $i');
          async.flushMicrotasks();
          async.elapse(const Duration(seconds: 10));
        }

        // یک فیکسِ خوب — طبقِ کد باید _restartAttempts را صفر کند.
        positionStreamController.add(_fixAt());
        async.flushMicrotasks();
        expect(service.state, LocationState.active);

        // این verify فقط تمامِ ۴ فراخوانیِ بالا را «مصرف/تایید» می‌کند تا
        // verifyِ بعدی صرفاً فراخوانیِ تازه‌ی پس از ریست را بشمارد.
        verify(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        ).called(greaterThanOrEqualTo(3));

        positionStreamController.addError('boom after recovery');
        async.elapse(const Duration(milliseconds: 1900));
        verifyNever(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        );
        async.elapse(const Duration(milliseconds: 200));
        verify(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        ).called(1);

        service.dispose();
      });
    });
  });

  group('no-fix watchdog (silent stream, no platform error)', () {
    test('auto-restarts if 12s pass with no fix and no error', () {
      fakeAsync((async) {
        final service = LocationService();
        service.start();
        async.flushMicrotasks();
        verify(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        ).called(1);

        // واچ‌داگ در ۱۲ ثانیه فایر می‌شود و backoff ۲ثانیه‌ای خودش را
        // زمان‌بندی می‌کند — پس اتصالِ بعدی حدودِ t=14s است.
        async.elapse(const Duration(seconds: 12));
        verifyNever(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        );

        async.elapse(const Duration(seconds: 3));
        verify(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        ).called(1);

        service.dispose();
      });
    });

    test('gives the raw Android provider enough time for a cold satellite fix',
        () {
      fakeAsync((async) {
        final service = LocationService();
        service.start();
        async.flushMicrotasks();
        verify(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        ).called(1);

        // Fused پس از ۱۲ ثانیه بی‌فایده تشخیص داده می‌شود. سرویس پس از
        // backoff دوثانیه‌ای با LocationManager خام وصل می‌شود.
        async.elapse(const Duration(seconds: 15));
        verify(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        ).called(1);

        // LocationManager در شروع سرد ممکن است بیش از ۱۲ ثانیه نیاز داشته
        // باشد؛ تا قبل از watchdog اختصاصی ۴۵ثانیه‌ای نباید مجدداً قطع شود.
        async.elapse(const Duration(seconds: 40));
        verifyNever(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        );

        // watchdog خام در t≈59 و backoff دوم در t≈63 اتصال بعدی را می‌سازد.
        async.elapse(const Duration(seconds: 10));
        verify(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        ).called(1);

        service.dispose();
      });
    });

    test('never fires once a first fix has already arrived', () {
      fakeAsync((async) {
        final service = LocationService();
        service.start();
        verify(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        ).called(1);
        positionStreamController.add(_fixAt());
        async.flushMicrotasks();
        expect(service.state, LocationState.active);

        async.elapse(const Duration(seconds: 20));

        // بدونِ خطا و بدونِ تایم‌اوت، هیچ اتصالِ مجددی نباید رخ دهد.
        verifyNever(
          () => mockPlatform.getPositionStream(
            locationSettings: any(named: 'locationSettings'),
          ),
        );

        service.dispose();
      });
    });
  });

  group('stop() / start() — pause and resume', () {
    test('stop() detaches the stream; a late fix on the old stream is ignored',
        () {
      fakeAsync((async) {
        final service = LocationService();
        service.start();
        async.flushMicrotasks();

        service.stop();
        expect(service.state, LocationState.waiting);

        positionStreamController.add(_fixAt());
        async.flushMicrotasks();
        expect(service.state, LocationState.waiting);

        service.dispose();
      });
    });

    test('start() after stop() resubscribes and can reach "active" again', () {
      fakeAsync((async) {
        final service = LocationService();
        service.start();
        async.flushMicrotasks();
        service.stop();

        service.start();
        async.flushMicrotasks();
        positionStreamController.add(_fixAt());
        async.flushMicrotasks();

        expect(service.state, LocationState.active);
        service.dispose();
      });
    });
  });
}
