import 'package:abtin_maps/features/gps/data/speed_fusion.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('SpeedFusion', () {
    test('سرعت GNSS معتبر را بر جابه‌جایی مختصات ترجیح می‌دهد', () {
      final fusion = SpeedFusion();

      final estimate = fusion.measure(
        latitude: 35.7000,
        longitude: 51.4000,
        timestampMs: 1000,
        gnssSpeedMs: 15.0,
        accuracyMeters: 5,
      );

      expect(estimate.source, SpeedSource.gnss);
      expect(estimate.metersPerSecond, 15.0);
    });

    test('speed صفر Fused را با جابه‌جایی واقعی بین دو فیکس جایگزین می‌کند',
        () {
      final fusion = SpeedFusion();
      fusion.measure(
        latitude: 35.7000,
        longitude: 51.4000,
        timestampMs: 1000,
        gnssSpeedMs: 0,
        accuracyMeters: 5,
      );

      // حدود 11.1 متر در یک ثانیه؛ معادل نزدیک 40 km/h.
      final estimate = fusion.measure(
        latitude: 35.7001,
        longitude: 51.4000,
        timestampMs: 2000,
        gnssSpeedMs: 0,
        accuracyMeters: 5,
      );

      expect(estimate.source, SpeedSource.positionDelta);
      expect(estimate.metersPerSecond, closeTo(11.1, 0.8));
    });

    test('jitter کوچک GPS با speed صفر، سرعت ساختگی تولید نمی‌کند', () {
      final fusion = SpeedFusion();
      fusion.measure(
        latitude: 35.7000,
        longitude: 51.4000,
        timestampMs: 1000,
        gnssSpeedMs: 0,
        accuracyMeters: 8,
      );

      // حدود 1.1 متر؛ کمتر از آستانهٔ دقت/حرکت است.
      final estimate = fusion.measure(
        latitude: 35.70001,
        longitude: 51.4000,
        timestampMs: 2000,
        gnssSpeedMs: 0,
        accuracyMeters: 8,
      );

      expect(estimate.source, SpeedSource.stationary);
      expect(estimate.metersPerSecond, 0);
    });

    test('فاصلهٔ زمانی کهنه برای استخراج سرعت استفاده نمی‌شود', () {
      final fusion = SpeedFusion();
      fusion.measure(
        latitude: 35.7000,
        longitude: 51.4000,
        timestampMs: 1000,
        gnssSpeedMs: 0,
        accuracyMeters: 5,
      );

      final estimate = fusion.measure(
        latitude: 35.7010,
        longitude: 51.4000,
        timestampMs: 8000,
        gnssSpeedMs: 0,
        accuracyMeters: 5,
      );

      expect(estimate.source, SpeedSource.stationary);
      expect(estimate.metersPerSecond, 0);
    });

    test('reset اجازه نمی‌دهد فیکس session قبل سرعت بسازد', () {
      final fusion = SpeedFusion();
      fusion.measure(
        latitude: 35.7000,
        longitude: 51.4000,
        timestampMs: 1000,
        gnssSpeedMs: 0,
        accuracyMeters: 5,
      );
      fusion.reset();

      final estimate = fusion.measure(
        latitude: 35.7002,
        longitude: 51.4000,
        timestampMs: 2000,
        gnssSpeedMs: 0,
        accuracyMeters: 5,
      );

      expect(estimate.source, SpeedSource.stationary);
      expect(estimate.metersPerSecond, 0);
    });
  });
}
