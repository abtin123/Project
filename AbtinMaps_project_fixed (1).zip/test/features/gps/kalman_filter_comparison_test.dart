import 'dart:math' as math;

import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_maps/features/gps/data/joint_kalman_filter_2d.dart';
import 'package:abtin_maps/features/gps/data/kalman_1d_filter.dart';

/// یک نقطه‌ی «حقیقتِ زمینی» (بدون نویز) روی مسیرِ سنتتیک.
class _GroundTruthPoint {
  const _GroundTruthPoint({
    required this.lat,
    required this.lng,
    required this.speedMs,
    required this.bearingDeg,
    required this.tMs,
  });
  final double lat;
  final double lng;
  final double speedMs;
  final double bearingDeg;
  final int tMs;
}

const double _metersPerDegLat = 111320.0;

double _degToRad(double d) => d * math.pi / 180.0;

/// مسیرِ سنتتیک: ۲۰ ثانیه رانندگیِ مستقیم به شمال با ۱۵ متر/ثانیه (۵۴
/// کیلومتر/ساعت)، سپس یک پیچ ۹۰ درجه به شرق طیِ ۵ ثانیه، سپس ۱۰ ثانیه
/// توقفِ کامل. فیکس هر ۱ ثانیه (نرخِ معمولِ GPS).
List<_GroundTruthPoint> _buildGroundTruth() {
  final points = <_GroundTruthPoint>[];
  const startLat = 35.700000;
  const startLng = 51.400000;
  var lat = startLat;
  var lng = startLng;
  var bearing = 0.0; // شمال
  const speedMoving = 15.0; // m/s
  var tMs = 0;

  void step(double speed, double brg, int durationMs) {
    final dtSec = durationMs / 1000.0;
    final dist = speed * dtSec;
    final rad = _degToRad(brg);
    lat += (dist * math.cos(rad)) / _metersPerDegLat;
    lng +=
        (dist * math.sin(rad)) / (_metersPerDegLat * math.cos(_degToRad(lat)));
    tMs += durationMs;
    points.add(_GroundTruthPoint(
        lat: lat, lng: lng, speedMs: speed, bearingDeg: brg, tMs: tMs));
  }

  // ۲۰ ثانیه مستقیم به شمال
  for (var i = 0; i < 20; i++) {
    step(speedMoving, bearing, 1000);
  }
  // پیچ ۹۰ درجه‌ای طیِ ۵ ثانیه (۱۸ درجه در ثانیه)
  for (var i = 0; i < 5; i++) {
    bearing += 18;
    step(speedMoving, bearing, 1000);
  }
  // ۱۰ ثانیه توقفِ کامل
  for (var i = 0; i < 10; i++) {
    step(0, bearing, 1000);
  }

  return points;
}

class _NoisyFix {
  const _NoisyFix({
    required this.lat,
    required this.lng,
    required this.speedMs,
    required this.bearingDeg,
    required this.accuracyM,
    required this.tMs,
  });
  final double lat;
  final double lng;
  final double speedMs;
  final double bearingDeg;
  final double accuracyM;
  final int tMs;
}

/// نویزِ GPS-مانند: خطای گاوسیِ ~۳ متر روی هر فیکس، به‌علاوه‌ی یک پرشِ
/// دورافتاده (outlier) ۴۰ متری روی فیکسِ بیستم — دقیقاً نوعِ چیزی که
/// multipath/انعکاسِ شهری تولید می‌کند و jump-rejection باید مهارش کند.
List<_NoisyFix> _addNoise(List<_GroundTruthPoint> truth, {int seed = 42}) {
  final rnd = math.Random(seed);
  double gaussian() {
    // Box–Muller
    final u1 = math.max(rnd.nextDouble(), 1e-9);
    final u2 = rnd.nextDouble();
    return math.sqrt(-2 * math.log(u1)) * math.cos(2 * math.pi * u2);
  }

  final out = <_NoisyFix>[];
  for (var i = 0; i < truth.length; i++) {
    final p = truth[i];
    var latNoiseM = gaussian() * 3.0;
    var lngNoiseM = gaussian() * 3.0;
    var accuracy = 5.0;

    if (i == 19) {
      // پرشِ دورافتاده‌ی عمدی
      latNoiseM += 40.0;
      accuracy = 8.0; // GPS اغلب دقتِ بدی برای outlierها گزارش نمی‌کند
    }

    final lat = p.lat + latNoiseM / _metersPerDegLat;
    final lng =
        p.lng + lngNoiseM / (_metersPerDegLat * math.cos(_degToRad(p.lat)));

    out.add(_NoisyFix(
      lat: lat,
      lng: lng,
      speedMs: math.max(0, p.speedMs + gaussian() * 0.5),
      bearingDeg: p.bearingDeg,
      accuracyM: accuracy,
      tMs: p.tMs,
    ));
  }
  return out;
}

double _distanceMeters(double lat1, double lng1, double lat2, double lng2) {
  const earthRadius = 6371000.0;
  final dLat = _degToRad(lat2 - lat1);
  final dLng = _degToRad(lng2 - lng1);
  final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
      math.cos(_degToRad(lat1)) *
          math.cos(_degToRad(lat2)) *
          math.sin(dLng / 2) *
          math.sin(dLng / 2);
  final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
  return earthRadius * c;
}

/// خروجیِ [Kalman1D] روی lat/lng را دقیقاً مطابقِ منطقِ فعلیِ
/// `LocationService._onPosition` (نویزِ فرآیندِ پویا بر اساسِ isMoving)
/// شبیه‌سازی می‌کند — بدونِ hysteresis، چون اینجا فقط دقتِ خودِ فیلتر را
/// می‌سنجیم، نه لایه‌ی جدا‌ی جلوگیریِ از رقصِ مکان‌نما.
List<({double lat, double lng})> _run1D(List<_NoisyFix> fixes) {
  final xFilter = Kalman1D(processNoisePerSecond: 1.5);
  final yFilter = Kalman1D(processNoisePerSecond: 1.5);
  final out = <({double lat, double lng})>[];
  for (final f in fixes) {
    final isMoving = f.speedMs > 1.5;
    final dynamicProcessNoise = isMoving ? 2.5 : 0.2;
    final lat = yFilter.process(
      f.lat,
      f.accuracyM / _metersPerDegLat,
      f.tMs,
      extraProcessNoise: dynamicProcessNoise / _metersPerDegLat,
    );
    final lng = xFilter.process(
      f.lng,
      f.accuracyM / (_metersPerDegLat * math.cos(_degToRad(f.lat))),
      f.tMs,
      extraProcessNoise:
          dynamicProcessNoise / (_metersPerDegLat * math.cos(_degToRad(f.lat))),
    );
    out.add((lat: lat, lng: lng));
  }
  return out;
}

List<({double lat, double lng})> _runJoint(List<_NoisyFix> fixes) {
  final filter = JointKalmanFilter2D();
  final out = <({double lat, double lng})>[];
  for (final f in fixes) {
    final sample = KalmanLocationSample(
      latitude: f.lat,
      longitude: f.lng,
      speedMs: f.speedMs,
      bearingDeg: f.bearingDeg,
      accuracyMeters: f.accuracyM,
      timestampMs: f.tMs,
    );
    final filtered = filter.process(sample);
    out.add((lat: filtered.latitude, lng: filtered.longitude));
  }
  return out;
}

double _rmsErrorMeters(
    List<_GroundTruthPoint> truth, List<({double lat, double lng})> filtered) {
  var sumSq = 0.0;
  for (var i = 0; i < truth.length; i++) {
    final d = _distanceMeters(
        truth[i].lat, truth[i].lng, filtered[i].lat, filtered[i].lng);
    sumSq += d * d;
  }
  return math.sqrt(sumSq / truth.length);
}

double _maxErrorMeters(
    List<_GroundTruthPoint> truth, List<({double lat, double lng})> filtered) {
  var maxD = 0.0;
  for (var i = 0; i < truth.length; i++) {
    final d = _distanceMeters(
        truth[i].lat, truth[i].lng, filtered[i].lat, filtered[i].lng);
    if (d > maxD) maxD = d;
  }
  return maxD;
}

void main() {
  group('Kalman1D vs JointKalmanFilter2D — synthetic-trace comparison (item 7)',
      () {
    // این مقایسه یک شبیه‌سازیِ ریاضیِ خودآزمون است، نه دیتای واقعیِ گوشی؛
    // multipath/urban-canyon واقعی الگوهای نویزِ پیچیده‌تری دارد که اینجا
    // مدل نشده. هدف این تست تصمیم‌گیریِ نهاییِ حذف یکی از دو فیلتر نیست
    // (که هنوز به یک لاگِ واقعیِ GPS نیاز دارد — به TODO_LOCATION_ENGINE.md
    // نگاه کنید)؛ هدف این است که مقایسه به‌صورت خودکار/تکرارپذیر در دسترس
    // باشد و رگرسیون‌های آشکار (مثلاً NaN شدنِ فیلتر، یا واگراییِ کامل حین
    // پیچ) را بلافاصله بگیرد.
    late List<_GroundTruthPoint> truth;
    late List<_NoisyFix> noisyFixes;

    setUp(() {
      truth = _buildGroundTruth();
      noisyFixes = _addNoise(truth);
    });

    test('both filters stay finite and roughly track the ground truth', () {
      final out1D = _run1D(noisyFixes);
      final outJoint = _runJoint(noisyFixes);

      for (final p in [...out1D, ...outJoint]) {
        expect(p.lat.isFinite, isTrue);
        expect(p.lng.isFinite, isTrue);
      }

      final rms1D = _rmsErrorMeters(truth, out1D);
      final rmsJoint = _rmsErrorMeters(truth, outJoint);

      // هر دو باید نویزِ ۳متری خام را به‌طور محسوس کاهش دهند، نه فقط از
      // آن عبور کنند بدون فیلتر واقعی.
      expect(rms1D, lessThan(10.0));
      expect(rmsJoint, lessThan(10.0));
    });

    test('neither filter explodes on the injected 40m outlier fix', () {
      final out1D = _run1D(noisyFixes);
      final outJoint = _runJoint(noisyFixes);

      // فیکسِ دورافتاده ایندکس ۱۹ است؛ خروجیِ فیلترشده در همان لحظه باید
      // بخشی از پرش را جذب کند، نه این‌که کاملاً به آن بپرد (که یعنی فیلتر
      // عملاً کالمن نیست، فقط pass-through است).
      final outlierErr1D = _distanceMeters(
        truth[19].lat,
        truth[19].lng,
        out1D[19].lat,
        out1D[19].lng,
      );
      final outlierErrJoint = _distanceMeters(
        truth[19].lat,
        truth[19].lng,
        outJoint[19].lat,
        outJoint[19].lng,
      );

      expect(outlierErr1D, lessThan(40.0));
      expect(outlierErrJoint, lessThan(40.0));
    });

    test('velocity measurement uses speedAccuracy, not position accuracy', () {
      final trusted = JointKalmanFilter2D();
      final noisy = JointKalmanFilter2D();

      KalmanLocationSample sample({
        required double speed,
        required double speedAccuracy,
        required int t,
      }) =>
          KalmanLocationSample(
            latitude: 35.7,
            longitude: 51.4 + t / 1000000.0,
            speedMs: speed,
            bearingDeg: 90,
            accuracyMeters: 5,
            speedAccuracyMs: speedAccuracy,
            timestampMs: t,
          );

      trusted.process(sample(speed: 10, speedAccuracy: 0.5, t: 1000));
      noisy.process(sample(speed: 10, speedAccuracy: 8.0, t: 1000));

      final trustedOut =
          trusted.process(sample(speed: 80, speedAccuracy: 0.5, t: 2000));
      final noisyOut =
          noisy.process(sample(speed: 80, speedAccuracy: 8.0, t: 2000));

      // A receiver that explicitly reports poor speed accuracy must not let a
      // single 80 km/h-equivalent measurement dominate the state just because
      // its positional accuracy happened to be 5m.
      expect(noisyOut.speedMs, lessThan(trustedOut.speedMs));
      expect(noisyOut.speedMs.isFinite, isTrue);
    });

    test(
        'a GPS fix older than a prediction tick cannot create a synthetic speed spike',
        () {
      final filter = JointKalmanFilter2D();
      final first = KalmanLocationSample(
        latitude: 35.7,
        longitude: 51.4,
        speedMs: 10,
        bearingDeg: 0,
        accuracyMeters: 5,
        speedAccuracyMs: 1,
        timestampMs: 1000,
      );
      filter.process(first);
      filter.predictOnly(1500);

      final stale = filter.process(
        KalmanLocationSample(
          latitude: 35.70001,
          longitude: 51.4,
          speedMs: 80,
          bearingDeg: 0,
          accuracyMeters: 5,
          speedAccuracyMs: 1,
          timestampMs: 1200,
        ),
      );

      expect(stale.speedMs, lessThan(20));
      expect(stale.speedMs.isFinite, isTrue);
    });

    test('a gross but falsely accurate position outlier is strongly attenuated',
        () {
      final filter = JointKalmanFilter2D();

      KalmanLocationSample sample({
        required double lat,
        required double lng,
        required double speed,
        required int t,
      }) =>
          KalmanLocationSample(
            latitude: lat,
            longitude: lng,
            speedMs: speed,
            bearingDeg: 0,
            accuracyMeters: 5,
            speedAccuracyMs: 1,
            timestampMs: t,
          );

      filter
          .process(sample(lat: 35.700000, lng: 51.400000, speed: 15, t: 1000));
      filter
          .process(sample(lat: 35.700135, lng: 51.400000, speed: 15, t: 2000));
      final filtered = filter.process(
        // حدود 600 متر شرق مسیر واقعی؛ accuracy عمداً خوش‌بینانه است.
        sample(lat: 35.700270, lng: 51.406700, speed: 15, t: 3000),
      );

      final expectedLat = 35.700270;
      final expectedLng = 51.400000;
      expect(
        _distanceMeters(
            filtered.latitude, filtered.longitude, expectedLat, expectedLng),
        lessThan(80.0),
      );
    });

    test(
        'a single impossible velocity sample cannot create a speedometer spike',
        () {
      final filter = JointKalmanFilter2D();

      KalmanLocationSample sample({required double speed, required int t}) =>
          KalmanLocationSample(
            latitude: 35.7 + ((t - 1000) / 1000) * 15 / _metersPerDegLat,
            longitude: 51.4,
            speedMs: speed,
            bearingDeg: 0,
            accuracyMeters: 5,
            speedAccuracyMs: 1,
            timestampMs: t,
          );

      filter.process(sample(speed: 15, t: 1000));
      filter.process(sample(speed: 15, t: 2000));
      final filtered = filter.process(sample(speed: 80, t: 3000));

      expect(filtered.speedMs, lessThan(30));
      expect(filtered.speedMs.isFinite, isTrue);
    });

    test('report RMS/max error for both — informational, prints the comparison',
        () {
      final out1D = _run1D(noisyFixes);
      final outJoint = _runJoint(noisyFixes);

      final rms1D = _rmsErrorMeters(truth, out1D);
      final rmsJoint = _rmsErrorMeters(truth, outJoint);
      final max1D = _maxErrorMeters(truth, out1D);
      final maxJoint = _maxErrorMeters(truth, outJoint);

      // چاپِ نتیجه برای خواندنِ دستی حین `flutter test -r expanded`؛ این
      // تست به‌عمد assert سخت‌گیرانه‌ای بینِ دو فیلتر نمی‌گذارد — نتیجه به
      // seed/سناریوی سنتتیک حساس است و نباید مبنای حذفِ کدِ تولیدی باشد.
      // ignore: avoid_print
      print(
          'Kalman1D:            RMS=${rms1D.toStringAsFixed(2)}m  max=${max1D.toStringAsFixed(2)}m');
      // ignore: avoid_print
      print(
          'JointKalmanFilter2D: RMS=${rmsJoint.toStringAsFixed(2)}m  max=${maxJoint.toStringAsFixed(2)}m');

      expect(rms1D.isFinite, isTrue);
      expect(rmsJoint.isFinite, isTrue);
    });
  });
}
