import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_maps/features/map/presentation/online_map_view.dart';
import 'package:abtin_maps/shared/providers/map_style_providers.dart';

void main() {
  test('road width scale persists independently from the palette colors', () {
    final source = OfflineMapPalette.darkDefault.copyWith(roadWidthScale: 1.6);
    final restored = OfflineMapPalette.deserialize(
      source.serialize(),
      fallback: OfflineMapPalette.lightDefault,
    );

    expect(restored.roadWidthScale, closeTo(1.6, 0.0001));
    expect(restored.background, source.background);
    expect(restored.roadPrimary, source.roadPrimary);
  });

  test('road width scale is clamped to the safe visual range', () {
    final tooThin = OfflineMapPalette.darkDefault.copyWith(roadWidthScale: 0.1);
    final tooWide = OfflineMapPalette.darkDefault.copyWith(roadWidthScale: 4.0);

    expect(
      OfflineMapPalette.deserialize(
        tooThin.serialize(),
        fallback: OfflineMapPalette.darkDefault,
      ).roadWidthScale,
      0.6,
    );
    expect(
      OfflineMapPalette.deserialize(
        tooWide.serialize(),
        fallback: OfflineMapPalette.darkDefault,
      ).roadWidthScale,
      1.8,
    );
  });

  test('road width expression grows with zoom and responds to scale', () {
    final normal = roadWidthExpression(1.0);
    final wide = roadWidthExpression(1.5);

    expect(normal.first, 'interpolate');
    expect(normal[3], 6);
    expect(normal[5], 10);
    expect(wide[4], closeTo(normal[4] * 1.5, 0.0001));
    expect(wide[6], closeTo(normal[6] * 1.5, 0.0001));
  });
}
