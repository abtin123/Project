import 'dart:math' as math;

import 'package:abtin_maps/features/map/presentation/online_map_view.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('mapRelativeHeading', () {
    test('heading شمال روی نقشهٔ شمال‌بالا بدون offset باقی می‌ماند', () {
      expect(mapRelativeHeading(0, 0), 0);
    });

    test('heading شرق روی نقشهٔ شمال‌بالا به سمت راست صفحه می‌چرخد', () {
      expect(mapRelativeHeading(90, 0), 90);
    });

    test('bearing دوربین از heading کم می‌شود', () {
      expect(mapRelativeHeading(90, 90), 0);
      expect(mapRelativeHeading(180, 90), 90);
    });

    test('زاویهٔ منفی به بازهٔ استاندارد ۰ تا کمتر از ۳۶۰ برمی‌گردد', () {
      expect(mapRelativeHeading(0, 90), 270);
      expect(mapRelativeHeading(10, 350), 20);
    });

    test('ورودی غیرعددی به جهت امن شمال تبدیل می‌شود', () {
      expect(mapRelativeHeading(double.nan, double.nan), 0);
    });
  });

  group('offlinePoiLayerFilter', () {
    test('حالت پیش‌فرض همهٔ کلاس‌های POI نام‌دار را نمایش می‌دهد', () {
      final filter = offlinePoiLayerFilter(null);

      expect(filter[0], 'all');
      expect(filter[1], <dynamic>['has', 'name']);
      expect(filter[2], contains('fuel'));
      expect(filter[2], contains('pharmacy'));
      expect(filter[2], contains('speed_camera'));
    });

    test('یک دسته فقط کلاس‌های همان دسته را نگه می‌دارد', () {
      final filter = offlinePoiLayerFilter(const {50});

      expect(filter[2], <dynamic>[
        'in',
        ['get', 'class'],
        'fuel'
      ]);
    });

    test('set خالی filter بدون تطبیق می‌سازد', () {
      expect(
        offlinePoiLayerFilter(const <int>{}),
        <dynamic>[
          '==',
          ['get', 'class'],
          '__abtin-hidden-poi__'
        ],
      );
    });

    test('مقایسهٔ state به تغییر ترتیب set حساس نیست', () {
      expect(sameOfflinePoiVisibility(const {50, 52}, const {52, 50}), isTrue);
      expect(sameOfflinePoiVisibility(null, const {50}), isFalse);
      expect(sameOfflinePoiVisibility(const <int>{}, const <int>{}), isTrue);
    });
  });

  group('mapScreenPointToFlutterOffset', () {
    test('مختصات فیزیکی Android را به logical pixel Flutter تبدیل می‌کند', () {
      final offset = mapScreenPointToFlutterOffset(
        const math.Point<double>(810, 1440),
        3,
      );

      expect(offset.dx, 270);
      expect(offset.dy, 480);
    });

    test('تراکم نامعتبر از marker خارج از صفحه جلوگیری می‌کند', () {
      final offset = mapScreenPointToFlutterOffset(
        const math.Point<double>(210, 420),
        double.nan,
      );

      expect(offset.dx, 210);
      expect(offset.dy, 420);
    });
  });
}
