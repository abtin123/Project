import 'dart:convert';

import 'package:abtin_maps/core/geo/geo_types.dart';
import 'package:abtin_maps/features/routing/data/online_routing_provider.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('OnlineRoutingProvider', () {
    test('maps OSRM alternatives, GeoJSON geometry and Persian instructions',
        () async {
      late Uri capturedUri;
      final client = MockClient((request) async {
        capturedUri = request.url;
        return http.Response(
          jsonEncode({
            'code': 'Ok',
            'routes': [
              {
                'distance': 1250.0,
                'duration': 180.0,
                'geometry': {
                  'type': 'LineString',
                  'coordinates': [
                    [51.400000, 35.700000],
                    [51.405000, 35.705000],
                  ],
                },
                'legs': [
                  {
                    'steps': [
                      {
                        'distance': 80.0,
                        'name': 'خیابان نمونه',
                        'maneuver': {
                          'type': 'depart',
                          'location': [51.400000, 35.700000],
                        },
                      },
                      {
                        'distance': 270.0,
                        'name': 'بلوار آزادی',
                        'maneuver': {
                          'type': 'turn',
                          'modifier': 'right',
                          'location': [51.402000, 35.702000],
                        },
                      },
                      {
                        'distance': 0.0,
                        'maneuver': {
                          'type': 'arrive',
                          'location': [51.405000, 35.705000],
                        },
                      },
                    ],
                  },
                ],
              },
              {
                'distance': 1400.0,
                'duration': 210.0,
                'geometry': {
                  'type': 'LineString',
                  'coordinates': [
                    [51.400000, 35.700000],
                    [51.401000, 35.706000],
                  ],
                },
                'legs': const [],
              },
            ],
          }),
          200,
          headers: const {'content-type': 'application/json'},
        );
      });
      final provider = OnlineRoutingProvider(
        client: client,
        endpoint: 'https://routing.example.test',
      );

      final routes = await provider.calculateRoutes(
        origin: const LatLng(35.7, 51.4),
        destination: const LatLng(35.705, 51.405),
      );

      expect(capturedUri.path,
          '/route/v1/driving/51.400000,35.700000;51.405000,35.705000');
      expect(capturedUri.queryParameters['alternatives'], 'true');
      expect(capturedUri.queryParameters['geometries'], 'geojson');
      expect(routes, hasLength(2));
      expect(routes.first.distanceKm, closeTo(1.25, 0.0001));
      expect(routes.first.durationMin, closeTo(3, 0.0001));
      expect(routes.first.geometry, hasLength(2));
      expect(routes.first.instructions, hasLength(3));
      expect(routes.first.instructions[1].text, contains('به راست بپیچید'));
      expect(routes.first.instructions.last.text, 'به مقصد رسیدید');
      expect(provider.lastError, isNull);
    });

    test('does not send a request when offline-only is required', () async {
      var calls = 0;
      final provider = OnlineRoutingProvider(
        client: MockClient((_) async {
          calls++;
          return http.Response('{}', 500);
        }),
      );

      final route = await provider.calculateRoute(
        origin: const LatLng(35.7, 51.4),
        destination: const LatLng(35.71, 51.41),
        offlineOnly: true,
      );

      expect(route, isNull);
      expect(calls, 0);
      expect(provider.lastError, contains('حالت آفلاین'));
    });

    test('surfaces a human-readable no-route response', () async {
      final provider = OnlineRoutingProvider(
        client: MockClient(
          (_) async => http.Response(jsonEncode({'code': 'NoRoute'}), 200),
        ),
      );

      final routes = await provider.calculateRoutes(
        origin: const LatLng(35.7, 51.4),
        destination: const LatLng(35.71, 51.41),
      );

      expect(routes, isEmpty);
      expect(provider.lastError, contains('پیدا نشد'));
    });
  });
}
