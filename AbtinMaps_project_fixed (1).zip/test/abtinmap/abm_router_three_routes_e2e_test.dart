import 'dart:io';
import 'dart:typed_data';

import 'package:abtin_maps/abtinmap/abm_file.dart';
import 'package:abtin_maps/abtinmap/abm_models.dart';
import 'package:abtin_maps/abtinmap/abm_router.dart';
import 'package:abtin_maps/abtinmap/abm_zstd.dart';
import 'package:flutter_test/flutter_test.dart';

class _IdentityZstd implements AbmZstd {
  const _IdentityZstd();

  @override
  Future<Uint8List> decompress(Uint8List input, {int? expectedSize}) async {
    if (expectedSize != null && input.length != expectedSize) {
      throw StateError('Unexpected fixture block size.');
    }
    return input;
  }
}

bool _nearDuplicate(AbmRoute a, AbmRoute b) {
  final smaller = a.usedWays.length < b.usedWays.length
      ? a.usedWays.length
      : b.usedWays.length;
  if (smaller == 0) return true;
  return a.usedWays.intersection(b.usedWays).length / smaller >= 0.92;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('سه corridor متفاوت در graph آفلاین به سه route واقعی تبدیل می‌شوند',
      () async {
    final file = await AbmFile.open(
      File('test/fixtures/three_offline_routes.abm'),
      zstd: const _IdentityZstd(),
    );

    addTearDown(file.close);

    final routes = await AbmRouter(file).routeAlternatives(
      const AbmPoint(54.000, 32.500),
      const AbmPoint(54.020, 32.500),
    );

    expect(routes, hasLength(3));
    for (var index = 0; index < routes.length; index++) {
      expect(routes[index].points.length, greaterThanOrEqualTo(2));
      for (var other = 0; other < index; other++) {
        expect(_nearDuplicate(routes[index], routes[other]), isFalse);
      }
    }
  });
}
