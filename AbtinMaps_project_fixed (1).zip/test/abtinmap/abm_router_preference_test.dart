import 'package:abtin_maps/abtinmap/abm_models.dart';
import 'package:abtin_maps/abtinmap/abm_router.dart';
import 'package:flutter_test/flutter_test.dart';

AbmWay _way({
  required int klass,
  int widthDm = 0,
  int attr = 0,
}) {
  return AbmWay(
    klass: klass,
    attr: attr,
    minZoom: 12,
    name: '',
    speedCode: 200,
    widthDm: widthDm,
    refs: const <int>[0, 1],
  );
}

void main() {
  group('AbmRouter road-class preference', () {
    test('service road و کوچه از خیابان اصلی هزینهٔ بیشتری دارند', () {
      final primary = _way(klass: AbmKlass.primary);
      final residential = _way(klass: AbmKlass.residential);
      final service = _way(klass: AbmKlass.service);

      expect(AbmRouter.roadClassCostMultiplier(primary), 1.0);
      expect(AbmRouter.roadClassCostMultiplier(residential), greaterThan(1.0));
      expect(
        AbmRouter.roadClassCostMultiplier(service),
        greaterThan(AbmRouter.roadClassCostMultiplier(residential)),
      );
    });

    test('کوچهٔ باریک از residential عادی جریمهٔ بیشتری دارد', () {
      final normal = _way(klass: AbmKlass.residential, widthDm: 60);
      final narrow = _way(klass: AbmKlass.residential, widthDm: 35);

      expect(
        AbmRouter.roadClassCostMultiplier(narrow),
        greaterThan(AbmRouter.roadClassCostMultiplier(normal)),
      );
    });

    test('link بزرگراه جریمهٔ کوچه نمی‌گیرد', () {
      final motorwayLink = _way(
        klass: AbmKlass.motorway,
        attr: AbmAttr.link,
      );

      expect(AbmRouter.roadClassCostMultiplier(motorwayLink), 1.0);
    });

    test('مسیر نخست بی‌جریمه و گزینه‌های بعدی چند تلاش متفاوت دارند', () {
      expect(AbmRouter.alternativePenaltyScalesFor(0), <double>[0]);
      expect(
        AbmRouter.alternativePenaltyScalesFor(1),
        <double>[0.20, 0.45, 0.75, 1.10],
      );
      expect(
        AbmRouter.alternativePenaltyScalesFor(2),
        <double>[0.20, 0.45, 0.75, 1.10],
      );
    });
  });
}
