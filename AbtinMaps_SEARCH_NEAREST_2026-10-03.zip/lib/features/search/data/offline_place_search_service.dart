import 'dart:isolate';
import 'dart:math' as math;

import 'package:sqlite3/sqlite3.dart';

import '../../../abtinmap/abm_map_service.dart';
import '../../../core/abm_debug_log.dart';
import '../../../core/geo/geo_types.dart';
import '../../offline_maps/data/map_catalog.dart';
import '../../offline_maps/data/vector_map_service.dart';
import 'place_search_service.dart';

/// Offline POI search adapter backed by the canonical ABM map.sqlite database.
class OfflinePlaceSearchService {
  OfflinePlaceSearchService(this._maps);
  final AbmMapService _maps;
  final VectorMapService _vectorMaps = VectorMapService();

  /// جست‌وجوی چند-استانی: هر استان نصب‌شده map.sqlite مخصوص خودش را دارد.
  /// [orderedRegions] باید از قبل با [RegionResolver.order] اولویت‌بندی شده
  /// باشد: جایگاه اول همان استانی است که با نام صریح در متن یا با GPS
  /// کاربر تشخیص داده شده. اگر استان اول نتیجهٔ کافی نداد، بقیهٔ استان‌های
  /// دانلودشده هم به همان ترتیب بررسی می‌شوند تا هیچ نقشهٔ نصب‌شده‌ای از
  /// جست‌وجو بیرون نماند.
  Future<List<PlaceSearchResult>> searchAcrossRegions(
    String query, {
    required List<MapRegion> orderedRegions,
    double? biasLat,
    double? biasLng,
    int limit = 12,
  }) async {
    final trimmed = query.trim();
    if (trimmed.length < 2 || orderedRegions.isEmpty) return const [];
    final merged = <PlaceSearchResult>[];
    for (var i = 0; i < orderedRegions.length; i++) {
      final region = orderedRegions[i];
      final regionResults = await search(
        trimmed,
        mapFileName: region.abmFileName,
        biasLat: biasLat,
        biasLng: biasLng,
        limit: limit,
      );
      merged.addAll(regionResults);
      // استان برنده (اول) اگر به‌تنهایی نتیجهٔ کافی داد، دیگر لازم نیست همهٔ
      // نقشه‌های دیگر هم باز و کوئری شوند؛ در غیر این صورت ادامه می‌دهیم.
      if (i == 0 && regionResults.length >= limit) break;
    }
    return rankPlaceResults(trimmed, merged, limit: limit);
  }

  Future<List<PlaceSearchResult>> search(
    String query, {
    required String mapFileName,
    double? biasLat,
    double? biasLng,
    String? city,
    int limit = 12,
  }) async {
    final trimmed = query.trim();
    if (trimmed.length < 2) {
      return const [];
    }
    final container = await _maps.localFile(mapFileName);
    if (!await container.exists()) {
      return const [];
    }
    final id = mapFileName.toLowerCase().endsWith('.abm')
        ? mapFileName.substring(0, mapFileName.length - 4)
        : mapFileName;
    try {
      final artifacts = await _vectorMaps.prepare(containerFile: container, id: id);
      final raw = await Isolate.run(() => _searchSync(
            artifacts.sqliteFile.path,
            trimmed,
            biasLat,
            biasLng,
            (limit * 40).clamp(200, 500),
          ));
      for (final line in (raw['trace'] as List).cast<String>()) {
      }
      final rows = (raw['results'] as List).cast<Map>();
      final results = rows.map((r) => PlaceSearchResult(
            name: '${r['name']}',
            region: (r['region'] as String?)?.isEmpty == true ? null : r['region'] as String?,
            point: LatLng((r['lat'] as num).toDouble(), (r['lon'] as num).toDouble()),
            isOffline: true,
            distanceMeters: (r['distance'] as num?)?.toDouble(),
          )).toList(growable: false);
      return rankPlaceResults(trimmed, results, limit: limit);
    } catch (error, stack) {
      return const [];
    }
  }

  static Map<String, dynamic> _searchSync(
    String sqlitePath,
    String query,
    double? biasLat,
    double? biasLng,
    int limit,
  ) {
    final trace = <String>[];
    trace.add('SQL OPEN path=$sqlitePath');
    final db = sqlite3.open(sqlitePath, mode: OpenMode.readOnly);
    try {
      final objects = db.select(
        "SELECT name,type FROM sqlite_master WHERE type IN ('table','view') ORDER BY name",
      );
      trace.add('SQL SCHEMA objects=${objects.length} names=${objects.map((r) => r['name']).join(',')}');
      final normalized = normalizeSearchText(query);
      trace.add('QUERY normalized="$normalized" candidates=$limit');
      // FTS5 prefix syntax is "term"* (the star must be OUTSIDE the quotes).
      final ftsTerms = normalized
          .split(RegExp(r'\s+'))
          .where((x) => x.isNotEmpty)
          .map((x) => '"${x.replaceAll('"', ' ')}"*')
          .join(' AND ');
      const baseSelect =
          'SELECT f.id, f.kind, n.name, n.name_fa, n.name_en, c.name AS category, '
          '(s.min_lat+s.max_lat)/2 AS lat, (s.min_lon+s.max_lon)/2 AS lon, f.opening_hours ';
      const joins = 'JOIN features f ON f.name_id=n.id '
          'JOIN categories c ON c.id=f.category_id '
          'JOIN spatial s ON s.id=f.id ';
      var rows = db.select('SELECT 1 WHERE 0');
      try {
        rows = db.select(
          '${baseSelect}FROM search_fts JOIN names n ON n.id=search_fts.rowid $joins'
          'WHERE search_fts MATCH ? AND s.min_lat IS NOT NULL AND s.min_lon IS NOT NULL '
          'ORDER BY bm25(search_fts) LIMIT ?',
          [ftsTerms, limit],
        );
      } catch (_) {
        // malformed FTS expression -> use the LIKE fallback below
      }
      trace.add('SQL FTS rows=${rows.length}');
      if (rows.isEmpty) {
        // Fallback: plain substring match (handles words the FTS tokenizer
        // splits differently from the user's spelling).
        final like = '%$normalized%';
        rows = db.select(
          '${baseSelect}FROM names n $joins'
          'WHERE (n.name_fa LIKE ? OR n.name LIKE ? OR n.name_en LIKE ?) '
          'AND s.min_lat IS NOT NULL AND s.min_lon IS NOT NULL LIMIT ?',
          [like, like, like, limit],
        );
        trace.add('SQL LIKE rows=${rows.length}');
      }
      final origin = biasLat == null || biasLng == null ? null : LatLng(biasLat, biasLng);
      final results = <Map<String, dynamic>>[];
      var skippedNoPoint = 0;
      for (final r in rows) {
        final lat = (r['lat'] as num?)?.toDouble();
        final lon = (r['lon'] as num?)?.toDouble();
        if (lat == null || lon == null) {
          skippedNoPoint++;
          continue;
        }
        final point = LatLng(lat, lon);
        results.add({
          'name': _firstText(r['name_fa'], r['name'], r['name_en']) ?? query,
          'region': '${r['category'] ?? ''}'.trim(),
          'lat': lat,
          'lon': lon,
          'distance': origin == null ? null : _distance(origin, point),
        });
      }
      // Ranking (relevance, then distance) happens in rankPlaceResults.
      final limited = results;
      trace.add('RESULTS usable=${results.length} skippedNoPoint=$skippedNoPoint returned=${limited.length}');
      for (var i = 0; i < limited.length; i++) {
        final r = limited[i];
        trace.add('RESULT[$i] name="${r['name']}" category="${r['region']}" '
            'point=${(r['lat'] as num).toStringAsFixed(6)},${(r['lon'] as num).toStringAsFixed(6)} '
            'distanceM=${(r['distance'] as num?)?.toStringAsFixed(1) ?? '-'}');
      }
      return {'results': limited, 'trace': trace};
    } catch (error, stack) {
      trace.add('ERROR SQL_POI error=$error\n$stack');
      return {'results': const [], 'trace': trace};
    } finally {
      db.dispose();
    }
  }

  static String? _firstText(Object? a, Object? b, Object? c) {
    for (final value in [a, b, c]) {
      final text = value?.toString().trim() ?? '';
      if (text.isNotEmpty) return text;
    }
    return null;
  }

  static double _distance(LatLng a, LatLng b) {
    const r = 6371008.8;
    final p1 = a.latitude * 3.141592653589793 / 180;
    final p2 = b.latitude * 3.141592653589793 / 180;
    final dp = (b.latitude - a.latitude) * 3.141592653589793 / 180;
    final dl = (b.longitude - a.longitude) * 3.141592653589793 / 180;
    final h = math.sin(dp / 2) * math.sin(dp / 2) +
        math.cos(p1) * math.cos(p2) * math.sin(dl / 2) * math.sin(dl / 2);
    return r * 2 * math.asin(math.sqrt(h.clamp(0.0, 1.0)));
  }
}
