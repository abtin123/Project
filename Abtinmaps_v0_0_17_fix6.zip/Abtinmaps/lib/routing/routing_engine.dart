import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'dart:math' as math;
import 'package:sqlite3/sqlite3.dart';


/// Lets a caller abort a running route search (kills its isolate).
class RouteCancelToken {
  bool _cancelled = false;
  final List<void Function()> _listeners = <void Function()>[];
  bool get isCancelled => _cancelled;

  void cancel() {
    if (_cancelled) return;
    _cancelled = true;
    final ls = List<void Function()>.of(_listeners);
    _listeners.clear();
    for (final l in ls) {
      l();
    }
  }

  void _listen(void Function() cb) {
    if (_cancelled) {
      cb();
    } else {
      _listeners.add(cb);
    }
  }

  void _unlisten(void Function() cb) => _listeners.remove(cb);
}

// Separate top-level function so the spawned closure captures only [computation]
// (a closure created inside _runCancellable would drag the token/ports along and
// fail to cross the isolate boundary).
Future<Isolate> _spawnJob<R>(
  Future<R> Function() computation,
  SendPort result,
  SendPort exit,
) =>
    Isolate.spawn<SendPort>(
      (SendPort port) async {
        try {
          port.send(<Object?>[await computation()]);
        } catch (e, st) {
          port.send(<Object?>['$e', '$st']);
        }
      },
      result,
      onExit: exit,
    );

/// Isolate.run replacement that can be killed through [token].
/// Returns null when cancelled.
Future<R?> _runCancellable<R>(
  Future<R> Function() computation,
  RouteCancelToken? token,
) async {
  if (token == null) return Isolate.run(computation);
  if (token.isCancelled) return null;
  final result = ReceivePort();
  final exit = ReceivePort();
  final done = Completer<R?>();
  Isolate? iso;
  void kill() {
    iso?.kill(priority: Isolate.immediate);
    if (!done.isCompleted) done.complete(null);
  }

  token._listen(kill);
  try {
    result.listen((Object? msg) {
      if (done.isCompleted) return;
      final m = msg as List<Object?>;
      if (m.length == 1) {
        done.complete(m[0] as R?);
      } else {
        done.completeError(StateError('${m[0]}'), StackTrace.fromString('${m[1]}'));
      }
    });
    exit.listen((_) {
      if (!done.isCompleted) done.complete(null);
    });
    iso = await _spawnJob<R>(computation, result.sendPort, exit.sendPort);
    if (token.isCancelled) kill();
    return await done.future;
  } finally {
    token._unlisten(kill);
    result.close();
    exit.close();
  }
}

class RoutePoint {
  const RoutePoint(this.lat, this.lon);
  final double lat;
  final double lon;
}

class RoundaboutBranchInfo {
  const RoundaboutBranchInfo({
    required this.angleDegrees,
    this.canEnter = false,
    this.canExit = false,
  });

  final double angleDegrees;
  final bool canEnter;
  final bool canExit;
}

class RouteEdgeInfo {
  const RouteEdgeInfo({
    required this.from,
    required this.to,
    required this.roadClass,
    required this.name,
    required this.junction,
    required this.wayId,
    this.speedKmh,
    this.roundaboutExitNumber,
    this.roundaboutExitCount,
    this.roundaboutBranches = const [],
    this.roundaboutEntranceAngles = const [],
    this.roundaboutExitAngles = const [],
    this.roundaboutActiveExitAngle,
    this.roundaboutActiveEntranceAngle,
    this.turnLanes = '',
    this.isBridge = false,
  });
  /// True when this edge lies on a bridge (OSM bridge=*).
  final bool isBridge;
  /// OSM turn:lanes of this way in the travel direction ("left|through|right").
  final String turnLanes;
  final RoutePoint from;
  final RoutePoint to;
  final String roadClass;
  final String name;
  final String junction;
  final int wayId;
  final double? speedKmh;
  final int? roundaboutExitNumber;
  final int? roundaboutExitCount;
  final List<RoundaboutBranchInfo> roundaboutBranches;
  final List<double> roundaboutEntranceAngles;
  final List<double> roundaboutExitAngles;
  final double? roundaboutActiveExitAngle;

  final double? roundaboutActiveEntranceAngle;
}

int _activeRouteMode = 0;

/// Roads reported closed by the driver (set inside the routing isolate).
List<_BlockPoly> _activeBlocks = const <_BlockPoly>[];

const double _blockRadiusM = 14.0;
const double _blockMinOverlapM = 30.0;

class _BlockPoly {
  _BlockPoly(List<RoutePoint> pts)
      : lat0 = pts[pts.length ~/ 2].lat,
        lon0 = pts[pts.length ~/ 2].lon {
    mLon = 111320.0 * math.cos(lat0 * math.pi / 180.0).abs().clamp(0.2, 1.0);
    for (final p in pts) {
      xs.add((p.lon - lon0) * mLon);
      ys.add((p.lat - lat0) * 110540.0);
    }
    minX = xs.reduce(math.min) - _blockRadiusM;
    maxX = xs.reduce(math.max) + _blockRadiusM;
    minY = ys.reduce(math.min) - _blockRadiusM;
    maxY = ys.reduce(math.max) + _blockRadiusM;
  }

  final double lat0;
  final double lon0;
  late final double mLon;
  final List<double> xs = <double>[];
  final List<double> ys = <double>[];
  late final double minX, maxX, minY, maxY;

  double _dist(double px, double py) {
    var best = double.infinity;
    for (var i = 1; i < xs.length; i++) {
      final ax = xs[i - 1], ay = ys[i - 1];
      final dx = xs[i] - ax, dy = ys[i] - ay;
      final len2 = dx * dx + dy * dy;
      var t = len2 < 1e-9 ? 0.0 : ((px - ax) * dx + (py - ay) * dy) / len2;
      t = t.clamp(0.0, 1.0).toDouble();
      final qx = ax + dx * t - px, qy = ay + dy * t - py;
      final d2 = qx * qx + qy * qy;
      if (d2 < best) best = d2;
    }
    return math.sqrt(best);
  }

  /// Metres of [line] that run within the block radius of this polyline.
  double overlapM(List<RoutePoint> line) {
    var overlap = 0.0;
    for (var i = 1; i < line.length; i++) {
      final ax = (line[i - 1].lon - lon0) * mLon;
      final ay = (line[i - 1].lat - lat0) * 110540.0;
      final cx = (line[i].lon - lon0) * mLon;
      final cy = (line[i].lat - lat0) * 110540.0;
      if (math.max(ax, cx) < minX || math.min(ax, cx) > maxX ||
          math.max(ay, cy) < minY || math.min(ay, cy) > maxY) {
        continue;
      }
      final len = math.sqrt((cx - ax) * (cx - ax) + (cy - ay) * (cy - ay));
      final n = math.max(1, (len / 5.0).ceil());
      for (var k = 0; k < n; k++) {
        final t = (k + 0.5) / n;
        final px = ax + (cx - ax) * t, py = ay + (cy - ay) * t;
        if (px < minX || px > maxX || py < minY || py > maxY) continue;
        if (_dist(px, py) <= _blockRadiusM) overlap += len / n;
      }
    }
    return overlap;
  }
}

/// Traffic side of the country being routed in (true = left-hand traffic).
/// Set inside the routing isolate (like [_activeRouteMode]) from the caller's
/// `leftHandTraffic` argument. It decides the circulation direction of a
/// roundabout when it cannot be read from the route geometry: right-hand
/// traffic circulates counter-clockwise, left-hand traffic clockwise.
bool _activeLeftHandTraffic = false;

double _fastestClassFactor(String roadClass) {
  final c = roadClass.toLowerCase();
  // رمپ/لینک‌ها (motorway_link و ...) قبلاً با ضریب خودِ آزادراه (۰.۹) و سرعت
  // ۵۵–۷۰ حساب می‌شدند و مسیر را به شاخه‌های فرعی می‌کشاندند.
  if (c.endsWith('_link')) return 1.25;
  if (c.startsWith('motorway')) return 0.90;
  if (c.startsWith('trunk')) return 0.93;
  if (c.startsWith('primary')) return 0.97;
  if (c.startsWith('secondary')) return 1.0;
  if (c.startsWith('tertiary')) return 1.03;
  return 1.10;
}

const double _economicRefMps = 80 / 3.6;

/// جریمه‌ی تغییر خیابان (پیچیدن/ورود به شاخه). تا قبل از این، عوض کردن خیابان
/// هزینه‌ی صفر داشت و مسیر برای صرفه‌جویی چند ثانیه‌ای از کوچه/لینک می‌پیچید.
double _turnPenalty(_DbRouteEdge from, _DbRouteEdge to) {
  if (from.wayId == to.wayId) return 0;
  final fj = from.junction.trim().toLowerCase();
  final tj = to.junction.trim().toLowerCase();
  if (fj == 'roundabout' && tj == 'roundabout') return 0;
  var sec = 3.0;
  final fc = from.roadClass.toLowerCase();
  final tc = to.roadClass.toLowerCase();
  if (fc != tc &&
      (tc.endsWith('_link') ||
          tc.startsWith('residential') ||
          tc.startsWith('service') ||
          tc.startsWith('living_street') ||
          tc.startsWith('unclassified'))) {
    sec += 5.0;
  }
  // در حالت «کوتاه‌ترین» هزینه بر حسب متر است (~۱۰ متر ≈ ۱ ثانیه).
  return _activeRouteMode == 1 ? sec * 10.0 : sec;
}

double _edgeRouteCost(_DbRouteEdge e) {
  final t = e.distanceM / e.speedKmh * 3.6;
  switch (_activeRouteMode) {
    case 1:
      return e.distanceM;
    case 2:
      return 0.5 * t + 0.5 * e.distanceM / _economicRefMps;
    default:
      return t * _fastestClassFactor(e.roadClass);
  }
}

class _DbRouteEdge {
  const _DbRouteEdge({
    required this.from, required this.to, required this.distanceM,
    required this.speedKmh, required this.wayId, required this.onewayMode,
    required this.roadClass, required this.name, required this.junction,
    this.idx = 0,
  });

  final int idx;
  final int from;
  final int to;
  final double distanceM;
  final double speedKmh;
  final int wayId;

  final int onewayMode;
  bool get oneway => onewayMode != 0;
  final String roadClass;
  final String name;
  final String junction;
}

class _SqliteSnap {
  const _SqliteSnap({
    required this.a, required this.b, required this.t, required this.point,
    required this.segmentMeters, required this.onewayMode, required this.wayId,
  });
  final int a;
  final int b;
  final double t;
  final RoutePoint point;
  final double segmentMeters;
  final int onewayMode;
  bool get oneway => onewayMode != 0;
  final int wayId;
}

class _ModernSnap {
  const _ModernSnap({required this.edge, required this.t, required this.distance, required this.point, this.candidates = const []});
  final _DbRouteEdge edge;
  final double t;
  final double distance;
  final RoutePoint point;
  final List<_ModernSnap> candidates;
  factory _ModernSnap.group(List<_ModernSnap> sorted) {
    final best = sorted.first;
    return _ModernSnap(edge: best.edge, t: best.t, distance: best.distance, point: best.point, candidates: sorted);
  }
}

class _WayGeometrySlice {
  const _WayGeometrySlice(this.points, this.forward);
  final List<RoutePoint> points;
  final bool forward;
}

class _PolylineProjection {
  const _PolylineProjection(this.distanceM, this.t, this.point);
  final double distanceM;
  final double t;
  final RoutePoint point;
}

class AbmRouteResult {
  const AbmRouteResult({required this.points, required this.edges, this.diagnostics = const []});
  final List<RoutePoint> points;
  final List<RouteEdgeInfo> edges;
  final List<String> diagnostics;
}


List<RoutePoint> _decodeAbmWayGeometry(dynamic raw) {
  if (raw is! List<int> || raw.isEmpty) return const <RoutePoint>[];
  int offset = 0;
  int px = 0, py = 0;
  int readVarint() {
    var value = 0;
    var shift = 0;
    while (offset < raw.length) {
      final b = raw[offset++];
      value |= (b & 0x7f) << shift;
      if ((b & 0x80) == 0) return value;
      shift += 7;
      if (shift > 63) throw const FormatException('invalid ABM geometry varint');
    }
    throw const FormatException('truncated ABM geometry');
  }
  int unzig(int value) => (value >> 1) ^ -(value & 1);
  final out = <RoutePoint>[];
  try {
    while (offset < raw.length) {
      px += unzig(readVarint());
      py += unzig(readVarint());
      out.add(RoutePoint(py / 100000.0, px / 100000.0));
    }
  } catch (_) {
    return const <RoutePoint>[];
  }
  return out;
}

int _parseOnewayMode(dynamic value) {
  if (value is num) {
    final n = value.toInt();
    if (n == -1) return -1;
    if (n == 1) return 1;
    return 0;
  }
  final x = '${value ?? ''}'.trim().toLowerCase();
  final parsed = num.tryParse(x);
  if (parsed != null) {
    if (parsed == -1) return -1;
    if (parsed == 1) return 1;
  }
  if (x == '-1' || x == 'reverse' || x == 'backward') return -1;
  if (x == '1' || x == 'true' || x == 'yes' || x == 'y' || x == 'forward') return 1;
  return 0;
}

int _effectiveOneway(int mode, Object? junction) {
  if (mode != 0) return mode;
  final j = '${junction ?? ''}'.trim().toLowerCase();
  return (j == 'roundabout' || j == 'circular') ? 1 : 0;
}

class AbmRoutingEngine {
  Future<List<RoutePoint>> route(
    File abmFile,
    RoutePoint origin,
    RoutePoint destination, {
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
    bool avoidTrafficZones = false,
    bool avoidHighways = false,
  }) async {
    final result = await routeDetailed(
      abmFile, origin, destination,
      avoidUnpavedRoads: avoidUnpavedRoads,
      avoidTolls: avoidTolls,
      avoidTrafficZones: avoidTrafficZones,
      avoidHighways: avoidHighways,
    );
    return result?.points ?? const [];
  }

  Future<AbmRouteResult?> routeDetailed(
    File abmFile,
    RoutePoint origin,
    RoutePoint destination, {
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
    bool avoidTrafficZones = false,
    bool avoidHighways = false,
    Map<int, double>? wayPenalty,
    int routeMode = 0,
    List<File> extraFiles = const <File>[],
    bool leftHandTraffic = false,
    List<List<RoutePoint>> blockedPolylines = const <List<RoutePoint>>[],
    RouteCancelToken? cancel,
  }) {
    final penalty = wayPenalty == null || wayPenalty.isEmpty
        ? null
        : Map<int, double>.of(wayPenalty);
    final extraPaths = <String>[for (final f in extraFiles) f.path];
    return _runCancellable<AbmRouteResult?>(() async {
      _activeRouteMode = routeMode;
      _activeLeftHandTraffic = leftHandTraffic;
      _activeBlocks = <_BlockPoly>[
        for (final b in blockedPolylines)
          if (b.length >= 2) _BlockPoly(b),
      ];
      return _routeDetailedSync(
          abmFile.path, origin, destination,
          avoidUnpavedRoads, avoidTolls, avoidTrafficZones, avoidHighways,
          penalty,
          extraPaths,
        );
    }, cancel);
  }

  static Future<AbmRouteResult?> _routeDetailedSync(
    String path, RoutePoint origin, RoutePoint destination,
    bool avoidUnpavedRoads, bool avoidTolls, bool avoidTrafficZones, bool avoidHighways,
    [Map<int, double>? wayPenalty, List<String> extraPaths = const <String>[]]
  ) async {
    final file = File(path);
    if (!await file.exists()) return null;
    if (path.toLowerCase().endsWith('.sqlite')) {
      return _routeSqliteDetailed(
        path, origin, destination, avoidUnpavedRoads, avoidTolls, avoidTrafficZones, avoidHighways,
        wayPenalty, extraPaths,
      );
    }
    final points = await _routeSync(
      path, origin, destination, avoidUnpavedRoads, avoidTolls, avoidTrafficZones, avoidHighways,
    );
    return points.isEmpty ? null : AbmRouteResult(points: points, edges: const []);
  }

  static Future<List<RoutePoint>> _routeSync(
    String path,
    RoutePoint origin,
    RoutePoint destination,
    bool avoidUnpavedRoads,
    bool avoidTolls,
    bool avoidTrafficZones,
    bool avoidHighways,
  ) async {
    final file = File(path);
    if (!await file.exists()) return const [];
    if (path.toLowerCase().endsWith('.sqlite')) {
      final detailed = await _routeSqliteDetailed(
        path, origin, destination, avoidUnpavedRoads, avoidTolls, avoidTrafficZones, avoidHighways,
      );
      return detailed?.points ?? const <RoutePoint>[];
    }
    final raf = await file.open();
    try {
      final magic = utf8.encode('ABMGRAPH1\n');
      final header = await raf.read(magic.length + 4);
      if (header.length < magic.length + 4) return const [];
      for (var i = 0; i < magic.length; i++) {
        if (header[i] != magic[i]) return const [];
      }
      final jsonLength = _u32(header, magic.length);
      final fileLength = await raf.length();
      final jsonStart = magic.length + 4;
      if (jsonLength <= 0 || jsonStart + jsonLength > fileLength)
        return const [];

      final nodes = <int, RoutePoint>{};
      final adjacency = <int, List<_Edge>>{};

      await _scanSection(
        raf,
        jsonStart,
        jsonLength,
        'nodes',
        (key, value) {
          if (key == null || value is! List || value.length < 2) return;
          final id = int.tryParse(key);
          if (id == null || value[0] is! num || value[1] is! num) return;
          nodes[id] = RoutePoint(
            (value[0] as num).toDouble(),
            (value[1] as num).toDouble(),
          );
        },
      );
      if (nodes.isEmpty) return const [];

      final start = _nearest(nodes, origin);
      final goal = _nearest(nodes, destination);
      if (start == goal) return <RoutePoint>[nodes[start]!];

      await _scanSection(
        raf,
        jsonStart,
        jsonLength,
        'edges',
        (key, value) {
          if (value is! Map) return;
          final a = _int(value['start'] ?? value['from']);
          final b = _int(value['end'] ?? value['to']);
          if (a == null ||
              b == null ||
              !nodes.containsKey(a) ||
              !nodes.containsKey(b)) return;
          final road =
              '${value['road_class'] ?? value['highway'] ?? value['class'] ?? value['road'] ?? ''}'
                  .toLowerCase();
          final toll = value['toll'] == true ||
              value['toll'] == 1 ||
              road.contains('toll');
          final restricted = value['traffic_zone'] == true ||
              value['trafficZone'] == true ||
              value['restricted'] == true;
          final surface = '${value['surface'] ?? ''}'.toLowerCase();
          final unpaved =
              surface.isNotEmpty && surface != 'paved' && surface != 'asphalt';
          if ((avoidTolls && toll) ||
              (avoidTrafficZones && restricted) ||
              (avoidHighways && (road.startsWith('motorway') || road.startsWith('trunk'))) ||
              (avoidUnpavedRoads && unpaved)) return;
          final speedRaw =
              value['speed_kmh'] ?? value['speed'] ?? value['maxspeed'] ?? 50;
          final speed = speedRaw is num
              ? speedRaw.toDouble().clamp(5, 160).toDouble()
              : 50.0;
          final distanceRaw = value['distance_m'] ?? value['distance'];
          final distance = distanceRaw is num
              ? distanceRaw.toDouble()
              : _distance(nodes[a]!, nodes[b]!);
          final onewayMode = _parseOnewayMode(value['oneway']);
          if (onewayMode != -1) {
            (adjacency[a] ??= []).add(_Edge(b, distance, speed));
          }
          if (onewayMode != 1) {
            (adjacency[b] ??= []).add(_Edge(a, distance, speed));
          }
        },
      );

      final distance = <int, double>{start: 0};
      final previous = <int, int?>{start: null};
      final open = _MinHeap<_QueueItem>((a, b) => a.cost.compareTo(b.cost));
      open.add(_QueueItem(start, 0));
      while (open.isNotEmpty) {
        final item = open.removeFirst();
        final current = item.node;
        if (item.cost > (distance[current] ?? double.infinity)) continue;
        if (current == goal) break;
        for (final edge in adjacency[current] ?? const <_Edge>[]) {
          final cost = edge.distanceM / edge.speedKmh * 3.6;
          final next = (distance[current] ?? double.infinity) + cost;
          if (next < (distance[edge.to] ?? double.infinity)) {
            distance[edge.to] = next;
            previous[edge.to] = current;
            open.add(_QueueItem(edge.to, next));
          }
        }
      }
      if (!previous.containsKey(goal)) return const [];
      final ids = <int>[];
      int? current = goal;
      while (current != null) {
        ids.add(current);
        current = previous[current];
      }
      return ids.reversed.map((id) => nodes[id]!).toList(growable: false);
    } finally {
      await raf.close();
    }
  }

  /// Bounding box (minLon, minLat, maxLon, maxLat) of a map's routing graph.
  static List<double>? _graphExtent(Database d) {
    try {
      final r = d.select(
        'SELECT MIN(min_lon) AS a, MIN(min_lat) AS b, MAX(max_lon) AS c, MAX(max_lat) AS e FROM routing_cells',
      );
      if (r.isEmpty) return null;
      final row = r.first;
      final a = (row['a'] as num?)?.toDouble();
      final b = (row['b'] as num?)?.toDouble();
      final c = (row['c'] as num?)?.toDouble();
      final e = (row['e'] as num?)?.toDouble();
      if (a == null || b == null || c == null || e == null) return null;
      if (!(a.isFinite && b.isFinite && c.isFinite && e.isFinite)) return null;
      return <double>[a, b, c, e];
    } catch (_) {
      return null;
    }
  }

  static AbmRouteResult? _routeModernSqliteDetailed(
    List<Database> dbs,
    RoutePoint origin,
    RoutePoint destination,
    bool avoidUnpavedRoads,
    bool avoidTolls,
    bool avoidTrafficZones,
    bool avoidHighways, [
    Map<int, double>? wayPenalty,
  ]) {
    if (!origin.lat.isFinite || !origin.lon.isFinite ||
        !destination.lat.isFinite || !destination.lon.isFinite) {
      return AbmRouteResult(points: const [], edges: const [], diagnostics: const ['MODERN GRAPH: invalid coordinates']);
    }

    const startId = -1;
    const goalId = -2;
    final virtualPoints = <int, RoutePoint>{};
    final nodeCache = <int, RoutePoint?>{};

    final nodeStmts = <PreparedStatement>[
      for (final d in dbs) d.prepare('SELECT lat,lon FROM nodes WHERE id=? LIMIT 1'),
    ];
    // Graph extent of every map (only when several maps are searched together) so
    // a node is only looked up in maps that can contain it. `hintDb` is the map the
    // last hit came from: neighbouring nodes almost always live in the same map.
    final graphBoxes = <List<double>?>[
      for (final d in dbs) dbs.length > 1 ? _graphExtent(d) : null,
    ];
    var hintDb = 0;
    bool dbMayHave(int i, double lat, double lon) {
      final b = graphBoxes[i];
      return b == null ||
          (lon >= b[0] - 0.01 && lon <= b[2] + 0.01 && lat >= b[1] - 0.01 && lat <= b[3] + 0.01);
    }

    RoutePoint? nodeOrNull(int id) {
      if (id < 0) return virtualPoints[id];
      if (nodeCache.containsKey(id)) return nodeCache[id];
      RoutePoint? p;
      final n = nodeStmts.length;
      for (var k = 0; k < n; k++) {
        final i = (hintDb + k) % n;
        final rows = nodeStmts[i].select([id]);
        if (rows.isNotEmpty) {
          p = RoutePoint((rows.first['lat'] as num).toDouble(), (rows.first['lon'] as num).toDouble());
          hintDb = i;
          break;
        }
      }
      nodeCache[id] = p;
      return p;
    }

    RoutePoint node(int id) => nodeOrNull(id) ?? (throw StateError('Missing node $id'));

    final wayGeometryCache = <int, List<RoutePoint>>{};
    final waySliceCache = <String, _WayGeometrySlice?>{};
    List<RoutePoint> wayGeometry(int wayId) {
      final cached = wayGeometryCache[wayId];
      if (cached != null) return cached;
      try {
        for (var k = 0; k < dbs.length; k++) {
          final rows = dbs[(hintDb + k) % dbs.length].select(
            'SELECT geometry FROM way_geometry WHERE way_id=? LIMIT 1',
            [wayId],
          );
          if (rows.isEmpty) continue;
          final decoded = _decodeAbmWayGeometry(rows.first['geometry']);
          wayGeometryCache[wayId] = decoded;
          return decoded;
        }
        return wayGeometryCache[wayId] = const <RoutePoint>[];
      } catch (_) {
        wayGeometryCache[wayId] = const <RoutePoint>[];
        return const <RoutePoint>[];
      }
    }

    double polylineLength(List<RoutePoint> line) {
      var total = 0.0;
      for (var i = 1; i < line.length; i++) total += _distance(line[i - 1], line[i]);
      return total;
    }

    const gridCell = 1e-4;
    final wayGrid = <int, Map<int, List<int>>>{};
    int cellKey(double lat, double lon) =>
        ((lat + 90.0) / gridCell).floor() * 8000000 + ((lon + 180.0) / gridCell).floor();
    Map<int, List<int>> gridFor(int wayId, List<RoutePoint> geom) {
      final cached = wayGrid[wayId];
      if (cached != null) return cached;
      final grid = <int, List<int>>{};
      for (var i = 0; i < geom.length; i++) {
        (grid[cellKey(geom[i].lat, geom[i].lon)] ??= <int>[]).add(i);
      }
      return wayGrid[wayId] = grid;
    }

    List<int> geometryCandidates(int wayId, List<RoutePoint> geom, RoutePoint target) {
      final grid = gridFor(wayId, geom);
      final base = cellKey(target.lat, target.lon);
      final near = <int>[];
      for (var dy = -1; dy <= 1; dy++) {
        for (var dx = -1; dx <= 1; dx++) {
          final bucket = grid[base + dy * 8000000 + dx];
          if (bucket != null) near.addAll(bucket);
        }
      }
      if (near.isNotEmpty) {
        var bestNear = double.infinity;
        final dist = <int, double>{};
        for (final i in near) {
          final d = _distance(target, geom[i]);
          dist[i] = d;
          if (d < bestNear) bestNear = d;
        }
        if (bestNear <= 6.0) {
          final limit = math.min(30.0, bestNear + 4.0);
          final out = <int>[
            for (final i in near)
              if (dist[i]! <= limit) i,
          ]..sort();
          return out;
        }
      }
      var bestD = double.infinity;
      final distances = List<double>.filled(geom.length, 0.0);
      for (var i = 0; i < geom.length; i++) {
        final d = _distance(target, geom[i]);
        distances[i] = d;
        if (d < bestD) bestD = d;
      }
      final out = <int>[];
      final limit = math.min(30.0, bestD + 4.0);
      for (var i = 0; i < geom.length; i++) {
        if (distances[i] <= limit) out.add(i);
      }
      return out;
    }

    _WayGeometrySlice? waySlice(_DbRouteEdge edge) {
      if (edge.from < 0 || edge.to < 0) return null;
      final cacheKey = '${edge.wayId}|${edge.from}|${edge.to}';
      if (waySliceCache.containsKey(cacheKey)) return waySliceCache[cacheKey];
      final a = nodeOrNull(edge.from), b = nodeOrNull(edge.to);
      if (a == null || b == null) { waySliceCache[cacheKey] = null; return null; }
      final geom = wayGeometry(edge.wayId);
      if (geom.length < 2) { waySliceCache[cacheKey] = null; return null; }
      final ca = geometryCandidates(edge.wayId, geom, a), cb = geometryCandidates(edge.wayId, geom, b);
      if (ca.isEmpty || cb.isEmpty) { waySliceCache[cacheKey] = null; return null; }

      final ring = _closedRingSlice(geom, ca, cb, a, b, edge.distanceM);
      if (ring != null) {
        waySliceCache[cacheKey] = ring;
        return ring;
      }

      var bestScore = double.infinity;
      var bestA = -1, bestB = -1;
      for (final ia in ca) {
        for (final ib in cb) {
          if (ia == ib) continue;
          final lo = math.min(ia, ib), hi = math.max(ia, ib);
          final sub = geom.sublist(lo, hi + 1);
          final len = polylineLength(sub);
          final endpointError = _distance(a, geom[ia]) + _distance(b, geom[ib]);
          final lengthError = edge.distanceM > 0 ? (len - edge.distanceM).abs() : 0.0;
          final score = endpointError * 8.0 + lengthError;
          if (score < bestScore) {
            bestScore = score;
            bestA = ia;
            bestB = ib;
          }
        }
      }
      if (bestA < 0 || bestB < 0) { waySliceCache[cacheKey] = null; return null; }
      if (_distance(a, geom[bestA]) > 30.0 || _distance(b, geom[bestB]) > 30.0) {
        waySliceCache[cacheKey] = null;
        return null;
      }
      if (bestA < bestB) {
        final result = _WayGeometrySlice(geom.sublist(bestA, bestB + 1), true);
        waySliceCache[cacheKey] = result;
        return result;
      }
      final result = _WayGeometrySlice(
        geom.sublist(bestB, bestA + 1).reversed.toList(growable: false),
        false,
      );
      waySliceCache[cacheKey] = result;
      return result;
    }

    // Edges whose way geometry could not be matched. They used to produce NO
    // points at all, so the drawn route cut straight across ramps/bridges.
    final geometryFallbackEdges = <String>{};
    List<RoutePoint> physicalEdgeGeometry(_DbRouteEdge edge) {
      final slice = waySlice(edge);
      if (slice != null) return slice.points;
      final a = nodeOrNull(edge.from), b = nodeOrNull(edge.to);
      if (a == null || b == null) return const <RoutePoint>[];
      geometryFallbackEdges.add('${edge.wayId}|${edge.from}|${edge.to}');
      return <RoutePoint>[a, b];
    }

    List<RoutePoint> subPolyline(List<RoutePoint> line, double fromT, double toT) {
      if (line.length < 2) return const <RoutePoint>[];
      final loT = fromT.clamp(0.0, 1.0).toDouble();
      final hiT = toT.clamp(0.0, 1.0).toDouble();
      if (hiT <= loT) return const <RoutePoint>[];
      final lengths = List<double>.filled(line.length, 0.0);
      for (var i = 1; i < line.length; i++) {
        lengths[i] = lengths[i - 1] + _distance(line[i - 1], line[i]);
      }
      final total = lengths.last;
      if (total < 0.01) return <RoutePoint>[line.first, line.last];

      RoutePoint at(double t) {
        final target = total * t;
        for (var i = 1; i < line.length; i++) {
          if (target <= lengths[i]) {
            final seg = lengths[i] - lengths[i - 1];
            if (seg <= 0.001) return line[i];
            final q = ((target - lengths[i - 1]) / seg).clamp(0.0, 1.0).toDouble();
            return RoutePoint(
              line[i - 1].lat + (line[i].lat - line[i - 1].lat) * q,
              line[i - 1].lon + (line[i].lon - line[i - 1].lon) * q,
            );
          }
        }
        return line.last;
      }

      final out = <RoutePoint>[at(loT)];
      for (var i = 1; i < line.length - 1; i++) {
        final t = lengths[i] / total;
        if (t > loT && t < hiT) out.add(line[i]);
      }
      out.add(at(hiT));
      return out;
    }

    _PolylineProjection? projectOnEdge(RoutePoint p, _DbRouteEdge edge) {
      final line = physicalEdgeGeometry(edge);
      if (line.length < 2) return null;
      final mLat = 110540.0;
      final mLon = 111320.0 * math.cos(p.lat * math.pi / 180.0).abs().clamp(0.2, 1.0);
      var total = polylineLength(line);
      if (total < 0.01) return null;
      var travelled = 0.0;
      var bestD = double.infinity;
      var bestT = 0.0;
      RoutePoint? bestPoint;
      for (var i = 1; i < line.length; i++) {
        final a = line[i - 1], b = line[i];
        final ax = (a.lon - p.lon) * mLon, ay = (a.lat - p.lat) * mLat;
        final bx = (b.lon - p.lon) * mLon, by = (b.lat - p.lat) * mLat;
        final dx = bx - ax, dy = by - ay;
        final len2 = dx * dx + dy * dy;
        if (len2 < 1e-9) continue;
        final segLen = math.sqrt(len2);
        final localT = (-(ax * dx + ay * dy) / len2).clamp(0.0, 1.0).toDouble();
        final px = ax + dx * localT, py = ay + dy * localT;
        final d = math.sqrt(px * px + py * py);
        if (d < bestD) {
          bestD = d;
          bestT = (travelled + segLen * localT) / total;
          bestPoint = RoutePoint(p.lat + py / mLat, p.lon + px / mLon);
        }
        travelled += segLen;
      }
      if (bestPoint == null) return null;
      return _PolylineProjection(bestD, bestT, bestPoint);
    }

    bool allowed(String road, String access, String surface) {
      if (avoidTrafficZones && access.contains('private')) return false;
      if (avoidHighways && (road.startsWith('motorway') || road.startsWith('trunk'))) return false;
      if (avoidTolls && road.contains('toll')) return false;
      if (avoidUnpavedRoads && surface.isNotEmpty && surface != 'paved' && surface != 'asphalt') return false;
      return true;
    }

    bool isRoundabout(String j) => j.trim().toLowerCase() == 'roundabout';

    var edgeSeq = 0;
    final adjacency = <int, List<_DbRouteEdge>>{};
    final expanded = <int>{};

    // Each map resolves class/name through its own categories/names tables
    // (those ids are per map), so attributes are always read per map.
    final wayAttrStmts = <PreparedStatement>[
      for (final d in dbs)
        d.prepare(
          'SELECT c.name AS road_class, w.speed_kmh, w.oneway, w.access, w.surface, '
          'n.name, n.name_fa, n.name_en, w.junction '
          'FROM way_data w JOIN categories c ON c.id=w.class_id '
          'LEFT JOIN names n ON n.id=w.name_id WHERE w.way_id=? LIMIT 1',
        ),
    ];
    final wayAttrCache = <int, _WayAttr?>{};
    const veryMinorClasses = <String>[
      'service', 'track', 'path', 'footway', 'cycleway', 'pedestrian', 'steps',
      'bridleway', 'living_street',
    ];
    const minorClasses = <String>[
      'residential', 'service', 'track', 'living_street', 'path', 'footway',
      'cycleway', 'pedestrian', 'steps', 'bridleway', 'road',
    ];
    _WayAttr? wayAttr(int wayId) {
      if (wayAttrCache.containsKey(wayId)) return wayAttrCache[wayId];
      Row? r;
      for (var k = 0; k < wayAttrStmts.length; k++) {
        final rows = wayAttrStmts[(hintDb + k) % wayAttrStmts.length].select([wayId]);
        if (rows.isNotEmpty) {
          r = rows.first;
          break;
        }
      }
      if (r == null) return wayAttrCache[wayId] = null;
      final road = '${r['road_class'] ?? ''}'.toLowerCase();
      final access = '${r['access'] ?? ''}'.toLowerCase();
      final surface = '${r['surface'] ?? ''}'.toLowerCase();
      final name = [r['name_fa'], r['name'], r['name_en']]
          .map((v) => '${v ?? ''}')
          .firstWhere((v) => v.isNotEmpty, orElse: () => '');
      return wayAttrCache[wayId] = _WayAttr(
        roadClass: '${r['road_class'] ?? ''}',
        speedKmh: ((r['speed_kmh'] as num?)?.toDouble() ?? 30).clamp(5, 160).toDouble(),
        onewayMode: _effectiveOneway(_parseOnewayMode(r['oneway']), r['junction']),
        name: name,
        junction: '${r['junction'] ?? ''}',
        allowed: allowed(road, access, surface),
        minor: minorClasses.any(road.startsWith),
        veryMinor: veryMinorClasses.any(road.startsWith),
        local: minorClasses.any(road.startsWith) ||
            road.startsWith('tertiary') ||
            road.startsWith('unclassified'),
      );
    }

    const edgeSql =
      'SELECT e.start, e."end", e.distance_m, e.way_id, '
      'CASE WHEN EXISTS(SELECT 1 FROM segments sf WHERE sf.way_id=e.way_id '
      'AND sf.a=e.start AND sf.b=e."end") THEN 1 '
      'WHEN EXISTS(SELECT 1 FROM segments sr WHERE sr.way_id=e.way_id '
      'AND sr.a=e."end" AND sr.b=e.start) THEN 0 ELSE -1 END AS fwd '
      'FROM edges e WHERE e.start=?';
    final edgeStmts = <PreparedStatement>[for (final d in dbs) d.prepare(edgeSql)];

    List<_DbRouteEdge> outgoing(int id) {
      if (id < 0) return adjacency[id] ?? const <_DbRouteEdge>[];
      if (!expanded.add(id)) return adjacency[id] ?? const <_DbRouteEdge>[];
      final list = adjacency[id] ??= <_DbRouteEdge>[];
      final nodePoint = dbs.length > 1 ? nodeOrNull(id) : null;
      final edgeRows = <Row>[];
      final seenSegments = <String>{};
      for (var di = 0; di < edgeStmts.length; di++) {
        if (nodePoint != null && !dbMayHave(di, nodePoint.lat, nodePoint.lon)) continue;
        for (final row in edgeStmts[di].select([id])) {
          // The same OSM segment exists in both maps inside their overlap.
          if (dbs.length > 1 &&
              !seenSegments.add('${row['end']}:${row['way_id']}')) {
            continue;
          }
          edgeRows.add(row);
        }
      }
      for (final r in edgeRows) {
        if (((r['fwd'] as num?)?.toInt() ?? 1) < 0) continue;
        final wayId = (r['way_id'] as num).toInt();
        final attr = wayAttr(wayId);
        if (attr == null || !attr.allowed) continue;
        final candidate = _DbRouteEdge(
          from: id,
          to: (r['end'] as num).toInt(),
          distanceM: (r['distance_m'] as num).toDouble(),
          speedKmh: attr.speedKmh,
          wayId: wayId,
          onewayMode: attr.onewayMode,
          roadClass: attr.roadClass,
          name: attr.name,
          junction: attr.junction,
          idx: edgeSeq++,
        );
        // One-way check straight from the directed `segments` table (way order):
        // far cheaper than decoding/slicing the way geometry for every expanded edge,
        // which dominated run time on long motorway/trunk (dual carriageway) routes.
        final fwd = ((r['fwd'] as num?)?.toInt() ?? 1) != 0;
        if (attr.onewayMode == 1 && !fwd) continue;
        if (attr.onewayMode == -1 && fwd) continue;
        list.add(candidate);
      }
      return list;
    }

    _ModernSnap? snapToRoad(RoutePoint p, [Set<int> skipWays = const <int>{}]) {
      for (final radius in const [0.0015, 0.004, 0.01, 0.03, 0.08]) {
        final cosLat = math.cos(p.lat * math.pi / 180.0).abs().clamp(0.2, 1.0);
        final lonRadius = radius / cosLat;
        final idSet = <int>{};
        for (var di = 0; di < dbs.length; di++) {
          final gb = graphBoxes[di];
          if (gb != null &&
              (p.lon + lonRadius < gb[0] ||
                  p.lon - lonRadius > gb[2] ||
                  p.lat + radius < gb[1] ||
                  p.lat - radius > gb[3])) {
            continue;
          }
          for (final row in dbs[di].select(
            'SELECT id FROM node_index WHERE max_lat>=? AND min_lat<=? AND max_lon>=? AND min_lon<=? LIMIT 3000',
            [p.lat - radius, p.lat + radius, p.lon - lonRadius, p.lon + lonRadius],
          )) {
            idSet.add((row['id'] as num).toInt());
          }
        }
        final near = <MapEntry<int, double>>[];
        for (final id in idSet) {
          final q = nodeOrNull(id);
          if (q == null) continue;
          final d = _distance(p, q);
          near.add(MapEntry(id, d));
        }
        near.sort((a, b) => a.value.compareTo(b.value));
        final cands = <_ModernSnap>[];
        var bestD = double.infinity;
        for (final entry in near.take(80)) {
          for (final e in outgoing(entry.key)) {
            if (skipWays.contains(e.wayId)) continue;
            final projection = projectOnEdge(p, e);
            if (projection == null) continue;
            final d = projection.distanceM;
            if (d < bestD) bestD = d;
            cands.add(_ModernSnap(
              edge: e,
              t: projection.t,
              distance: d,
              point: projection.point,
            ));
          }
        }
        if (cands.isNotEmpty && bestD <= radius * 111500.0) {
          final best0 = cands.reduce((a, b) => a.distance <= b.distance ? a : b);
          bool samePhysical(_ModernSnap c) =>
              c.edge.wayId == best0.edge.wayId &&
              ((c.edge.from == best0.edge.from && c.edge.to == best0.edge.to) ||
                  (c.edge.from == best0.edge.to && c.edge.to == best0.edge.from));
          final keep = cands.where(samePhysical).toList()
            ..sort((a, b) => a.distance.compareTo(b.distance));
          return _ModernSnap.group(keep);
        }
      }
      return null;
    }

    // یک جادهٔ جزیره‌ای (مثلاً کوچه/راه داخل روستا که به شبکه وصل نیست) اگر
    // نزدیک‌ترین جاده به مقصد باشد، جست‌وجو تا پایان بودجه کل شبکه را می‌گردد و
    // هیچ‌وقت نتیجه نمی‌دهد. با یک پیمایشِ کوچک جزیره را تشخیص می‌دهیم و به
    // نزدیک‌ترین جادهٔ متصل می‌چسبانیم.
    bool isIsland(_ModernSnap s) {
      const limit = 300;
      final seen = <int>{s.edge.from, s.edge.to};
      final queue = <int>[s.edge.from, s.edge.to];
      var head = 0;
      while (head < queue.length && seen.length < limit) {
        final id = queue[head++];
        for (final e in outgoing(id)) {
          if (seen.add(e.to)) queue.add(e.to);
        }
      }
      return seen.length < limit;
    }

    _ModernSnap? connectedSnap(RoutePoint p, _ModernSnap? first) {
      var snap = first;
      final skip = <int>{};
      for (var i = 0; i < 4 && snap != null && isIsland(snap); i++) {
        skip.add(snap.edge.wayId);
        final alt = snapToRoad(p, skip);
        if (alt == null) break;
        snap = alt;
      }
      return snap;
    }

    final startSnap = connectedSnap(origin, snapToRoad(origin));
    final goalSnap = connectedSnap(destination, snapToRoad(destination));
    if (startSnap == null || goalSnap == null) {
      return AbmRouteResult(points: const [], edges: const [], diagnostics: const ['MODERN GRAPH: nearest road not found']);
    }
    virtualPoints[startId] = startSnap.point;
    virtualPoints[goalId] = goalSnap.point;

    void addVirtual(_DbRouteEdge e) => (adjacency[e.from] ??= <_DbRouteEdge>[]).add(e);
    _DbRouteEdge partial(_DbRouteEdge base, int from, int to, double meters) => _DbRouteEdge(
          from: from, to: to, distanceM: meters, speedKmh: base.speedKmh,
          wayId: base.wayId, onewayMode: base.onewayMode, roadClass: base.roadClass,
          name: base.name, junction: base.junction, idx: edgeSeq++,
        );
    for (final c in startSnap.candidates) {
      addVirtual(partial(c.edge, startId, c.edge.to, c.edge.distanceM * (1.0 - c.t)));
    }
    for (final s in startSnap.candidates) {
      for (final g in goalSnap.candidates) {
        if (s.edge.from == g.edge.from && s.edge.to == g.edge.to && s.edge.wayId == g.edge.wayId && g.t >= s.t) {
          addVirtual(partial(s.edge, startId, goalId, s.edge.distanceM * (g.t - s.t)));
        }
      }
    }
    final goalIn = <int, List<_DbRouteEdge>>{};
    for (final c in goalSnap.candidates) {
      (goalIn[c.edge.from] ??= <_DbRouteEdge>[]).add(partial(c.edge, c.edge.from, goalId, c.edge.distanceM * c.t));
    }

    final rulesByVia = <int, Map<int, _TurnRule>>{};
    _TurnRule ruleFor(int via, int inWay) =>
        (rulesByVia[via] ??= <int, _TurnRule>{})[inWay] ??=
            _TurnRule(no: <int>{}, only: <int>{});
    // Restrictions are read per map. When a map's lookup table has an index on
    // (from_way, via_node) they are loaded on demand per junction instead of
    // reading up to 3M rows per route.
    final lazyRestrictionStmts = List<PreparedStatement?>.filled(dbs.length, null);
    final lazyLoaded = <int, Set<int>>{};
    void addRestriction(int via, int inWay, int to, Object? kind) {
      final rule = ruleFor(via, inWay);
      if ('${kind ?? ''}'.toLowerCase().startsWith('only')) {
        rule.only.add(to);
      } else {
        rule.no.add(to);
      }
    }

    for (var di = 0; di < dbs.length; di++) {
      final d = dbs[di];
      try {
        final hasLookup = d.select(
          "SELECT 1 FROM sqlite_master WHERE type='table' AND name='turn_restriction_lookup' LIMIT 1",
        ).isNotEmpty;
        var lookupIndexed = false;
        if (hasLookup) {
          try {
            final plan = d.select(
              'EXPLAIN QUERY PLAN SELECT restriction,to_way FROM turn_restriction_lookup '
              'WHERE from_way=? AND via_node=?',
              [0, 0],
            );
            lookupIndexed =
                plan.any((r) => '${r['detail']}'.toUpperCase().contains('SEARCH'));
          } catch (_) {}
        }
        if (hasLookup && lookupIndexed) {
          lazyRestrictionStmts[di] = d.prepare(
            'SELECT restriction,to_way FROM turn_restriction_lookup '
            'WHERE from_way=? AND via_node=?',
          );
        } else if (hasLookup) {
          for (final row in d.select(
            'SELECT restriction,from_way,via_node,to_way FROM turn_restriction_lookup LIMIT 3000000',
          )) {
            addRestriction(
              (row['via_node'] as num).toInt(),
              (row['from_way'] as num).toInt(),
              (row['to_way'] as num).toInt(),
              row['restriction'],
            );
          }
        } else {
          List<int> ids(dynamic v) {
            try {
              final x = jsonDecode('${v ?? '[]'}');
              return x is List ? x.whereType<num>().map((n) => n.toInt()).toList() : const [];
            } catch (_) {
              return const [];
            }
          }
          for (final r in d.select('SELECT restriction,from_json,via_json,to_json FROM turn_restrictions')) {
            for (final fw in ids(r['from_json'])) {
              for (final vn in ids(r['via_json'])) {
                for (final tw in ids(r['to_json'])) {
                  addRestriction(vn, fw, tw, r['restriction']);
                }
              }
            }
          }
        }
      } catch (_) {}
    }
    final hasLazyRestrictions = lazyRestrictionStmts.any((st) => st != null);
    bool turnAllowed(int inWay, int via, int outWay) {
      if (hasLazyRestrictions && via >= 0 && (lazyLoaded[via] ??= <int>{}).add(inWay)) {
        final viaPoint = dbs.length > 1 ? nodeOrNull(via) : null;
        for (var di = 0; di < dbs.length; di++) {
          final lazy = lazyRestrictionStmts[di];
          if (lazy == null) continue;
          if (viaPoint != null && !dbMayHave(di, viaPoint.lat, viaPoint.lon)) continue;
          for (final row in lazy.select([inWay, via])) {
            addRestriction(via, inWay, (row['to_way'] as num).toInt(), row['restriction']);
          }
        }
      }
      final rule = rulesByVia[via]?[inWay];
      if (rule == null) return true;
      if (rule.only.isNotEmpty && !rule.only.contains(outWay)) return false;
      return !rule.no.contains(outWay);
    }

    // Fastest road classes only (uses idx_way_data_class) instead of scanning all of
    // way_data on every route.
    var maxSpeed = 0.0;
    for (final d in dbs) {
      try {
        final r = d.select(
          'SELECT MAX(w.speed_kmh) AS m FROM way_data w WHERE w.class_id IN '
          "(SELECT id FROM categories WHERE name IN ('motorway','trunk','motorway_link','trunk_link'))",
        );
        final m = r.isEmpty ? null : (r.first['m'] as num?)?.toDouble();
        if (m != null && m.isFinite && m > maxSpeed) maxSpeed = m;
      } catch (_) {}
    }
    maxSpeed = maxSpeed <= 0 ? 120.0 : maxSpeed.clamp(50.0, 160.0).toDouble();
    final directMeters = _distance(startSnap.point, goalSnap.point);
    var hWeight = directMeters > 300000
        ? 1.6
        : directMeters > 150000
            ? 1.5
            : directMeters > 40000
                ? 1.35
                : directMeters > 10000
                    ? 1.25
                    : directMeters > 3000
                        ? 1.12
                        : 1.0;
    if (_activeRouteMode == 1 && hWeight > 1.1) hWeight = 1.1;
    final pruneMinor = directMeters > 6000 && _activeRouteMode != 1;
    final nearRadius = math.max(2500.0, directMeters * 0.08);
    const budgetMs = 75000;
    final clock = Stopwatch()..start();
    var anyLevelTimedOut = false;
    var timedOut = false;
    var expandedStates = 0;

    var curHWeight = hWeight;
    final hCache = <int, double>{};
    double heuristic(int nodeId) {
      final cached = hCache[nodeId];
      if (cached != null) return cached;
      final d = _distance(node(nodeId), goalSnap.point);
      final double base;
      switch (_activeRouteMode) {
        case 1:
          base = d;
        case 2:
          base = 0.5 * d / _economicRefMps + 0.5 * d / maxSpeed * 3.6;
        default:
          base = d / maxSpeed * 3.6 * 0.90;
      }
      return hCache[nodeId] = base * curHWeight;
    }

    final nearCache = <int, bool>{};
    bool nearEndpoints(int nodeId) {
      final cached = nearCache[nodeId];
      if (cached != null) return cached;
      final p = node(nodeId);
      final near = _distance(p, startSnap.point) <= nearRadius ||
          _distance(p, goalSnap.point) <= nearRadius;
      return nearCache[nodeId] = near;
    }

    final minorByWay = <int, bool>{};
    bool isMinorWay(_DbRouteEdge e) =>
        minorByWay[e.wayId] ??= (wayAttrCache[e.wayId]?.minor ?? false);
    final localByWay = <int, bool>{};
    bool isLocalWay(_DbRouteEdge e) =>
        localByWay[e.wayId] ??= (wayAttrCache[e.wayId]?.local ?? false);
    final veryMinorByWay = <int, bool>{};
    bool isVeryMinorWay(_DbRouteEdge e) =>
        veryMinorByWay[e.wayId] ??= (wayAttrCache[e.wayId]?.veryMinor ?? false);

    var cost = <int, double>{};
    var prevState = <int, int?>{};
    var stateEdge = <int, _DbRouteEdge>{};
    int? goalKey;
    // Roads the driver marked as closed: an edge is blocked when its real
    // geometry runs along a reported stretch (a crossing street only touches it).
    final blockedEdgeCache = <int, bool>{};
    bool edgeBlocked(_DbRouteEdge e) {
      if (_activeBlocks.isEmpty || e.to == goalId) return false;
      return blockedEdgeCache[e.idx] ??= () {
        List<RoutePoint> line;
        if (e.from == startId) {
          final c = startSnap.candidates.firstWhere(
            (x) => x.edge.to == e.to && x.edge.wayId == e.wayId,
            orElse: () => startSnap.candidates.first,
          );
          line = subPolyline(physicalEdgeGeometry(c.edge), c.t, 1.0);
        } else {
          line = physicalEdgeGeometry(e);
        }
        if (line.length < 2) {
          final a = nodeOrNull(e.from), b = nodeOrNull(e.to);
          if (a == null || b == null) return false;
          line = <RoutePoint>[a, b];
        }
        for (final blk in _activeBlocks) {
          if (blk.overlapM(line) >= _blockMinOverlapM) return true;
        }
        return false;
      }();
    }

    // Search tiers, cheapest first. pruneTier: 2 = drop every minor class away from the
    // endpoints, 1 = drop only service/track/path-like ways, 0 = full network.
    // Fallback tiers on long trips use a greedier heuristic so a route is found quickly
    // instead of exhausting the whole network until the time budget runs out.
    const tiers = <({int prune, bool banU, bool restr, double greed})>[
      (prune: 3, banU: true, restr: true, greed: 1.0),
      (prune: 2, banU: true, restr: true, greed: 1.0),
      (prune: 1, banU: true, restr: true, greed: 1.0),
      (prune: 0, banU: true, restr: true, greed: 1.5),
      (prune: 0, banU: false, restr: true, greed: 1.5),
      (prune: 0, banU: false, restr: false, greed: 1.5),
    ];
    final longTrip = directMeters > 40000;
    final veryLongTrip = directMeters > 60000;
    var level = 0;
    for (; level < tiers.length && goalKey == null; level++) {
      final tier = tiers[level];
      if (!pruneMinor && tier.prune > 0) continue;
      if (tier.prune == 3 && !veryLongTrip) continue;
      if (clock.elapsedMilliseconds > budgetMs) {
        timedOut = true;
        break;
      }
      // Each pruned tier gets a slice so one slow tier cannot starve the fallbacks.
      final levelDeadline = tier.prune > 0
          ? math.min(
              budgetMs,
              clock.elapsedMilliseconds +
                  (longTrip
                      ? (tier.prune == 3 ? 10000 : 12000)
                      : (tier.prune == 2 ? 25000 : 20000)))
          : budgetMs;
      final levelHWeight = (longTrip && tier.greed > 1.0 && _activeRouteMode != 1)
          ? math.max(hWeight, tier.greed * 1.35)
          : hWeight;
      curHWeight = levelHWeight;
      hCache.clear();
      cost = <int, double>{};
      prevState = <int, int?>{};
      stateEdge = <int, _DbRouteEdge>{};
      final open = _MinHeap<_EdgeStateItem>((a, b) => a.priority.compareTo(b.priority));
      final pruneTier = tier.prune;
      final banUTurn = tier.banU;
      final useRestrictions = tier.restr;

      void push(_DbRouteEdge e, int? fromKey, double g0, [double extra = 0]) {
        final k = e.idx;
        final pen = wayPenalty == null ? 1.0 : (wayPenalty[e.wayId] ?? 1.0);
        final g = g0 + extra + _edgeRouteCost(e) * pen;
        if (g < (cost[k] ?? double.infinity)) {
          cost[k] = g;
          prevState[k] = fromKey;
          stateEdge[k] = e;
          open.add(_EdgeStateItem(k, e, g, g + heuristic(e.to)));
        }
      }

      for (final e in adjacency[startId] ?? const <_DbRouteEdge>[]) {
        if (edgeBlocked(e)) continue;
        push(e, null, 0);
      }
      var tick = 0;
      while (open.isNotEmpty) {
        if ((++tick & 511) == 0 && clock.elapsedMilliseconds > levelDeadline) {
          anyLevelTimedOut = true;
          if (levelDeadline >= budgetMs) timedOut = true;
          break;
        }
        final item = open.removeFirst();
        if (item.g > (cost[item.key] ?? double.infinity)) continue;
        expandedStates++;
        final inc = item.edge;
        if (inc.to == goalId) {
          goalKey = item.key;
          break;
        }
        final goalExtra = goalIn[inc.to];
        final base = outgoing(inc.to);
        var hasAlt = false;
        for (final x in base) {
          if (x.to != inc.from) { hasAlt = true; break; }
        }
        if (!hasAlt && goalExtra != null) {
          for (final x in goalExtra) {
            if (x.to != inc.from) { hasAlt = true; break; }
          }
        }
        void relax(_DbRouteEdge n) {
          if (edgeBlocked(n)) return;
          if (useRestrictions && !turnAllowed(inc.wayId, inc.to, n.wayId)) return;
          if (banUTurn && n.to == inc.from && hasAlt) return;
          if (pruneTier > 0 && n.to >= 0 &&
              (pruneTier == 3
                  ? isLocalWay(n)
                  : pruneTier == 2
                      ? isMinorWay(n)
                      : isVeryMinorWay(n)) &&
              !nearEndpoints(n.to) && !nearEndpoints(n.from)) return;
          push(n, item.key, item.g, _turnPenalty(inc, n));
        }
        for (final n in base) {
          relax(n);
        }
        if (goalExtra != null) {
          for (final n in goalExtra) {
            relax(n);
          }
        }
      }
    }

    if (goalKey == null && (timedOut || anyLevelTimedOut)) {
      return AbmRouteResult(points: const [], edges: const [], diagnostics: <String>[
        'MODERN GRAPH: search timed out after ${clock.elapsedMilliseconds}ms '
            '(states=$expandedStates nodes=${expanded.length})',
      ]);
    }

    if (goalKey == null) {
      return AbmRouteResult(points: const [], edges: const [], diagnostics: const ['MODERN GRAPH: route not found']);
    }

    final pathEdges = <_DbRouteEdge>[];
    int? walk = goalKey;
    while (walk != null) {
      pathEdges.add(stateEdge[walk]!);
      walk = prevState[walk];
    }
    final pathReversed = pathEdges.reversed.toList();
    pathEdges
      ..clear()
      ..addAll(pathReversed);
    final orderedIds = <int>[startId, ...pathEdges.map((e) => e.to)];

    final points = <RoutePoint>[startSnap.point];
    for (var i = 1; i < orderedIds.length; i++) {
      final _DbRouteEdge? edge = pathEdges[i - 1];
      if (edge == null) continue;
      List<RoutePoint> shape;
      if (edge.from == startId && edge.to == goalId) {
        _ModernSnap? match;
        _ModernSnap? goalMatch;
        for (final s in startSnap.candidates) {
          for (final g in goalSnap.candidates) {
            if (s.edge.from == g.edge.from && s.edge.to == g.edge.to &&
                s.edge.wayId == g.edge.wayId && g.t >= s.t) {
              match = s;
              goalMatch = g;
              break;
            }
          }
          if (match != null) break;
        }
        if (match != null && goalMatch != null) {
          shape = subPolyline(physicalEdgeGeometry(match.edge), match.t, goalMatch.t);
        } else {
          shape = const <RoutePoint>[];
        }
      } else if (edge.from == startId) {
        final c = startSnap.candidates.firstWhere(
          (x) => x.edge.to == edge.to && x.edge.wayId == edge.wayId,
          orElse: () => startSnap.candidates.first,
        );
        shape = subPolyline(physicalEdgeGeometry(c.edge), c.t, 1.0);
      } else if (edge.to == goalId) {
        final c = goalSnap.candidates.firstWhere(
          (x) => x.edge.from == edge.from && x.edge.wayId == edge.wayId,
          orElse: () => goalSnap.candidates.first,
        );
        shape = subPolyline(physicalEdgeGeometry(c.edge), 0.0, c.t);
      } else {
        shape = physicalEdgeGeometry(edge);
      }
      for (final p in shape) {
        if (_distance(points.last, p) > 0.05) points.add(p);
      }
    }
    if (_distance(points.last, goalSnap.point) > 0.05) points.add(goalSnap.point);

    final edges = <RouteEdgeInfo>[];
    final fromIds = <int>[];
    final toIds = <int>[];
    // Lane arrows are optional: older map files have no turn_lanes columns.
    final laneCache = <int, List<String>>{};
    List<String> wayLanes(int wayId) {
      final c = laneCache[wayId];
      if (c != null) return c;
      var res = const <String>['', ''];
      for (final d in dbs) {
        try {
          final r = d.select('SELECT turn_lanes, turn_lanes_bwd FROM way_data WHERE way_id=?', [wayId]);
          if (r.isNotEmpty) {
            res = ['${r.first['turn_lanes'] ?? ''}', '${r.first['turn_lanes_bwd'] ?? ''}'];
            break;
          }
        } catch (_) {
          break;
        }
      }
      return laneCache[wayId] = res;
    }
    final bridgeCache = <int, bool>{};
    bool bridgeFor(int wayId) {
      final c = bridgeCache[wayId];
      if (c != null) return c;
      var res = false;
      for (final d in dbs) {
        try {
          final r = d.select('SELECT flags FROM way_data WHERE way_id=?', [wayId]);
          if (r.isNotEmpty) {
            res = ((r.first['flags'] as num?)?.toInt() ?? 0) & 1 == 1;
            break;
          }
        } catch (_) {
          break;
        }
      }
      return bridgeCache[wayId] = res;
    }
    String lanesFor(_DbRouteEdge e) {
      final l = wayLanes(e.wayId);
      if (l[0].isEmpty && l[1].isEmpty) return '';
      if (e.oneway || l[1].isEmpty) return l[0];
      var forward = true;
      for (final d in dbs) {
        try {
          forward = d.select('SELECT 1 FROM segments WHERE way_id=? AND a=? AND b=? LIMIT 1',
              [e.wayId, e.from, e.to]).isNotEmpty;
          break;
        } catch (_) {
          break;
        }
      }
      return forward ? l[0] : l[1];
    }
    for (var i = 1; i < orderedIds.length; i++) {
      final _DbRouteEdge? edge = pathEdges[i - 1];
      if (edge == null) continue;
      final from = node(edge.from);
      final to = node(edge.to);
      if (_distance(from, to) < 0.3) continue;
      edges.add(RouteEdgeInfo(
        from: from, to: to, roadClass: edge.roadClass, name: edge.name,
        junction: edge.junction, wayId: edge.wayId, speedKmh: edge.speedKmh,
        turnLanes: lanesFor(edge),
        isBridge: bridgeFor(edge.wayId),
      ));
      fromIds.add(edge.from);
      toIds.add(edge.to);
    }
    if (points.length < 2) {
      return AbmRouteResult(points: const [], edges: const [], diagnostics: const ['MODERN GRAPH: route geometry has fewer than two physical points']);
    }

    double bearing(RoutePoint a, RoutePoint b) {
      final lat1 = a.lat * math.pi / 180, lat2 = b.lat * math.pi / 180;
      final dl = (b.lon - a.lon) * math.pi / 180;
      final y = math.sin(dl) * math.cos(lat2);
      final x = math.cos(lat1) * math.sin(lat2) - math.sin(lat1) * math.cos(lat2) * math.cos(dl);
      return (math.atan2(y, x) * 180 / math.pi + 360) % 360;
    }

    for (var i = 0; i < edges.length;) {
      if (!isRoundabout(edges[i].junction)) { i++; continue; }
      final begin = i;
      while (i < edges.length && isRoundabout(edges[i].junction)) i++;
      final end = i;

      final ringIds = <int>{};
      for (var k = begin; k < end; k++) {
        if (fromIds[k] >= 0) ringIds.add(fromIds[k]);
        if (toIds[k] >= 0) ringIds.add(toIds[k]);
      }

      RoutePoint? ringCenter;
      {
        var la = 0.0, lo = 0.0, cn = 0;
        for (final id in ringIds) {
          final p = nodeOrNull(id);
          if (p == null) continue;
          la += p.lat; lo += p.lon; cn++;
        }
        if (cn > 0) ringCenter = RoutePoint(la / cn, lo / cn);
      }

      final branchByAngle = <double, RoundaboutBranchInfo>{};
      void addBranch(double angle, {required bool canEnter, required bool canExit}) {
        final a = (angle % 360 + 360) % 360;
        double? key;
        for (final k in branchByAngle.keys) {
          var d = (k - a).abs();
          if (d > 180) d = 360 - d;
          if (d <= 16) { key = k; break; }
        }
        if (key == null) {
          branchByAngle[a] = RoundaboutBranchInfo(angleDegrees: a, canEnter: canEnter, canExit: canExit);
        } else {
          final old = branchByAngle[key]!;
          branchByAngle[key] = RoundaboutBranchInfo(
            angleDegrees: old.angleDegrees,
            canEnter: old.canEnter || canEnter,
            canExit: old.canExit || canExit,
          );
        }
      }

      for (final nodeId in ringIds) {
        final center = nodeOrNull(nodeId);
        if (center == null) continue;
        for (final e in outgoing(nodeId)) {
          if (isRoundabout(e.junction)) continue;
          final other = nodeOrNull(e.to);
          if (other == null) continue;
          addBranch(bearing(ringCenter ?? center, other), canEnter: false, canExit: true);
        }
        try {
          final rows = <Row>[
            for (final d in dbs)
              ...d.select(
                'SELECT e.start,w.junction FROM edges e JOIN way_data w ON w.way_id=e.way_id WHERE e."end"=?',
                [nodeId],
              ),
          ];
          for (final r in rows) {
            if (isRoundabout('${r['junction'] ?? ''}')) continue;
            final other = nodeOrNull((r['start'] as num).toInt());
            if (other == null) continue;
            addBranch(bearing(ringCenter ?? center, other), canEnter: true, canExit: false);
          }
        } catch (_) {}
      }

      final branches = branchByAngle.values.toList()
        ..sort((a, b) => a.angleDegrees.compareTo(b.angleDegrees));
      double? entrance;
      if (begin > 0) entrance = bearing(ringCenter ?? edges[begin].from, edges[begin - 1].from);
      final entranceAngles = branches.where((b) => b.canEnter).map((b) => b.angleDegrees).toList(growable: false);
      final exitAngles = branches.where((b) => b.canExit).map((b) => b.angleDegrees).toList(growable: false);
      double? activeExitAngle;
      if (end < edges.length) activeExitAngle = bearing(ringCenter ?? edges[end - 1].to, edges[end].to);

      final exitBranches = branches.where((b) => b.canExit).toList();
      final usableExitBranches = entrance == null
          ? exitBranches
          : exitBranches.where((b) {
              var d = (b.angleDegrees - entrance!).abs();
              if (d > 180) d = 360 - d;
              return d > 16;
            }).toList();

      int exitNumber = 0;
      if (activeExitAngle != null && usableExitBranches.isNotEmpty && entrance != null) {
        // Single-edge ring: direction unknown from geometry -> use traffic side.
        final ccwDefault = _activeLeftHandTraffic;
        final routeClockwise = (() {
          if (end - begin >= 2) {
            final a = bearing(edges[begin].from, edges[begin].to);
            final b = bearing(edges[begin + 1].from, edges[begin + 1].to);
            final d = (b - a + 360) % 360;
            return d > 0 && d < 180;
          }
          return ccwDefault;
        })();
        double delta(double from, double to) =>
            routeClockwise ? (to - from + 360) % 360 : (from - to + 360) % 360;
        final ordered = usableExitBranches
            .where((b) => delta(entrance!, b.angleDegrees) > 5)
            .toList()
          ..sort((a, b) => delta(entrance!, a.angleDegrees).compareTo(delta(entrance!, b.angleDegrees)));
        for (var n = 0; n < ordered.length; n++) {
          var d = (ordered[n].angleDegrees - activeExitAngle).abs();
          if (d > 180) d = 360 - d;
          if (d <= 16) { exitNumber = n + 1; break; }
        }
      }
      if (exitNumber == 0 && activeExitAngle != null) exitNumber = 1;

      for (var n = begin; n < end; n++) {
        final old = edges[n];
        edges[n] = RouteEdgeInfo(
          from: old.from, to: old.to, roadClass: old.roadClass, name: old.name,
          junction: old.junction, wayId: old.wayId, speedKmh: old.speedKmh,
          roundaboutExitNumber: exitNumber == 0 ? null : exitNumber,
          roundaboutExitCount: usableExitBranches.length,
          roundaboutBranches: branches,
          roundaboutEntranceAngles: entranceAngles,
          roundaboutExitAngles: exitAngles,
          roundaboutActiveEntranceAngle: entrance,
          roundaboutActiveExitAngle: activeExitAngle,
        );
      }
    }

    return AbmRouteResult(
      points: points,
      edges: edges,
      diagnostics: [
        'GEOMETRY FALLBACK edges=${geometryFallbackEdges.length}',
        'ABM v6 GRAPH: nodes=${adjacency.length} expanded=${expanded.length} states=$expandedStates '
            'level=${level - 1} ms=${clock.elapsedMilliseconds} maxSpeed=${maxSpeed.toStringAsFixed(0)} spatial=node_index '
            'startSnap=${startSnap.distance.toStringAsFixed(1)}m goalSnap=${goalSnap.distance.toStringAsFixed(1)}m',
      ],
    );
  }

  static AbmRouteResult? _routeSqliteDetailed(
    String path,
    RoutePoint origin,
    RoutePoint destination,
    bool avoidUnpavedRoads,
    bool avoidTolls,
    bool avoidTrafficZones,
    bool avoidHighways, [
    Map<int, double>? wayPenalty,
    List<String> extraPaths = const <String>[],
  ]) {
    final db = sqlite3.open(path, mode: OpenMode.readOnly);
    final extraDbs = <Database>[];
    try {
      try {
        db.execute('PRAGMA query_only=ON');
        db.execute('PRAGMA temp_store=FILE');
        db.execute('PRAGMA cache_size=-65536');
        db.execute('PRAGMA mmap_size=268435456');
      } catch (_) {}
      final modernSchema = db.select(
        "SELECT name FROM sqlite_master WHERE type IN ('table','view') AND name IN ('nodes','edges','node_index','way_data','segments')"
      ).map((r) => '${r['name']}').toSet();
      if (modernSchema.containsAll({'nodes','edges','node_index','way_data','segments'})) {
        // Neighbouring province maps share OSM node/way ids, so they are searched
        // together as one graph (border nodes connect the maps).
        for (final extra in extraPaths) {
          if (extra == path) continue;
          try {
            final d = sqlite3.open(extra, mode: OpenMode.readOnly);
            try {
              d.execute('PRAGMA query_only=ON');
              d.execute('PRAGMA temp_store=FILE');
              d.execute('PRAGMA cache_size=-16384');
              d.execute('PRAGMA mmap_size=134217728');
            } catch (_) {}
            final names = d.select(
              "SELECT name FROM sqlite_master WHERE type IN ('table','view') AND name IN ('nodes','edges','node_index','way_data','segments')"
            ).map((r) => '${r['name']}').toSet();
            if (names.containsAll({'nodes','edges','node_index','way_data','segments'})) {
              extraDbs.add(d);
            } else {
              d.dispose();
            }
          } catch (_) {}
        }
        return _routeModernSqliteDetailed(
          <Database>[db, ...extraDbs], origin, destination, avoidUnpavedRoads, avoidTolls, avoidTrafficZones, avoidHighways,
          wayPenalty,
        );
      }
      RoutePoint pointFor(int id) {
        final r = db.select('SELECT lat_e7,lon_e7 FROM node_data WHERE id=?', [id]);
        if (r.isEmpty) throw StateError('Missing routing node $id');
        return RoutePoint(
          (r.first['lat_e7'] as num).toDouble() * 1e-7,
          (r.first['lon_e7'] as num).toDouble() * 1e-7,
        );
      }

      final nodeCache = LinkedHashMap<int, RoutePoint>();
      RoutePoint? node(int id) {
        final cached = nodeCache.remove(id);
        if (cached != null) {
          nodeCache[id] = cached;
          return cached;
        }
        try {
          final p = pointFor(id);
          nodeCache[id] = p;
          if (nodeCache.length > 8192) nodeCache.remove(nodeCache.keys.first);
          return p;
        } catch (_) {
          return null;
        }
      }

      _SqliteSnap? snap(RoutePoint p) {
        if (!p.lat.isFinite || !p.lon.isFinite || p.lat < -90 || p.lat > 90 || p.lon < -180 || p.lon > 180) return null;
        final cosLat = math.cos(p.lat * math.pi / 180).abs().clamp(0.2, 1.0);
        _SqliteSnap? best;
        var bestMeters = double.infinity;
        for (final radius in const [0.005, 0.01, 0.03, 0.08, 0.2, 0.5, 1.0]) {
          final lonRadius = radius / cosLat;
          var rows = db.select(
            'SELECT s.a,s.b,s.dist_dm,w.way_id,w.oneway,COALESCE(w.junction,\'\') AS junction,na.lat_e7 alat,na.lon_e7 alon,nb.lat_e7 blat,nb.lon_e7 blon '
            'FROM road_index r JOIN segments s ON s.id BETWEEN r.seg_from AND r.seg_to '
            'JOIN way_data w ON w.way_id=s.way_id JOIN node_data na ON na.id=s.a JOIN node_data nb ON nb.id=s.b '
            'WHERE r.max_lat>=? AND r.min_lat<=? AND r.max_lon>=? AND r.min_lon<=? LIMIT 5000',
            [p.lat + radius, p.lat - radius, p.lon + lonRadius, p.lon - lonRadius],
          );

          for (final r in rows) {
            final a = RoutePoint((r['alat'] as num).toDouble() * 1e-7, (r['alon'] as num).toDouble() * 1e-7);
            final b = RoutePoint((r['blat'] as num).toDouble() * 1e-7, (r['blon'] as num).toDouble() * 1e-7);
            final latScale = 111320.0;
            final lonScale = 111320.0 * math.cos(p.lat * math.pi / 180).abs().clamp(0.2, 1.0);
            final ax = (a.lon - p.lon) * lonScale, ay = (a.lat - p.lat) * latScale;
            final bx = (b.lon - p.lon) * lonScale, by = (b.lat - p.lat) * latScale;
            final dx = bx - ax, dy = by - ay;
            final len2 = dx * dx + dy * dy;
            final t = len2 <= 1e-9 ? 0.0 : (-(ax * dx + ay * dy) / len2).clamp(0.0, 1.0);
            final px = ax + dx * t, py = ay + dy * t;
            final d = math.sqrt(px * px + py * py);
            if (d >= bestMeters) continue;
            final segmentMeters = ((r['dist_dm'] as num?)?.toDouble() ?? _distance(a, b) * 10.0) / 10.0;
            final wayId = (r['way_id'] as num).toInt();
            final onewayMode = _effectiveOneway(_parseOnewayMode(r['oneway']), r['junction']);
            bestMeters = d;
            best = _SqliteSnap(
              a: (r['a'] as num).toInt(), b: (r['b'] as num).toInt(), t: t,
              point: RoutePoint(p.lat + py / latScale, p.lon + px / lonScale),
              segmentMeters: segmentMeters, onewayMode: onewayMode, wayId: wayId,
            );
          }
          if (best != null && bestMeters <= radius * 111500.0) break;
        }
        return best;
      }
      final startSnap = snap(origin);
      final goalSnap = snap(destination);
      if (startSnap == null || goalSnap == null) {
        return AbmRouteResult(points: const [], edges: const [], diagnostics: const []);
      }

      const start = -1;
      const goal = -2;
      final virtualPoints = <int, RoutePoint>{start: startSnap.point, goal: goalSnap.point};
      final adjacency = LinkedHashMap<int, List<_DbRouteEdge>>();
      void add(_DbRouteEdge e) => (adjacency[e.from] ??= <_DbRouteEdge>[]).add(e);
      void boundAdjacencyCache() {
        while (adjacency.length > 4096) {
          final candidate = adjacency.keys.firstWhere(
            (id) => id >= 0,
            orElse: () => adjacency.keys.first,
          );
          adjacency.remove(candidate);
        }
      }

      bool allowed(String road, String access, String surface) {
        if (avoidTrafficZones && access.contains('private')) return false;
        if (avoidHighways && (road.startsWith('motorway') || road.startsWith('trunk'))) return false;
        if (avoidTolls && road.contains('toll')) return false;
        if (avoidUnpavedRoads && surface.isNotEmpty && surface != 'paved' && surface != 'asphalt') return false;
        return true;
      }
      _DbRouteEdge fromRow(Map r, {required int from, required int to, required double distance}) {
        return _DbRouteEdge(
          from: from, to: to, distanceM: distance,
          speedKmh: ((r['speed_kmh'] as num?)?.toDouble() ?? 30).clamp(5, 160).toDouble(),
          wayId: (r['way_id'] as num).toInt(), onewayMode: _parseOnewayMode(r['oneway']),
          roadClass: '${r['road_class'] ?? ''}', name: '${r['name'] ?? ''}', junction: '${r['junction'] ?? ''}',
        );
      }

      bool toleranceZero(double v) => v.abs() < 1e-7;
      void addSegmentMoves(_SqliteSnap s, {required int virtual, required bool fromVirtual}) {
        final r = db.select(
          "SELECT c.name AS road_class, "
          "COALESCE(NULLIF(n.name_fa,''), NULLIF(n.name,''), NULLIF(n.name_en,''), '') AS name, "
          "COALESCE(w.junction,'') AS junction, w.speed_kmh, w.oneway, "
          "COALESCE(w.access,'') AS access, COALESCE(w.surface,'') AS surface, w.way_id "
          'FROM way_data w JOIN categories c ON c.id = w.class_id '
          'LEFT JOIN names n ON n.id = w.name_id '
          'WHERE w.way_id=? LIMIT 1', [s.wayId],
        );
        if (r.isEmpty) return;
        final row = r.first;
        if (!allowed('${r.first['road_class'] ?? ''}'.toLowerCase(), '${r.first['access'] ?? ''}'.toLowerCase(), '${r.first['surface'] ?? ''}'.toLowerCase())) return;
        final aDist = s.segmentMeters * s.t;
        final bDist = s.segmentMeters * (1.0 - s.t);
        if (fromVirtual) {
          if (s.onewayMode == 1) {
            add(fromRow(row, from: virtual, to: s.b, distance: bDist));
          } else if (s.onewayMode == -1) {
            add(fromRow(row, from: virtual, to: s.a, distance: aDist));
          } else {
            add(fromRow(row, from: virtual, to: s.a, distance: aDist));
            add(fromRow(row, from: virtual, to: s.b, distance: bDist));
          }
        } else {
          if (s.onewayMode == 1) {
            add(fromRow(row, from: s.a, to: virtual, distance: aDist));
          } else if (s.onewayMode == -1) {
            add(fromRow(row, from: s.b, to: virtual, distance: bDist));
          } else {
            add(fromRow(row, from: s.a, to: virtual, distance: aDist));
            add(fromRow(row, from: s.b, to: virtual, distance: bDist));
          }
        }
      }
      addSegmentMoves(startSnap, virtual: start, fromVirtual: true);
      addSegmentMoves(goalSnap, virtual: goal, fromVirtual: false);

      void expandNode(int id) {
        if (id < 0) return;
        final cached = adjacency.remove(id);
        if (cached != null) {
          adjacency[id] = cached;
          return;
        }
        final p = node(id);
        if (p == null) return;
        final rows = db.select(
          'SELECT e.start,e.end,e.distance_m,e.speed_kmh,e.way_id,e.oneway,w.junction,'
          'EXISTS(SELECT 1 FROM segments sf WHERE sf.way_id=e.way_id AND sf.a=e.start AND sf.b=e.end) AS fwd,'
          'w.access,w.surface,c.name AS road_class '
          'FROM edges e JOIN way_data w ON w.way_id=e.way_id '
          'JOIN categories c ON c.id=w.class_id '
          'WHERE (e.start=? OR e.end=?) '
          'AND EXISTS ('
          'SELECT 1 FROM segments s WHERE s.way_id=e.way_id '
          'AND ((s.a=e.start AND s.b=e.end) OR (s.a=e.end AND s.b=e.start))'
          ')',
          [id, id],
        );
        final list = adjacency[id] ??= <_DbRouteEdge>[];
        for (final r in rows) {
          final storedStart = (r['start'] as num).toInt();
          final storedEnd = (r['end'] as num).toInt();
          final onewayMode = _effectiveOneway(_parseOnewayMode(r['oneway']), r['junction']);
          if (onewayMode == 1 && ((r['fwd'] as num?)?.toInt() ?? 1) == 0) continue;
          final road = '${r['road_class'] ?? ''}'.toLowerCase();
          final access = '${r['access'] ?? ''}'.toLowerCase();
          final surface = '${r['surface'] ?? ''}'.toLowerCase();
          if (!allowed(road, access, surface)) continue;
          final dist = (r['distance_m'] as num).toDouble();
          final speed = ((r['speed_kmh'] as num?)?.toDouble() ?? 30).clamp(5, 160).toDouble();
          final way = (r['way_id'] as num).toInt();
          if (storedStart == id) {
            list.add(_DbRouteEdge(
              from: id, to: storedEnd, distanceM: dist, speedKmh: speed,
              wayId: way, onewayMode: onewayMode,
              roadClass: '${r['road_class'] ?? ''}', name: '', junction: '',
            ));
          } else if (storedEnd == id && onewayMode == 0) {
            list.add(_DbRouteEdge(
              from: id, to: storedStart, distanceM: dist, speedKmh: speed,
              wayId: way, onewayMode: onewayMode,
              roadClass: '${r['road_class'] ?? ''}', name: '', junction: '',
            ));
          }
        }
        boundAdjacencyCache();
      }

      final hasIndexedRestrictions = db.select(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='turn_restriction_lookup' LIMIT 1",
      ).isNotEmpty;
      final turnRuleCache = <String, _TurnRule>{};
      final legacyNoTurns = <String>{};
      final legacyOnlyTurns = <String, int>{};
      if (!hasIndexedRestrictions) {
        try {
          final rows = db.select('SELECT restriction,from_json,via_json,to_json FROM turn_restrictions');
          for (final r in rows) {
            final type='${r['restriction'] ?? ''}'.toLowerCase();
            List<int> ids(dynamic v){ try { final x=jsonDecode('${v ?? '[]'}'); return x is List ? x.whereType<num>().map((n)=>n.toInt()).toList() : const []; } catch(_){ return const []; } }
            for(final fw in ids(r['from_json'])) for(final vn in ids(r['via_json'])) for(final tw in ids(r['to_json'])) {
              if(type.startsWith('only')) legacyOnlyTurns['$fw|$vn']=tw; else legacyNoTurns.add('$fw|$vn|$tw');
            }
          }
        } catch (_) {}
      }
      _TurnRule ruleFor(int incomingWay, int viaNode) {
        final key = '$incomingWay|$viaNode';
        final cached = turnRuleCache[key];
        if (cached != null) return cached;
        final no = <int>{};
        final only = <int>{};
        if (hasIndexedRestrictions) {
          try {
            final rows = db.select(
              'SELECT restriction,to_way FROM turn_restriction_lookup WHERE from_way=? AND via_node=?',
              [incomingWay, viaNode],
            );
            for (final row in rows) {
              final toWay = (row['to_way'] as num).toInt();
              if ('${row['restriction'] ?? ''}'.toLowerCase().startsWith('only')) {
                only.add(toWay);
              } else {
                no.add(toWay);
              }
            }
          } catch (_) {}
        }
        final rule = _TurnRule(no: no, only: only);
        turnRuleCache[key] = rule;
        return rule;
      }
      bool turnAllowed(int incomingWay,int viaNode,int outgoingWay){
        if (!hasIndexedRestrictions) {
          final only=legacyOnlyTurns['$incomingWay|$viaNode'];
          if(only!=null && only!=outgoingWay) return false;
          return !legacyNoTurns.contains('$incomingWay|$viaNode|$outgoingWay');
        }
        final rule = ruleFor(incomingWay, viaNode);
        if (rule.only.isNotEmpty && !rule.only.contains(outgoingWay)) return false;
        return !rule.no.contains(outgoingWay);
      }

      const noWay = -999999999;
      String stateKey(int n,int w)=>'$n|$w';
      final startKey=stateKey(start,noWay);
      final distance=<String,double>{startKey:0};
      final previous=<String,String?>{startKey:null};
      final previousEdge=<String,_DbRouteEdge>{};
      final open=_MinHeap<_TurnQueueItem>((a,b)=>a.priority.compareTo(b.priority));
      open.add(_TurnQueueItem(start,noWay,0,_distance(startSnap.point,destination)/160.0*3.6));
      String? goalState;
      while(open.isNotEmpty){
        final item=open.removeFirst();
        final key=stateKey(item.node,item.way);
        if(item.cost>(distance[key]??double.infinity))continue;
        if(item.node==goal){goalState=key;break;}
        expandNode(item.node);
        for(final e in adjacency[item.node]??const <_DbRouteEdge>[]){
          if(item.way!=noWay && !turnAllowed(item.way,item.node,e.wayId))continue;
          final next=item.cost+e.distanceM/e.speedKmh*3.6;
          final nk=stateKey(e.to,e.wayId);
          if(next<(distance[nk]??double.infinity)){
            distance[nk]=next; previous[nk]=key; previousEdge[nk]=e;
            final target=e.to==goal?goalSnap.point:(node(e.to)??destination);
            final h=_distance(target,destination)/160.0*3.6;
            open.add(_TurnQueueItem(e.to,e.wayId,next,next+h));
          }
        }
      }
      if(goalState==null){
        return AbmRouteResult(points: const [], edges: const [], diagnostics: const []);
      }
      var states=<String>[]; String? cur=goalState;
      while(cur!=null){states.add(cur);cur=previous[cur];}
      states = states.reversed.toList();
      final routeWayIds = <int>{};
      for (var i = 1; i < states.length; i++) {
        final e = previousEdge[states[i]];
        if (e != null) routeWayIds.add(e.wayId);
      }
      final wayMeta = <int, Map<String, dynamic>>{};
      final ids = routeWayIds.toList(growable: false);
      for (var offset = 0; offset < ids.length; offset += 400) {
        final end = offset + 400 < ids.length ? offset + 400 : ids.length;
        final batch = ids.sublist(offset, end);
        if (batch.isEmpty) continue;
        final marks = List.filled(batch.length, '?').join(',');
        final rows = db.select(
          'SELECT w.way_id,c.name AS road_class,'
          "COALESCE(NULLIF(n.name_fa,''),NULLIF(n.name,''),NULLIF(n.name_en,''),'') AS name,"
          "COALESCE(w.junction,'') AS junction "
          'FROM way_data w JOIN categories c ON c.id=w.class_id '
          'LEFT JOIN names n ON n.id=w.name_id '
          'WHERE w.way_id IN ($marks)',
          batch,
        );
        for (final row in rows) {
          wayMeta[(row['way_id'] as num).toInt()] = row;
        }
      }

      final legacyWayGeometryCache=<int,List<RoutePoint>>{};
      List<RoutePoint> legacyWayGeometry(int wayId){
        final cached=legacyWayGeometryCache[wayId];
        if(cached!=null)return cached;
        try{
          final rows=db.select('SELECT geometry FROM way_geometry WHERE way_id=? LIMIT 1',[wayId]);
          if(rows.isEmpty){legacyWayGeometryCache[wayId]=const <RoutePoint>[];return const <RoutePoint>[];}
          final decoded=_decodeAbmWayGeometry(rows.first['geometry']);
          legacyWayGeometryCache[wayId]=decoded;
          return decoded;
        }catch(_){
          legacyWayGeometryCache[wayId]=const <RoutePoint>[];
          return const <RoutePoint>[];
        }
      }
      List<RoutePoint> legacyPhysicalGeometry(_DbRouteEdge e){
        if(e.from==start){
          final to=node(e.to);
          return to==null?const <RoutePoint>[]:[startSnap.point,to];
        }
        if(e.to==goal){
          final from=node(e.from);
          return from==null?const <RoutePoint>[]:[from,goalSnap.point];
        }
        final from=node(e.from),to=node(e.to);
        if(from==null||to==null)return const <RoutePoint>[];
        final geom=legacyWayGeometry(e.wayId);
        if(geom.length<2)return const <RoutePoint>[];
        int nearest(RoutePoint target){
          var best=0,bestD=double.infinity;
          for(var j=0;j<geom.length;j++){final d=_distance(target,geom[j]);if(d<bestD){bestD=d;best=j;}}
          return best;
        }
        final ia=nearest(from),ib=nearest(to);
        final ring=_closedRingSlice(geom,[ia],[ib],from,to,e.distanceM);
        if(ring!=null)return ring.points;
        if(_distance(from,geom[ia])>25.0||_distance(to,geom[ib])>25.0||ia==ib)return const <RoutePoint>[];
        if(ia<ib)return geom.sublist(ia,ib+1);
        return geom.sublist(ib,ia+1).reversed.toList(growable:false);
      }

      final points=<RoutePoint>[startSnap.point];
      final edges=<RouteEdgeInfo>[];
      for(var i=1;i<states.length;i++){
        final e=previousEdge[states[i]]; if(e==null)continue;
        final from=e.from==start?startSnap.point:(e.from==goal?goalSnap.point:(node(e.from)??destination));
        final to=e.to==goal?goalSnap.point:(e.to==start?startSnap.point:(node(e.to)??destination));
        for(final p in legacyPhysicalGeometry(e)){
          if(_distance(points.last,p)>0.05)points.add(p);
        }
        final meta = wayMeta[e.wayId];
        edges.add(RouteEdgeInfo(
          from: from,
          to: to,
          roadClass: '${meta?['road_class'] ?? e.roadClass}',
          name: '${meta?['name'] ?? e.name}',
          junction: '${meta?['junction'] ?? e.junction}',
          wayId: e.wayId,
          speedKmh: e.speedKmh,
        ));
      }
      if(points.length<2){ return AbmRouteResult(points: const [], edges: const [], diagnostics: const []); }

      for (var i = 0; i < edges.length;) {
        if (edges[i].junction.trim().toLowerCase() != 'roundabout') { i++; continue; }
        final begin = i;
        while (i < edges.length && edges[i].junction.trim().toLowerCase() == 'roundabout') i++;
        final end = i;

        final nodeIds = <int>{};
        for (var k = begin; k < end; k++) {
          nodeIds.add(int.parse(states[k].split('|').first));
          nodeIds.add(int.parse(states[k + 1].split('|').first));
        }

        double bearing(RoutePoint a, RoutePoint b) {
          final lat1 = a.lat * math.pi / 180;
          final lat2 = b.lat * math.pi / 180;
          final dl = (b.lon - a.lon) * math.pi / 180;
          final y = math.sin(dl) * math.cos(lat2);
          final x = math.cos(lat1) * math.sin(lat2) -
              math.sin(lat1) * math.cos(lat2) * math.cos(dl);
          return (math.atan2(y, x) * 180 / math.pi + 360) % 360;
        }

        bool truthy(dynamic value) {
          final x = '$value'.toLowerCase();
          return value == true || value == 1 || x == 'true' || x == 'yes' || x == '1';
        }

        RoutePoint? ringCenter;
        {
          var la = 0.0, lo = 0.0, cn = 0;
          for (final id in nodeIds) {
            final p = node(id);
            if (p == null) continue;
            la += p.lat; lo += p.lon; cn++;
          }
          if (cn > 0) ringCenter = RoutePoint(la / cn, lo / cn);
        }

        final branchByAngle = <double, RoundaboutBranchInfo>{};
        void addBranch(double angle, {required bool canEnter, required bool canExit}) {
          final normalized = (angle % 360 + 360) % 360;
          double? existingKey;
          for (final key in branchByAngle.keys) {
            var d = (key - normalized).abs();
            if (d > 180) d = 360 - d;
            if (d <= 16) { existingKey = key; break; }
          }
          if (existingKey == null) {
            branchByAngle[normalized] = RoundaboutBranchInfo(
              angleDegrees: normalized,
              canEnter: canEnter,
              canExit: canExit,
            );
          } else {
            final old = branchByAngle[existingKey]!;
            branchByAngle[existingKey] = RoundaboutBranchInfo(
              angleDegrees: old.angleDegrees,
              canEnter: old.canEnter || canEnter,
              canExit: old.canExit || canExit,
            );
          }
        }

        for (final nodeId in nodeIds) {
          final center = node(nodeId);
          if (center == null) continue;
          final rows = db.select(
            'SELECT e.start,e.end,e.oneway,e.junction,na.lat_e7 alat,na.lon_e7 alon,nb.lat_e7 blat,nb.lon_e7 blon '
            'FROM edges e JOIN node_data na ON na.id=e.start JOIN node_data nb ON nb.id=e.end '
            'WHERE e.start=? OR e.end=?',
            [nodeId, nodeId],
          );
          for (final r in rows) {
            final junction = '${r['junction'] ?? ''}'.trim().toLowerCase();
            if (junction == 'roundabout') continue;
            final start = (r['start'] as num).toInt();
            final endNode = (r['end'] as num).toInt();
            final otherId = start == nodeId ? endNode : start;
            final other = node(otherId) ?? RoutePoint(
              (r['blat'] as num).toDouble() * 1e-7,
              (r['blon'] as num).toDouble() * 1e-7,
            );
            final angle = bearing(ringCenter ?? center, other);
            final oneway = truthy(r['oneway']);
            final canExit = start == nodeId || !oneway;
            final canEnter = endNode == nodeId || !oneway;
            addBranch(angle, canEnter: canEnter, canExit: canExit);
          }
        }

        final branches = branchByAngle.values.toList()
          ..sort((a, b) => a.angleDegrees.compareTo(b.angleDegrees));
        final routeEntranceAngles = <double>[];
        if (begin > 0) {
          final firstNode = edges[begin].from;
          routeEntranceAngles.add(bearing(ringCenter ?? firstNode, edges[begin - 1].from));
        }
        final entranceAngles = branches
            .where((b) => b.canEnter)
            .map((b) => b.angleDegrees)
            .toList(growable: false);
        final exitAngles = branches
            .where((b) => b.canExit)
            .map((b) => b.angleDegrees)
            .toList(growable: false);
        double? activeExitAngle;
        if (end < edges.length) {
          final lastNode = edges[end - 1].to;
          activeExitAngle = bearing(ringCenter ?? lastNode, edges[end].to);
        }

        final exitBranches = branches.where((b) => b.canExit).toList();
        final entrance = routeEntranceAngles.isEmpty ? null : routeEntranceAngles.first;
        final usableExitBranches = entrance == null
            ? exitBranches
            : exitBranches.where((b) {
                var d = (b.angleDegrees - entrance).abs();
                if (d > 180) d = 360 - d;
                return d > 16;
              }).toList();
        int exitNumber = 0;
        if (activeExitAngle != null && usableExitBranches.isNotEmpty && entrance != null) {
          final routeClockwise = (() {
            if (end - begin >= 2) {
              final a = bearing(edges[begin].from, edges[begin].to);
              final b = bearing(edges[begin + 1].from, edges[begin + 1].to);
              var d = (b - a + 360) % 360;
              return d > 0 && d < 180;
            }
            // Single-edge ring: direction unknown from geometry -> use traffic side.
            return _activeLeftHandTraffic;
          })();
          double delta(double from, double to) => routeClockwise
              ? (to - from + 360) % 360
              : (from - to + 360) % 360;
          final ordered = usableExitBranches
              .where((b) => delta(entrance, b.angleDegrees) > 5)
              .toList()
            ..sort((a, b) => delta(entrance, a.angleDegrees)
                .compareTo(delta(entrance, b.angleDegrees)));
          for (var n = 0; n < ordered.length; n++) {
            var d = (ordered[n].angleDegrees - activeExitAngle).abs();
            if (d > 180) d = 360 - d;
            if (d <= 16) {
              exitNumber = n + 1;
              break;
            }
          }
        }
        if (exitNumber == 0 && activeExitAngle != null) exitNumber = 1;
        final totalExits = usableExitBranches.length;

        for (var n = begin; n < end; n++) {
          final old = edges[n];
          edges[n] = RouteEdgeInfo(
            from: old.from,
            to: old.to,
            roadClass: old.roadClass,
            name: old.name,
            junction: old.junction,
            wayId: old.wayId,
            speedKmh: old.speedKmh,
            roundaboutExitNumber: exitNumber == 0 ? null : exitNumber,
            roundaboutExitCount: totalExits,
            roundaboutBranches: branches,
            roundaboutEntranceAngles: entranceAngles,
            roundaboutExitAngles: exitAngles,
            roundaboutActiveEntranceAngle: entrance,
            roundaboutActiveExitAngle: activeExitAngle,
          );
        }
      }
      return AbmRouteResult(points: points, edges: edges, diagnostics: const []);
    } finally {
      for (final d in extraDbs) {
        try { d.dispose(); } catch (_) {}
      }
      db.dispose();
    }
  }

  static _WayGeometrySlice? _closedRingSlice(
    List<RoutePoint> geom,
    List<int> candA,
    List<int> candB,
    RoutePoint a,
    RoutePoint b,
    double wantMeters,
  ) {
    if (geom.length < 4 || _distance(geom.first, geom.last) > 3.0) return null;
    final m = geom.length - 1; // ring without the duplicated closing vertex
    final cum = List<double>.filled(m, 0.0);
    for (var i = 1; i < m; i++) {
      cum[i] = cum[i - 1] + _distance(geom[i - 1], geom[i]);
    }
    final perimeter = cum[m - 1] + _distance(geom[m - 1], geom[0]);
    if (perimeter < 1.0) return null;
    double fwdLen(int i, int j) =>
        j >= i ? cum[j] - cum[i] : perimeter - (cum[i] - cum[j]);

    final ias = {for (final i in candA) i % m}.toList()..sort();
    final ibs = {for (final i in candB) i % m}.toList()..sort();
    var bestScore = double.infinity;
    var bestI = -1, bestJ = -1;
    var bestForward = true;
    for (final i in ias) {
      for (final j in ibs) {
        if (i == j) continue;
        final endpointError = _distance(a, geom[i]) + _distance(b, geom[j]);
        final f = fwdLen(i, j);
        final bk = perimeter - f;
        for (final forward in const [true, false]) {
          final len = forward ? f : bk;
          final lengthError = wantMeters > 0 ? (len - wantMeters).abs() : 0.0;
          final score = endpointError * 8.0 + lengthError + len * 1e-6;
          if (score < bestScore) {
            bestScore = score;
            bestI = i;
            bestJ = j;
            bestForward = forward;
          }
        }
      }
    }
    if (bestI < 0) return null;
    if (_distance(a, geom[bestI]) > 30.0 || _distance(b, geom[bestJ]) > 30.0) {
      return null;
    }
    final pts = <RoutePoint>[geom[bestI]];
    var k = bestI;
    while (k != bestJ) {
      k = bestForward ? (k + 1) % m : (k - 1 + m) % m;
      pts.add(geom[k]);
    }
    return _WayGeometrySlice(pts, bestForward);
  }

  static double _distance(RoutePoint a, RoutePoint b) {
    const r = 6371008.8;
    final p1 = a.lat * math.pi / 180, p2 = b.lat * math.pi / 180;
    final dp = (b.lat - a.lat) * math.pi / 180, dl = (b.lon - a.lon) * math.pi / 180;
    final h = math.sin(dp/2)*math.sin(dp/2) + math.cos(p1)*math.cos(p2)*math.sin(dl/2)*math.sin(dl/2);
    return r * 2 * math.asin(math.sqrt(h));
  }

  static Future<List<int>> _readSectionWindow(
      RandomAccessFile raf, int start, int length) async {
    await raf.setPosition(start);
    return raf.read(length);
  }

  static Future<void> _scanSection(
    RandomAccessFile raf,
    int jsonStart,
    int jsonLength,
    String section,
    void Function(String? key, dynamic value) onValue,
  ) async {
    final bytes = await _readSectionWindow(raf, jsonStart, jsonLength);
    final marker = utf8.encode('"$section":');
    final sectionOffset = _findBytes(bytes, marker);
    if (sectionOffset < 0) return;
    var i = sectionOffset + marker.length;
    while (i < bytes.length && _isWhitespace(bytes[i])) i++;
    if (i >= bytes.length) return;
    final open = bytes[i];
    final close = open == 0x7B ? 0x7D : (open == 0x5B ? 0x5D : -1);
    if (close < 0) return;
    i++;
    while (i < bytes.length) {
      while (i < bytes.length && (_isWhitespace(bytes[i]) || bytes[i] == 0x2C))
        i++;
      if (i >= bytes.length || bytes[i] == close) break;
      String? key;
      if (open == 0x7B) {
        if (bytes[i] != 0x22) break;
        final keyEnd = _quotedEnd(bytes, i);
        if (keyEnd < 0) break;
        key = utf8.decode(bytes.sublist(i + 1, keyEnd));
        i = keyEnd + 1;
        while (i < bytes.length && _isWhitespace(bytes[i])) i++;
        if (i >= bytes.length || bytes[i] != 0x3A) break;
        i++;
        while (i < bytes.length && _isWhitespace(bytes[i])) i++;
      }
      final end = _jsonValueEnd(bytes, i);
      if (end <= i) break;
      try {
        final value = jsonDecode(utf8.decode(bytes.sublist(i, end)));
        onValue(key, value);
      } catch (_) {
      }
      i = end;
    }
  }

  static int _jsonValueEnd(List<int> b, int start) {
    if (start >= b.length) return start;
    final first = b[start];
    if (first != 0x7B && first != 0x5B && first != 0x22) {
      var i = start;
      while (i < b.length && b[i] != 0x2C && b[i] != 0x7D && b[i] != 0x5D) i++;
      return i;
    }
    if (first == 0x22) {
      final e = _quotedEnd(b, start);
      return e < 0 ? b.length : e + 1;
    }
    final open = first;
    final close = open == 0x7B ? 0x7D : 0x5D;
    var depth = 0;
    var string = false;
    var escaped = false;
    for (var i = start; i < b.length; i++) {
      final c = b[i];
      if (string) {
        if (escaped) {
          escaped = false;
        } else if (c == 0x5C) {
          escaped = true;
        } else if (c == 0x22) {
          string = false;
        }
        continue;
      }
      if (c == 0x22) {
        string = true;
      } else if (c == open) {
        depth++;
      } else if (c == close) {
        depth--;
        if (depth == 0) return i + 1;
      }
    }
    return b.length;
  }

  static int _quotedEnd(List<int> b, int start) {
    var escaped = false;
    for (var i = start + 1; i < b.length; i++) {
      final c = b[i];
      if (escaped) {
        escaped = false;
      } else if (c == 0x5C) {
        escaped = true;
      } else if (c == 0x22) {
        return i;
      }
    }
    return -1;
  }

  static int _findBytes(List<int> data, List<int> needle) {
    if (needle.isEmpty || needle.length > data.length) return -1;
    outer:
    for (var i = 0; i <= data.length - needle.length; i++) {
      for (var j = 0; j < needle.length; j++) {
        if (data[i + j] != needle[j]) continue outer;
      }
      return i;
    }
    return -1;
  }

  static bool _isWhitespace(int c) =>
      c == 0x20 || c == 0x09 || c == 0x0A || c == 0x0D;
  static int _u32(List<int> b, int o) =>
      (b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3];
  static int? _int(dynamic value) =>
      value is num ? value.toInt() : int.tryParse('$value');
  static int _nearest(Map<int, RoutePoint> nodes, RoutePoint p) {
    var id = nodes.keys.first;
    var best = double.infinity;
    for (final e in nodes.entries) {
      final d = _distance(p, e.value);
      if (d < best) {
        best = d;
        id = e.key;
      }
    }
    return id;
  }

}

class _Edge {
  const _Edge(this.to, this.distanceM, this.speedKmh);
  final int to;
  final double distanceM;
  final double speedKmh;
}

class _AStarQueueItem {
  const _AStarQueueItem(this.node, this.g, this.priority);
  final int node;
  final double g;
  final double priority;
}

class _QueueItem {
  const _QueueItem(this.node, this.cost);
  final int node;
  final double cost;
}

class _TurnQueueItem {
  const _TurnQueueItem(this.node, this.way, this.cost, this.priority);
  final int node;
  final int way;
  final double cost;
  final double priority;
}

class _EdgeStateItem {
  const _EdgeStateItem(this.key, this.edge, this.g, this.priority);
  final int key;
  final _DbRouteEdge edge;
  final double g;
  final double priority;
}

class _WayAttr {
  const _WayAttr({
    required this.roadClass,
    required this.speedKmh,
    required this.onewayMode,
    required this.name,
    required this.junction,
    required this.allowed,
    required this.minor,
    this.veryMinor = false,
    this.local = false,
  });
  final String roadClass;
  final double speedKmh;
  final int onewayMode;
  final String name;
  final String junction;

  final bool allowed;

  final bool minor;

  final bool veryMinor;

  /// minor + tertiary + unclassified: dropped first on very long trips.
  final bool local;
}

class _TurnRule {
  const _TurnRule({required this.no, required this.only});
  final Set<int> no;
  final Set<int> only;
}

class _MinHeap<T> {
  _MinHeap(this.compare);
  final int Function(T, T) compare;
  final List<T> _items = <T>[];
  bool get isNotEmpty => _items.isNotEmpty;
  void add(T value) {
    _items.add(value);
    var i = _items.length - 1;
    while (i > 0) {
      final parent = (i - 1) >> 1;
      if (compare(_items[parent], _items[i]) <= 0) break;
      final t = _items[parent];
      _items[parent] = _items[i];
      _items[i] = t;
      i = parent;
    }
  }

  T removeFirst() {
    final first = _items.first;
    final last = _items.removeLast();
    if (_items.isNotEmpty) {
      _items[0] = last;
      var i = 0;
      while (true) {
        final left = i * 2 + 1, right = left + 1;
        var smallest = i;
        if (left < _items.length && compare(_items[left], _items[smallest]) < 0)
          smallest = left;
        if (right < _items.length &&
            compare(_items[right], _items[smallest]) < 0) smallest = right;
        if (smallest == i) break;
        final t = _items[i];
        _items[i] = _items[smallest];
        _items[smallest] = t;
        i = smallest;
      }
    }
    return first;
  }
}

