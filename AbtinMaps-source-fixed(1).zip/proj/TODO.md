# TODO

- [x] Offline search: "city + place" queries (e.g. "تهران شهرک آزادی") now fall back to qualifier split, biased to the city center
- [ ] Test on device: "تهران شهرک آزادی", "شهرک آزادی تهران", "تهران آزادی"
- [ ] Online search (place_search_service.dart) — same qualifier handling if needed
- [ ] Offline city names not rendered on map (open)
- [ ] Sygic-style Real View (open)
