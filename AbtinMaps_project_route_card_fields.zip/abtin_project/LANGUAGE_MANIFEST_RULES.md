# Language manifest rules

- The online manifest is the source of truth for the published language list.
- Every language entry returned by the manifest is displayed; no fa/en/ar/etc.
  filter is applied to the manifest list.
- Built-in Persian and English remain bundled and selectable without download.
- A non-built-in manifest language must be downloaded before it can be activated.
- No language-specific download condition was added.
- Existing localization fallback/selection logic remains intact.
