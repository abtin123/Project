import 'abm_file.dart';
import 'abm_models.dart';

/// یک کمان گراف (یال جهت‌دار) با هزینه‌ی زمانی.
class AbmArc {
  const AbmArc({
    required this.toKey,
    required this.toPoint,
    required this.seconds,
    required this.meters,
    required this.way,
    this.shape = const [],
  });

  final int toKey;
  final AbmPoint toPoint;
  final double seconds;
  final double meters;
  final AbmWay way;

  /// نقاطِ میانیِ شکلِ واقعیِ راه بین گرهٔ مبدأ و [toKey] این یال (بدون دو
  /// سرِ یال)، به‌ترتیبِ حرکت از مبدأ به toKey. قبلاً مسیرِ نهایی فقط از
  /// گره‌های تقاطع (fromKey/toKey هر یال) تشکیل می‌شد و همین باعث می‌شد هر
  /// قوس/میدان روی نقشه (که در دادهٔ .abm با چند نقطهٔ میانی رسم شده) در
  /// مسیرِ رسم‌شده به یک پاره‌خط صاف/بریده تبدیل شود — دقیقاً هندسه‌ی
  /// way را دنبال نمی‌کرد. این فیلد اجازه می‌دهد [AbmRouter._build] همان
  /// نقاطِ میانی را هم در geometry نهایی بگنجاند.
  final List<AbmPoint> shape;
}

/// نتیجه‌ی snap کردن یک نقطه (مبدأ/مقصد) روی گراف.
///
/// [key] می‌تواند یک گره‌ی واقعی باشد یا یک «گره‌ی مجازی» (کلید منفی) که
/// دقیقاً روی نزدیک‌ترین *یال* مجاز قرار گرفته — نه لزوماً روی یک تقاطع.
class AbmSnap {
  const AbmSnap({required this.key, required this.point, required this.meters});
  final int key;
  final AbmPoint point;
  final double meters;

  /// true یعنی این یک گره‌ی مصنوعیِ میان‌یالی است که باید بعد از پایان
  /// مسیریابی با [AbmGraph.releaseSnap] از گراف پاک شود.
  bool get isVirtual => key < 0;
}

/// نتیجه‌ی تصویر یک نقطه روی یک پاره‌خط (segment projection).
class _Proj {
  const _Proj(this.point, this.t);
  final AbmPoint point;

  /// کسر (۰..۱) از fromKey تا toKey که نقطه‌ی تصویرشده روی آن قرار دارد.
  final double t;
}

/// بهترین یال پیداشده در یک دور جست‌وجوی snap.
class _BestEdge {
  _BestEdge({
    required this.fromKey,
    required this.fromPos,
    required this.toKey,
    required this.toPos,
    required this.t,
    required this.point,
    required this.meters,
    required this.way,
    required this.arcSeconds,
    required this.arcMeters,
  });

  final int fromKey;
  final AbmPoint fromPos;
  final int toKey;
  final AbmPoint toPos;
  final double t;
  final AbmPoint point;
  final double meters;
  final AbmWay way;
  final double arcSeconds;
  final double arcMeters;
}

/// گراف مسیریابی که به‌صورت تدریجی (کاشی‌به‌کاشی) از فایل .abm ساخته می‌شود.
///
/// کاشی‌ها همان کاشی‌های نمایشی‌اند؛ یعنی گراف و نقشه دقیقاً یکی هستند
/// (همان تضمینی که abtinmap_inspect.py با دستور `--route` اثبات می‌کند).
class AbmGraph {
  AbmGraph(this.file, {int? zoom}) : z = zoom ?? file.baseZoom;

  final AbmFile file;
  final int z;

  final Map<int, List<AbmArc>> _adj = {};
  final Map<int, int> _incomingCounts = {};
  final Map<int, AbmPoint> _positions = {};
  final Set<int> _borderKeys = {};
  final Set<int> _loadedTiles = {};

  /// شمارنده‌ی کلید گره‌های مجازی — همیشه منفی، چون `AbmTileMath.graphKey`
  /// هرگز مقدار منفی تولید نمی‌کند (هر دو جمله‌ی فرمول غیرمنفی‌اند).
  int _virtualCounter = -1;

  /// برای هر گره‌ی مجازیِ مقصد (goal)، فهرست گره‌های واقعی‌ای که یک یال
  /// موقت به آن اضافه شده — لازم برای پاک‌سازی تمیز در [releaseSnap].
  final Map<int, List<int>> _virtualIncomingAttachments = {};

  /// POIهای دیده‌شده در کاشی‌های بارگذاری‌شده (برای دوربین سرعت/سرعت‌گیر/پلیس
  /// روی مسیر — نگاه کنید به [AbmPoi.isNavigationAlert]).
  final List<AbmPoi> pois = [];

  int get loadedTileCount => _loadedTiles.length;
  int get nodeCount => _positions.length;

  bool isBorderNode(int key) => _borderKeys.contains(key);

  AbmPoint? positionOf(int key) => _positions[key];

  List<AbmArc> neighbors(int key) => _adj[key] ?? const [];

  Future<void> ensureTile(int x, int y) async {
    final id = AbmTileMath.tileId(z, x, y);
    if (!_loadedTiles.add(id)) return;
    final tile = await file.tile(z, x, y);
    if (tile == null) return;

    for (final poi in tile.pois) {
      if (poi.isNavigationAlert) pois.add(poi);
    }

    for (final edge in tile.edges) {
      if (edge.wayIndex >= tile.ways.length) continue;
      final way = tile.ways[edge.wayIndex];
      // جاده‌ی بدون دسترسی عمومی (خصوصی/بسته) هرگز نباید در گراف مسیریابی
      // ظاهر شود، حتی اگر یال‌هایش هزینه‌ی مثبت داشته باشند.
      if (way.isNoAccess) continue;
      // پیاده‌رو/دوچرخه‌رو/پله (و هر کلاس غیرقابل‌رانندگی) هرگز نباید وارد
      // گراف مسیریابیِ خودرو شوند — این یک محافظِ صریح در همین لایه است و
      // به درستیِ داده‌ی ورودی (پایپ‌لاین ساخت نقشه) متکی نیست.
      if (!way.isCarPassableClass) continue;
      if (way.refs.length <= edge.a || way.refs.length <= edge.b) continue;
      final na = way.refs[edge.a];
      final nb = way.refs[edge.b];
      if (na >= tile.nodes.length || nb >= tile.nodes.length) continue;

      final pa = tile.nodes[na];
      final pb = tile.nodes[nb];
      final ka = file.graphKeyOf(tile, na);
      final kb = file.graphKeyOf(tile, nb);
      _positions[ka] = pa;
      _positions[kb] = pb;
      final meters = AbmTileMath.haversineMeters(pa, pb);

      // نقاطِ میانیِ شکلِ واقعیِ way بین این دو گره (اندیس‌های edge.a و
      // edge.b در way.refs) — همانی که [AbmArc.shape] مستند می‌کند. جهتِ
      // شمارش را طوری انتخاب می‌کنیم که همیشه از edge.a به‌سمتِ edge.b باشد
      // (یعنی از pa به pb، هم‌جهت با یالِ رفت).
      final List<AbmPoint> forwardShape;
      if (edge.a < edge.b) {
        forwardShape = [
          for (var idx = edge.a + 1; idx < edge.b; idx++)
            tile.nodes[way.refs[idx]]
        ];
      } else if (edge.a > edge.b) {
        forwardShape = [
          for (var idx = edge.a - 1; idx > edge.b; idx--)
            tile.nodes[way.refs[idx]]
        ];
      } else {
        forwardShape = const [];
      }

      if (edge.forward10 > 0) {
        (_adj[ka] ??= []).add(AbmArc(
          toKey: kb,
          toPoint: pb,
          seconds: edge.forwardSeconds,
          meters: meters,
          way: way,
          shape: forwardShape,
        ));
        _incomingCounts[kb] = (_incomingCounts[kb] ?? 0) + 1;
      }
      if (edge.backward10 > 0) {
        (_adj[kb] ??= []).add(AbmArc(
          toKey: ka,
          toPoint: pa,
          seconds: edge.backwardSeconds,
          meters: meters,
          way: way,
          shape: forwardShape.isEmpty
              ? forwardShape
              : forwardShape.reversed.toList(growable: false),
        ));
        _incomingCounts[ka] = (_incomingCounts[ka] ?? 0) + 1;
      }
    }

    for (final nodeIndex in tile.border.keys) {
      if (nodeIndex < tile.nodes.length) {
        _borderKeys.add(file.graphKeyOf(tile, nodeIndex));
      }
    }
  }

  /// بارگذاری بلوک ۳×۳ کاشی حول یک نقطه.
  Future<void> ensureAround(AbmPoint p, {int ring = 1}) async {
    final tx = AbmTileMath.tileX(p.lon, z);
    final ty = AbmTileMath.tileY(p.lat, z);
    for (var dx = -ring; dx <= ring; dx++) {
      for (var dy = -ring; dy <= ring; dy++) {
        await ensureTile(tx + dx, ty + dy);
      }
    }
  }

  /// تصویر [p] روی پاره‌خط [a]→[b] در یک تقریب اقلیدسیِ محلی (متر) —
  /// همان مقیاسی که هیوریستیک A* در AbmRouter استفاده می‌کند؛ برای طول یک
  /// یال (چند ده تا چند صد متر) خطای این تقریب نسبت به ژئودزیک واقعی
  /// ناچیز است.
  _Proj _projectOntoSegment(AbmPoint p, AbmPoint a, AbmPoint b) {
    const lonScale = 88000.0;
    const latScale = 111000.0;
    final ax = a.lon * lonScale, ay = a.lat * latScale;
    final bx = b.lon * lonScale, by = b.lat * latScale;
    final px = p.lon * lonScale, py = p.lat * latScale;
    final dx = bx - ax, dy = by - ay;
    final lenSq = dx * dx + dy * dy;
    var t = lenSq <= 1e-9 ? 0.0 : ((px - ax) * dx + (py - ay) * dy) / lenSq;
    if (t < 0.0) t = 0.0;
    if (t > 1.0) t = 1.0;
    final lon = a.lon + (b.lon - a.lon) * t;
    final lat = a.lat + (b.lat - a.lat) * t;
    return _Proj(AbmPoint(lon, lat), t);
  }

  /// یالِ برگشتِ [way] از [toKey] به [fromKey] را برمی‌گرداند (اگر خیابان
  /// دوطرفه باشد) — لازم برای ساختن یال‌های مجازی گره‌ی snap در هر دو جهت.
  AbmArc? _reverseArc(int toKey, int fromKey, AbmWay way) {
    final arcs = _adj[toKey];
    if (arcs == null) return null;
    for (final arc in arcs) {
      if (arc.toKey == fromKey && identical(arc.way, way)) return arc;
    }
    return null;
  }

  /// نزدیک‌ترین *یال* قابل‌عبور (نه صرفاً نزدیک‌ترین گره) به [p]؛ نتیجه یک
  /// گره‌ی مجازی است که دقیقاً روی همان یال، در جهتِ مجازِ واقعی قرار دارد.
  ///
  /// این جایگزینِ snap قدیمی (نزدیک‌ترین *گره*) شده چون snap به گره باعث
  /// می‌شد مسیر گاهی از خیابان/کوچه‌ی مجاورِ اشتباه یا از انتهای غلط یک
  /// یال شروع شود — به‌خصوص در تقاطع‌های شلوغ یا نزدیک بن‌بست‌ها.
  ///
  /// [requireOutgoing] فقط برای مبدأ true باشد؛ [requireIncoming] فقط برای
  /// مقصد. چون خودِ snap اکنون همیشه *روی یک یال با جهتِ مجازِ موجود* انجام
  /// می‌شود، امکان حرکت رو به جلو (برای مبدأ) یا رسیدن از یک مسیر مجاز (برای
  /// مقصد) به‌صورت ذاتی تضمین می‌شود؛ این پرچم‌ها فقط تعیین می‌کنند کدام‌طرفِ
  /// یال‌های مجازی ساخته شود.
  Future<AbmSnap?> snap(
    AbmPoint p, {
    double maxMeters = 3000,
    bool requireOutgoing = false,
    bool requireIncoming = false,
  }) async {
    for (final ring in const [1, 2, 3]) {
      await ensureAround(p, ring: ring);
      final candidates = <_BestEdge>[];
      _adj.forEach((fromKey, arcs) {
        final fromPos = _positions[fromKey];
        if (fromPos == null) return;
        for (final arc in arcs) {
          final proj = _projectOntoSegment(p, fromPos, arc.toPoint);
          final d = AbmTileMath.haversineMeters(p, proj.point);
          if (d > maxMeters) continue;
          candidates.add(_BestEdge(
            fromKey: fromKey,
            fromPos: fromPos,
            toKey: arc.toKey,
            toPos: arc.toPoint,
            t: proj.t,
            point: proj.point,
            meters: d,
            way: arc.way,
            arcSeconds: arc.seconds,
            arcMeters: arc.meters,
          ));
        }
      });
      if (candidates.isEmpty) continue;
      candidates.sort((a, b) => a.meters.compareTo(b.meters));
      // از نزدیک‌ترین یال شروع می‌کنیم؛ اگر دقیقاً روی یکی از دو سرِ یال
      // بیفتد و آن سر قید مورد نیاز (خروجی برای مبدأ / ورودی برای مقصد) را
      // نداشته باشد (مثلاً انتهای یک بن‌بستِ یک‌طرفه)، به یالِ بعدی نزدیک‌تر
      // می‌رویم — دقیقاً همان تضمینی که snap قدیمیِ گره‌محور فراهم می‌کرد.
      for (final cand in candidates) {
        final result = _tryMaterialize(
          cand,
          requireOutgoing: requireOutgoing,
          requireIncoming: requireIncoming,
        );
        if (result != null) return result;
      }
    }
    return null;
  }

  AbmSnap? _tryMaterialize(
    _BestEdge e, {
    required bool requireOutgoing,
    required bool requireIncoming,
  }) {
    final atFrom = e.t <= 1e-9;
    final atTo = e.t >= 1.0 - 1e-9;

    if (atFrom) {
      // خروجی از fromKey همین الان با همین arc تضمین شده؛ فقط ورودی را چک کن.
      if (requireIncoming && (_incomingCounts[e.fromKey] ?? 0) == 0)
        return null;
      return AbmSnap(key: e.fromKey, point: e.fromPos, meters: e.meters);
    }
    if (atTo) {
      // ورودی به toKey همین الان با همین arc تضمین شده؛ فقط خروجی را چک کن.
      if (requireOutgoing && (_adj[e.toKey]?.isEmpty ?? true)) return null;
      return AbmSnap(key: e.toKey, point: e.toPos, meters: e.meters);
    }

    // میان‌یال — همیشه معتبر: خودِ گره‌ی مجازی طوری ساخته می‌شود که دقیقاً
    // یال پیداشده (و برگشتِ آن در صورت دوطرفه بودن) را به‌عنوان یال
    // خروجی/ورودی داشته باشد، پس نیازی به بررسی اضافه نیست.
    return _materializeVirtual(e,
        requireOutgoing: requireOutgoing, requireIncoming: requireIncoming);
  }

  AbmSnap _materializeVirtual(
    _BestEdge e, {
    required bool requireOutgoing,
    required bool requireIncoming,
  }) {
    final vKey = _virtualCounter--;
    _positions[vKey] = e.point;
    final reverse = _reverseArc(e.toKey, e.fromKey, e.way);

    if (requireOutgoing) {
      final outArcs = <AbmArc>[
        AbmArc(
          toKey: e.toKey,
          toPoint: e.toPos,
          seconds: e.arcSeconds * (1.0 - e.t),
          meters: e.arcMeters * (1.0 - e.t),
          way: e.way,
        ),
      ];
      if (reverse != null) {
        outArcs.add(AbmArc(
          toKey: e.fromKey,
          toPoint: e.fromPos,
          seconds: reverse.seconds * e.t,
          meters: e.arcMeters * e.t,
          way: e.way,
        ));
      }
      _adj[vKey] = outArcs;
    }

    if (requireIncoming) {
      final attachedTo = <int>[];
      _adj.putIfAbsent(e.fromKey, () => []).add(AbmArc(
            toKey: vKey,
            toPoint: e.point,
            seconds: e.arcSeconds * e.t,
            meters: e.arcMeters * e.t,
            way: e.way,
          ));
      attachedTo.add(e.fromKey);
      if (reverse != null) {
        _adj.putIfAbsent(e.toKey, () => []).add(AbmArc(
              toKey: vKey,
              toPoint: e.point,
              seconds: reverse.seconds * (1.0 - e.t),
              meters: e.arcMeters * (1.0 - e.t),
              way: e.way,
            ));
        attachedTo.add(e.toKey);
      }
      _virtualIncomingAttachments[vKey] = attachedTo;
    }

    return AbmSnap(key: vKey, point: e.point, meters: e.meters);
  }

  /// پاک‌سازی یال‌ها و موقعیت گره‌ی مجازی ساخته‌شده توسط [snap] — باید بعد
  /// از پایان هر عملیات مسیریابی صدا زده شود (چه موفق چه ناموفق)، وگرنه
  /// این یال‌های موقتی روی گره‌های واقعی باقی می‌مانند و در جست‌وجوهای بعدی
  /// (مثلاً reroute زنده‌ی GPS) به‌اشتباه به‌عنوان یال واقعی استفاده می‌شوند.
  void releaseSnap(int key) {
    if (key >= 0)
      return; // فقط گره‌های مجازی (کلید منفی) نیاز به پاک‌سازی دارند.
    _positions.remove(key);
    _adj.remove(key);
    final attachedTo = _virtualIncomingAttachments.remove(key);
    if (attachedTo != null) {
      for (final realKey in attachedTo) {
        _adj[realKey]?.removeWhere((a) => a.toKey == key);
      }
    }
  }

  void clear() {
    _adj.clear();
    _incomingCounts.clear();
    _positions.clear();
    _borderKeys.clear();
    _loadedTiles.clear();
    _virtualIncomingAttachments.clear();
    _virtualCounter = -1;
    pois.clear();
  }
}
