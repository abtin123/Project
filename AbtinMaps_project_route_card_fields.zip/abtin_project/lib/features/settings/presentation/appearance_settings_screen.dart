import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../shared/widgets/bottom_nav.dart';
import '../../../shared/widgets/page_header.dart';
import '../../../shared/widgets/route_guidance_card.dart';
import '../../weather/presentation/weather_settings_providers.dart';
import 'appearance/shared_widgets.dart';
import 'appearance_settings_providers.dart';

/// پالتِ رنگ‌های پیشنهادیِ صفحهٔ ظاهر — طبق طراحیِ مرجع (۸ رنگِ ثابت +
/// گزینهٔ رنگِ سفارشی). عمداً مستقل از appColorPresets نگه داشته شده،
/// چون آن پالت برای رنگِ مسیر/پیکان است، نه رنگِ اصلیِ اپ.
const List<Color> _themeColorPresets = [
  Color(0xFF8A3FD0), // بنفش (پیش‌فرض)
  Color(0xFFFFFFFF), // سفید
  Color(0xFF14161B), // مشکی
  Color(0xFF2F6FE0), // آبی
  Color(0xFF3FD0E0), // فیروزه‌ای
  Color(0xFF52C24C), // سبز
  Color(0xFFE0A83F), // طلایی
  Color(0xFFE0523F), // قرمز
];

/// صفحهٔ «تنظیمات ظاهر»: رنگ و حالتِ نمایشِ کلیِ اپ، ظاهرِ کارتِ
/// مسیریابی و ظاهرِ ویجتِ شناورِ آب‌وهوا — همه در یک محل، با هدرِ
/// مشترکِ [PageHeader] و رنگِ داینامیکِ [AppColors.primaryAccent].
class AppearanceSettingsScreen extends ConsumerWidget {
  const AppearanceSettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final accent = AppColors.primaryAccent(context);

    return Scaffold(
      backgroundColor: AppColors.background(context),
      appBar: const PageHeader(title: 'تنظیمات ظاهر'),
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.12,
            colors: [accent.withOpacity(0.15), AppColors.background(context)],
          ),
        ),
        child: Stack(
          children: [
            ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 112),
              children: const [
                _GeneralSettingsCard(),
                SizedBox(height: 14),
                _RouteCardSettingsCard(),
                SizedBox(height: 14),
                _WeatherWidgetSettingsCard(),
              ],
            ),
            const BottomNav(currentPage: NavKey.settings),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// پوستهٔ مشترکِ کارت‌های شیشه‌ای این صفحه.
// ============================================================

class _GlassCard extends StatelessWidget {
  const _GlassCard({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.child,
    this.headerLeading,
  });

  final IconData icon;
  final Color iconColor;
  final String title;
  final Widget child;
  final Widget? headerLeading;

  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.glassPanelSoft(context),
              borderRadius: BorderRadius.circular(18),
              border:
                  Border.all(color: AppColors.glassBorder(context), width: 0.7),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    if (headerLeading != null) ...[
                      headerLeading!,
                    ],
                    const Spacer(),
                    Text(
                      title,
                      textAlign: TextAlign.right,
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            color: AppColors.textPrimary(context),
                            fontWeight: FontWeight.w800,
                          ),
                    ),
                    const SizedBox(width: 9),
                    Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: iconColor.withOpacity(0.18),
                      ),
                      child: Icon(icon, color: iconColor, size: 17),
                    ),
                  ],
                ),
                const SizedBox(height: 15),
                child,
              ],
            ),
          ),
        ),
      );
}

// ============================================================
// اجزای عمومیِ سطرها.
// ============================================================

class _RowIcon extends StatelessWidget {
  const _RowIcon({required this.icon, required this.color});
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
        width: 27,
        height: 27,
        alignment: Alignment.center,
        decoration:
            BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.16)),
        child: Icon(icon, size: 14, color: color),
      );
}

class _SettingHeader extends StatelessWidget {
  const _SettingHeader({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.leading,
    this.iconColor,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Widget? leading;
  final Color? iconColor;

  @override
  Widget build(BuildContext context) {
    final color = iconColor ?? AppColors.primaryAccent(context);
    return Row(
      children: [
        if (leading != null) ...[leading!, const SizedBox(width: 12)],
        _RowIcon(icon: icon, color: color),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                title,
                textAlign: TextAlign.right,
                style: TextStyle(
                  color: AppColors.textPrimary(context),
                  fontWeight: FontWeight.w700,
                  fontSize: 14.5,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                textAlign: TextAlign.right,
                style:
                    TextStyle(color: AppColors.textMuted(context), fontSize: 11.5),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// سطرِ کامل: هدر (آیکون+عنوان+زیرعنوان) + یک اسلایدر، با امکانِ یک
/// کنترلِ کمکی (فلش/چیپ درصد/دکمهٔ بزرگ‌نمایی) سمتِ چپِ اسلایدر.
class _SliderSetting extends StatelessWidget {
  const _SliderSetting({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
    this.min = 0.0,
    this.max = 1.0,
    this.trailing,
    this.iconColor,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;
  final Widget? trailing;
  final Color? iconColor;

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.primaryAccent(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _SettingHeader(
          icon: icon,
          title: title,
          subtitle: subtitle,
          iconColor: iconColor,
        ),
        const SizedBox(height: 2),
        Row(
          children: [
            if (trailing != null) ...[trailing!, const SizedBox(width: 10)],
            Expanded(
              child: SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  activeTrackColor: accent,
                  inactiveTrackColor: accent.withOpacity(0.18),
                  thumbColor: accent,
                  overlayColor: accent.withOpacity(0.12),
                  trackHeight: 4,
                ),
                child: Slider(
                  value: value.clamp(min, max).toDouble(),
                  min: min,
                  max: max,
                  onChanged: onChanged,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

/// سطرِ تک‌خطیِ رنگ: هدر + یک دایرهٔ رنگ که با تپ، شیتِ انتخاب‌گرِ رنگِ
/// کاملِ [ColorPickerSheet] را باز می‌کند.
class _ColorSetting extends StatelessWidget {
  const _ColorSetting({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onChanged,
    this.iconColor,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final ValueChanged<Color> onChanged;
  final Color? iconColor;

  @override
  Widget build(BuildContext context) => _SettingHeader(
        icon: icon,
        title: title,
        subtitle: subtitle,
        iconColor: iconColor,
        leading: _ColorSwatchButton(color: color, onChanged: onChanged),
      );
}

class _ColorSwatchButton extends StatelessWidget {
  const _ColorSwatchButton({required this.color, required this.onChanged});
  final Color color;
  final ValueChanged<Color> onChanged;

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () async {
            final picked = await ColorPickerSheet.show(context, color);
            if (picked != null) onChanged(picked);
          },
          customBorder: const CircleBorder(),
          child: Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.35), width: 1.4),
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(0.25), blurRadius: 4),
              ],
            ),
          ),
        ),
      );
}

/// سطرِ سوییچِ روشن/خاموش (هدر + یک Switch سمتِ چپ).
class _SwitchSetting extends StatelessWidget {
  const _SwitchSetting({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
    this.iconColor,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  final Color? iconColor;

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.primaryAccent(context);
    return _SettingHeader(
      icon: icon,
      title: title,
      subtitle: subtitle,
      iconColor: iconColor,
      leading: Switch.adaptive(
        value: value,
        onChanged: onChanged,
        activeColor: accent,
      ),
    );
  }
}

/// گروهِ دوتاییِ فلش (بالا/پایین یا چپ/راست) برای پرشِ سریعِ اسلایدر به
/// دو انتها. جهتِ فعلاً‌فعال بر اساسِ مقدارِ جاری هایلایت می‌شود.
class _BiStepper extends StatelessWidget {
  const _BiStepper({
    required this.value,
    required this.onChanged,
    required this.startIcon,
    required this.endIcon,
  });

  final double value; // 0..100
  final ValueChanged<double> onChanged;
  final IconData startIcon;
  final IconData endIcon;

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.primaryAccent(context);
    final secondActive = value > 50;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Container(
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          color: AppColors.surfaceMuted(context),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _StepperButton(
              icon: startIcon,
              active: !secondActive,
              color: accent,
              onTap: () => onChanged(0),
            ),
            _StepperButton(
              icon: endIcon,
              active: secondActive,
              color: accent,
              onTap: () => onChanged(100),
            ),
          ],
        ),
      ),
    );
  }
}

/// گروهِ سه‌تاییِ چپ / سوآپ / راست — برای جایگاهِ افقی و راستاچینیِ
/// محتوا. دکمهٔ میانی همیشه به‌عنوانِ ابزارِ فعال نمایش داده می‌شود و با
/// تپ، مقدار را به میانه (۵۰) برمی‌گرداند؛ دو فلشِ کناری مستقیم به
/// انتها می‌پرند.
class _TriStepper extends StatelessWidget {
  const _TriStepper({required this.onLeft, required this.onCenter, required this.onRight});

  final VoidCallback onLeft;
  final VoidCallback onCenter;
  final VoidCallback onRight;

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.primaryAccent(context);
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Container(
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          color: AppColors.surfaceMuted(context),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _StepperButton(
              icon: Icons.chevron_left_rounded,
              active: false,
              color: accent,
              onTap: onLeft,
            ),
            _StepperButton(
              icon: Icons.swap_horiz_rounded,
              active: true,
              color: accent,
              onTap: onCenter,
            ),
            _StepperButton(
              icon: Icons.chevron_right_rounded,
              active: false,
              color: accent,
              onTap: onRight,
            ),
          ],
        ),
      ),
    );
  }
}

class _StepperButton extends StatelessWidget {
  const _StepperButton({
    required this.icon,
    required this.active,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final bool active;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 30,
            height: 30,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: active ? color : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon,
                size: 18,
                color: active ? Colors.white : AppColors.textSecondary(context)),
          ),
        ),
      );
}

/// دکمهٔ تکیِ بزرگ‌نمایی — برای بازنشانیِ سریعِ اندازهٔ ویجت به مقدارِ
/// پیش‌فرض.
class _ExpandButton extends StatelessWidget {
  const _ExpandButton({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.primaryAccent(context);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          width: 36,
          height: 36,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: AppColors.surfaceMuted(context),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(Icons.open_in_full_rounded, size: 16, color: accent),
        ),
      ),
    );
  }
}

/// چیپِ نمایشِ درصد — نمایشِ صرفاً بصریِ مقدارِ فعلیِ اسلایدرِ کناری.
class _PercentChip extends StatelessWidget {
  const _PercentChip({required this.value});
  final int value;

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.primaryAccent(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
      decoration: BoxDecoration(
        color: accent.withOpacity(0.15),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: accent.withOpacity(0.4)),
      ),
      child: Text(
        '$value%',
        style: TextStyle(
          color: AppColors.textPrimary(context),
          fontWeight: FontWeight.w700,
          fontSize: 12,
        ),
      ),
    );
  }
}

// ============================================================
// بخش ۱: تنظیمات عمومی — رنگ اصلی اپ + حالت نمایش.
// ============================================================

class _GeneralSettingsCard extends ConsumerWidget {
  const _GeneralSettingsCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appearance = ref.watch(appearanceSettingsProvider);
    final notifier = ref.read(appearanceSettingsProvider.notifier);
    final isCustom = !_themeColorPresets
        .any((c) => c.value == appearance.primaryColor.value);

    Future<void> setColor(Color c) =>
        notifier.update((s) => s.copyWith(primaryColor: c));
    Future<void> setThemeMode(ThemeMode m) =>
        notifier.update((s) => s.copyWith(themeMode: m));

    return _GlassCard(
      icon: Icons.palette_rounded,
      iconColor: AppColors.primaryAccent(context),
      title: 'تنظیمات عمومی',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Directionality(
            textDirection: TextDirection.ltr,
            child: Wrap(
              spacing: 14,
              runSpacing: 12,
              children: [
                for (final c in _themeColorPresets)
                  AppColorSwatch(
                    color: c,
                    selected: !isCustom && c.value == appearance.primaryColor.value,
                    onTap: () => setColor(c),
                  ),
                RainbowSwatch(
                  selected: isCustom,
                  onTap: () async {
                    final picked =
                        await ColorPickerSheet.show(context, appearance.primaryColor);
                    if (picked != null) await setColor(picked);
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'حالت نمایش',
            textAlign: TextAlign.right,
            style: TextStyle(
              color: AppColors.textSecondary(context),
              fontSize: 12.5,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 10),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Row(
              children: [
                Expanded(
                  child: PillChoice(
                    label: 'روز',
                    icon: Icons.wb_sunny_rounded,
                    selected: appearance.themeMode == ThemeMode.light,
                    onTap: () => setThemeMode(ThemeMode.light),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: PillChoice(
                    label: 'شب',
                    icon: Icons.dark_mode_rounded,
                    selected: appearance.themeMode == ThemeMode.dark,
                    onTap: () => setThemeMode(ThemeMode.dark),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: PillChoice(
                    label: 'پیروی از سیستم',
                    icon: Icons.smartphone_rounded,
                    selected: appearance.themeMode == ThemeMode.system,
                    onTap: () => setThemeMode(ThemeMode.system),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// بخش ۲: کارتِ مسیریابی.
// ============================================================

/// دادهٔ نمونه برای پیش‌نمایشِ زندهٔ کارتِ مسیریابی در صفحهٔ تنظیمات —
/// همان شکلی که در ناوبریِ واقعی دیده می‌شود، با اعداد ثابتِ دلخواه.
RouteGuidanceCardData _previewRouteCardData() => const RouteGuidanceCardData(
      icon: Icons.turn_right_rounded,
      distanceText: '300 متر',
      streetText: 'به راست بپیچید، خیابان ولیعصر',
      etaLabel: 'رسیدن',
      etaValue: '14:32',
      remainingLabel: 'باقی‌مانده',
      remainingValue: '4.2 کیلومتر',
      durationLabel: 'زمان',
      durationValue: '9 دقیقه',
      onClose: null,
    );

class _RouteCardSettingsCard extends ConsumerWidget {
  const _RouteCardSettingsCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appearance = ref.watch(appearanceSettingsProvider);
    final notifier = ref.read(appearanceSettingsProvider.notifier);
    const rowColor = Color(0xFFB57BFF);

    return _GlassCard(
      icon: Icons.map_rounded,
      iconColor: rowColor,
      title: 'کارت مسیریابی',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // پیش‌نمایشِ زنده: همان ویجتی که در ناوبریِ واقعی رندر می‌شود،
          // با دادهٔ نمونه — هر تغییری در اسلایدرها/رنگ‌های زیر بلافاصله
          // این‌جا هم منعکس می‌شود.
          RouteGuidanceCard(settings: appearance, data: _previewRouteCardData()),
          const SizedBox(height: 16),
          _SliderSetting(
            icon: Icons.height_rounded,
            iconColor: const Color(0xFFB57BFF),
            title: 'ارتفاع کارت',
            subtitle: 'بلندی کارت مسیریابی',
            value: appearance.routeCardHeight,
            onChanged: (v) =>
                notifier.update((s) => s.copyWith(routeCardHeight: v)),
          ),
          const RowDivider(),
          _SliderSetting(
            icon: Icons.opacity_rounded,
            iconColor: const Color(0xFF5CC8FF),
            title: 'شفافیت کارت',
            subtitle: 'میزان شفافیت پس‌زمینه کارت',
            value: appearance.routeCardOpacity,
            onChanged: (v) =>
                notifier.update((s) => s.copyWith(routeCardOpacity: v)),
          ),
          const RowDivider(),
          _SliderSetting(
            icon: Icons.rounded_corner_rounded,
            iconColor: const Color(0xFFFF6FA5),
            title: 'گردی گوشه کارت',
            subtitle: 'میزان گردی گوشه‌های کارت',
            value: appearance.routeCardCornerRadius,
            onChanged: (v) =>
                notifier.update((s) => s.copyWith(routeCardCornerRadius: v)),
          ),
          const RowDivider(),
          _SliderSetting(
            icon: Icons.flare_rounded,
            iconColor: const Color(0xFF8FD14F),
            title: 'شدت درخشش کارت',
            subtitle: 'میزان درخشش حاشیه کارت',
            value: appearance.routeCardGlowIntensity,
            onChanged: (v) =>
                notifier.update((s) => s.copyWith(routeCardGlowIntensity: v)),
          ),

          // --- کنترلِ جداگانهٔ هر بخشِ کارت ---
          const SizedBox(height: 8),
          _SectionLabel(text: 'فلش جهت‌نما'),
          _SliderSetting(
            icon: Icons.zoom_out_map_rounded,
            iconColor: const Color(0xFF3DDC84),
            title: 'اندازه فلش',
            subtitle: 'اندازه آیکون جهت‌نما',
            value: appearance.routeCardArrowSize,
            onChanged: (v) =>
                notifier.update((s) => s.copyWith(routeCardArrowSize: v)),
          ),
          const RowDivider(),
          _ColorSetting(
            icon: Icons.palette_rounded,
            iconColor: const Color(0xFF3DDC84),
            title: 'رنگ فلش',
            subtitle: 'رنگ آیکون جهت‌نما',
            color: appearance.routeCardArrowColor,
            onChanged: (c) =>
                notifier.update((s) => s.copyWith(routeCardArrowColor: c)),
          ),

          const SizedBox(height: 8),
          _SectionLabel(text: 'فاصله تا پیچ بعدی'),
          _SliderSetting(
            icon: Icons.text_fields_rounded,
            iconColor: const Color(0xFF4FD1C5),
            title: 'اندازه فونت فاصله',
            subtitle: 'اندازه عددِ فاصله تا پیچ بعدی',
            value: appearance.routeCardDistanceFontSize,
            onChanged: (v) => notifier
                .update((s) => s.copyWith(routeCardDistanceFontSize: v)),
          ),
          const RowDivider(),
          _ColorSetting(
            icon: Icons.palette_rounded,
            iconColor: const Color(0xFF4FD1C5),
            title: 'رنگ فاصله',
            subtitle: 'رنگ عددِ فاصله تا پیچ بعدی',
            color: appearance.routeCardDistanceColor,
            onChanged: (c) =>
                notifier.update((s) => s.copyWith(routeCardDistanceColor: c)),
          ),

          const SizedBox(height: 8),
          _SectionLabel(text: 'نام خیابان / دستور مسیر'),
          _SliderSetting(
            icon: Icons.text_fields_rounded,
            iconColor: const Color(0xFFF2A93C),
            title: 'اندازه فونت متن راهنما',
            subtitle: 'اندازه نام خیابان و دستور مسیر',
            value: appearance.routeCardStreetFontSize,
            onChanged: (v) =>
                notifier.update((s) => s.copyWith(routeCardStreetFontSize: v)),
          ),
          const RowDivider(),
          _ColorSetting(
            icon: Icons.palette_rounded,
            iconColor: const Color(0xFFF2A93C),
            title: 'رنگ متن راهنما',
            subtitle: 'رنگ نام خیابان و دستور مسیر',
            color: appearance.routeCardStreetColor,
            onChanged: (c) =>
                notifier.update((s) => s.copyWith(routeCardStreetColor: c)),
          ),

          const SizedBox(height: 8),
          _SectionLabel(text: 'ردیف آمار (رسیدن / باقی‌مانده / زمان)'),
          _SliderSetting(
            icon: Icons.text_fields_rounded,
            iconColor: const Color(0xFF5CC8FF),
            title: 'اندازه فونت آمار',
            subtitle: 'اندازه نوشته‌های ردیف پایین کارت',
            value: appearance.routeCardStatsFontSize,
            onChanged: (v) =>
                notifier.update((s) => s.copyWith(routeCardStatsFontSize: v)),
          ),
          const RowDivider(),
          _ColorSetting(
            icon: Icons.palette_rounded,
            iconColor: const Color(0xFF5CC8FF),
            title: 'رنگ آمار',
            subtitle: 'رنگ نوشته‌های ردیف پایین کارت',
            color: appearance.routeCardStatsColor,
            onChanged: (c) =>
                notifier.update((s) => s.copyWith(routeCardStatsColor: c)),
          ),
        ],
      ),
    );
  }
}

/// برچسبِ کوچکِ جداکنندهٔ گروهِ کنترل‌های هر بخشِ کارت (فلش/فاصله/متنِ
/// راهنما/آمار) — صرفاً یک متنِ خاکستریِ راست‌چین با کمی فاصلهٔ بالا و
/// پایین، بدون هیچ منطقی.
class _SectionLabel extends StatelessWidget {
  const _SectionLabel({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(
          text,
          textAlign: TextAlign.right,
          style: TextStyle(
            color: AppColors.textMuted(context),
            fontSize: 12,
            fontWeight: FontWeight.w700,
          ),
        ),
      );
}

// ============================================================
// بخش ۳: ویجت آب‌وهوا.
// ============================================================

class _WeatherWidgetSettingsCard extends ConsumerWidget {
  const _WeatherWidgetSettingsCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appearance = ref.watch(appearanceSettingsProvider);
    final notifier = ref.read(appearanceSettingsProvider.notifier);
    final enabled = ref.watch(weatherEnabledProvider);
    final accent = AppColors.primaryAccent(context);

    Future<void> setEnabled(bool v) =>
        ref.read(weatherEnabledProvider.notifier).setEnabled(v);

    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _SwitchSetting(
          icon: Icons.power_settings_new_rounded,
          iconColor: const Color(0xFF6FE0A8),
          title: 'روشن / خاموش',
          subtitle: 'نمایش یا مخفی کردن ویجت آب و هوا',
          value: enabled,
          onChanged: (v) => setEnabled(v),
        ),
        const RowDivider(),
        _SliderSetting(
          icon: Icons.swap_vert_rounded,
          iconColor: const Color(0xFF49C7E7),
          title: 'جایگاه عمودی',
          subtitle: 'موقعیت عمودی ویجت',
          min: 0,
          max: 100,
          value: appearance.weatherVerticalPercent,
          trailing: _BiStepper(
            value: appearance.weatherVerticalPercent,
            startIcon: Icons.keyboard_arrow_up_rounded,
            endIcon: Icons.keyboard_arrow_down_rounded,
            onChanged: (v) =>
                notifier.update((s) => s.copyWith(weatherVerticalPercent: v)),
          ),
          onChanged: (v) =>
              notifier.update((s) => s.copyWith(weatherVerticalPercent: v)),
        ),
        const RowDivider(),
        _SliderSetting(
          icon: Icons.swap_horiz_rounded,
          iconColor: const Color(0xFFB57BFF),
          title: 'جایگاه افقی',
          subtitle: 'موقعیت افقی ویجت',
          min: 0,
          max: 100,
          value: appearance.weatherHorizontalPercent,
          trailing: _TriStepper(
            onLeft: () =>
                notifier.update((s) => s.copyWith(weatherHorizontalPercent: 0)),
            onCenter: () =>
                notifier.update((s) => s.copyWith(weatherHorizontalPercent: 50)),
            onRight: () =>
                notifier.update((s) => s.copyWith(weatherHorizontalPercent: 100)),
          ),
          onChanged: (v) =>
              notifier.update((s) => s.copyWith(weatherHorizontalPercent: v)),
        ),
        const RowDivider(),
        _SliderSetting(
          icon: Icons.crop_free_rounded,
          iconColor: const Color(0xFF8FD14F),
          title: 'ارتفاع ویجت',
          subtitle: 'ارتفاع ویجت آب و هوا',
          min: 70,
          max: 150,
          value: appearance.weatherSize,
          trailing: _ExpandButton(
            onTap: () => notifier.update((s) => s.copyWith(weatherSize: 100)),
          ),
          onChanged: (v) => notifier.update((s) => s.copyWith(weatherSize: v)),
        ),
        const RowDivider(),
        _SliderSetting(
          icon: Icons.compare_arrows_rounded,
          iconColor: const Color(0xFFF2A93C),
          title: 'چپ / راست بودن',
          subtitle: 'تراز افقی ویجت',
          min: 0,
          max: 100,
          value: appearance.weatherContentAlign,
          trailing: _TriStepper(
            onLeft: () =>
                notifier.update((s) => s.copyWith(weatherContentAlign: 0)),
            onCenter: () =>
                notifier.update((s) => s.copyWith(weatherContentAlign: 50)),
            onRight: () =>
                notifier.update((s) => s.copyWith(weatherContentAlign: 100)),
          ),
          onChanged: (v) =>
              notifier.update((s) => s.copyWith(weatherContentAlign: v)),
        ),
        const RowDivider(),
        _ColorSetting(
          icon: Icons.format_color_fill_rounded,
          iconColor: const Color(0xFFFF6FA5),
          title: 'رنگ پس‌زمینه',
          subtitle: 'رنگ پس‌زمینه ویجت',
          color: appearance.weatherBgColor,
          onChanged: (c) => notifier.update((s) => s.copyWith(weatherBgColor: c)),
        ),
        const RowDivider(),
        _SliderSetting(
          icon: Icons.explore_rounded,
          iconColor: const Color(0xFF5CC8FF),
          title: 'شفافیت پس‌زمینه',
          subtitle: 'میزان شفافیت پس‌زمینه ویجت',
          min: 0,
          max: 1,
          value: appearance.weatherBgOpacity,
          trailing: _PercentChip(value: (appearance.weatherBgOpacity * 100).round()),
          onChanged: (v) => notifier.update((s) => s.copyWith(weatherBgOpacity: v)),
        ),
        const RowDivider(),
        _ColorSetting(
          icon: Icons.format_color_text_rounded,
          iconColor: const Color(0xFFF2D93C),
          title: 'رنگ نوشته',
          subtitle: 'رنگ متن ویجت',
          color: appearance.weatherTextColor,
          onChanged: (c) => notifier.update((s) => s.copyWith(weatherTextColor: c)),
        ),
      ],
    );

    return _GlassCard(
      icon: Icons.cloud_rounded,
      iconColor: const Color(0xFF9C8CFF),
      title: 'ویجت آب و هوا',
      headerLeading: Switch.adaptive(
          value: enabled, onChanged: (v) => setEnabled(v), activeColor: accent),
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 180),
        opacity: enabled ? 1 : 0.45,
        child: IgnorePointer(ignoring: !enabled, child: content),
      ),
    );
  }
}
