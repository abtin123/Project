import 'package:flutter/material.dart';

/// نشانگر خودرو روی نقشهٔ زنده — کاملاً با CustomPainter کشیده می‌شود، نه با
/// موتور سه‌بعدی Filament.
///
/// چرا نه GLB روی نقشه؟
/// پکیج `interactive_3d` (که برای پیش‌نمایش سه‌بعدی در تنظیمات همچنان استفاده
/// می‌شود) اصلاً پارامتری برای پس‌زمینهٔ واقعاً شفاف ندارد — طبق مستندات خودش
/// «solidBackgroundColor» یک رنگ توپر است، نه شفاف؛ و skybox هم یک عکس واقعی
/// پس‌زمینه می‌گذارد، نه شفافیت. یعنی رندر GLB روی نقشه همیشه یا یک بلوک
/// رنگی/سیاه یا یک عکس صحنه پشت خودرو نشان می‌داد — دقیقاً همون چیزی که در
/// اسکرین‌شات‌ها دیده شد. جایگزین بررسی‌شدهٔ دیگر (`playx_3d_scene`) واقعاً
/// شفافیت دارد، اما هیچ API مستندی برای تغییر رنگ بدنهٔ یک مدل GLB از پیش
/// ساخته‌شده ندارد (فقط برای Shape/Ground ساخته‌شده با کد، آن‌هم با فایل
/// متریال کامپایل‌شدهٔ .filamat). یعنی هیچ‌کدام هم‌زمان «شفافیت واقعی روی
/// نقشه» و «تغییر رنگ بدنه» را با هم نمی‌دادند.
///
/// راه‌حل: دقیقاً همون تکنیکی که خودِ این پروژه برای فلش (`NavArrow`) استفاده
/// می‌کند — یک شکل بردار با CustomPainter رسم می‌شود که به‌طور ذاتی پس‌زمینه‌ی
/// شفاف دارد (چون فقط همون پیکسل‌هایی که رسم می‌شوند دیده می‌شوند) و رنگش هم
/// مستقیماً از `bodyColor` انتخابیِ کاربر می‌آید — بدون نیاز به هیچ فایل
/// نور/محیط یا موتور رندر جداگانه. این یعنی روی نقشه دیگر هیچ‌وقت هیچ باکس
/// مشکی یا صحنهٔ پس‌زمینهٔ ناخواسته دیده نمی‌شود.
///
/// رندر سه‌بعدی واقعی (GLB + IBL/Skybox) همچنان فقط در کارت «پیش‌نمایش زنده»
/// تنظیمات مکان‌نما استفاده می‌شود، جایی که پس‌زمینه از قبل توپر/طراحی‌شده
/// است و شفافیت اصلاً لازم نیست.
class TopDownCarPainter extends CustomPainter {
  const TopDownCarPainter({
    required this.bodyColor,
    this.glow = false,
  });

  final Color bodyColor;
  final bool glow;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // بدنهٔ خودرو از بالا: باریک‌تر جلو (نوک به سمت بالا = جهت حرکت)،
    // پهن‌تر وسط، عقب کمی گردتر.
    final body = Path()
      ..moveTo(w * 0.5, h * 0.02)
      ..quadraticBezierTo(w * 0.86, h * 0.10, w * 0.90, h * 0.30)
      ..quadraticBezierTo(w * 0.94, h * 0.46, w * 0.90, h * 0.62)
      ..quadraticBezierTo(w * 0.88, h * 0.86, w * 0.72, h * 0.96)
      ..quadraticBezierTo(w * 0.5, h * 1.02, w * 0.28, h * 0.96)
      ..quadraticBezierTo(w * 0.12, h * 0.86, w * 0.10, h * 0.62)
      ..quadraticBezierTo(w * 0.06, h * 0.46, w * 0.10, h * 0.30)
      ..quadraticBezierTo(w * 0.14, h * 0.10, w * 0.5, h * 0.02)
      ..close();

    final light = Color.lerp(bodyColor, Colors.white, 0.42)!;
    final dark = Color.lerp(bodyColor, Colors.black, 0.32)!;

    if (glow) {
      canvas.drawPath(
        body,
        Paint()
          ..color = bodyColor.withOpacity(0.55)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.14),
      );
    }

    // سایهٔ نرم زیر خودرو.
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(w * 0.5, h * 0.98),
        width: w * 0.72,
        height: h * 0.10,
      ),
      Paint()
        ..color = Colors.black.withOpacity(0.28)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.06),
    );

    // بدنه با گرادیان (روشن سمت چپ/جلو، تیره سمت راست/عقب) برای حس حجم.
    canvas.drawPath(
      body,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [light, bodyColor, dark],
          stops: const [0.0, 0.5, 1.0],
        ).createShader(body.getBounds()),
    );

    canvas.drawPath(
      body,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.02
        ..color = Colors.black.withOpacity(0.35),
    );

    // شیشهٔ جلو/عقب — تیره‌ی نیمه‌شفاف وسط بدنه.
    final windshield = Path()
      ..moveTo(w * 0.30, h * 0.28)
      ..quadraticBezierTo(w * 0.5, h * 0.18, w * 0.70, h * 0.28)
      ..lineTo(w * 0.66, h * 0.44)
      ..lineTo(w * 0.34, h * 0.44)
      ..close();
    canvas.drawPath(
      windshield,
      Paint()..color = const Color(0xFF11151C).withOpacity(0.82),
    );

    final rearGlass = Path()
      ..moveTo(w * 0.32, h * 0.80)
      ..quadraticBezierTo(w * 0.5, h * 0.90, w * 0.68, h * 0.80)
      ..lineTo(w * 0.64, h * 0.68)
      ..lineTo(w * 0.36, h * 0.68)
      ..close();
    canvas.drawPath(
      rearGlass,
      Paint()..color = const Color(0xFF11151C).withOpacity(0.72),
    );

    // نورهای جلو (سفید مایل به آبی) و چراغ‌های عقب (قرمز).
    final headlightPaint = Paint()..color = const Color(0xFFEFF6FF);
    canvas.drawOval(
      Rect.fromCenter(
          center: Offset(w * 0.22, h * 0.08), width: w * 0.12, height: h * 0.05),
      headlightPaint,
    );
    canvas.drawOval(
      Rect.fromCenter(
          center: Offset(w * 0.78, h * 0.08), width: w * 0.12, height: h * 0.05),
      headlightPaint,
    );
    final taillightPaint = Paint()..color = const Color(0xFFE23B3B);
    canvas.drawOval(
      Rect.fromCenter(
          center: Offset(w * 0.24, h * 0.94), width: w * 0.10, height: h * 0.045),
      taillightPaint,
    );
    canvas.drawOval(
      Rect.fromCenter(
          center: Offset(w * 0.76, h * 0.94), width: w * 0.10, height: h * 0.045),
      taillightPaint,
    );

    // خط نور روی سقف برای حس براقی بدنه.
    final sheen = Path()
      ..moveTo(w * 0.40, h * 0.30)
      ..lineTo(w * 0.46, h * 0.30)
      ..lineTo(w * 0.40, h * 0.66)
      ..lineTo(w * 0.34, h * 0.66)
      ..close();
    canvas.drawPath(
      sheen,
      Paint()..color = Colors.white.withOpacity(0.35),
    );
  }

  @override
  bool shouldRepaint(covariant TopDownCarPainter oldDelegate) {
    return oldDelegate.bodyColor != bodyColor || oldDelegate.glow != glow;
  }
}

/// ویجت آماده‌مصرف نشانگر خودروی نقشه — جایگزین سبک، شفاف و رنگ‌پذیرِ
/// [GlbVehicleMarker] روی نقشهٔ زنده.
class TopDownCarMarker extends StatelessWidget {
  const TopDownCarMarker({
    super.key,
    required this.size,
    required this.bodyColor,
    this.glow = false,
  });

  final double size;
  final Color bodyColor;
  final bool glow;

  @override
  Widget build(BuildContext context) {
    return SizedBox.square(
      dimension: size,
      child: CustomPaint(
        painter: TopDownCarPainter(bodyColor: bodyColor, glow: glow),
      ),
    );
  }
}
