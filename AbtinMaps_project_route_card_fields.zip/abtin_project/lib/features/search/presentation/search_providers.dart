import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/place_search_service.dart';
import '../../gps/presentation/gps_providers.dart';

/// آیا نوار جستجو در حالت فعال (تمام‌صفحه/باز) است.
final searchActiveProvider = StateProvider<bool>((ref) => false);

/// متن فعلی داخل اینپوت جستجو.
final searchQueryProvider = StateProvider<String>((ref) => '');

/// اندیس کارت مکانی که در حال حاضر روی نقشه نمایش داده می‌شود
/// (با اسلاید بین کارت‌ها عوض می‌شود).
final searchSelectedIndexProvider = StateProvider<int>((ref) => 0);

final _placeSearchServiceProvider =
    Provider<PlaceSearchService>((ref) => PlaceSearchService());

/// نتایج جستجو برای متن فعلی؛ با debounce ۴۰۰ میلی‌ثانیه‌ای تا با هر
/// حرف تایپ‌شده درخواست جدید به سرور نرود.
final searchResultsProvider =
    FutureProvider.autoDispose<List<PlaceSearchResult>>((ref) async {
  final query = ref.watch(searchQueryProvider);
  if (query.trim().length < 2) return const [];

  // اگر در حین تأخیر متن دوباره عوض شود، این Future قدیمی توسط
  // autoDispose+watch به‌صورت خودکار نادیده گرفته می‌شود.
  await Future<void>.delayed(const Duration(milliseconds: 400));

  final service = ref.watch(_placeSearchServiceProvider);
  final currentPosition = ref.read(vehiclePositionProvider).valueOrNull;

  final results = await service.search(
    query,
    biasLat: currentPosition?.lat,
    biasLng: currentPosition?.lng,
  );

  // با آمدن نتیجهٔ جدید، کارت اول به‌صورت پیش‌فرض انتخاب می‌شود.
  ref.read(searchSelectedIndexProvider.notifier).state = 0;

  return results;
});
