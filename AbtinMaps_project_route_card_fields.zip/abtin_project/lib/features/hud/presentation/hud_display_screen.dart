import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/localization/app_localizations.dart';
import '../../../core/theme/app_colors.dart';
import '../../gps/presentation/gps_providers.dart';
import '../../routing/data/routing_service.dart' show RouteInstruction;
import '../../routing/presentation/routing_providers.dart';
import '../domain/hud_maneuver_icon.dart';
import 'hud_settings_providers.dart';

/// نمایشِ واقعیِ HUD حین رانندگی.
///
/// قبلاً این صفحه فلشِ «مستقیم» را ثابت نشان می‌داد (رجوع کنید به تصویرِ
/// باگ). حالا آیکونِ جهت از [hudManeuverIcon] و از رویِ دستورِ واقعیِ
/// ناوبریِ جاری (`activeNavigationProvider`) ساخته می‌شود؛ یعنی برای هر
/// میدان یا پیچ به هر سمت، همان جهتِ واقعی (چپ/راست/تند/ملایم/میدان/دور زدن)
/// نمایش داده می‌شود، نه یک فلشِ یکسان برای همه‌ی حالت‌ها.
class HudDisplayScreen extends ConsumerStatefulWidget {
  const HudDisplayScreen({super.key});

  @override
  ConsumerState<HudDisplayScreen> createState() => _HudDisplayScreenState();
}

class _HudDisplayScreenState extends ConsumerState<HudDisplayScreen> {
  String _compassLabel(double? headingDeg) {
    if (headingDeg == null) return '--';
    const labels = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    final idx = (((headingDeg % 360) + 22.5) / 45).floor() % 8;
    return labels[idx];
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(hudSettingsProvider);
    final nav = ref.watch(activeNavigationProvider);
    final vehiclePositionAsync = ref.watch(vehiclePositionProvider);
    final accent = AppColors.primaryAccent(context);
    String t(String key) => AppStrings.get(context, ref, key);

    final speedKmh = vehiclePositionAsync.value?.speedKmh ?? 0;
    final headingDeg = vehiclePositionAsync.value?.headingDeg;
    final instruction = nav?.currentInstruction;

    final scale = (settings.scalePercent / 100).clamp(0.5, 1.3);
    final brightness = (settings.brightnessPercent / 100).clamp(0.10, 1.0);

    Widget content = Container(
      color: Colors.black,
      child: SafeArea(
        child: Opacity(
          opacity: brightness,
          child: Align(
            alignment: Alignment(
              settings.horizontalOffset,
              settings.verticalOffset,
            ),
            child: Transform.scale(
              scale: scale,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (settings.showSpeed)
                          _SpeedBlock(speedKmh: speedKmh),
                        if (settings.showSpeedLimit &&
                            instruction?.speedLimit != null) ...[
                          const SizedBox(width: 18),
                          _SpeedLimitCircle(limit: instruction!.speedLimit!),
                        ],
                        const Spacer(),
                        if (settings.showCompassHeading)
                          _CompassBlock(label: _compassLabel(headingDeg)),
                      ],
                    ),
                    const SizedBox(height: 18),
                    if (nav != null &&
                        (settings.showNextManeuver ||
                            settings.showDistanceToManeuver))
                      _ManeuverBlock(
                        accent: accent,
                        instruction: instruction,
                        distanceM: nav.distanceToNextManeuverM,
                        showIcon: settings.showNextManeuver,
                        showDistance: settings.showDistanceToManeuver,
                        arrivedLabel: t('hud_arrived'),
                      )
                    else if (settings.showNextManeuver)
                      Text(
                        t('hud_no_active_navigation'),
                        style: const TextStyle(
                            color: Colors.white38, fontSize: 14),
                      ),
                    if (settings.showAiAlerts) ...[
                      const SizedBox(height: 10),
                      const Icon(Icons.directions_car_filled_rounded,
                          color: Colors.amber, size: 26),
                    ],
                    const SizedBox(height: 24),
                    Text(
                      'ABTINMAP HUD',
                      style: TextStyle(
                        color: accent.withOpacity(0.8),
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 3,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );

    if (settings.mirrorImage) {
      content = Transform(
        alignment: Alignment.center,
        transform: Matrix4.identity()..scale(-1.0, 1.0, 1.0),
        child: content,
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(child: content),
          Positioned(
            top: 8,
            right: 8,
            child: IconButton(
              icon: const Icon(Icons.close_rounded, color: Colors.white54),
              onPressed: () => context.pop(),
            ),
          ),
        ],
      ),
    );
  }
}

class _SpeedBlock extends StatelessWidget {
  const _SpeedBlock({required this.speedKmh});
  final double speedKmh;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            speedKmh.round().toString(),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 56,
              fontWeight: FontWeight.w900,
              height: 1,
            ),
          ),
          const Text('km/h',
              style: TextStyle(color: Colors.white54, fontSize: 13)),
        ],
      );
}

class _SpeedLimitCircle extends StatelessWidget {
  const _SpeedLimitCircle({required this.limit});
  final int limit;

  @override
  Widget build(BuildContext context) => Container(
        width: 54,
        height: 54,
        margin: const EdgeInsets.only(top: 4),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white,
          border: Border.all(color: Colors.red, width: 5),
        ),
        child: Text(
          '$limit',
          style: const TextStyle(
              color: Colors.black, fontWeight: FontWeight.w900, fontSize: 20),
        ),
      );
}

class _CompassBlock extends StatelessWidget {
  const _CompassBlock({required this.label});
  final String label;

  @override
  Widget build(BuildContext context) => Column(
        children: [
          const Icon(Icons.explore_rounded,
              color: Colors.lightBlueAccent, size: 22),
          const SizedBox(height: 2),
          Text(label,
              style: const TextStyle(
                  color: Colors.lightBlueAccent,
                  fontSize: 13,
                  fontWeight: FontWeight.w700)),
        ],
      );
}

/// بلاکِ مرکزیِ HUD: آیکونِ جهتِ واقعیِ پیچ/میدان بعدی (نه یک فلشِ ثابت)
/// به‌همراهِ فاصله تا آن.
class _ManeuverBlock extends StatelessWidget {
  const _ManeuverBlock({
    required this.accent,
    required this.instruction,
    required this.distanceM,
    required this.showIcon,
    required this.showDistance,
    required this.arrivedLabel,
  });

  final Color accent;
  final RouteInstruction? instruction;
  final double distanceM;
  final bool showIcon;
  final bool showDistance;
  final String arrivedLabel;

  @override
  Widget build(BuildContext context) {
    final instr = instruction;
    if (instr == null) return const SizedBox.shrink();
    final String type = instr.type;
    final String? modifier = instr.modifier;
    final bool arrived = type == 'arrive';

    return Column(
      children: [
        if (showIcon)
          Transform.rotate(
            angle: arrived
                ? 0
                : hudManeuverRotationRadiansIfPlain(type, modifier),
            child: Icon(
              hudManeuverIcon(type, modifier),
              color: accent,
              size: 72,
            ),
          ),
        const SizedBox(height: 6),
        if (arrived)
          Text(
            arrivedLabel,
            style: TextStyle(
                color: accent, fontSize: 16, fontWeight: FontWeight.w800),
          )
        else if (showDistance)
          Text(
            distanceM >= 1000
                ? '${(distanceM / 1000).toStringAsFixed(1)} km'
                : '${distanceM.round()} m',
            style: TextStyle(
                color: accent, fontSize: 18, fontWeight: FontWeight.w800),
          ),
      ],
    );
  }
}

/// [hudManeuverIcon] برای اکثرِ حالت‌ها آیکونِ اختصاصیِ صحیح برمی‌گرداند
/// (که خودش چرخیده است)، پس نیازی به چرخشِ اضافه نیست. این تابع فقط صفر
/// برمی‌گرداند تا در آینده اگر خواستیم برای آیکونِ ساده‌ی فلش هم چرخش
/// دستی اضافه کنیم، به‌جای دستکاریِ ویجت بالا همین‌جا تغییر بدهیم.
double hudManeuverRotationRadiansIfPlain(String type, String? modifier) => 0;
