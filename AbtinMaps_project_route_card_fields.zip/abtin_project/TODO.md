# TODO

- [ ] Run `flutter analyze` / `flutter build` (no Flutter SDK in dev sandbox — unverified by compiler).
- [ ] Appearance settings screen (`appearance_settings_screen.dart`): route-card style values (height/font/opacity/corner/glow) are persisted but not yet consumed by an actual route-card widget on the map — apply them wherever the routing card is rendered.
- [ ] `NavKey.routes` enum value + its switch cases in `bottom_nav.dart` are now unused (kept to avoid touching exhaustive switches) — safe to fully remove later.
- [ ] Confirm favorite-places bottom-nav slot (`NavKey.saved` -> `/saved-places`) fully replaces old routes-list flow from a UX standpoint.
- [ ] New `route_settings_screen.dart`: `avoidHighways`/`avoidFerries` are persisted but not yet threaded into the offline routing engine (`routing_service.dart`/`abtinmap_routing_provider.dart`) — same current state as the pre-existing `avoidTraffic` flag.
- [ ] `routeStartDelay` currently just delays activating the "navigating" state after route draw in `home_screen._startNavigation` (Future.delayed) — it is NOT gated on actual GPS-detected movement, just a flat pause. Revisit if true movement-detection is wanted.
- [ ] Route settings screen reachable via Settings > "تنظیمات مسیر" (`/route-settings`).
