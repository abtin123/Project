# Abtin Maps — unified settings & localization architecture

## Settings
The Settings root exposes independent sections:
- Voice settings
- Appearance settings
- Map settings
- AI camera settings
- Vehicle & arrow settings
- Routing settings
- Favorite pages
- About Abtin

Legacy accordion/nested Appearance pages must not be used.

## Map catalog
The online map manifest is the source of truth for the country/region list.
Do not fall back to a hard-coded country list such as an Iran-only list when
the online manifest is unavailable.

## Languages
The online language manifest is the source of truth for the language list.
Every manifest entry is displayed; there is no hard-coded fa/en/ar/etc. filter.
Bundled languages remain usable without downloading a pack. Non-bundled
manifest languages are downloadable and become selectable after installation.

Language activation may use explicit locale behavior (for example fa/en), but
manifest discovery/download must remain manifest-driven.

## Routing cards
Routing-card strings are localization keys, not hard-coded language branches.
Every published language pack should contain the routing-card keys. The pack
builder/validator should merge the app key catalog and routing-card catalog.
