import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:abtin_maps/features/routing/presentation/routes_screen.dart';

void main() {
  Future<void> pumpPage(WidgetTester tester, Widget page) async {
    await tester.pumpWidget(
      const ProviderScope(
        child: MaterialApp(
          home: SizedBox.shrink(),
        ),
      ),
    );
    await tester.pumpWidget(
      ProviderScope(
        child: MaterialApp(home: page),
      ),
    );
    await tester.pump(const Duration(milliseconds: 200));
    expect(tester.takeException(), isNull);
  }

  testWidgets('routing page builds visible content', (tester) async {
    await pumpPage(tester, const RoutesScreen());
    expect(find.text('مسیرها'), findsWidgets);
  });
}
