# TODO
## Done
- 3D buildings: height expr (render_height/height/levels, default 9m), height-based tint, vertical gradient, map light (`_apply3dBuildings` in abm_style_assets.dart); extrusion from z13; style revision v5.
## Left
- Test on device (offline + online); tune default height / light.
- If offline MBTiles lack height tags, add `height`/`levels` to buildings layer in Builder.
- Optional: raise default map pitch.

## Country SVGs (download screen)
- Done: assets/maps/countries/{iso2}.svg for all 37 countries in countries.json (Natural Earth 10m, simplified, single path each; ES has Canary inset, US has AK/HI inset, FR metropolitan only, UA includes Crimea).
- Optional: region-level SVGs for countries other than IR.
