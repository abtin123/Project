import 'dart:io';
import 'package:sqlite3/sqlite3.dart';

class SearchResult {
  const SearchResult(
      {required this.name,
      required this.category,
      required this.latitude,
      required this.longitude,
      this.distanceMeters});
  final String name, category;
  final double latitude, longitude;
  final double? distanceMeters;
}

class AbmSearchEngine {
  Future<List<SearchResult>> search(File dbFile, String query,
      {int limit = 20}) async {
    if (!await dbFile.exists() || query.trim().length < 2) return const [];
    final db = sqlite3.open(dbFile.path, mode: OpenMode.readOnly);
    try {
      final tables = db.select(
          "SELECT name FROM sqlite_master WHERE type='table' AND name='search_fts'");
      if (tables.isEmpty) return const [];
      final q = query
          .trim()
          .replaceAll('"', ' ')
          .split(RegExp(r'\s+'))
          .where((x) => x.isNotEmpty)
          .map((x) => '"${x.replaceAll('"', '""')}"*')
          .join(' AND ');
      final rows = db.select(
          'SELECT n.name, n.name_fa, n.name_en, c.name AS category, '
          '(spt.min_lat+spt.max_lat)/2 AS lat, (spt.min_lon+spt.max_lon)/2 AS lon '
          'FROM search_fts s JOIN names n ON n.id=s.rowid '
          'JOIN features f ON f.name_id=n.id JOIN categories c ON c.id=f.category_id '
          'JOIN spatial spt ON spt.id=f.id '
          'WHERE s MATCH ? AND spt.min_lat IS NOT NULL AND spt.min_lon IS NOT NULL LIMIT ?',
          [q, limit]);
      return [
        for (final r in rows)
          SearchResult(
              name: '${r['name_fa'] ?? r['name'] ?? r['name_en'] ?? ''}',
              category: '${r['category'] ?? ''}',
              latitude: (r['lat'] as num).toDouble(),
              longitude: (r['lon'] as num).toDouble())
      ];
    } finally {
      db.dispose();
    }
  }
}
