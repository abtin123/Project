/// Layer-based rendering for the user's saved places.
///
/// The source is a single GeoJSON FeatureCollection and the style owns all
/// placement/collision decisions.  Saved places therefore behave like normal
/// map symbols and never create a large pile of Android/Flutter Markers.
abstract final class AbmSavedPlaces {
  static const sourceId = 'abm-saved-places';
  static const layerId = 'abm-saved-places-symbols';

  static void applyToStyle(Map<String, dynamic> style) {
    final sources = Map<String, dynamic>.from(
      (style['sources'] as Map?)?.map((k, v) => MapEntry('$k', v)) ??
          const <String, dynamic>{},
    );
    sources[sourceId] = <String, dynamic>{
      'type': 'geojson',
      'data': <String, dynamic>{
        'type': 'FeatureCollection',
        'features': <dynamic>[],
      },
    };
    style['sources'] = sources;

    final layers = List<dynamic>.from(style['layers'] as List? ?? const []);
    layers.removeWhere((layer) => layer is Map && layer['id'] == layerId);

    // Saved places are useful but should not cover navigation hazards or road
    // names.  Insert them immediately before the road-hazard layers.
    var at = layers.indexWhere((layer) =>
        layer is Map && '${layer['id']}'.startsWith('abm-hz-'));
    if (at < 0) at = layers.length;
    layers.insert(at, <String, dynamic>{
      'id': layerId,
      'type': 'symbol',
      'source': sourceId,
      'minzoom': 10,
      'maxzoom': 24,
      'layout': <String, dynamic>{
        'icon-image': 'abm-hz-saved_place',
        'icon-size': <dynamic>[
          'interpolate',
          <dynamic>['linear'],
          <dynamic>['zoom'],
          10, 0.24,
          13, 0.31,
          16, 0.40,
          19, 0.48,
        ],
        'icon-allow-overlap': false,
        'icon-ignore-placement': false,
        'icon-optional': false,
        'icon-padding': 8,
        'icon-pitch-alignment': 'viewport',
        'icon-rotation-alignment': 'viewport',
        'symbol-sort-key': 90,
      },
      'paint': <String, dynamic>{
        'icon-opacity': <dynamic>[
          'interpolate',
          <dynamic>['linear'],
          <dynamic>['zoom'],
          10, 0.78,
          14, 0.94,
          17, 1.0,
        ],
      },
    });
    style['layers'] = layers;
  }

  static Map<String, dynamic> compose(List<AbmSavedPlace> places) {
    final seen = <String>{};
    final features = <Map<String, dynamic>>[];
    for (final place in places) {
      if (!place.latitude.isFinite || !place.longitude.isFinite) continue;
      final key =
          '${place.latitude.toStringAsFixed(6)},${place.longitude.toStringAsFixed(6)}';
      if (!seen.add(key)) continue;
      features.add(<String, dynamic>{
        'type': 'Feature',
        'geometry': <String, dynamic>{
          'type': 'Point',
          'coordinates': <double>[place.longitude, place.latitude],
        },
        'properties': <String, dynamic>{
          'name': place.name,
          'category': place.category,
          'saved': true,
        },
      });
    }
    return <String, dynamic>{
      'type': 'FeatureCollection',
      'features': features,
    };
  }
}

class AbmSavedPlace {
  const AbmSavedPlace({
    required this.latitude,
    required this.longitude,
    required this.name,
    this.category = 'favorite',
  });

  final double latitude;
  final double longitude;
  final String name;
  final String category;
}
