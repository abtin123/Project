import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:abtin_maps/core/geo/geo_types.dart';
import '../../../core/localization/app_localizations.dart';

import '../../../shared/providers/abtinmap_providers.dart';
import '../../../shared/providers/app_settings_providers.dart';
import 'abtinmap_routing_provider.dart';
import 'online_routing_provider.dart';
import 'routing_provider.dart';

class RouteInfo {
  const RouteInfo({
    required this.geometry,
    required this.distanceKm,
    required this.durationMin,
    required this.instructions,
    this.alerts = const [],
  });

  final List<LatLng> geometry;
  final double distanceKm;
  final double durationMin;
  final List<RouteInstruction> instructions;
  final List<RouteAlert> alerts;
}

enum RouteAlertType { speedCamera, speedBump, policeCheckpoint, trafficLight }

class RouteAlert {
  const RouteAlert({required this.type, required this.location, this.name});
  final RouteAlertType type;
  final LatLng location;
  final String? name;
}

class RouteInstruction {
  const RouteInstruction({
    required this.text,
    required this.distanceMeters,
    required this.location,
    required this.type,
    this.modifier,
    this.exit,
    this.roundaboutAngleDegrees,
    this.roundaboutExitCount,
    this.roundaboutBranchAngles = const [],
    this.roundaboutEntranceAngles = const [],
    this.roundaboutExitAngles = const [],
    this.roundaboutActiveExitAngle,
    this.drivingSide = 'right',
    this.speedLimit,
    this.maneuverEndLocation,
    this.maneuverAngleDegrees,
  });

  final String text;
  final double distanceMeters;
  final LatLng location;
  final String type;
  final String? modifier;
  final int? exit;
  final double? roundaboutAngleDegrees;

  /// Total number of usable exits detected for this roundabout.
  final int? roundaboutExitCount;

  /// Actual physical arm bearings discovered from the offline SQLite graph.
  /// These replace the old hard-coded four-branch drawing.
  final List<double> roundaboutBranchAngles;
  final List<double> roundaboutEntranceAngles;
  final List<double> roundaboutExitAngles;
  final double? roundaboutActiveExitAngle;

  /// 'left' or 'right' - which side of the road the source country drives
  /// on. Roundabouts are traversed clockwise under right-hand traffic and
  /// counter-clockwise under left-hand traffic; the guidance icon uses this
  /// to draw the correct rotation instead of assuming one country.
  final String drivingSide;
  final int? speedLimit;

  /// For a roundabout this is the point where the vehicle actually leaves
  /// the roundabout. It prevents the next instruction from replacing the
  /// roundabout guidance while the driver is still inside it.
  final LatLng? maneuverEndLocation;

  /// Signed real heading change of the maneuver, when the routing provider can derive it.
  /// Negative = left, positive = right; used to render the guidance arrow from actual geometry.
  final double? maneuverAngleDegrees;
}

/// تنها درگاه مسیریابی اپ: graph داخل فایل ABM نصب‌شده روی دستگاه.
/// این کلاس هیچ endpoint، client HTTP یا fallback شبکه‌ای ندارد.
class RoutingService {
  RoutingService(this._ref);

  final Ref _ref;
  AbtinmapRoutingProvider? _abmProvider;
  OnlineRoutingProvider? _onlineProvider;
  String? lastError;

  /// موتور فعال از provider سراسری خوانده می‌شود تا با انتخاب کاربر در
  /// تنظیمات، محاسبهٔ مسیر بعدی واقعاً به همان منبع هدایت شود.
  RoutingEngine get engine => _ref.read(routingEngineProvider);

  final Map<String, AbtinmapRoutingProvider> _abmProviders =
      <String, AbtinmapRoutingProvider>{};

  AbtinmapRoutingProvider _abmProviderFor(String mapName) =>
      _abmProviders.putIfAbsent(
        mapName,
        () => AbtinmapRoutingProvider(
          mapService: _ref.read(abmMapServiceProvider),
          vectorMapService: _ref.read(vectorMapServiceProvider),
          mapName: mapName,
          languageCode: () => _ref.read(languageProvider),
        ),
      );

  /// همهٔ نقشه‌های نصب‌شده هم‌زمان فعال‌اند. ترتیب تلاش: نقشه‌ای که مبدأ و مقصد
  /// هر دو در آن‌اند، سپس مبدأ، سپس مقصد، سپس بقیه. اولین نقشه‌ای که مسیر
  /// بدهد برنده است.
  Future<List<AbtinmapRoutingProvider>> _offlineProvidersFor(
    LatLng origin,
    LatLng destination,
  ) async {
    final sources = await _ref.read(installedOfflineMapSourcesProvider.future);
    if (sources.isEmpty) {
      final activeMap = _ref.read(abmActiveMapNameProvider).trim();
      return <AbtinmapRoutingProvider>[_abmProviderFor(activeMap)];
    }
    final vector = _ref.read(vectorMapServiceProvider);
    final scored = <MapEntry<int, OfflineMapSource>>[];
    for (final source in sources) {
      final box = await offlineMapBbox(vector, source);
      final hasO = bboxContains(box, origin.latitude, origin.longitude);
      final hasD = bboxContains(box, destination.latitude, destination.longitude);
      final score = (hasO && hasD) ? 0 : hasO ? 1 : hasD ? 2 : 3;
      scored.add(MapEntry(score, source));
    }
    scored.sort((x, y) => x.key.compareTo(y.key));
    return <AbtinmapRoutingProvider>[
      for (final e in scored) _abmProviderFor(e.value.fileName),
    ];
  }

  OnlineRoutingProvider get onlineProvider =>
      _onlineProvider ??= OnlineRoutingProvider(
        languageCode: () => _ref.read(languageProvider),
      );

  static List<String> _osrmExclude(bool tolls, bool highways, bool ferries) =>
      [if (tolls) 'toll', if (highways) 'motorway', if (ferries) 'ferry'];

  Future<RouteInfo?> calculateRoute({
    required LatLng origin,
    required LatLng destination,
    bool offlineOnly = false,
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
    bool avoidTrafficZones = false,
    bool avoidHighways = false,
    bool avoidFerries = false,
  }) async {
    lastError = null;
    if (!offlineOnly && engine == RoutingEngine.online) {
      final route = await onlineProvider.calculateRoute(
        origin: origin,
        destination: destination,
        exclude: _osrmExclude(avoidTolls, avoidHighways, avoidFerries),
      );
      if (route != null) return route;
      lastError = onlineProvider.lastError ??
          AppStrings.getForLanguage(
              _ref.read(languageProvider), 'route_error_online_failed_generic');
      return null;
    }

    String? offlineError;
    for (final provider in await _offlineProvidersFor(origin, destination)) {
      final route = await provider.calculateRoute(
        origin: origin,
        destination: destination,
        offlineOnly: true,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
        avoidTrafficZones: avoidTrafficZones,
        avoidHighways: avoidHighways,
      );
      if (route != null) return route;
      offlineError ??= provider.lastError;
    }
    lastError = offlineError ??
        AppStrings.getForLanguage(
            _ref.read(languageProvider), 'route_error_offline_map_missing');
    return null;
  }

  Future<List<RouteInfo>> calculateRoutes({
    required LatLng origin,
    required LatLng destination,
    bool offlineOnly = false,
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
    bool avoidTrafficZones = false,
    bool avoidHighways = false,
    bool avoidFerries = false,
  }) async {
    lastError = null;
    if (!offlineOnly && engine == RoutingEngine.online) {
      final routes = await onlineProvider.calculateRoutes(
        origin: origin,
        destination: destination,
        exclude: _osrmExclude(avoidTolls, avoidHighways, avoidFerries),
      );
      if (routes.isEmpty) {
        lastError = onlineProvider.lastError ??
            AppStrings.getForLanguage(_ref.read(languageProvider),
                'route_error_online_failed_generic');
      }
      return routes;
    }

    String? offlineError;
    for (final provider in await _offlineProvidersFor(origin, destination)) {
      final routes = await provider.calculateRoutes(
        origin: origin,
        destination: destination,
        offlineOnly: true,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
        avoidTrafficZones: avoidTrafficZones,
        avoidHighways: avoidHighways,
      );
      if (routes.isNotEmpty) return routes;
      offlineError ??= provider.lastError;
    }
    lastError =
        offlineError ?? 'برای مسیریابی، ابتدا یک نقشهٔ آفلاین ABM نصب کنید.';
    return const <RouteInfo>[];
  }

  void dispose() {
    _onlineProvider?.dispose();
  }
}
