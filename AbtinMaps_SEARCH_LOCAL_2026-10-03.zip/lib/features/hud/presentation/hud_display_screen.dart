import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../core/abm_debug_log.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/geo/geo_types.dart';
import '../../../core/localization/app_localizations.dart';
import '../../../core/theme/app_colors.dart';
import '../../gps/data/location_service.dart';
import '../../gps/presentation/gps_providers.dart';
import '../../routing/data/routing_service.dart'
    show RouteAlert, RouteAlertType, RouteInstruction;
import '../../routing/presentation/routing_providers.dart';
import '../domain/hud_maneuver_icon.dart';
import 'hud_settings_providers.dart';
import 'flat_phone_provider.dart';
import 'hud_bold_icon.dart';
import 'hud_live_data.dart';

/// نزدیک‌ترین [RouteAlert] جلوی خودرو، در بازهٔ [maxDistanceM] و در مخروطِ
/// جلوی heading — همان الگویی که home_screen.dart برای نشان‌دادن هشدار
/// جاده روی نقشهٔ اصلی استفاده می‌کند، اینجا برای بلاکِ HUD تکرار شده تا
/// آیکونِ ثابتِ قبلی (که به هیچ داده‌ای وصل نبود) با یک هشدارِ واقعی
/// جایگزین شود.
RouteAlert? nearestAheadRouteAlert(
  ActiveNavigation? nav,
  VehiclePosition? position, {
  double maxDistanceM = 300.0,
  double maxBearingDeltaDeg = 70.0,
}) {
  if (nav == null || position == null) return null;
  RouteAlert? best;
  var bestDistance = double.infinity;
  for (final alert in nav.route.alerts) {
    final distance = _hudDistanceM(
      position.lat,
      position.lng,
      alert.location.latitude,
      alert.location.longitude,
    );
    if (distance > maxDistanceM || distance >= bestDistance) continue;
    if (position.headingDeg.isFinite) {
      final bearing = _hudBearingDeg(
        position.lat,
        position.lng,
        alert.location.latitude,
        alert.location.longitude,
      );
      final delta = ((bearing - position.headingDeg + 540) % 360) - 180;
      if (delta.abs() > maxBearingDeltaDeg) continue;
    }
    best = alert;
    bestDistance = distance;
  }
  return best;
}

IconData hudAlertIcon(RouteAlertType type) {
  switch (type) {
    case RouteAlertType.speedCamera:
      return Icons.camera_alt_rounded;
    case RouteAlertType.speedBump:
      return Icons.warning_amber_rounded;
    case RouteAlertType.policeCheckpoint:
      return Icons.local_police_rounded;
    case RouteAlertType.trafficLight:
      return Icons.traffic_rounded;
  }
}

double _hudDistanceM(double lat1, double lng1, double lat2, double lng2) {
  const r = 6371000.0;
  final dLat = (lat2 - lat1) * math.pi / 180.0;
  final dLng = (lng2 - lng1) * math.pi / 180.0;
  final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
      math.cos(lat1 * math.pi / 180.0) *
          math.cos(lat2 * math.pi / 180.0) *
          math.sin(dLng / 2) *
          math.sin(dLng / 2);
  return r * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
}

double _hudBearingDeg(double lat1, double lng1, double lat2, double lng2) {
  final p1 = lat1 * math.pi / 180.0;
  final p2 = lat2 * math.pi / 180.0;
  final dl = (lng2 - lng1) * math.pi / 180.0;
  final y = math.sin(dl) * math.cos(p2);
  final x =
      math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl);
  return (math.atan2(y, x) * 180.0 / math.pi + 360.0) % 360.0;
}

/// نمایشِ واقعیِ HUD حین رانندگی.
///
/// قبلاً این صفحه فلشِ «مستقیم» را ثابت نشان می‌داد (رجوع کنید به تصویرِ
/// باگ). حالا آیکونِ جهت از [hudManeuverIcon] و از رویِ دستورِ واقعیِ
/// ناوبریِ جاری (`activeNavigationProvider`) ساخته می‌شود؛ یعنی برای هر
/// میدان یا پیچ به هر سمت، همان جهتِ واقعی (چپ/راست/تند/ملایم/میدان/دور زدن)
/// نمایش داده می‌شود، نه یک فلشِ یکسان برای همه‌ی حالت‌ها.
class HudDisplayScreen extends ConsumerStatefulWidget {
  const HudDisplayScreen({super.key});

  @override
  ConsumerState<HudDisplayScreen> createState() => _HudDisplayScreenState();
}

class _HudDisplayScreenState extends ConsumerState<HudDisplayScreen> {
  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    super.dispose();
  }

  void _validateHudConditions(HudSettings settings, ActiveNavigation? nav) {
    if (settings.enabled && nav != null) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && context.canPop()) context.pop();
    });
  }

  String _compassLabel(double? headingDeg, String Function(String) t) {
    if (headingDeg == null) return '--';
    const keys = [
      'hud_dir_n',
      'hud_dir_ne',
      'hud_dir_e',
      'hud_dir_se',
      'hud_dir_s',
      'hud_dir_sw',
      'hud_dir_w',
      'hud_dir_nw',
    ];
    final idx = (((headingDeg % 360) + 22.5) / 45).floor() % 8;
    return t(keys[idx]);
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(hudSettingsProvider);
    final nav = ref.watch(activeNavigationProvider);
    // بعد از باز شدن، HUD فقط با دکمهٔ ضربدر بسته می‌شود؛ لرزش/شیب دیگر
    // آن را نمی‌بندد.
    // همان منبعِ سرعت‌سنجِ صفحهٔ اصلی (جریان نرم و مسیر-محور)؛ اگر هنوز چیزی
    // نداشت، GPS خام.
    final navPos = ref.watch(navigationPositionProvider).valueOrNull;
    final rawPos = ref.watch(vehiclePositionProvider).valueOrNull;
    final sharedLimit = ref.watch(hudSpeedLimitProvider);
    final sharedAlert = ref.watch(hudNextAlertProvider);
    final accent = AppColors.primaryAccent(context);
    _validateHudConditions(settings, nav);
    String t(String key) => AppStrings.get(context, ref, key);

    final vehiclePosition = navPos ?? rawPos;
    final speedKmh = vehiclePosition?.speedKmh ?? 0;
    final headingDeg = vehiclePosition?.headingDeg;
    final instruction = nav?.currentInstruction;
    final aheadAlert =
        sharedAlert ?? nearestAheadRouteAlert(nav, vehiclePosition);
    final speedLimit = instruction?.speedLimit ?? sharedLimit;

    final scale = (settings.scalePercent / 100).clamp(0.5, 1.3);
    final brightness = (settings.brightnessPercent / 100).clamp(0.10, 1.0);

    String dist(double meters) => meters >= 1000
        ? AppStrings.getWithParams(context, ref, 'route_distance_km',
            {'value': (meters / 1000).toStringAsFixed(1)})
        : AppStrings.getWithParams(
            context, ref, 'route_distance_m', {'value': meters.round()});
    final appName = t('hud_app_name');
    // letterSpacing روی متن فارسی حروف را از هم جدا می‌کند.
    final latinOnly = RegExp(r'^[\x00-\x7F]+$').hasMatch(appName);

    Widget content = Container(
      color: Colors.black,
      child: SafeArea(
        child: Opacity(
          opacity: brightness,
          child: Align(
            alignment: Alignment(
              settings.horizontalOffset,
              settings.verticalOffset,
            ),
            child: Transform.scale(
              scale: scale,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: LayoutBuilder(
                  builder: (context, box) => FittedBox(
                    fit: BoxFit.scaleDown,
                    child: SizedBox(
                      width: box.maxWidth,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (settings.showSpeed)
                                _SpeedBlock(
                                  speedKmh: speedKmh,
                                  unit: t('hud_speed_unit'),
                                ),
                              if (settings.showSpeedLimit && speedLimit != null) ...[
                                if (settings.showSpeed) const SizedBox(width: 18),
                                _SpeedLimitCircle(
                                  limit: speedLimit,
                                  over: speedKmh > speedLimit,
                                ),
                              ],
                              const Spacer(),
                              if (settings.showCompassHeading)
                                _CompassBlock(
                                    label: _compassLabel(headingDeg, t)),
                            ],
                          ),
                          const SizedBox(height: 10),
                          if (nav != null &&
                              (settings.showNextManeuver ||
                                  settings.showDistanceToManeuver))
                            _ManeuverBlock(
                              accent: accent,
                              instruction: instruction,
                              distanceLabel: dist(nav.distanceToNextManeuverM),
                              showIcon: settings.showNextManeuver,
                              showDistance: settings.showDistanceToManeuver,
                              arrivedLabel: t('hud_arrived'),
                            )
                          else if (settings.showNextManeuver)
                            Text(
                              t('hud_no_active_navigation'),
                              style: const TextStyle(
                                  color: Colors.white38, fontSize: 18),
                            ),
                          if (settings.showOtherInfo && nav != null) ...[
                            const SizedBox(height: 8),
                            Text(
                              '${t('hud_remaining')}: ${dist(nav.remainingDistanceKm * 1000)}',
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                          // این آیکون از nav.route.alerts (خطرِ روی نقشه، مثلِ
                          // دوربینِ سرعت/سرعت‌گیر) می‌آید و با showRouteAlerts
                          // کنترل می‌شود.
                          if (settings.showRouteAlerts && aheadAlert != null) ...[
                            const SizedBox(height: 10),
                            HudBoldIcon(hudAlertIcon(aheadAlert.type),
                                color: Colors.amber, size: 44, boldness: 0.06),
                          ],
                          const SizedBox(height: 14),
                          Text(
                            appName,
                            style: TextStyle(
                              color: accent.withOpacity(0.8),
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              letterSpacing: latinOnly ? 3 : 0,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    if (settings.mirrorImage) {
      content = Transform(
        alignment: Alignment.center,
        transform: Matrix4.identity()..scale(-1.0, 1.0, 1.0),
        child: content,
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(child: content),
          Positioned(
            top: 8,
            right: 8,
            child: IconButton(
              icon: const Icon(Icons.close_rounded, color: Colors.white54),
              onPressed: () => context.pop(),
            ),
          ),
        ],
      ),
    );
  }
}

class _SpeedBlock extends StatelessWidget {
  const _SpeedBlock({required this.speedKmh, required this.unit});
  final double speedKmh;
  final String unit;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            speedKmh.round().toString(),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 64,
              fontWeight: FontWeight.w900,
              height: 1,
            ),
          ),
          Text(unit,
              style: const TextStyle(color: Colors.white70, fontSize: 15)),
        ],
      );
}

class _SpeedLimitCircle extends StatelessWidget {
  const _SpeedLimitCircle({required this.limit, this.over = false});
  final int limit;
  final bool over;

  @override
  Widget build(BuildContext context) => Container(
        width: 78,
        height: 78,
        margin: const EdgeInsets.only(top: 4),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: over ? Colors.red : Colors.white,
          border: Border.all(color: Colors.red, width: 7),
        ),
        child: Text(
          '$limit',
          style: TextStyle(
              color: over ? Colors.white : Colors.black,
              fontWeight: FontWeight.w900,
              fontSize: 30),
        ),
      );
}

class _CompassBlock extends StatelessWidget {
  const _CompassBlock({required this.label});
  final String label;

  @override
  Widget build(BuildContext context) => Column(
        children: [
          const HudBoldIcon(Icons.explore_rounded,
              color: Colors.lightBlueAccent, size: 30, boldness: 0.05),
          const SizedBox(height: 2),
          Text(label,
              style: const TextStyle(
                  color: Colors.lightBlueAccent,
                  fontSize: 17,
                  fontWeight: FontWeight.w800)),
        ],
      );
}

/// بلاکِ مرکزیِ HUD: آیکونِ جهتِ واقعیِ پیچ/میدان بعدی (نه یک فلشِ ثابت)
/// به‌همراهِ فاصله تا آن.
class _ManeuverBlock extends StatelessWidget {
  const _ManeuverBlock({
    required this.accent,
    required this.instruction,
    required this.distanceLabel,
    required this.showIcon,
    required this.showDistance,
    required this.arrivedLabel,
  });

  final Color accent;
  final RouteInstruction? instruction;
  final String distanceLabel;
  final bool showIcon;
  final bool showDistance;
  final String arrivedLabel;

  @override
  Widget build(BuildContext context) {
    final instr = instruction;
    if (instr == null) return const SizedBox.shrink();
    final String type = instr.type;
    final String? modifier = instr.modifier;
    final bool arrived = type == 'arrive';

    return Column(
      children: [
        if (showIcon)
          Transform.rotate(
            angle:
                arrived ? 0 : hudManeuverRotationRadiansIfPlain(type, modifier),
            child: HudBoldIcon(
              hudManeuverIcon(type, modifier),
              color: accent,
              size: 130,
            ),
          ),
        const SizedBox(height: 4),
        if (arrived)
          Text(
            arrivedLabel,
            style: TextStyle(
                color: accent, fontSize: 30, fontWeight: FontWeight.w900),
          )
        else if (showDistance)
          Text(
            distanceLabel,
            style: TextStyle(
                color: accent, fontSize: 40, fontWeight: FontWeight.w900),
          ),
      ],
    );
  }
}

/// [hudManeuverIcon] برای اکثرِ حالت‌ها آیکونِ اختصاصیِ صحیح برمی‌گرداند
/// (که خودش چرخیده است)، پس نیازی به چرخشِ اضافه نیست. این تابع فقط صفر
/// برمی‌گرداند تا در آینده اگر خواستیم برای آیکونِ ساده‌ی فلش هم چرخش
/// دستی اضافه کنیم، به‌جای دستکاریِ ویجت بالا همین‌جا تغییر بدهیم.
double hudManeuverRotationRadiansIfPlain(String type, String? modifier) => 0;
