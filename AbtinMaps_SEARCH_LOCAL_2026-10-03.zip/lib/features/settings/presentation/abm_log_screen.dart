import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';

import '../../../core/abm_debug_log.dart';
import '../../../core/localization/app_localizations.dart';

class AbmLogScreen extends StatefulWidget {
  const AbmLogScreen({super.key});

  @override
  State<AbmLogScreen> createState() => _AbmLogScreenState();
}

class _AbmLogScreenState extends State<AbmLogScreen> {
  String? _tag;
  static const _tags = ['MAP', 'ROUTE', 'POI', 'HUD'];

  @override
  Widget build(BuildContext context) {
    final text = AbmDebugLog.merged()
        .where((line) => _tag == null || line.contains('[$_tag]'))
        .join('\n');
    return Scaffold(
      appBar: AppBar(
        title: Text(AppStrings.literal('گزارش')),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () =>
              context.canPop() ? context.pop() : context.go('/settings'),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => setState(() {}),
          ),
          IconButton(
            icon: const Icon(Icons.copy_rounded),
            onPressed: () => Clipboard.setData(ClipboardData(text: text)),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded),
            onPressed: () => setState(AbmDebugLog.clear),
          ),
        ],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              children: [
                for (final tag in [null, ..._tags])
                  Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: ChoiceChip(
                      label: Text(tag ?? 'ALL'),
                      selected: _tag == tag,
                      onSelected: (_) => setState(() => _tag = tag),
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(12),
              child: SelectableText(
                text.isEmpty ? '—' : text,
                textDirection: TextDirection.ltr,
                style: const TextStyle(fontSize: 11, fontFamily: 'monospace'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
