import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../localization/app_localizations.dart';
import 'app_update_service.dart';

String _sizeLabel(int bytes) =>
    bytes <= 0 ? '' : ' (${(bytes / (1024 * 1024)).toStringAsFixed(0)} MB)';

Future<void> openAppUpdate(AppUpdateInfo info) async {
  final apk = Uri.parse(info.downloadUrl);
  var ok = false;
  try {
    ok = await launchUrl(apk, mode: LaunchMode.externalApplication);
  } catch (_) {}
  if (!ok) {
    try {
      await launchUrl(Uri.parse(info.releasePageUrl),
          mode: LaunchMode.externalApplication);
    } catch (_) {}
  }
}

/// پنجرهٔ هشدار به‌روزرسانی. true یعنی کاربر «به‌روزرسانی» را زد.
Future<bool> showAppUpdateDialog(BuildContext context, AppUpdateInfo info) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: Text(AppStrings.literal('نسخهٔ جدید آبتین‌مپ')),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'نسخهٔ ${info.latestVersion} منتشر شده است '
                '(نسخهٔ شما: ${info.currentVersion})'
                '${_sizeLabel(info.apkSizeBytes)}',
              ),
              if (info.notes.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text(
                  info.notes.length > 600
                      ? '${info.notes.substring(0, 600)}…'
                      : info.notes,
                  style: Theme.of(ctx).textTheme.bodySmall,
                ),
              ],
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(AppStrings.literal('بعداً')),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(AppStrings.literal('به‌روزرسانی')),
          ),
        ],
      ),
    ),
  );
  if (result == true) await openAppUpdate(info);
  return result == true;
}
