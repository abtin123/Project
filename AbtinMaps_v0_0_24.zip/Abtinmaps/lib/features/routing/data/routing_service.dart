import 'dart:math' as math;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:abtin_maps/core/geo/geo_types.dart';
import '../../../core/localization/app_localizations.dart';

import '../../../shared/providers/abtinmap_providers.dart';
import '../../../shared/providers/app_settings_providers.dart';
import '../../gps/data/road_snapper.dart';
import '../domain/road_block.dart';
import '../../../routing/routing_engine.dart' show RouteCancelToken;
import 'abtinmap_routing_provider.dart';
import 'online_routing_provider.dart';
import 'routing_provider.dart';

class RouteInfo {
  const RouteInfo({
    required this.geometry,
    required this.distanceKm,
    required this.durationMin,
    required this.instructions,
    this.alerts = const [],
  });

  final List<LatLng> geometry;
  final double distanceKm;
  final double durationMin;
  final List<RouteInstruction> instructions;
  final List<RouteAlert> alerts;
}

enum RouteAlertType { speedCamera, speedBump, policeCheckpoint, trafficLight }

class RouteAlert {
  const RouteAlert({required this.type, required this.location, this.name});
  final RouteAlertType type;
  final LatLng location;
  final String? name;
}

class RouteInstruction {
  const RouteInstruction({
    required this.text,
    required this.distanceMeters,
    required this.location,
    required this.type,
    this.modifier,
    this.exit,
    this.roundaboutAngleDegrees,
    this.roundaboutExitCount,
    this.roundaboutBranchAngles = const [],
    this.roundaboutEntranceAngles = const [],
    this.roundaboutExitAngles = const [],
    this.roundaboutActiveExitAngle,
    this.drivingSide = 'right',
    this.speedLimit,
    this.maneuverEndLocation,
    this.maneuverAngleDegrees,
    this.turnLanes = '',
  });

  /// OSM turn:lanes before the maneuver ("left|through|through;right"), or ''.
  final String turnLanes;

  final String text;
  final double distanceMeters;
  final LatLng location;
  final String type;
  final String? modifier;
  final int? exit;
  final double? roundaboutAngleDegrees;

  final int? roundaboutExitCount;

  final List<double> roundaboutBranchAngles;
  final List<double> roundaboutEntranceAngles;
  final List<double> roundaboutExitAngles;
  final double? roundaboutActiveExitAngle;

  final String drivingSide;
  final int? speedLimit;

  final LatLng? maneuverEndLocation;

  final double? maneuverAngleDegrees;
}

class RoutingService {
  RoutingService(this._ref);

  final Ref _ref;
  OnlineRoutingProvider? _onlineProvider;
  String? lastError;

  RoutingEngine get engine => _ref.read(routingEngineProvider);

  final Map<String, AbtinmapRoutingProvider> _abmProviders =
      <String, AbtinmapRoutingProvider>{};

  /// Set by [_offlineProvidersFor] when no installed map can serve the trip.
  String? _coverageError;

  AbtinmapRoutingProvider _abmProviderFor(
    String mapName, [
    List<String> extraMapNames = const <String>[],
  ]) =>
      _abmProviders.putIfAbsent(
        extraMapNames.isEmpty ? mapName : '$mapName|${extraMapNames.join(',')}',
        () => AbtinmapRoutingProvider(
          mapService: _ref.read(abmMapServiceProvider),
          vectorMapService: _ref.read(vectorMapServiceProvider),
          mapName: mapName,
          extraMapNames: extraMapNames,
          languageCode: () => _ref.read(languageProvider),
          leftHandTraffic: () => RoadSnapper.instance.leftHandTraffic,
        ),
      );

  /// Chooses the offline map(s) for a trip.
  ///
  /// Province maps are built from the same OSM data (shared node/way ids) and each
  /// graph reaches `routing_overlap_degrees` beyond its province, so neighbouring
  /// maps are searched together as ONE graph. A short trip fully covered by a single
  /// map keeps the fast single-map path.
  Future<List<AbtinmapRoutingProvider>> _offlineProvidersFor(
    LatLng origin,
    LatLng destination,
  ) async {
    final sources = await _ref.read(installedOfflineMapSourcesProvider.future);
    if (sources.isEmpty) {
      final activeMap = _ref.read(abmActiveMapNameProvider).trim();
      return <AbtinmapRoutingProvider>[_abmProviderFor(activeMap)];
    }
    final vector = _ref.read(vectorMapServiceProvider);
    _coverageError = null;
    const tol = 0.02;
    bool inBox(List<double> b, LatLng p) =>
        p.longitude >= b[0] - tol &&
        p.longitude <= b[2] + tol &&
        p.latitude >= b[1] - tol &&
        p.latitude <= b[3] + tol;
    final boxes = <_MapBox>[];
    final unknown = <OfflineMapSource>[];
    for (final source in sources) {
      final box = await offlineMapBbox(vector, source);
      if (box == null) {
        unknown.add(source);
        continue;
      }
      final rbox = await offlineMapRoutingBbox(vector, source) ?? box;
      boxes.add(_MapBox(source, box, rbox));
    }
    // Maps without bbox metadata cannot be reasoned about: keep the old behaviour.
    if (boxes.isEmpty) {
      return <AbtinmapRoutingProvider>[
        for (final source in unknown) _abmProviderFor(source.fileName),
      ];
    }
    final coverO = <_MapBox>[
      for (final b in boxes)
        if (inBox(b.routeBox, origin)) b,
    ];
    final coverD = <_MapBox>[
      for (final b in boxes)
        if (inBox(b.routeBox, destination)) b,
    ];
    if (coverO.isEmpty || coverD.isEmpty) {
      _coverageError = coverO.isEmpty && coverD.isEmpty
          ? 'مبدأ و مقصد هیچ‌کدام داخل نقشه‌های آفلاین نصب‌شده نیستند.'
          : coverD.isEmpty
              ? 'مقصد داخل نقشه‌های آفلاین نصب‌شده نیست. نقشه‌ی منطقه‌ی مقصد را دانلود کنید.'
              : 'مبدأ داخل نقشه‌های آفلاین نصب‌شده نیست. نقشه‌ی منطقه‌ی مبدأ را دانلود کنید.';
      return const <AbtinmapRoutingProvider>[];
    }
    final spanDeg = math.max(
      (origin.latitude - destination.latitude).abs(),
      (origin.longitude - destination.longitude).abs(),
    );
    // Prefer the map whose province really contains the origin.
    _MapBox pickPrimary(List<_MapBox> from) => from.firstWhere(
          (b) => inBox(b.box, origin),
          orElse: () => from.first,
        );
    final single = <_MapBox>[
      for (final b in coverO)
        if (inBox(b.routeBox, destination)) b,
    ];
    if (single.isNotEmpty && spanDeg < 1.0) {
      return <AbtinmapRoutingProvider>[
        _abmProviderFor(pickPrimary(single).source.fileName),
      ];
    }

    // Joint search: every installed map whose graph touches a window around the trip.
    final margin = math.min(1.5, math.max(0.35, spanDeg * 0.2));
    final wMinLon = math.min(origin.longitude, destination.longitude) - margin;
    final wMaxLon = math.max(origin.longitude, destination.longitude) + margin;
    final wMinLat = math.min(origin.latitude, destination.latitude) - margin;
    final wMaxLat = math.max(origin.latitude, destination.latitude) + margin;
    final window = <_MapBox>[
      for (final b in boxes)
        if (!(b.routeBox[2] < wMinLon ||
            b.routeBox[0] > wMaxLon ||
            b.routeBox[3] < wMinLat ||
            b.routeBox[1] > wMaxLat))
          b,
    ];
    // Distance (degrees) from a map's centre to the straight line origin->destination.
    double chordDistance(_MapBox b) {
      final ax = origin.longitude, ay = origin.latitude;
      final bx = destination.longitude, by = destination.latitude;
      final dx = bx - ax, dy = by - ay;
      final len2 = dx * dx + dy * dy;
      var t = len2 == 0
          ? 0.0
          : ((b.centerLon - ax) * dx + (b.centerLat - ay) * dy) / len2;
      t = t.clamp(0.0, 1.0).toDouble();
      final px = ax + dx * t, py = ay + dy * t;
      final ex = b.centerLon - px, ey = b.centerLat - py;
      return math.sqrt(ex * ex + ey * ey);
    }

    window.sort((a, b) => chordDistance(a).compareTo(chordDistance(b)));
    // Distance (degrees) from the origin->destination chord to a map's graph extent.
    double chordToBox(_MapBox b) {
      final r = b.routeBox;
      var best = double.infinity;
      for (var i = 0; i <= 32; i++) {
        final t = i / 32;
        final x = origin.longitude + (destination.longitude - origin.longitude) * t;
        final y = origin.latitude + (destination.latitude - origin.latitude) * t;
        final dx = math.max(math.max(r[0] - x, 0.0), x - r[2]);
        final dy = math.max(math.max(r[1] - y, 0.0), y - r[3]);
        final d = math.sqrt(dx * dx + dy * dy);
        if (d < best) best = d;
      }
      return best;
    }

    List<_MapBox> withEndpoints(List<_MapBox> base) {
      final out = List<_MapBox>.of(base);
      for (final b in <_MapBox>[...coverO, ...coverD]) {
        if (!out.contains(b)) out.add(b);
      }
      return out;
    }

    // Narrow corridor around the chord first: opening fewer maps keeps the graph small.
    final corridor = math.min(1.0, math.max(0.3, spanDeg * 0.10));
    var chosen = withEndpoints(<_MapBox>[
      for (final b in window)
        if (chordToBox(b) <= corridor) b,
    ].take(14).toList());
    // Fail fast when the chosen maps are not connected (a province map in between
    // is missing): searching would only run until the time budget expires.
    bool overlaps(_MapBox a, _MapBox b) =>
        !(a.routeBox[2] < b.routeBox[0] ||
            b.routeBox[2] < a.routeBox[0] ||
            a.routeBox[3] < b.routeBox[1] ||
            b.routeBox[3] < a.routeBox[1]);
    Set<_MapBox> reachedFrom(List<_MapBox> set) {
      final seen = <_MapBox>{...coverO};
      final queue = <_MapBox>[...coverO];
      while (queue.isNotEmpty) {
        final cur = queue.removeLast();
        for (final b in set) {
          if (seen.contains(b) || !overlaps(cur, b)) continue;
          seen.add(b);
          queue.add(b);
        }
      }
      return seen;
    }

    var reached = reachedFrom(chosen);
    if (!coverD.any(reached.contains)) {
      // Corridor left a gap: fall back to the wide window.
      chosen = withEndpoints(window.take(14).toList());
      reached = reachedFrom(chosen);
    }
    if (!coverD.any(reached.contains)) {
      _coverageError =
          'بین مبدأ و مقصد نقشه‌ی یکی از استان‌های مسیر نصب نشده است. '
          'نقشه‌ی استان‌های میان‌راه را هم دانلود کنید.';
      return const <AbtinmapRoutingProvider>[];
    }
    final primary = pickPrimary(coverO);
    final extras = <String>[
      for (final b in chosen)
        if (b != primary && reached.contains(b)) b.source.fileName,
    ];
    return <AbtinmapRoutingProvider>[_abmProviderFor(primary.source.fileName, extras)];
  }

  OnlineRoutingProvider get onlineProvider =>
      _onlineProvider ??= OnlineRoutingProvider(
        languageCode: () => _ref.read(languageProvider),
      );

  static List<String> _osrmExclude(bool tolls, bool highways, bool ferries) =>
      [if (tolls) 'toll', if (highways) 'motorway', if (ferries) 'ferry'];

  Future<RouteInfo?> calculateRoute({
    required LatLng origin,
    required LatLng destination,
    bool offlineOnly = false,
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
    bool avoidTrafficZones = false,
    bool avoidHighways = false,
    bool avoidFerries = false,
    int routeMode = 0,
    List<RoadBlock> roadBlocks = const <RoadBlock>[],
  }) async {
    lastError = null;
    if (!offlineOnly && engine == RoutingEngine.online) {
      final route = await onlineProvider.calculateRoute(
        origin: origin,
        destination: destination,
        exclude: _osrmExclude(avoidTolls, avoidHighways, avoidFerries),
        roadBlocks: roadBlocks,
      );
      if (route != null) return route;
      lastError = onlineProvider.lastError ??
          AppStrings.getForLanguage(
              _ref.read(languageProvider), 'route_error_online_failed_generic');
      return null;
    }

    String? offlineError;
    final providers = await _offlineProvidersFor(origin, destination);
    for (final provider in providers) {
      final route = await provider.calculateRoute(
        origin: origin,
        destination: destination,
        offlineOnly: true,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
        avoidTrafficZones: avoidTrafficZones,
        avoidHighways: avoidHighways,
        routeMode: routeMode,
        blockedPolylines: <List<LatLng>>[
          for (final b in roadBlocks) b.polyline,
        ],
      );
      if (route != null) return route;
      offlineError ??= provider.lastError;
    }
    lastError = offlineError ??
        _coverageError ??
        AppStrings.getForLanguage(
            _ref.read(languageProvider), 'route_error_offline_map_missing');
    return null;
  }

  Future<List<RouteInfo>> calculateRoutes({
    required LatLng origin,
    required LatLng destination,
    bool offlineOnly = false,
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
    bool avoidTrafficZones = false,
    bool avoidHighways = false,
    bool avoidFerries = false,
    int routeMode = 0,
  }) async {
    lastError = null;
    if (!offlineOnly && engine == RoutingEngine.online) {
      final routes = await onlineProvider.calculateRoutes(
        origin: origin,
        destination: destination,
        exclude: _osrmExclude(avoidTolls, avoidHighways, avoidFerries),
      );
      if (routes.isEmpty) {
        lastError = onlineProvider.lastError ??
            AppStrings.getForLanguage(_ref.read(languageProvider),
                'route_error_online_failed_generic');
      }
      return routes;
    }

    String? offlineError;
    final providers = await _offlineProvidersFor(origin, destination);
    for (final provider in providers) {
      final routes = await provider.calculateRoutes(
        origin: origin,
        destination: destination,
        offlineOnly: true,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
        avoidTrafficZones: avoidTrafficZones,
        avoidHighways: avoidHighways,
        routeMode: routeMode,
      );
      if (routes.isNotEmpty) return routes;
      offlineError ??= provider.lastError;
    }
    lastError =
        offlineError ??
        _coverageError ??
        'برای مسیریابی، ابتدا یک نقشهٔ آفلاین ABM نصب کنید.';
    return const <RouteInfo>[];
  }

  Stream<List<RouteInfo>> calculateRoutesStream({
    required LatLng origin,
    required LatLng destination,
    bool offlineOnly = false,
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
    bool avoidTrafficZones = false,
    bool avoidHighways = false,
    bool avoidFerries = false,
    int routeMode = 0,
    RouteCancelToken? cancel,
  }) async* {
    if (!offlineOnly && engine == RoutingEngine.online) {
      final routes = await calculateRoutes(
        origin: origin,
        destination: destination,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
        avoidTrafficZones: avoidTrafficZones,
        avoidHighways: avoidHighways,
        avoidFerries: avoidFerries,
        routeMode: routeMode,
      );
      yield routes;
      return;
    }
    lastError = null;
    String? offlineError;
    final providers = await _offlineProvidersFor(origin, destination);
    for (final provider in providers) {
      var any = false;
      await for (final routes in provider.calculateRoutesStream(
        origin: origin,
        destination: destination,
        offlineOnly: true,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
        avoidTrafficZones: avoidTrafficZones,
        avoidHighways: avoidHighways,
        routeMode: routeMode,
        cancel: cancel,
      )) {
        if (routes.isEmpty) continue;
        any = true;
        yield routes;
      }
      if (any) return;
      offlineError ??= provider.lastError;
    }
    lastError =
        offlineError ??
        _coverageError ??
        'برای مسیریابی، ابتدا یک نقشهٔ آفلاین ABM نصب کنید.';
    yield const <RouteInfo>[];
  }

  /// Builds one continuous route through ordered intermediate stops and the
  /// final destination. Each leg uses the same routing engine and preferences.
  Future<RouteInfo?> calculateMultiStopRoute({
    required LatLng origin,
    required List<LatLng> stops,
    required LatLng destination,
    bool offlineOnly = false,
    bool avoidUnpavedRoads = false,
    bool avoidTolls = false,
    bool avoidTrafficZones = false,
    bool avoidHighways = false,
    bool avoidFerries = false,
    int routeMode = 0,
    List<RoadBlock> roadBlocks = const <RoadBlock>[],
  }) async {
    final waypoints = <LatLng>[...stops, destination];
    var legOrigin = origin;
    final geometry = <LatLng>[];
    final instructions = <RouteInstruction>[];
    final alerts = <RouteAlert>[];
    var distanceKm = 0.0;
    var durationMin = 0.0;

    for (final legDestination in waypoints) {
      final leg = await calculateRoute(
        origin: legOrigin,
        destination: legDestination,
        offlineOnly: offlineOnly,
        avoidUnpavedRoads: avoidUnpavedRoads,
        avoidTolls: avoidTolls,
        avoidTrafficZones: avoidTrafficZones,
        avoidHighways: avoidHighways,
        avoidFerries: avoidFerries,
        routeMode: routeMode,
        roadBlocks: roadBlocks,
      );
      if (leg == null || leg.geometry.length < 2) return null;
      for (final point in leg.geometry) {
        if (geometry.isEmpty ||
            _distanceMeters(geometry.last, point) > 1.0) {
          geometry.add(point);
        }
      }
      instructions.addAll(leg.instructions);
      alerts.addAll(leg.alerts);
      distanceKm += leg.distanceKm;
      durationMin += leg.durationMin;
      legOrigin = legDestination;
    }
    if (geometry.length < 2) return null;
    return RouteInfo(
      geometry: List<LatLng>.unmodifiable(geometry),
      distanceKm: distanceKm,
      durationMin: durationMin,
      instructions: List<RouteInstruction>.unmodifiable(instructions),
      alerts: List<RouteAlert>.unmodifiable(alerts),
    );
  }

  double _distanceMeters(LatLng a, LatLng b) {
    const radius = 6371000.0;
    final dLat = (b.latitude - a.latitude) * math.pi / 180.0;
    final dLon = (b.longitude - a.longitude) * math.pi / 180.0;
    final lat1 = a.latitude * math.pi / 180.0;
    final lat2 = b.latitude * math.pi / 180.0;
    final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1) * math.cos(lat2) *
            math.sin(dLon / 2) * math.sin(dLon / 2);
    return radius * 2 * math.atan2(math.sqrt(h), math.sqrt(1 - h));
  }

  void dispose() {
    _onlineProvider?.dispose();
  }
}

class _MapBox {
  const _MapBox(this.source, this.box, this.routeBox);
  final OfflineMapSource source;

  /// Published province bbox: minLon, minLat, maxLon, maxLat
  final List<double> box;

  /// Routing graph extent (province polygon + overlap buffer), same order.
  final List<double> routeBox;
  double get centerLat => (box[1] + box[3]) / 2;
  double get centerLon => (box[0] + box[2]) / 2;
}
