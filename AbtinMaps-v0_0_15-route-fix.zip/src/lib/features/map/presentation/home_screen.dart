import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart' show Clipboard, PlatformException;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:maplibre_gl/maplibre_gl.dart' as native_maplibre;
import 'package:go_router/go_router.dart';
import 'package:abtin_maps/core/geo/geo_types.dart';

import '../../../abtinmap/abm_models.dart';
import '../../../abtinmap/abm_saved_places.dart';
import '../../routing/data/routing_provider.dart';
import '../../../core/deep_link/deep_link_service.dart';
import '../../../core/update/app_update_dialog.dart';
import '../../../core/update/app_update_service.dart';
import '../../../core/permissions/location_permission_flow.dart';
import '../../../core/theme/app_colors.dart';
import '../../../shared/providers/app_settings_providers.dart';
import '../../../shared/providers/app_notice_provider.dart';
import '../../../shared/providers/map_style_providers.dart';
import '../../../shared/providers/abm_poi_visibility_providers.dart';
import '../../../shared/providers/abtinmap_providers.dart';
import '../../settings/presentation/settings_repository_provider.dart';
import '../../settings/presentation/appearance_settings_providers.dart'
    show
        appearanceSettingsProvider,
        AppearanceTab,
        mapTiltProvider,
        navigationCameraTiltProvider,
        vehicleViewAngleProvider,
        routeColorHexProvider,
        routeLineStyleProvider;
import '../../hud/presentation/flat_phone_provider.dart';
import '../../hud/presentation/hud_settings_providers.dart'
    show hudSettingsProvider;
import '../../hud/presentation/hud_live_data.dart';
import '../../../shared/widgets/bottom_nav.dart';
import '../../../shared/widgets/glass_panel.dart';
import '../../../shared/widgets/glass_notice.dart';
import '../../../shared/widgets/route_guidance_card.dart';
import '../../../shared/widgets/route_shape_arrow.dart';
import '../../gps/data/location_service.dart';
import '../../gps/data/offline_road_snap_service.dart';
import '../../gps/data/driving_side.dart';
import '../../gps/data/road_snapper.dart';
import '../../gps/presentation/gps_providers.dart';
import '../../history/presentation/history_providers.dart';
import '../../offline_maps/data/region_resolver.dart';
import '../../offline_maps/data/map_catalog.dart' show MapRegion;
import '../../offline_maps/presentation/offline_maps_providers.dart';
import 'online_map_view.dart';
import '../../routing/data/routing_service.dart';
import '../../routing/domain/maneuver_geometry.dart';
import '../../routing/data/road_safety_service.dart';
import '../../routing/presentation/routing_providers.dart';
import '../../routing/presentation/road_alert_badge.dart';
import '../../routing/presentation/roundabout_dynamic.dart';
import '../../vehicle/presentation/modern_speedometer.dart';
import '../../vehicle/presentation/vehicle_provider.dart';
import '../../voice_settings/data/voice_pack_fa.dart';
import '../../voice_settings/presentation/tts_providers.dart';
import 'destination_provider.dart';
import '../../../shared/providers/share_service.dart';
import '../../../core/localization/app_localizations.dart';
import '../../saved_places/presentation/home_work_widgets.dart';
import '../../saved_places/presentation/saved_places_providers.dart';
import '../../settings/data/settings_repository.dart';
import '../../system_info/presentation/unified_status_map_overlay.dart';
import '../../search/presentation/search_overlay.dart';
import '../../search/presentation/search_providers.dart';

import 'package:abtin_maps/shared/widgets/app_icon.dart';

Color _hexToColorOrDefault(String hex, String fallback) {
  String normalized(String value) => value.trim().replaceFirst('#', '');

  final candidate = normalized(hex);
  final fallbackValue = normalized(fallback);
  final value = candidate.length == 6 || candidate.length == 8
      ? candidate
      : fallbackValue;
  final argb = value.length == 6 ? 'FF$value' : value;
  final parsed = int.tryParse(argb, radix: 16);
  return Color(
    parsed ??
        int.parse(
          fallbackValue.length == 6 ? 'FF$fallbackValue' : fallbackValue,
          radix: 16,
        ),
  );
}

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _RouteSample {
  const _RouteSample(this.point, this.headingDeg, this.progressMeters);
  final LatLng point;
  final double headingDeg;
  final double progressMeters;
}

class _SegmentProjection {
  const _SegmentProjection({
    required this.t,
    required this.segmentMeters,
    required this.distanceMeters,
  });
  final double t;
  final double segmentMeters;
  final double distanceMeters;
}

class _RouteMatch {
  const _RouteMatch({required this.segmentIndex, required this.projection});
  final int segmentIndex;
  final _SegmentProjection projection;
  double get distanceMeters => projection.distanceMeters;
}

class _HomeScreenState extends ConsumerState<HomeScreen>
    with WidgetsBindingObserver {
  bool _cameraFollowsVehicle = true;
  int _gpsFocusRequest = 0;
  bool _didCenterOnFirstFix = false;
  bool _arrivalHandled = false;
  int _lastSpokenInstructionIndex = -1;

  final Set<int> _spokenStages = <int>{};

  final Set<String> _beepedRouteAlerts = <String>{};
  DateTime? _lastAlertBeepAt;

  int _offRouteStrikeCount = 0;
  DateTime? _offRouteSince;
  bool _isRerouting = false;
  int _navSession = 0;
  Timer? _arrivalStopTimer;
  DateTime? _lastRerouteAt;
  VehiclePosition? _previousValidationPosition;
  DateTime? _previousValidationAt;
  double? _recentMovementBearingDeg;

  final RoadSafetyService _roadSafetyService = RoadSafetyService();
  RoadSafetySnapshot _roadSafety = const RoadSafetySnapshot();
  VehiclePosition? _normalSnappedVehiclePosition;
  DateTime? _normalSnapSourceAt;
  int _normalSnapRequest = 0;
  final OfflineRoadSnapService _offlineRoadSnapService =
      OfflineRoadSnapService();

  DateTime? _lastRoadSafetyUpdate;
  LatLng? _lastRoadSafetyCenter;
  bool _roadSafetyRequestInFlight = false;

  ({RouteAlert alert, double distanceM})? _transientRoadAlert;
  Timer? _transientRoadAlertTimer;
  final Map<String, DateTime> _shownRoadAlertKeys = <String, DateTime>{};

  List<AbmSavedPlace> _savedPlacesForMap = const <AbmSavedPlace>[];

  static const double _movingAlertDistanceM = 300.0;
  static const double _movingAlertMinSpeedKmh = 5.0;

  bool _styleLoaded = false;
  bool _hudAutoOpening = false;
  bool _hudConditionsWereMet = false;
  String? _hudLastSignature;

  bool _showMapRetry = false;
  Timer? _mapLoadTimeoutTimer;
  int _mapReloadKey = 0;

  bool _hasReceivedGpsFix = false;
  bool _showGpsStuckBanner = false;
  Timer? _gpsAcquireWatchdog;

  void _armGpsAcquireWatchdog() {
    if (_hasReceivedGpsFix || _gpsAcquireWatchdog != null) return;
    _gpsAcquireWatchdog = Timer(const Duration(seconds: 20), () {
      if (mounted && !_hasReceivedGpsFix) {
        setState(() => _showGpsStuckBanner = true);
      }
    });
  }

  void _onFirstGpsFixReceived() {
    if (_hasReceivedGpsFix) return;
    _hasReceivedGpsFix = true;
    _gpsAcquireWatchdog?.cancel();
    _transientRoadAlertTimer?.cancel();
    _gpsAcquireWatchdog = null;
    if (_showGpsStuckBanner && mounted) {
      setState(() => _showGpsStuckBanner = false);
    }
  }

  void _retryGpsAcquire() {
    setState(() => _showGpsStuckBanner = false);
    _gpsAcquireWatchdog?.cancel();
    _transientRoadAlertTimer?.cancel();
    _gpsAcquireWatchdog = null;
    ref.read(locationRepositoryProvider).start();
    _armGpsAcquireWatchdog();
  }

  Timer? _persistCameraDebounceTimer;

  CameraPosition? _lastKnownCamera;
  final ValueNotifier<double> _mapBearingDegrees = ValueNotifier<double>(0);

  static const CameraPosition _initialCamera = CameraPosition(
    target: LatLng(32.5, 54.0),
    zoom: 5.1,
    tilt: 0,
    bearing: 0,
  );

  Future<void> _reloadSavedPlacesForMap() async {
    dynamic repo = ref.read(savedPlacesRepositoryProvider);
    dynamic rows;

    Future<dynamic> tryCall(FutureOr<dynamic> Function() call) async {
      try {
        final value = await call();
        if (value is Stream) return await value.first;
        return value;
      } catch (_) {
        return null;
      }
    }

    rows = await tryCall(() => repo.getAll());
    rows ??= await tryCall(() => repo.getAllPlaces());
    rows ??= await tryCall(() => repo.list());
    rows ??= await tryCall(() => repo.loadAll());
    rows ??= await tryCall(() => repo.watchAll());
    rows ??= await tryCall(() => repo.all());
    rows ??= await tryCall(() => repo.getPlaces());
    rows ??= await tryCall(() => repo.savedPlaces);
    rows ??= await tryCall(() => repo.places);
    rows ??= await tryCall(() => repo.items);
    if (rows is! Iterable) return;

    double? asDouble(dynamic value) {
      if (value is num) return value.toDouble();
      return double.tryParse('${value ?? ''}');
    }

    AbmSavedPlace? decode(dynamic row) {
      dynamic lat;
      dynamic lon;
      dynamic name;
      dynamic category;
      if (row is Map) {
        lat = row['latitude'] ?? row['lat'];
        lon = row['longitude'] ?? row['lng'] ?? row['lon'];
        name = row['name'] ?? row['title'] ?? row['label'];
        category = row['category'];
      } else {
        try {
          lat = row.latitude;
        } catch (_) {}
        try {
          lat ??= row.lat;
        } catch (_) {}
        try {
          lon = row.longitude;
        } catch (_) {}
        try {
          lon ??= row.lng;
        } catch (_) {}
        try {
          lon ??= row.lon;
        } catch (_) {}
        try {
          name = row.name;
        } catch (_) {}
        try {
          name ??= row.title;
        } catch (_) {}
        try {
          category = row.category;
        } catch (_) {}
      }
      final latitude = asDouble(lat);
      final longitude = asDouble(lon);
      if (latitude == null || longitude == null) return null;
      return AbmSavedPlace(
        latitude: latitude,
        longitude: longitude,
        name: '${name ?? ''}'.trim(),
        category: '${category ?? 'favorite'}'.trim(),
      );
    }

    final next = <AbmSavedPlace>[];
    for (final row in rows) {
      final place = decode(row);
      if (place != null) next.add(place);
    }
    if (!mounted) return;
    setState(() => _savedPlacesForMap = List<AbmSavedPlace>.unmodifiable(next));
  }

  Future<void> _restoreSavedMapCamera() async {
    final repo = ref.read(settingsRepositoryProvider);
    final lat = await repo.getDouble(
      SettingsRepository.keyLastMapCenterLat,
      fallback: _initialCamera.target.latitude,
    );
    final lng = await repo.getDouble(
      SettingsRepository.keyLastMapCenterLng,
      fallback: _initialCamera.target.longitude,
    );
    final zoom = await repo.getDouble(
      SettingsRepository.keyLastMapZoom,
      fallback: _initialCamera.zoom,
    );
    final bearing = await repo.getDouble(
      SettingsRepository.keyLastMapBearing,
      fallback: _initialCamera.bearing,
    );
    final tilt = await repo.getDouble(
      SettingsRepository.keyLastMapTilt,
      fallback: _initialCamera.tilt,
    );
    final followsVehicle = await repo.getBool(
      SettingsRepository.keyLastMapFollowVehicle,
      fallback: true,
    );

    final restored = CameraPosition(
      target: LatLng(lat, lng),
      zoom: zoom.clamp(2.0, 16.0).toDouble(),
      bearing: bearing,
      tilt: tilt.clamp(0.0, 60.0).toDouble(),
    );

    _lastKnownCamera = restored;
    _mapBearingDegrees.value = restored.bearing;
    _cameraFollowsVehicle = followsVehicle;
    if (!followsVehicle) {
      _didCenterOnFirstFix = true;
    }
    if (mounted) setState(() {});
  }

  CameraPosition _currentLogicalCamera() => _lastKnownCamera ?? _initialCamera;

  void _persistMapCameraSoon() {
    _persistCameraDebounceTimer?.cancel();
    _persistCameraDebounceTimer = Timer(
      const Duration(milliseconds: 450),
      _persistMapCameraNow,
    );
  }

  Future<void> _persistMapCameraNow() async {
    final repo = ref.read(settingsRepositoryProvider);
    final camera = _currentLogicalCamera();
    await repo.setDouble(
      SettingsRepository.keyLastMapCenterLat,
      camera.target.latitude,
    );
    await repo.setDouble(
      SettingsRepository.keyLastMapCenterLng,
      camera.target.longitude,
    );
    await repo.setDouble(SettingsRepository.keyLastMapZoom, camera.zoom);
    await repo.setDouble(SettingsRepository.keyLastMapBearing, camera.bearing);
    await repo.setDouble(SettingsRepository.keyLastMapTilt, camera.tilt);
    await repo.setBool(
      SettingsRepository.keyLastMapFollowVehicle,
      _cameraFollowsVehicle,
    );
  }

  VehiclePosition? _resolveVehiclePosition(AsyncValue<VehiclePosition> live) {
    return live.valueOrNull;
  }

  List<LatLng>? _routeMatchGeometry;
  List<double>? _routeMatchCumulativeM;
  int? _routeMatchLastSegment;
  double? _routeMatchLastProgressM;
  DateTime? _routeMatchHoldSince;

  List<RouteAlert>? _routeAlertsSource;
  List<double>? _routeAlertsProgressM;

  List<RouteInstruction>? _routeInstructionsSource;
  List<double>? _routeInstructionsProgressM;

  // شکلِ فلشِ مانورِ فعلی (برای نقشه و کارت). به ازای هر دستور یک‌بار ساخته می‌شود.
  List<LatLng>? _maneuverShapeGeometry;
  List<double>? _maneuverShapeCum;
  int _maneuverShapeIndex = -1;
  ManeuverShape? _maneuverShape;

  // فلشِ مانورِ روی نقشه (جدا از کارت): پیچ بعدیِ واقعی، حتی وقتی دستور فعلی
  // «شروع حرکت» یا «ادامه دهید» است.
  static const double _maneuverArrowRangeM = 450.0;
  List<LatLng>? _mapArrowGeometry;
  List<double>? _mapArrowCum;
  int _mapArrowIndex = -1;
  ManeuverShape? _mapArrowShape;

  double get _alertDisplayRangeM =>
      ref.read(voiceFirstAlertDistanceProvider).clamp(50.0, 1000.0).toDouble();

  Timer? _longTunnelWatchTimer;
  VehiclePosition? _lastNavigationSignal;
  DateTime? _lastNavigationSignalAt;
  VehiclePosition? _tunnelEstimatedPosition;
  DateTime? _tunnelEstimateStartedAt;
  DateTime? _lastTunnelEstimateAt;
  double _tunnelRouteProgressM = 0;
  bool _longTunnelEstimateExhausted = false;
  static const Duration _longTunnelSilenceBeforeStart = Duration(seconds: 5);
  static const Duration _maxLongTunnelEstimate = Duration(seconds: 25);
  static const double _minimumTunnelEstimateSpeedKmh = 8;

  void _startMapLoadWatchdog() {
    _mapLoadTimeoutTimer?.cancel();
    _showMapRetry = false;
    _mapLoadTimeoutTimer = Timer(const Duration(seconds: 20), () {
      if (mounted && !_styleLoaded) {
        setState(() => _showMapRetry = true);
      }
    });
  }

  void _retryMapLoad() {
    unawaited(native_maplibre.clearAmbientCache().catchError((error) {}));
    setState(() {
      _styleLoaded = false;
      _showMapRetry = false;
      _mapReloadKey++;
    });
    _startMapLoadWatchdog();
  }

  void _markMapStyleLoaded() {
    _mapLoadTimeoutTimer?.cancel();
    if (!mounted || (_styleLoaded && !_showMapRetry)) return;
    setState(() {
      _styleLoaded = true;
      _showMapRetry = false;
    });
  }

  void _onNativeCameraPosition(native_maplibre.CameraPosition camera) {
    final bearing = camera.bearing.isFinite ? camera.bearing % 360.0 : 0.0;
    _lastKnownCamera = CameraPosition(
      target: LatLng(camera.target.latitude, camera.target.longitude),
      zoom: camera.zoom,
      bearing: bearing,
      tilt: camera.tilt,
    );
    if ((_mapBearingDegrees.value - bearing).abs() > 0.05) {
      _mapBearingDegrees.value = bearing;
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _startMapLoadWatchdog();
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkForAppUpdate());
    final selectedVehicleIndex = ref
        .read(appearanceSettingsProvider)
        .vehicleModelIndex
        .clamp(0, vehicleModels.length - 1)
        .toInt();
    unawaited(warmUpVehicleModel(selectedVehicleIndex));
    _drivingModeSubscription = null;
    unawaited(_restoreSavedMapCamera());
    unawaited(_reloadSavedPlacesForMap());
    _syncTunnelTimer(ref.read(activeNavigationProvider) != null);
  }

  void _syncTunnelTimer(bool navigating) {
    if (!navigating) {
      _longTunnelWatchTimer?.cancel();
      _longTunnelWatchTimer = null;
      return;
    }
    _longTunnelWatchTimer ??= Timer.periodic(
      const Duration(milliseconds: 250),
      (_) => _advanceLongTunnelEstimate(),
    );
  }

  StreamSubscription? _drivingModeSubscription;

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
  }

  void _maybeOpenHudAutomatically({
    required bool hudEnabled,
    required bool navigationActive,
    required bool canAttemptOpenHud,
  }) {
    final conditionsMet = hudEnabled && navigationActive && canAttemptOpenHud;
    final risingEdge = conditionsMet && !_hudConditionsWereMet;
    final signature = '$hudEnabled/$navigationActive/$canAttemptOpenHud';
    if (signature != _hudLastSignature) {
      _hudLastSignature = signature;
    }
    _hudConditionsWereMet = conditionsMet;
    if (!risingEdge || _hudAutoOpening || !mounted) {
      if (conditionsMet && _hudAutoOpening) {}
      return;
    }
    _hudAutoOpening = true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        if (!mounted) {
          return;
        }
        await context.push('/hud-display');
      } catch (e, st) {
      } finally {
        _hudAutoOpening = false;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    ref.listen(activeNavigationProvider, (previous, next) {
      if (next != null) return;
      final controller = ref.read(navigationPositionControllerProvider);
      if (!controller.isRouteDriven) return;
      final gps = ref.read(vehiclePositionProvider).valueOrNull ??
          ref.read(navigationPositionProvider).valueOrNull;
      if (gps != null) {
        controller.resetToFreeDrive(gps);
      } else {
        controller.clearActiveRoute();
      }
      ref.read(locationServiceProvider).ensureAlive();
    });
    final readiness = ref.watch(locationReadinessProvider);
    final destination = ref.watch(selectedDestinationProvider);
    ref.listen(savedPlacesListProvider, (_, __) => _reloadSavedPlacesForMap());
    final activeNav = ref.watch(activeNavigationProvider);
    final hudEnabled = ref.watch(hudSettingsProvider).enabled;
    _maybeOpenHudAutomatically(
      hudEnabled: hudEnabled,
      navigationActive: activeNav != null,
      canAttemptOpenHud: ref.watch(canAttemptOpenHudProvider),
    );
    final searchActive = ref.watch(searchActiveProvider);
    final routeCandidatesAsync = ref.watch(calculateRoutesProvider);
    final routeCandidates =
        !searchActive && activeNav == null && destination != null
            ? (routeCandidatesAsync.valueOrNull ?? const <RouteInfo>[])
            : const <RouteInfo>[];
    final routeOptionsLoading = !searchActive &&
        activeNav == null &&
        destination != null &&
        routeCandidatesAsync.isLoading;
    final selectedRouteCandidateIndex = ref.watch(
      selectedRouteCandidateIndexProvider,
    );
    final selectedRouteIndex = routeCandidates.isEmpty
        ? 0
        : selectedRouteCandidateIndex.clamp(0, routeCandidates.length - 1);
    final routingEngine = ref.watch(routingEngineProvider);
    final bool isDarkMap =
        ref.watch(mapStyleModeProvider) == MapStyleMode.night;
    final bool requestedOffline = routingEngine != RoutingEngine.online;
    final offlineFile = requestedOffline
        ? ref.watch(activeOfflineMapFileProvider).valueOrNull
        : null;
    final bool isOfflineMode = requestedOffline && offlineFile != null;
    final ResolvedMapStyle? resolvedStyleResult =
        ref.watch(resolvedMapStyleFileProvider).valueOrNull;
    final String? resolvedStyle = (resolvedStyleResult != null &&
            resolvedStyleResult.offline == isOfflineMode)
        ? resolvedStyleResult.path
        : null;
    final abmPoiVisibility = ref.watch(abmPoiVisibilityProvider);
    final abmInstalledSources = isOfflineMode
        ? ref.watch(installedOfflineMapSourcesProvider).valueOrNull
        : null;
    final Color resolvedRouteColor = _hexToColorOrDefault(
      ref.watch(routeColorHexProvider),
      kRouteColorHexes[0],
    );
    final routeWidth = ref.watch(routeWidthProvider);
    final mapPerspective = ref.watch(mapPerspectiveProvider);
    final idleMapTilt = ref.watch(mapTiltProvider);
    final markerAppearance = ref.watch(appearanceSettingsProvider);
    final carDrivesCamera = markerAppearance.activeTab == AppearanceTab.car;
    final carViewAngle =
        ref.watch(vehicleViewAngleProvider).clamp(0.0, 60.0).toDouble();
    final mapCameraTilt = carDrivesCamera
        ? carViewAngle
        : (activeNav != null
            ? ref
                .watch(navigationCameraTiltProvider)
                .clamp(0.0, 60.0)
                .toDouble()
            : (mapPerspective == MapPerspective.threeD
                ? idleMapTilt.clamp(0.0, 60.0).toDouble()
                : 0.0));
    final offlineMapPalette = ref.watch(currentOfflineMapPaletteProvider);
    ref.watch(installedMapRegionsProvider); // keep alive for _updateDrivingSide
    ref.listen<AsyncValue<VehiclePosition>>(vehiclePositionProvider, (
      prev,
      next,
    ) {
      next.whenData((pos) {
        _updateDrivingSide(pos);
        final navigation = ref.read(activeNavigationProvider);
        _acceptNavigationSignal(pos);
        _onFirstGpsFixReceived();
        if (ref.read(activeNavigationProvider) == null) {
          unawaited(_refreshNormalRoadSnap(pos));
        }
        unawaited(_refreshRoadSafety(pos));
        if (!_didCenterOnFirstFix) {
          _didCenterOnFirstFix = true;
          if (mounted) setState(() => _gpsFocusRequest++);
        }
        if (navigation != null) {
          final animated =
              ref.read(navigationPositionProvider).valueOrNull ?? pos;
          _updateNavigationProgress(
            animated,
            navigation,
            gpsValidationPosition: pos,
          );
        }
      });
    });

    ref.listen<AsyncValue<LocationReadiness>>(locationReadinessProvider, (
      prev,
      next,
    ) {
      next.whenData((state) {
        if (state == LocationReadiness.ready) {
          _armGpsAcquireWatchdog();
        } else {
          _gpsAcquireWatchdog?.cancel();
          _transientRoadAlertTimer?.cancel();
          _gpsAcquireWatchdog = null;
          if (_showGpsStuckBanner) {
            _showGpsStuckBanner = false;
          }
        }
      });
    });

    ref.listen(activeNavigationProvider, (prev, next) {
      _syncTunnelTimer(next != null);
    });
    ref.listen<SelectedDestination?>(selectedDestinationProvider, (prev, next) {
      if (next != null && prev?.point != next.point) {
        ref.read(selectedRouteCandidateIndexProvider.notifier).state = 0;
        setState(() => _cameraFollowsVehicle = false);
        _persistMapCameraSoon();
      }

      if (next?.autoStart == true && prev?.autoStart != true) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;
          if (ref.read(activeNavigationProvider) != null) {
            _stopNavigation();
            ref.read(selectedDestinationProvider.notifier).state = next;
            return;
          }
          final current = ref.read(selectedDestinationProvider);
          if (current?.point != next?.point || current?.autoStart != true)
            return;
          unawaited(_startNavigationWhenReady());
        });
      }
    });

    final canPopHome = destination == null && activeNav == null;

    return PopScope(
      canPop: canPopHome,
      onPopInvoked: (didPop) {
        if (didPop) return;
        if (activeNav != null) {
          _stopNavigation();
        } else if (destination != null) {
          ref.read(selectedDestinationProvider.notifier).state = null;
        }
      },
      child: Scaffold(
        backgroundColor: AppColors.frameBackground(context),
        body: Stack(
          children: [
            Positioned(
              left: 0,
              right: 0,
              top: 0,
              bottom: math.max(
                MediaQuery.paddingOf(context).bottom,
                MediaQuery.viewPaddingOf(context).bottom,
              ),
              child: resolvedStyle == null
                  ? Container(
                      color: isDarkMap
                          ? const Color(0xFF0b1014)
                          : const Color(0xFFcfe0e8),
                      alignment: Alignment.center,
                      child: const CircularProgressIndicator(),
                    )
                  : Consumer(
                      builder: (context, mapRef, _) {
                        final liveVehiclePosition = _resolveVehiclePosition(
                          mapRef.watch(navigationPositionProvider),
                        );
                        final snapIsFresh = _normalSnapSourceAt != null &&
                            DateTime.now().difference(_normalSnapSourceAt!) <
                                const Duration(seconds: 3);
                        final useLegacySnap = !RoadSnapper.instance.enabled ||
                            !RoadSnapper.instance.hasRoads;
                        final baseVehiclePosition = activeNav == null
                            ? (snapIsFresh && useLegacySnap
                                ? (_normalSnappedVehiclePosition ??
                                    liveVehiclePosition)
                                : liveVehiclePosition)
                            : liveVehiclePosition;
                        final matchedVehiclePosition =
                            activeNav != null && baseVehiclePosition != null
                                ? (_matchPositionToRoute(
                                      baseVehiclePosition,
                                      activeNav.route.geometry,
                                    ) ??
                                    baseVehiclePosition)
                                : baseVehiclePosition;
                        final vehiclePosition = matchedVehiclePosition == null
                            ? null
                            : VehiclePosition(
                                lat: matchedVehiclePosition.lat,
                                lng: matchedVehiclePosition.lng,
                                headingDeg: activeNav != null
                                    ? matchedVehiclePosition.headingDeg
                                    : ((RoadSnapper.instance.enabled &&
                                                RoadSnapper
                                                    .instance.hasRoads) ||
                                            matchedVehiclePosition.speedKmh >=
                                                3.0
                                        ? matchedVehiclePosition.headingDeg
                                        : (_roadSafety.roadHeadingDeg ??
                                            matchedVehiclePosition.headingDeg)),
                                speedKmh: matchedVehiclePosition.speedKmh,
                                accuracyM: matchedVehiclePosition.accuracyM,
                                isEstimated: matchedVehiclePosition.isEstimated,
                              );
                        final canFollowVehicle =
                            _cameraFollowsVehicle && vehiclePosition != null;
                        // فلش مانور وقتی پیچ نزدیک است (یا داخل میدان هستیم) روی
                        // مسیر کشیده می‌شود، مثل نقشه‌های مسیریابی معمول.
                        final maneuverShape = activeNav == null
                            ? null
                            : _routeManeuverShapeFor(activeNav);
                        final showManeuverArrow = maneuverShape != null;
                        return OnlineMapView(
                          key: ValueKey(
                            isOfflineMode
                                ? 'offline-map-${offlineFile!.path}-$resolvedStyle-$_mapReloadKey'
                                : 'online-map-$resolvedStyle-$_mapReloadKey',
                          ),
                          vehiclePosition: vehiclePosition,
                          showCarModel:
                              markerAppearance.activeTab == AppearanceTab.car,
                          modelIndex: markerAppearance.vehicleModelIndex
                              .clamp(0, vehicleModels.length - 1)
                              .toInt(),
                          isDark: isDarkMap,
                          followVehicle: canFollowVehicle,
                          drivingMode: activeNav != null,
                          markerColor: markerAppearance.pinColor,
                          pinSizePercent: markerAppearance.pinSize,
                          carSizePercent: markerAppearance.carSizePercent,
                          pinShadowEnabled: markerAppearance.pinShadowEnabled,
                          cameraTiltDegrees: mapCameraTilt,
                          carCameraAngleDegrees: mapCameraTilt,
                          locationFocusRequest: _gpsFocusRequest,
                          palette: offlineMapPalette,
                          visiblePoiKlasses: abmPoiVisibility,
                          trafficLights: const <LatLng>[],
                          roadAlerts: _roadAlertsForMap(activeNav),
                          savedPlaces: _savedPlacesForMap,
                          onPoiTap: (properties) {
                            if (!mounted) return;
                            final name =
                                '${properties['name'] ?? properties['name_fa'] ?? properties['name_en'] ?? ''}'
                                    .trim();
                            final category =
                                '${properties['category'] ?? properties['class'] ?? ''}'
                                    .trim();
                            final hours =
                                '${properties['opening_hours'] ?? ''}'.trim();
                            final lines = <String>[
                              name.isEmpty ? 'مکان' : name,
                              if (category.isNotEmpty) _poiCategoryFa(category),
                              if (hours.isNotEmpty) hours,
                            ];
                            showGlassNotice(
                              context,
                              lines.join('\n'),
                              icon: Icons.place_rounded,
                              colors: const [
                                Color(0xFF7C5CFF),
                                Color(0xFF4F8CFF),
                              ],
                              duration: const Duration(seconds: 4),
                            );
                          },
                          localStylePath: resolvedStyle,
                          abmFile: isOfflineMode ? offlineFile : null,
                          abmSources: abmInstalledSources,
                          abmCountry: isOfflineMode
                              ? ref.read(activeOfflineMapIdProvider)
                              : null,
                          routeGeometry: activeNav?.route.geometry,
                          routeProgressMeters: activeNav == null
                              ? null
                              : (_routeMatchLastProgressM ??
                                  _projectLatLngProgressMeters(
                                    LatLng(
                                      vehiclePosition!.lat,
                                      vehiclePosition.lng,
                                    ),
                                    activeNav.route.geometry,
                                  )),
                          routeOverlays: !searchActive &&
                                  destination != null &&
                                  activeNav == null &&
                                  routeCandidates.isNotEmpty
                              ? [
                                  for (var index = 0;
                                      index < routeCandidates.length &&
                                          index < 3;
                                      index++)
                                    OnlineRouteOverlay(
                                      geometry: routeCandidates[index].geometry,
                                      color: index == selectedRouteIndex
                                          ? resolvedRouteColor
                                          : const Color(0xFF99B4C1)
                                              .withValues(alpha: 0.62),
                                      width: index == selectedRouteIndex
                                          ? routeWidth + 2
                                          : routeWidth,
                                      kind: index == selectedRouteIndex
                                          ? OnlineRouteKind.route
                                          : OnlineRouteKind.alternative,
                                    ),
                                ]
                              : null,
                          maneuverArrow:
                              showManeuverArrow ? maneuverShape : null,
                          routeColor: resolvedRouteColor,
                          routeWidth: routeWidth,
                          routeLineStyle: markerAppearance.routeLineStyle.name,
                          routeGlowIntensity: kRouteNeonGlowIntensity,
                          destination: destination?.point,
                          onLongPress: (point) {
                            ref
                                .read(selectedDestinationProvider.notifier)
                                .state = SelectedDestination(
                              point,
                            );
                            _takeManualCameraControl();
                          },
                          onRouteTap: (index) => ref
                              .read(
                                selectedRouteCandidateIndexProvider.notifier,
                              )
                              .state = index,
                          onUserGestureStart: _takeManualCameraControl,
                          onCameraIdle: _persistMapCameraSoon,
                          onCameraPositionChanged: _onNativeCameraPosition,
                          onStyleLoaded: _markMapStyleLoaded,
                        );
                      },
                    ),
            ),

            Builder(
              builder: (context) {
                final screenSize = MediaQuery.of(context).size;
                final clusterWidth = screenSize.width * 0.32;
                final clusterBottom = screenSize.height * 0.115 +
                    MediaQuery.viewPaddingOf(context).bottom;
                final speedometerSize = clusterWidth * 0.66;
                final osmWidth = speedometerSize * 0.82;
                const osmHeight = 30.0;
                const gap = 12.0;
                final osmLeft =
                    screenSize.width * 0.02 + (speedometerSize - osmWidth) / 2;
                final osmRadius = BorderRadius.circular(osmHeight / 2);

                return Positioned(
                  left: osmLeft,
                  bottom: clusterBottom - osmHeight - gap,
                  width: osmWidth,
                  height: osmHeight,
                  child: ClipRRect(
                    borderRadius: osmRadius,
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
                      child: Material(
                        color: Colors.white.withOpacity(0.08),
                        child: InkWell(
                          onTap: () async {
                            try {
                              await launchUrl(
                                Uri.parse(
                                  'https://www.openstreetmap.org/copyright',
                                ),
                                mode: LaunchMode.externalApplication,
                              );
                            } catch (_) {}
                          },
                          child: Ink(
                            decoration: BoxDecoration(
                              borderRadius: osmRadius,
                              border: Border.all(
                                color: Colors.white.withOpacity(0.22),
                                width: 1,
                              ),
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  Colors.white.withOpacity(0.14),
                                  Colors.white.withOpacity(0.04),
                                ],
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              textDirection: TextDirection.ltr,
                              children: const [
                                Text(
                                  '\u00A9',
                                  textDirection: TextDirection.ltr,
                                  style: TextStyle(
                                    color: Color(0xE6FFFFFF),
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    height: 1.0,
                                  ),
                                ),
                                SizedBox(width: 4),
                                Text(
                                  'OSM',
                                  textDirection: TextDirection.ltr,
                                  maxLines: 1,
                                  style: TextStyle(
                                    color: Color(0xF2FFFFFF),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    height: 1.0,
                                    letterSpacing: 0.3,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),

            const UnifiedStatusMapOverlay(),

            if (_showMapRetry && !_styleLoaded)
              Positioned(
                top: MediaQuery.of(context).padding.top +
                    5 +
                    (activeNav != null
                        ? 140
                        : (destination != null
                            ? 108
                            : (readiness.valueOrNull != null &&
                                    readiness.valueOrNull !=
                                        LocationReadiness.ready
                                ? 64
                                : 12))),
                left: 24,
                right: 24,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 10,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.glassPanel(context),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: Colors.white.withOpacity(.12),
                        ),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black45,
                            blurRadius: 16,
                            offset: Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          const AppIcon(
                            Icons.cloud_off_rounded,
                            color: Colors.white70,
                            size: 16,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              AppStrings.literal('اتصال نقشه کند است…'),
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                              ),
                            ),
                          ),
                          GestureDetector(
                            onTap: _retryMapLoad,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                gradient: AppColors.primaryGradient(context),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                AppStrings.literal('تلاش دوباره'),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 11,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

            Positioned(
              top: MediaQuery.of(context).padding.top +
                  5 +
                  (activeNav != null ? 140 : (destination != null ? 108 : 12)),
              left: 24,
              right: 24,
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                transitionBuilder: (child, anim) => FadeTransition(
                  opacity: anim,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, -0.3),
                      end: Offset.zero,
                    ).animate(anim),
                    child: child,
                  ),
                ),
                child: readiness.when(
                  data: (state) => state != LocationReadiness.ready
                      ? _GpsWarningBanner(
                          key: ValueKey('gps-$state'),
                          state: state,
                        )
                      : (_showGpsStuckBanner
                          ? _GpsStuckBanner(
                              key: const ValueKey('gps-stuck'),
                              onRetry: _retryGpsAcquire,
                            )
                          : (activeNav != null &&
                                  _tunnelEstimatedPosition != null
                              ? const _EstimatedLocationBanner(
                                  key: ValueKey('location-estimated'),
                                )
                              : const SizedBox.shrink(
                                  key: ValueKey('gps-ok'),
                                ))),
                  loading: () =>
                      const SizedBox.shrink(key: ValueKey('gps-loading')),
                  error: (_, __) =>
                      const SizedBox.shrink(key: ValueKey('gps-error')),
                ),
              ),
            ),

            if (!searchActive && destination != null && activeNav == null)
              Positioned(
                top: MediaQuery.of(context).padding.top + 8.0,
                left: 16.0,
                right: 16.0,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _DestinationCard(
                      destination: destination,
                      onSavedPlacesChanged: _reloadSavedPlacesForMap,
                      onClear: () {
                        ref.read(selectedDestinationProvider.notifier).state =
                            null;
                        _clearRoute();
                      },
                      onStartNavigation: routeOptionsLoading
                          ? null
                          : () => unawaited(
                                _startNavigationNow(
                                  selectedRoute: routeCandidates.isEmpty
                                      ? null
                                      : routeCandidates[selectedRouteIndex],
                                ),
                              ),
                    ),
                    if (routeCandidates.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      _RouteChoiceStrip(
                        routes: routeCandidates.take(3).toList(growable: false),
                        selectedIndex: selectedRouteIndex,
                        onSelect: (index) {
                          ref
                              .read(
                                selectedRouteCandidateIndexProvider.notifier,
                              )
                              .state = index;
                        },
                      ),
                    ],
                  ],
                ),
              ),

            Builder(
              builder: (context) {
                final screenWidth = MediaQuery.sizeOf(context).width;
                final navScale = screenWidth / 1214.0;

                const bottomNavOccupiedHeight = 246.0;
                final systemBottomInset = math.max(
                  MediaQuery.paddingOf(context).bottom,
                  MediaQuery.viewPaddingOf(context).bottom,
                );
                final controlsBottom = systemBottomInset +
                    bottomNavOccupiedHeight * navScale +
                    16.0;
                return Positioned(
                  bottom: controlsBottom,
                  right: 16,
                  child: Column(
                    children: [
                      ValueListenableBuilder<double>(
                        valueListenable: _mapBearingDegrees,
                        builder: (context, bearing, _) =>
                            _Compass(mapBearingDeg: bearing),
                      ),
                      const SizedBox(height: 8),
                      _RoundIconButton(
                        icon: Icons.my_location_rounded,
                        dot: true,
                        onLongPress: () {
                          setState(() {
                            _cameraFollowsVehicle = true;
                            _mapReloadKey++;
                          });
                        },
                        onTap: () {
                          setState(() {
                            _cameraFollowsVehicle = true;
                            _gpsFocusRequest++;
                          });
                          _persistMapCameraSoon();
                        },
                      ),
                      if (activeNav != null && !searchActive) ...[
                        const SizedBox(height: 8),
                        _ArCameraButton(
                          onTap: () => context.push('/ar-navigation'),
                        ),
                        const SizedBox(height: 8),
                        _NavigationCloseButton(onTap: () => _stopNavigation()),
                      ],
                    ],
                  ),
                );
              },
            ),

            Builder(
              builder: (context) {
                final screenSize = MediaQuery.of(context).size;
                final clusterWidth = screenSize.width * 0.32;
                final clusterHeight = screenSize.height * 0.15;
                final clusterBottom = screenSize.height * 0.115 +
                    MediaQuery.viewPaddingOf(context).bottom;
                final clusterLeft = screenSize.width * 0.02;
                final speedometerSize = clusterWidth * 0.66;
                final signSize = clusterWidth * 0.44;

                return Positioned(
                  bottom: clusterBottom,
                  left: clusterLeft,
                  width: clusterWidth,
                  height: clusterHeight,
                  child: Consumer(
                    builder: (context, ref, _) {
                      final currentSpeed = _tunnelEstimatedPosition?.speedKmh ??
                          ref
                              .watch(navigationPositionProvider)
                              .valueOrNull
                              ?.speedKmh ??
                          0;
                      final speedLimit =
                          activeNav?.currentInstruction.speedLimit ??
                              _roadSafety.speedLimitKmh;
                      final showSpeedLimit =
                          speedLimit != null && currentSpeed >= speedLimit - 10;
                      _publishHudLive(
                        speedLimit: speedLimit,
                        alert: _hudPublishedAlert,
                      );
                      return Stack(
                        clipBehavior: Clip.none,
                        children: [
                          if (showSpeedLimit)
                            Positioned(
                              left: clusterWidth * 0.50,
                              bottom: clusterHeight * 0.35,
                              width: signSize,
                              height: signSize,
                              child: _SpeedLimitSign(
                                value: speedLimit.toString(),
                              ),
                            ),
                          Positioned(
                            left: 0,
                            bottom: 0,
                            width: speedometerSize,
                            height: speedometerSize,
                            child: ModernSpeedometer(speedKmh: currentSpeed),
                          ),
                        ],
                      );
                    },
                  ),
                );
              },
            ),

            BottomNav(currentPage: NavKey.home, isHomePage: true),

            if (ref.watch(searchActiveProvider))
              const Positioned.fill(child: SearchOverlay()),

            if (activeNav != null && !searchActive)
              Positioned(
                top: MediaQuery.of(context).padding.top + 8.0,
                left: 16.0,
                right: 16.0,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _ActiveNavigationCard(
                      navigation: activeNav,
                      maneuverShape: _maneuverShapeFor(activeNav),
                      onClose: () => _stopNavigation(),
                    ),
                    Builder(
                      builder: (context) {
                        final alerts = _displayRoadAlerts(activeNav);
                        _publishHudLive(
                          speedLimit: _hudPublishedLimit,
                          alert: alerts.isEmpty ? null : alerts.first.alert,
                        );
                        if (alerts.isEmpty) return const SizedBox.shrink();
                        final appearance = ref.watch(
                          appearanceSettingsProvider,
                        );
                        return Align(
                          alignment: Alignment.topLeft,
                          child: Padding(
                            padding: const EdgeInsets.only(top: 2),
                            child: _RouteAlertSpriteStack(
                              alerts: [for (final item in alerts) item.alert],
                              sizePercent: appearance.routeAlertSizePercent,
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _mapLoadTimeoutTimer?.cancel();
    unawaited(_offlineRoadSnapService.dispose());
    _persistCameraDebounceTimer?.cancel();
    _longTunnelWatchTimer?.cancel();
    _drivingModeSubscription?.cancel();
    _gpsAcquireWatchdog?.cancel();
    _transientRoadAlertTimer?.cancel();
    _mapBearingDegrees.dispose();
    _roadSafetyService.dispose();
    super.dispose();
  }

  static const Map<String, String> _poiCategoryFaMap = {
    'pharmacy': 'داروخانه',
    'chemist': 'داروخانه',
    'hospital': 'بیمارستان',
    'clinic': 'درمانگاه',
    'doctors': 'پزشک',
    'dentist': 'دندان‌پزشک',
    'fuel': 'پمپ بنزین',
    'cafe': 'کافه',
    'restaurant': 'رستوران',
    'fast_food': 'فست‌فود',
    'bank': 'بانک',
    'atm': 'خودپرداز',
    'school': 'مدرسه',
    'university': 'دانشگاه',
    'hotel': 'هتل',
    'parking': 'پارکینگ',
    'bus_stop': 'ایستگاه اتوبوس',
    'mosque': 'مسجد',
    'museum': 'موزه',
    'supermarket': 'سوپرمارکت',
    'bakery': 'نانوایی',
    'police': 'پلیس',
  };

  String _poiCategoryFa(String category) =>
      _poiCategoryFaMap[category.toLowerCase()] ?? category;

  void _showGlassNotice(
    String message, {
    required IconData icon,
    required List<Color> colors,
    Duration duration = const Duration(seconds: 3),
  }) {
    if (!mounted) return;
    final level = colors.contains(Colors.red)
        ? AppNoticeLevel.error
        : colors.contains(Colors.orange)
            ? AppNoticeLevel.warning
            : AppNoticeLevel.info;
    unawaited(
      ref.read(appNoticeProvider.notifier).show(
            title: AppStrings.literal('آبتین مپس'),
            message: message,
            level: level,
          ),
    );
    showGlassNotice(
      context,
      message,
      icon: icon,
      colors: colors,
      duration: duration,
    );
  }

  Future<void> _startNavigationWhenReady() async {
    if (ref.read(activeNavigationProvider) != null) return;
    if (ref.read(vehiclePositionProvider).value == null) {
      final completer = Completer<void>();
      late final ProviderSubscription<AsyncValue<VehiclePosition>> sub;
      sub = ref.listenManual(vehiclePositionProvider, (prev, next) {
        if (next.value != null && !completer.isCompleted) {
          completer.complete();
        }
      });
      try {
        await completer.future.timeout(const Duration(seconds: 8));
      } catch (_) {
      } finally {
        sub.close();
      }
    }
    if (!mounted || ref.read(activeNavigationProvider) != null) return;
    final destination = ref.read(selectedDestinationProvider);
    if (destination?.autoStart != true) return;
    List<RouteInfo> candidates = const [];
    try {
      candidates = await ref.read(calculateRoutesProvider.future);
    } catch (_) {}
    if (!mounted || ref.read(activeNavigationProvider) != null) return;
    final current = ref.read(selectedDestinationProvider);
    if (current?.point != destination?.point || current?.autoStart != true) {
      return;
    }
    if (candidates.length > 1) return;
    unawaited(
      _startNavigationNow(
        selectedRoute: candidates.isEmpty ? null : candidates.first,
      ),
    );
  }

  RouteInfo _rebaseRouteToVehicle(RouteInfo route, VehiclePosition vehicle) {
    final geometry = route.geometry;
    if (geometry.length < 2) return route;

    final match = _bestSegmentMatch(vehicle, geometry, 0, geometry.length - 2);
    if (match == null || match.distanceMeters > 80.0) return route;

    final segment = geometry[match.segmentIndex];
    final next = geometry[match.segmentIndex + 1];
    final t = match.projection.t.clamp(0.0, 1.0).toDouble();
    final projected = LatLng(
      segment.latitude + (next.latitude - segment.latitude) * t,
      segment.longitude + (next.longitude - segment.longitude) * t,
    );

    final rebased = <LatLng>[projected];
    for (var i = match.segmentIndex + 1; i < geometry.length; i++) {
      final point = geometry[i];
      if (_calculateDistance(rebased.last, point) > 0.05) {
        rebased.add(point);
      }
    }
    if (rebased.length < 2) return route;

    final originalDistance = math.max(route.distanceKm, 0.001);
    final remainingDistanceKm = _routeGeometryDistanceKm(rebased);
    final ratio = (remainingDistanceKm / originalDistance).clamp(0.0, 1.0);

    return RouteInfo(
      geometry: List<LatLng>.unmodifiable(rebased),
      distanceKm: remainingDistanceKm,
      durationMin: route.durationMin * ratio,
      instructions: route.instructions,
      alerts: route.alerts,
    );
  }

  double _routeGeometryDistanceKm(List<LatLng> geometry) {
    var meters = 0.0;
    for (var i = 1; i < geometry.length; i++) {
      meters += _calculateDistance(geometry[i - 1], geometry[i]);
    }
    return meters / 1000.0;
  }

  Future<void> _startNavigationNow({RouteInfo? selectedRoute}) async {
    final destination = ref.read(selectedDestinationProvider);
    final vehiclePosition = ref.read(vehiclePositionProvider).value ??
        ref.read(navigationPositionProvider).valueOrNull;

    if (destination == null || vehiclePosition == null) return;

    _navSession++;
    _arrivalStopTimer?.cancel();
    final origin = LatLng(vehiclePosition.lat, vehiclePosition.lng);
    if (AbmTileMath.haversineMeters(
          AbmPoint(origin.longitude, origin.latitude),
          AbmPoint(destination.point.longitude, destination.point.latitude),
        ) <
        20) {
      _showGlassNotice(
        AppStrings.literal('شما همین الان در مقصد هستید.'),
        icon: Icons.flag_rounded,
        colors: const [Colors.teal, Colors.green],
      );
      return;
    }

    _arrivalHandled = false;
    _offRouteStrikeCount = 0;
    _offRouteSince = null;
    _previousValidationPosition = null;
    _previousValidationAt = null;
    _recentMovementBearingDeg = null;
    _spokenStages.clear();
    _beepedRouteAlerts.clear();

    unawaited(
      ref.read(historyRepositoryProvider).addRoute(
            startLat: origin.latitude,
            startLng: origin.longitude,
            endLat: destination.point.latitude,
            endLng: destination.point.longitude,
            endLabel: destination.label,
          ),
    );

    try {
      var route =
          selectedRoute ?? await _computeRoute(origin, destination.point);
      if (!mounted) return;

      var livePosition = ref.read(vehiclePositionProvider).value ??
          ref.read(navigationPositionProvider).valueOrNull ??
          vehiclePosition;

      if (selectedRoute == null &&
          livePosition != null &&
          AbmTileMath.haversineMeters(
                AbmPoint(origin.longitude, origin.latitude),
                AbmPoint(livePosition.lng, livePosition.lat),
              ) >
              30) {
        route = await _computeRoute(
          LatLng(livePosition.lat, livePosition.lng),
          destination.point,
        );
        if (!mounted) return;
      }

      route = _rebaseRouteToVehicle(route, livePosition);
      await _drawRoute(route.geometry);

      livePosition = ref.read(vehiclePositionProvider).value ??
          ref.read(navigationPositionProvider).valueOrNull ??
          livePosition;
      route = _rebaseRouteToVehicle(route, livePosition);

      ref.read(activeNavigationProvider.notifier).setNavigation(
            ActiveNavigation(
              route: route,
              state: NavigationState.navigating,
              remainingDistanceKm: route.distanceKm,
            ),
          );

      ref
          .read(navigationPositionControllerProvider)
          .setActiveRoute(route.geometry, anchor: livePosition);

      if (route.instructions.isNotEmpty && ref.read(ttEnabledProvider)) {
        _lastSpokenInstructionIndex = 0;
        _spokenStages.addAll(const [0, 1]);
        final voice = ref.read(ttsServiceProvider)
          ..setVolume(ref.read(ttsVolumeProvider))
          ..setPlaybackRate(ref.read(ttsRateProvider));
        voice.playCue('route_found');
      }

      setState(() => _cameraFollowsVehicle = true);

      ref.read(drivingModeProvider.notifier).state = true;
    } catch (e) {
      _showGlassNotice(
        AppStrings.literal(
            'خطا در محاسبه مسیر: ${'$e'.replaceFirst(RegExp(r'^Exception:\s*'), '')}'),
        icon: Icons.error_outline_rounded,
        colors: [Colors.red, Colors.orange],
      );
    }
  }

  Future<RouteInfo> _computeRoute(LatLng origin, LatLng destination) async {
    final service = ref.read(routingServiceProvider);
    final route = await service.calculateRoute(
      origin: origin,
      destination: destination,
      avoidUnpavedRoads: ref.read(appearanceSettingsProvider).avoidUnpavedRoads,
      avoidTolls: ref.read(appearanceSettingsProvider).avoidTolls,
      avoidTrafficZones: ref.read(appearanceSettingsProvider).avoidTraffic,
      avoidHighways: ref.read(appearanceSettingsProvider).avoidHighways,
      avoidFerries: ref.read(appearanceSettingsProvider).avoidFerries,
      routeMode: routeModeIndex(
        ref.read(appearanceSettingsProvider).routePlanningMode,
      ),
    );
    if (route != null) return route;
    throw Exception(
      service.lastError ??
          AppStrings.literal('مسیری روی شبکهٔ واقعی جاده‌ها پیدا نشد'),
    );
  }

  void _rerouteOffPath(
    double deviationMeters, {
    VehiclePosition? gpsPosition,
  }) async {
    if (_isRerouting) return;
    _isRerouting = true;
    final session = _navSession;
    bool stale() =>
        !mounted ||
        session != _navSession ||
        ref.read(activeNavigationProvider) == null;
    _lastRerouteAt = DateTime.now();

    // The vehicle stays locked to the current route while the new one is being
    // calculated. Previously adoptGpsAnchor() was called here, which switched the
    // animator to free-drive and left the car roaming if the reroute failed.

    final destination = ref.read(selectedDestinationProvider);
    final vehiclePosition = gpsPosition ??
        ref.read(navigationPositionProvider).valueOrNull ??
        ref.read(vehiclePositionProvider).value;

    if (destination == null || vehiclePosition == null) {
      _isRerouting = false;
      return;
    }

    if (ref.read(alertsVoiceEnabledProvider)) {
      final voice = ref.read(ttsServiceProvider)
        ..setVolume(ref.read(ttsVolumeProvider))
        ..setPlaybackRate(ref.read(ttsRateProvider));
      voice.playCue('off_route');
    }
    _showGlassNotice(
      AppStrings.literal('از مسیر خارج شدید؛ مسیر جدید در حال محاسبه است'),
      icon: Icons.alt_route_rounded,
      colors: const [Color(0xFFF59E0B), Color(0xFFEF4444)],
      duration: const Duration(seconds: 4),
    );

    try {
      final origin = LatLng(vehiclePosition.lat, vehiclePosition.lng);
      var route = await _computeRoute(origin, destination.point);

      if (stale()) return;

      var livePosition = ref.read(vehiclePositionProvider).value ??
          ref.read(navigationPositionProvider).valueOrNull ??
          vehiclePosition;
      if (livePosition != null &&
          AbmTileMath.haversineMeters(
                AbmPoint(origin.longitude, origin.latitude),
                AbmPoint(livePosition.lng, livePosition.lat),
              ) >
              30) {
        route = await _computeRoute(
          LatLng(livePosition.lat, livePosition.lng),
          destination.point,
        );
        if (stale()) return;
      }

      route = _rebaseRouteToVehicle(route, livePosition);
      await _drawRoute(route.geometry);
      if (stale()) return;

      livePosition = ref.read(vehiclePositionProvider).value ??
          ref.read(navigationPositionProvider).valueOrNull ??
          livePosition;
      route = _rebaseRouteToVehicle(route, livePosition);

      ref.read(activeNavigationProvider.notifier).setNavigation(
            ActiveNavigation(
              route: route,
              state: NavigationState.navigating,
              remainingDistanceKm: route.distanceKm,
            ),
          );

      ref
          .read(navigationPositionControllerProvider)
          .setActiveRoute(route.geometry, anchor: livePosition);

      _showGlassNotice(
        AppStrings.literal('مسیر جدید آماده است'),
        icon: Icons.route_rounded,
        colors: const [Color(0xFF8B5CF6), Color(0xFF3B82F6)],
      );

      _arrivalHandled = false;
      _lastSpokenInstructionIndex = -1;
      _spokenStages.clear();
      _beepedRouteAlerts.clear();
      if (route.instructions.isNotEmpty && ref.read(ttEnabledProvider)) {
        _lastSpokenInstructionIndex = 0;
        _spokenStages.addAll(const [0, 1]);
        final voice = ref.read(ttsServiceProvider)
          ..setVolume(ref.read(ttsVolumeProvider))
          ..setPlaybackRate(ref.read(ttsRateProvider));
        voice.playCue('recalculating_route');
      }
    } catch (_) {
      // Reroute failed: keep following the existing route (still route-driven).
      if (!stale()) {
        _showGlassNotice(
          AppStrings.literal('محاسبهٔ مسیر جدید انجام نشد؛ مسیر قبلی حفظ شد'),
          icon: Icons.route_rounded,
          colors: const [Color(0xFFF59E0B), Color(0xFFEF4444)],
        );
      }
    } finally {
      _isRerouting = false;
    }
  }

  Future<void> _drawRoute(List<LatLng> geometry) async {
  }

  Future<void> _clearRoute() async {
    ref.read(selectedRouteCandidateIndexProvider.notifier).state = 0;
    if (ref.read(selectedDestinationProvider) != null) {
      ref.read(selectedDestinationProvider.notifier).state = null;
    }
    if (mounted) setState(() {});
  }

  void _takeManualCameraControl() {
    if (ref.read(searchActiveProvider)) {
      FocusManager.instance.primaryFocus?.unfocus();
    }
    if (!_cameraFollowsVehicle) return;
    setState(() => _cameraFollowsVehicle = false);
    _persistMapCameraSoon();
  }

  void _acceptNavigationSignal(VehiclePosition pos) {
    final now = DateTime.now();
    final previous = _previousValidationPosition;
    _lastNavigationSignal = pos;
    _lastNavigationSignalAt = now;
    _longTunnelEstimateExhausted = false;
    final nav = ref.read(activeNavigationProvider);
    if (nav != null) {
      _tunnelRouteProgressM = _projectRouteProgressMeters(
        pos,
        nav.route.geometry,
      );
    }
    if (_tunnelEstimatedPosition != null) {
      _clearLongTunnelEstimate(notify: true);
    } else {}
  }

  void _advanceLongTunnelEstimate() {
    if (!mounted) return;
    final nav = ref.read(activeNavigationProvider);
    final last = _lastNavigationSignal;
    final lastAt = _lastNavigationSignalAt;
    if (nav == null ||
        last == null ||
        lastAt == null ||
        nav.route.geometry.length < 2 ||
        last.isEstimated ||
        last.speedKmh < _minimumTunnelEstimateSpeedKmh) {
      _clearLongTunnelEstimate();
      return;
    }

    final now = DateTime.now();
    if (_longTunnelEstimateExhausted) return;
    final silence = now.difference(lastAt);
    if (silence < _longTunnelSilenceBeforeStart) return;

    _tunnelEstimateStartedAt ??= now;
    final estimatedFor = now.difference(_tunnelEstimateStartedAt!);
    if (estimatedFor > _maxLongTunnelEstimate) {
      if (_tunnelEstimatedPosition != null) {
        _clearLongTunnelEstimate();
        _longTunnelEstimateExhausted = true;
        if (mounted) setState(() {});
      }
      return;
    }

    final previousAt = _lastTunnelEstimateAt ?? lastAt;
    final deltaSeconds = now.difference(previousAt).inMilliseconds / 1000.0;
    if (deltaSeconds <= 0) return;
    _lastTunnelEstimateAt = now;

    final seconds = estimatedFor.inMilliseconds / 1000.0;
    final speedFactor = (seconds <= 20
            ? 1.0
            : (1.0 - ((seconds - 20) / 100) * 0.7).clamp(0.3, 1.0))
        .toDouble();
    final speedKmh = (last.speedKmh * speedFactor).clamp(0.0, 130.0).toDouble();
    final nextProgress =
        _tunnelRouteProgressM + (speedKmh / 3.6) * deltaSeconds;
    final sample = _routeSampleAtMeters(nav.route.geometry, nextProgress);
    if (sample == null) return;
    _tunnelRouteProgressM = sample.progressMeters;
    final estimated = VehiclePosition(
      lat: sample.point.latitude,
      lng: sample.point.longitude,
      headingDeg: sample.headingDeg,
      speedKmh: speedKmh,
      accuracyM: (last.accuracyM + seconds * 5).clamp(8.0, 500.0).toDouble(),
      isEstimated: true,
    );

    final firstEstimate = _tunnelEstimatedPosition == null;
    _tunnelEstimatedPosition = estimated;
    if (firstEstimate) {}
    _updateNavigationProgress(estimated, nav, estimated: true);
    setState(() {});
  }

  void _clearLongTunnelEstimate({bool notify = false}) {
    final hadEstimate = _tunnelEstimatedPosition != null;
    _tunnelEstimatedPosition = null;
    _tunnelEstimateStartedAt = null;
    _lastTunnelEstimateAt = null;
    _longTunnelEstimateExhausted = false;
    if (notify && hadEstimate && mounted) setState(() {});
  }

  double _projectRouteProgressMeters(
    VehiclePosition position,
    List<LatLng> geometry,
  ) {
    if (geometry.length < 2) return 0;
    var bestDistance = double.infinity;
    var bestProgress = 0.0;
    var prefix = 0.0;
    for (var i = 0; i < geometry.length - 1; i++) {
      final a = geometry[i];
      final b = geometry[i + 1];
      final projected = _projectOnSegment(position.lat, position.lng, a, b);
      if (projected.distanceMeters < bestDistance) {
        bestDistance = projected.distanceMeters;
        bestProgress = prefix + projected.segmentMeters * projected.t;
      }
      prefix += projected.segmentMeters;
    }
    return bestProgress;
  }

  /// نزدیک‌ترین نقطهٔ مسیر به [point] (برحسب متر از ابتدا). با [minProgressM] فقط
  /// قسمتِ بعد از آن جست‌وجو می‌شود؛ برای دستورهای مسیر لازم است چون در
  /// دوربرگردان یا خیابانی که دوبار طی می‌شود، نزدیک‌ترین نقطهٔ سراسری می‌تواند
  /// روی بخش اشتباهِ مسیر بنشیند و ترتیب مانورها را به‌هم بریزد.
  double _projectLatLngProgressMeters(
    LatLng point,
    List<LatLng> geometry, {
    double minProgressM = 0,
    double? maxAheadM,
    bool preferLast = false,
  }) {
    if (geometry.length < 2) return 0;
    final maxProgress =
        maxAheadM == null ? double.infinity : minProgressM + maxAheadM;
    final candidates = <({double distance, double progress})>[];
    var bestDistance = double.infinity;
    var prefix = 0.0;
    for (var i = 0; i < geometry.length - 1; i++) {
      final a = geometry[i];
      final b = geometry[i + 1];
      final projected = _projectOnSegment(
        point.latitude,
        point.longitude,
        a,
        b,
      );
      final segStart = prefix;
      prefix += projected.segmentMeters;
      if (minProgressM > 0 && prefix < minProgressM - 1.0) continue;
      if (segStart > maxProgress) break;
      final progress = segStart + projected.segmentMeters * projected.t;
      candidates.add((distance: projected.distanceMeters, progress: progress));
      if (projected.distanceMeters < bestDistance) {
        bestDistance = projected.distanceMeters;
      }
    }
    if (candidates.isEmpty) return minProgressM;
    // مسیر در میدان/دوربرگردان به خودش نزدیک می‌شود؛ نزدیک‌ترین نقطهٔ کلی
    // ممکن است روی شاخهٔ دیگر باشد. بین نقاطِ تقریباً هم‌فاصله، اولین (یا برای
    // نقطهٔ خروج، آخرین) را برمی‌داریم.
    final tol = preferLast ? 1.5 : 3.0;
    if (preferLast) {
      for (var i = candidates.length - 1; i >= 0; i--) {
        if (candidates[i].distance <= bestDistance + tol) {
          return math.max(candidates[i].progress, minProgressM);
        }
      }
    }
    for (final c in candidates) {
      if (c.distance <= bestDistance + tol) {
        return math.max(c.progress, minProgressM);
      }
    }
    return minProgressM;
  }

  Future<void> _refreshNormalRoadSnap(VehiclePosition position) async {
    if (ref.read(activeNavigationProvider) != null) return;
    final requestId = ++_normalSnapRequest;
    final engine = ref.read(routingEngineProvider);
    VehiclePosition? snapped;

    if (engine == RoutingEngine.online) {
      final matched = _roadSafety.roadMatchedPosition;
      if (matched != null &&
          _distanceBetween(LatLng(position.lat, position.lng), matched) <=
              (position.isEstimated ? 45.0 : 35.0)) {
        snapped = VehiclePosition(
          lat: matched.latitude,
          lng: matched.longitude,
          headingDeg: _roadSafety.roadHeadingDeg ?? position.headingDeg,
          speedKmh: position.speedKmh,
          accuracyM: math.max(
            position.accuracyM,
            _distanceBetween(LatLng(position.lat, position.lng), matched),
          ),
          isEstimated: position.isEstimated,
        );
      }
    } else {
      try {
        final file = await _resolveOfflineMapFile(
          LatLng(position.lat, position.lng),
        ).timeout(const Duration(seconds: 5));
        snapped = await _offlineRoadSnapService
            .snap(position, file)
            .timeout(const Duration(seconds: 5));
      } on TimeoutException {
        snapped = null;
      }
    }

    if (!mounted ||
        requestId != _normalSnapRequest ||
        ref.read(activeNavigationProvider) != null) return;
    final current = ref.read(vehiclePositionProvider).valueOrNull;
    if (current != null && snapped != null) {
      final drift = _distanceBetween(
        LatLng(current.lat, current.lng),
        LatLng(snapped.lat, snapped.lng),
      );
      if (drift > (current.isEstimated ? 60.0 : 45.0)) return;
    }
    setState(() {
      _normalSnappedVehiclePosition = snapped;
      _normalSnapSourceAt = DateTime.now();
    });
  }

  Future<File?> _resolveOfflineMapFile(LatLng center) async {
    try {
      final installed = await ref.read(installedMapRegionsProvider.future);
      if (installed.isNotEmpty) {
        final region = const RegionResolver().resolveByPosition(
          center,
          installed,
        );
        if (region != null) {
          final file = await ref
              .read(abmMapServiceProvider)
              .localFile(region.abmFileName);
          if (await file.exists() && await file.length() > 0) return file;
        }
      }
    } catch (_) {}
    return ref.read(activeOfflineMapFileProvider).valueOrNull;
  }

  Future<void> _refreshRoadSafety(VehiclePosition position) async {
    if (_roadSafetyRequestInFlight) return;
    final center = LatLng(position.lat, position.lng);
    final now = DateTime.now();
    final lastCenter = _lastRoadSafetyCenter;
    if (_lastRoadSafetyUpdate != null &&
        now.difference(_lastRoadSafetyUpdate!) < const Duration(seconds: 8) &&
        lastCenter != null &&
        _distanceBetween(center, lastCenter) < 70) {
      return;
    }
    _roadSafetyRequestInFlight = true;
    try {
      final engine = ref.read(routingEngineProvider);
      RoadSafetySnapshot snapshot;
      if (engine == RoutingEngine.online) {
        snapshot = await _roadSafetyService
            .online(center, preferredHeadingDeg: position.headingDeg)
            .timeout(const Duration(seconds: 15));
      } else {
        final file = await _resolveOfflineMapFile(center)
            .timeout(const Duration(seconds: 5));
        if (file != null) {
          snapshot = await _roadSafetyService
              .offline(file, center, preferredHeadingDeg: position.headingDeg)
              .timeout(const Duration(seconds: 15));
        } else {
          snapshot = const RoadSafetySnapshot();
        }
      }
      if (!mounted) return;
      setState(() {
        _roadSafety = snapshot;
        _lastRoadSafetyCenter = center;
        _lastRoadSafetyUpdate = DateTime.now();
      });
      if (engine == RoutingEngine.online) {
        unawaited(_refreshNormalRoadSnap(position));
      }
      _maybeShowMovingRoadAlert(position, snapshot.alerts);
    } on TimeoutException {
    } finally {
      _roadSafetyRequestInFlight = false;
    }
  }

  void _maybeShowMovingRoadAlert(
    VehiclePosition position,
    List<RouteAlert> alerts,
  ) {
    if (ref.read(activeNavigationProvider) != null) return;
    if (!mounted ||
        position.speedKmh < _movingAlertMinSpeedKmh ||
        alerts.isEmpty) {
      return;
    }

    final current = LatLng(position.lat, position.lng);
    ({RouteAlert alert, double distanceM})? best;
    var bestDistance = double.infinity;
    for (final alert in alerts) {
      final distance = _distanceBetween(current, alert.location);
      if (distance > _movingAlertDistanceM || distance >= bestDistance)
        continue;

      final bearing = _bearingBetween(current, alert.location);
      final delta = ((bearing - position.headingDeg + 540) % 360) - 180;
      final headingValid = position.headingDeg.isFinite;
      if (headingValid && delta.abs() > 75) continue;

      final key =
          '${alert.type.name}:${alert.location.latitude.toStringAsFixed(5)}:${alert.location.longitude.toStringAsFixed(5)}';
      final lastShown = _shownRoadAlertKeys[key];
      if (lastShown != null &&
          DateTime.now().difference(lastShown) < const Duration(seconds: 35)) {
        continue;
      }
      best = (alert: alert, distanceM: distance);
      bestDistance = distance;
    }

    if (best == null) return;
    final key =
        '${best!.alert.type.name}:${best!.alert.location.latitude.toStringAsFixed(5)}:${best!.alert.location.longitude.toStringAsFixed(5)}';
    _shownRoadAlertKeys[key] = DateTime.now();
    _transientRoadAlertTimer?.cancel();
    if (ref.read(alertsVoiceEnabledProvider)) {
      unawaited(ref.read(ttsServiceProvider).playAlert());
    }
    setState(() => _transientRoadAlert = best);
    _transientRoadAlertTimer = Timer(const Duration(seconds: 4), () {
      if (mounted) setState(() => _transientRoadAlert = null);
    });

    final cutoff = DateTime.now().subtract(const Duration(minutes: 3));
    _shownRoadAlertKeys.removeWhere((_, time) => time.isBefore(cutoff));
  }

  List<RouteAlert>? _roadAlertsCache;
  Object? _roadAlertsSrcA;
  Object? _roadAlertsSrcB;

  /// True when the alert sits on the route carriageway (not the opposite side
  /// of a divided road and not on a side street).
  bool _alertIsOnRoute(RouteAlert alert, List<LatLng> geometry) {
    if (geometry.length < 2) return false;
    final match = _bestSegmentMatch(
      VehiclePosition(
        lat: alert.location.latitude,
        lng: alert.location.longitude,
        headingDeg: 0,
        speedKmh: 0,
        accuracyM: 5,
      ),
      geometry,
      0,
      geometry.length - 2,
    );
    return match != null && match.distanceMeters <= 8.0;
  }

  Object? _roadAlertsSrcC;

  List<RouteAlert> _roadAlertsForMap(ActiveNavigation? nav) {
    final a = _roadSafety.alerts;
    final b = nav?.route.alerts;
    final c = nav?.route.geometry;
    final cached = _roadAlertsCache;
    if (cached != null &&
        identical(a, _roadAlertsSrcA) &&
        identical(b, _roadAlertsSrcB) &&
        identical(c, _roadAlertsSrcC)) {
      return cached;
    }
    final seen = <String>{};
    final out = <RouteAlert>[];
    void add(Iterable<RouteAlert>? alerts) {
      if (alerts == null) return;
      for (final alert in alerts) {
        if (alert.type != RouteAlertType.speedCamera &&
            alert.type != RouteAlertType.speedBump &&
            alert.type != RouteAlertType.trafficLight) {
          continue;
        }
        final k =
            '${alert.type.index}:${alert.location.latitude.toStringAsFixed(5)},${alert.location.longitude.toStringAsFixed(5)}';
        if (seen.add(k)) out.add(alert);
      }
    }

    if (nav == null) {
      add(a);
    } else {
      // During navigation show only alerts on the route itself.
      add(b);
      if (b == null || b.isEmpty) {
        add(a.where((x) => _alertIsOnRoute(x, nav.route.geometry)));
      }
    }
    _roadAlertsSrcA = a;
    _roadAlertsSrcB = b;
    _roadAlertsSrcC = c;
    return _roadAlertsCache = out;
  }

  double _distanceBetween(LatLng a, LatLng b) {
    const r = 6371000.0;
    final dLat = (b.latitude - a.latitude) * math.pi / 180.0;
    final dLng = (b.longitude - a.longitude) * math.pi / 180.0;
    final aa = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(a.latitude * math.pi / 180.0) *
            math.cos(b.latitude * math.pi / 180.0) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    return r * 2 * math.atan2(math.sqrt(aa), math.sqrt(1 - aa));
  }

  List<({RouteAlert alert, double distanceM})> _displayRoadAlerts(
    ActiveNavigation? navigation,
  ) {
    if (navigation == null ||
        !ref.read(appearanceSettingsProvider).showRouteWarnings) {
      return const [];
    }

    final upcoming = _upcomingAlerts(navigation);
    if (upcoming.isNotEmpty) return upcoming;
    if (navigation.route.alerts.isNotEmpty) return const [];

    final position = _tunnelEstimatedPosition ??
        ref.read(navigationPositionProvider).valueOrNull;
    if (position == null) return const [];

    // Navigation is active but the route carries no precomputed alerts (online
    // engine): only use nearby alerts that lie ON the route and ahead of the
    // vehicle along it, never ones on the opposite carriageway / side streets.
    final geometry = navigation.route.geometry;
    final progressM = _routeMatchLastProgressM;
    if (geometry.length < 2 || progressM == null) return const [];
    final matches = <({RouteAlert alert, double distanceM})>[];
    for (final alert in _roadSafety.alerts) {
      if (!_alertIsOnRoute(alert, geometry)) continue;
      final remaining =
          _projectLatLngProgressMeters(alert.location, geometry) - progressM;
      if (remaining < 0 || remaining > _alertDisplayRangeM) continue;
      matches.add((alert: alert, distanceM: remaining));
    }
    matches.sort((a, b) => a.distanceM.compareTo(b.distanceM));
    final unique = _onePerType(matches);
    if (unique.length > _maxStackedAlerts) {
      unique.removeRange(_maxStackedAlerts, unique.length);
    }
    return unique;
  }

  List<double> _ensureRouteAlertProgress(RouteInfo route) {
    if (identical(_routeAlertsSource, route.alerts) &&
        _routeAlertsProgressM != null) {
      return _routeAlertsProgressM!;
    }
    _routeAlertsSource = route.alerts;
    _routeAlertsProgressM = route.alerts
        .map(
          (alert) =>
              _projectLatLngProgressMeters(alert.location, route.geometry),
        )
        .toList(growable: false);
    return _routeAlertsProgressM!;
  }

  List<double> _ensureRouteInstructionProgress(RouteInfo route) {
    if (identical(_routeInstructionsSource, route.instructions) &&
        _routeInstructionsProgressM != null) {
      return _routeInstructionsProgressM!;
    }
    _routeInstructionsSource = route.instructions;
    // هر دستور فقط بعد از دستور قبلی جست‌وجو می‌شود تا ترتیب مانورها روی مسیرهای
    // دوربرگردان‌دار یا تکراری به‌هم نخورد.
    final progress = <double>[];
    var floor = 0.0;
    for (final instr in route.instructions) {
      final p = _projectLatLngProgressMeters(
        instr.location,
        route.geometry,
        minProgressM: floor,
      );
      floor = math.max(floor, p);
      progress.add(floor);
    }
    _routeInstructionsProgressM = progress;
    return _routeInstructionsProgressM!;
  }

  /// شکلِ فلشِ مانورِ فعلی؛ از هندسهٔ واقعیِ مسیر بریده می‌شود و برای هر دستور
  /// فقط یک‌بار محاسبه می‌شود. برای «شروع»، «رسیدن» و ادامهٔ مستقیم null است.
  ManeuverShape? _maneuverShapeFor(ActiveNavigation nav) {
    final route = nav.route;
    final geometry = route.geometry;
    if (geometry.length < 2 || route.instructions.isEmpty) return null;
    final idx = nav.currentInstructionIndex
        .clamp(0, route.instructions.length - 1)
        .toInt();
    final instr = route.instructions[idx];
    final type = instr.type.trim().toLowerCase();
    final isRound = type == 'roundabout' || type == 'rotary';
    final modifier = (instr.modifier ?? '').trim().toLowerCase();
    if (type == 'depart' ||
        type == 'arrive' ||
        type == 'continue' ||
        type == 'new name' ||
        (!isRound && modifier == 'straight')) {
      return null;
    }
    if (identical(_maneuverShapeGeometry, geometry) &&
        _maneuverShapeIndex == idx) {
      return _maneuverShape;
    }
    if (!identical(_maneuverShapeGeometry, geometry) ||
        _maneuverShapeCum == null) {
      _maneuverShapeCum = ManeuverGeometry.cumulative(geometry);
    }
    _maneuverShapeGeometry = geometry;
    _maneuverShapeIndex = idx;
    final progress = _ensureRouteInstructionProgress(route);
    final start = progress[idx];
    double? end;
    final endLocation = instr.maneuverEndLocation;
    if (isRound && endLocation != null) {
      end = _projectLatLngProgressMeters(
        endLocation,
        geometry,
        minProgressM: start + 2.0,
        maxAheadM: 220.0,
        preferLast: true,
      );
    }
    _maneuverShape = ManeuverGeometry.build(
      geometry,
      _maneuverShapeCum!,
      startProgressM: start,
      endProgressM: end,
    );
    return _maneuverShape;
  }

  static bool _instructionNeedsArrow(RouteInstruction instr) {
    final type = instr.type.trim().toLowerCase();
    final isRound = type == 'roundabout' || type == 'rotary';
    final modifier = (instr.modifier ?? '').trim().toLowerCase();
    if (type == 'depart' ||
        type == 'arrive' ||
        type == 'continue' ||
        type == 'new name') {
      return false;
    }
    if (!isRound && modifier == 'straight') return false;
    return true;
  }

  /// فلشِ پیچِ بعدی روی مسیر (مثل نشان/ویز). از دستور فعلی به بعد، اولین
  /// مانورِ واقعی را پیدا می‌کند و اگر تا [_maneuverArrowRangeM] متر جلوتر بود
  /// شکلش را از هندسهٔ مسیر می‌برد. برای هر مانور فقط یک‌بار ساخته می‌شود.
  ManeuverShape? _routeManeuverShapeFor(ActiveNavigation nav) {
    final route = nav.route;
    final geometry = route.geometry;
    final instructions = route.instructions;
    if (geometry.length < 2 || instructions.isEmpty) return null;
    final progress = _ensureRouteInstructionProgress(route);
    final here = _routeMatchLastProgressM ?? 0.0;
    final first =
        nav.currentInstructionIndex.clamp(0, instructions.length - 1).toInt();
    final last = math.min(instructions.length - 1, first + 4);
    for (var i = first; i <= last; i++) {
      final instr = instructions[i];
      if (!_instructionNeedsArrow(instr)) continue;
      final ahead = progress[i] - here;
      if (ahead > _maneuverArrowRangeM) return null;
      // پیچی که از آن رد شده‌ایم دیگر فلش نمی‌خواهد.
      if (ahead < -25.0) continue;
      if (identical(_mapArrowGeometry, geometry) && _mapArrowIndex == i) {
        return _mapArrowShape;
      }
      if (!identical(_mapArrowGeometry, geometry) || _mapArrowCum == null) {
        _mapArrowCum = ManeuverGeometry.cumulative(geometry);
      }
      _mapArrowGeometry = geometry;
      _mapArrowIndex = i;
      final type = instr.type.trim().toLowerCase();
      final isRound = type == 'roundabout' || type == 'rotary';
      double? end;
      final endLocation = instr.maneuverEndLocation;
      if (isRound && endLocation != null) {
        end = _projectLatLngProgressMeters(
          endLocation,
          geometry,
          minProgressM: progress[i] + 2.0,
          maxAheadM: 220.0,
          preferLast: true,
        );
      }
      _mapArrowShape = ManeuverGeometry.build(
        geometry,
        _mapArrowCum!,
        startProgressM: progress[i],
        endProgressM: end,
      );
      return _mapArrowShape;
    }
    return null;
  }

  static const int _maxStackedAlerts = 3;

  int? _hudPublishedLimit;
  RouteAlert? _hudPublishedAlert;

  void _publishHudLive({int? speedLimit, RouteAlert? alert}) {
    if (speedLimit == _hudPublishedLimit &&
        identical(alert, _hudPublishedAlert)) {
      return;
    }
    _hudPublishedLimit = speedLimit;
    _hudPublishedAlert = alert;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      ref.read(hudSpeedLimitProvider.notifier).state = speedLimit;
      ref.read(hudNextAlertProvider.notifier).state = alert;
    });
  }

  List<({RouteAlert alert, double distanceM})> _onePerType(
    List<({RouteAlert alert, double distanceM})> sortedByDistance,
  ) {
    final seen = <RouteAlertType>{};
    return [
      for (final item in sortedByDistance)
        if (seen.add(item.alert.type)) item,
    ];
  }

  List<({RouteAlert alert, double distanceM})> _upcomingAlerts(
    ActiveNavigation navigation,
  ) {
    final alerts = navigation.route.alerts;
    if (alerts.isEmpty) return const [];
    final currentProgressM = _routeMatchLastProgressM;
    if (currentProgressM == null) return const [];
    final progressList = _ensureRouteAlertProgress(navigation.route);

    final matches = <({RouteAlert alert, double distanceM})>[];
    for (var i = 0; i < alerts.length; i++) {
      final remaining = progressList[i] - currentProgressM;
      if (remaining < 0 || remaining > _alertDisplayRangeM) continue;
      matches.add((
        alert: alerts[i],
        distanceM: remaining.clamp(0.0, double.infinity),
      ));
    }
    matches.sort((a, b) => a.distanceM.compareTo(b.distanceM));
    final unique = _onePerType(matches);
    if (unique.length > _maxStackedAlerts) {
      unique.removeRange(_maxStackedAlerts, unique.length);
    }
    return unique;
  }

  VehiclePosition? _matchPositionToRoute(
    VehiclePosition position,
    List<LatLng> geometry,
  ) {
    if (geometry.length < 2) return null;
    final maxAccuracyM = position.isEstimated ? 120.0 : 50.0;
    if (!position.accuracyM.isFinite || position.accuracyM > maxAccuracyM) {
      return null;
    }

    if (!identical(_routeMatchGeometry, geometry)) {
      _routeMatchGeometry = geometry;
      _routeMatchCumulativeM = _buildCumulativeDistances(geometry);
      _routeMatchLastSegment = null;
      _routeMatchLastProgressM = null;
      _routeMatchHoldSince = null;
    }
    final cumulative = _routeMatchCumulativeM!;
    final lastSegmentCount = geometry.length - 2;

    final speedMs = (position.speedKmh.isFinite ? position.speedKmh : 0.0) / 3.6;
    final backWindowM = 30.0;
    final aheadWindowM = (80.0 + speedMs * 5.0).clamp(80.0, 260.0).toDouble();
    var startIdx = 0;
    var endIdx = lastSegmentCount;
    final lastIdx = _routeMatchLastSegment;
    final lastProgressForScore = _routeMatchLastProgressM;
    if (lastIdx != null && lastIdx >= 0 && lastIdx <= lastSegmentCount) {
      final lastProgress = cumulative[lastIdx];
      final lo = lastProgress - backWindowM;
      final hi = lastProgress + aheadWindowM;
      var s = lastIdx;
      while (s > 0 && cumulative[s] > lo) s--;
      var e = lastIdx;
      while (e < lastSegmentCount && cumulative[e] < hi) e++;
      startIdx = s;
      endIdx = e;
    }

    final headingDeg =
        position.speedKmh >= 4.0 && position.headingDeg.isFinite
            ? position.headingDeg
            : null;
    var best = _bestSegmentMatch(
      position,
      geometry,
      startIdx,
      endIdx,
      cumulative: cumulative,
      lastProgressM: lastProgressForScore,
      headingDeg: headingDeg,
    );
    if (best == null || best.distanceMeters > 45) {
      best = _bestSegmentMatch(
        position,
        geometry,
        0,
        lastSegmentCount,
        cumulative: cumulative,
        lastProgressM: lastProgressForScore,
        headingDeg: headingDeg,
      );
    }
    if (best == null || best.distanceMeters > 45) {
      return null;
    }

    final progressM = cumulative[best.segmentIndex] +
        best.projection.segmentMeters * best.projection.t;
    final lastProgressM = _routeMatchLastProgressM;
    if (lastProgressM != null && progressM < lastProgressM - 15.0) {
      final now = DateTime.now();
      _routeMatchHoldSince ??= now;
      // نگه‌داشتن موقعیت فقط کوتاه‌مدت؛ در میدان/دوربرگردان که مسیر به خودش
      // نزدیک می‌شود نباید برای همیشه روی نقطهٔ قبلی گیر کند.
      if (now.difference(_routeMatchHoldSince!) <
          const Duration(milliseconds: 1500)) {
        final held = _routeSampleAtMeters(geometry, lastProgressM);
        if (held != null) {
          return VehiclePosition(
            lat: held.point.latitude,
            lng: held.point.longitude,
            headingDeg: held.headingDeg,
            speedKmh: position.speedKmh,
            accuracyM: position.accuracyM,
            isEstimated: position.isEstimated,
          );
        }
        return null;
      }
    }
    _routeMatchHoldSince = null;

    _routeMatchLastSegment = best.segmentIndex;
    _routeMatchLastProgressM = progressM;
    final a = geometry[best.segmentIndex];
    final b = geometry[best.segmentIndex + 1];
    final t = best.projection.t;
    return VehiclePosition(
      lat: a.latitude + (b.latitude - a.latitude) * t,
      lng: a.longitude + (b.longitude - a.longitude) * t,
      headingDeg: _bearingBetween(a, b),
      speedKmh: position.speedKmh,
      accuracyM: position.accuracyM,
      isEstimated: position.isEstimated,
    );
  }

  _RouteMatch? _bestRouteMatchNearProgress(
    VehiclePosition position,
    List<LatLng> geometry,
    double progressM,
  ) {
    if (geometry.length < 2) return null;
    final cumulative =
        _routeMatchCumulativeM ?? _buildCumulativeDistances(geometry);
    const backWindowM = 35.0;
    const aheadWindowM = 180.0;
    final lo = math.max(0.0, progressM - backWindowM);
    final hi = math.min(cumulative.last, progressM + aheadWindowM);
    var startIdx = 0;
    while (startIdx < geometry.length - 2 && cumulative[startIdx + 1] < lo) {
      startIdx++;
    }
    var endIdx = startIdx;
    while (endIdx < geometry.length - 2 && cumulative[endIdx] < hi) {
      endIdx++;
    }
    final match = _bestSegmentMatch(position, geometry, startIdx, endIdx);
    if (match == null || match.distanceMeters > 65.0) return null;
    return match;
  }

  _RouteMatch? _bestSegmentMatch(
    VehiclePosition position,
    List<LatLng> geometry,
    int startIdx,
    int endIdx, {
    List<double>? cumulative,
    double? lastProgressM,
    double? headingDeg,
  }) {
    var bestCost = double.infinity;
    _RouteMatch? best;
    for (var i = startIdx; i <= endIdx; i++) {
      final a = geometry[i];
      final b = geometry[i + 1];
      final projection = _projectOnSegment(position.lat, position.lng, a, b);
      var cost = projection.distanceMeters;
      if (cumulative != null && lastProgressM != null) {
        final progress = cumulative[i] + projection.segmentMeters * projection.t;
        final delta = progress - lastProgressM;
        cost += delta < 0 ? -delta * 0.2 : delta * 0.01;
      }
      if (headingDeg != null && projection.segmentMeters > 1.0) {
        final diff = _angleDifference(headingDeg, _bearingBetween(a, b)).abs();
        cost += diff * 0.12;
      }
      if (cost < bestCost) {
        bestCost = cost;
        best = _RouteMatch(segmentIndex: i, projection: projection);
      }
    }
    return best;
  }

  List<double> _buildCumulativeDistances(List<LatLng> geometry) {
    final cumulative = List<double>.filled(geometry.length, 0);
    for (var i = 1; i < geometry.length; i++) {
      cumulative[i] =
          cumulative[i - 1] + _calculateDistance(geometry[i - 1], geometry[i]);
    }
    return cumulative;
  }

  _RouteSample? _routeSampleAtMeters(List<LatLng> geometry, double meters) {
    if (geometry.length < 2) return null;
    var remaining = meters.clamp(0.0, double.infinity).toDouble();
    var prefix = 0.0;
    for (var i = 0; i < geometry.length - 1; i++) {
      final a = geometry[i];
      final b = geometry[i + 1];
      final segment = _calculateDistance(a, b);
      if (segment <= 0.01) continue;
      if (remaining <= segment || i == geometry.length - 2) {
        final t = (remaining / segment).clamp(0.0, 1.0).toDouble();
        return _RouteSample(
          LatLng(
            a.latitude + (b.latitude - a.latitude) * t,
            a.longitude + (b.longitude - a.longitude) * t,
          ),
          _bearingBetween(a, b),
          prefix + segment * t,
        );
      }
      remaining -= segment;
      prefix += segment;
    }
    final last = geometry.last;
    return _RouteSample(last, 0.0, prefix);
  }

  _SegmentProjection _projectOnSegment(
    double lat,
    double lng,
    LatLng a,
    LatLng b,
  ) {
    const metersPerDegree = 111320.0;
    final cosLat = math.cos(((a.latitude + b.latitude) / 2) * math.pi / 180);
    final bx = (b.longitude - a.longitude) * metersPerDegree * cosLat;
    final by = (b.latitude - a.latitude) * metersPerDegree;
    final px = (lng - a.longitude) * metersPerDegree * cosLat;
    final py = (lat - a.latitude) * metersPerDegree;
    final segmentSquared = bx * bx + by * by;
    final t = (segmentSquared <= 0
            ? 0.0
            : ((px * bx + py * by) / segmentSquared).clamp(0.0, 1.0))
        .toDouble();
    final dx = px - bx * t;
    final dy = py - by * t;
    return _SegmentProjection(
      t: t,
      segmentMeters: math.sqrt(segmentSquared),
      distanceMeters: math.sqrt(dx * dx + dy * dy),
    );
  }

  double _bearingBetween(LatLng a, LatLng b) {
    final y = (b.longitude - a.longitude) *
        math.cos((a.latitude + b.latitude) * math.pi / 360);
    final x = b.latitude - a.latitude;
    return (math.atan2(y, x) * 180 / math.pi + 360) % 360;
  }

  Future<void> _stopNavigation() async {
    _navSession++;
    _arrivalStopTimer?.cancel();
    _arrivalStopTimer = null;
    _arrivalHandled = false;
    _lastSpokenInstructionIndex = -1;
    _spokenStages.clear();
    _beepedRouteAlerts.clear();
    final latestGps = ref.read(vehiclePositionProvider).valueOrNull ??
        ref.read(navigationPositionProvider).valueOrNull;
    final positionController = ref.read(navigationPositionControllerProvider);
    if (latestGps != null) {
      positionController.resetToFreeDrive(latestGps);
    } else {
      positionController.clearActiveRoute();
    }
    ref.read(activeNavigationProvider.notifier).clear();
    ref.read(selectedDestinationProvider.notifier).state = null;
    ref.read(selectedRouteCandidateIndexProvider.notifier).state = 0;

    _offRouteStrikeCount = 0;
    _offRouteSince = null;
    _previousValidationPosition = null;
    _previousValidationAt = null;
    _recentMovementBearingDeg = null;
    _isRerouting = false;
    _lastRerouteAt = null;
    _clearLongTunnelEstimate();
    _routeMatchGeometry = null;
    _routeMatchCumulativeM = null;
    _routeMatchLastSegment = null;
    _routeMatchLastProgressM = null;
    _routeAlertsSource = null;
    _routeAlertsProgressM = null;
    _routeInstructionsSource = null;
    _routeInstructionsProgressM = null;
    _maneuverShapeGeometry = null;
    _maneuverShapeCum = null;
    _maneuverShapeIndex = -1;
    _maneuverShape = null;
    _mapArrowGeometry = null;
    _mapArrowCum = null;
    _mapArrowIndex = -1;
    _mapArrowShape = null;

    ref.read(drivingModeProvider.notifier).state = false;

    _cameraFollowsVehicle = true;
    _gpsFocusRequest++;
    if (mounted) setState(() {});

    ref.read(locationServiceProvider).ensureAlive();

    ref.invalidate(calculateRouteProvider);
    ref.invalidate(calculateRoutesProvider);

    unawaited(
      _clearRoute().timeout(const Duration(seconds: 2), onTimeout: () {}),
    );
    unawaited(
      ref
          .read(ttsServiceProvider)
          .stop()
          .timeout(const Duration(seconds: 2), onTimeout: () {}),
    );
  }

  double _angleDifference(double a, double b) =>
      ((a - b + 540.0) % 360.0) - 180.0;

  DateTime? _lastRouteDrivenHealAt;

  DateTime? _lastDrivingSideCheckAt;

  /// Sets the traffic side (left/right) from the country of the installed map
  /// that contains the current position. Unknown -> keeps the previous value
  /// (default: right-hand traffic).
  void _updateDrivingSide(VehiclePosition pos) {
    final now = DateTime.now();
    final last = _lastDrivingSideCheckAt;
    if (last != null && now.difference(last) < const Duration(seconds: 20)) {
      return;
    }
    _lastDrivingSideCheckAt = now;
    final regions = ref.read(installedMapRegionsProvider).valueOrNull;
    if (regions == null || regions.isEmpty) return;
    MapRegion? best;
    var bestArea = double.infinity;
    for (final r in regions) {
      final b = r.bounds;
      if (pos.lat < b.southwest.latitude ||
          pos.lat > b.northeast.latitude ||
          pos.lng < b.southwest.longitude ||
          pos.lng > b.northeast.longitude) {
        continue;
      }
      final area = (b.northeast.latitude - b.southwest.latitude).abs() *
          (b.northeast.longitude - b.southwest.longitude).abs();
      if (area < bestArea) {
        bestArea = area;
        best = r;
      }
    }
    if (best == null) return;
    RoadSnapper.instance.leftHandTraffic =
        DrivingSide.isLeftHandCountry(best.effectiveCountryCode);
  }

  /// While navigation is active the vehicle must always follow the route.
  /// If the animator dropped out of route-driven mode for any reason (provider
  /// rebuild, failed reroute, ...), re-attach it to the active route.
  void _ensureRouteDriven(VehiclePosition pos, ActiveNavigation nav) {
    if (nav.state != NavigationState.navigating || _isRerouting) return;
    final controller = ref.read(navigationPositionControllerProvider);
    if (controller.isRouteDriven) return;
    final geometry = nav.route.geometry;
    if (geometry.length < 2) return;
    final cumulative = _routeMatchCumulativeM;
    final progress = _routeMatchLastProgressM;
    if (cumulative != null &&
        progress != null &&
        cumulative.isNotEmpty &&
        cumulative.last - progress < 50.0) {
      return; // arrival zone: let the animator finish normally
    }
    final now = DateTime.now();
    final last = _lastRouteDrivenHealAt;
    if (last != null && now.difference(last) < const Duration(seconds: 2)) {
      return;
    }
    _lastRouteDrivenHealAt = now;
    controller.setActiveRoute(geometry, anchor: pos);
  }

  void _updateNavigationProgress(
    VehiclePosition pos,
    ActiveNavigation nav, {
    bool estimated = false,
    VehiclePosition? gpsValidationPosition,
  }) {
    final currentLoc = LatLng(pos.lat, pos.lng);
    final validation = gpsValidationPosition ?? pos;
    final validationLoc = LatLng(validation.lat, validation.lng);

    final previousAt = _previousValidationAt;
    final previous = _previousValidationPosition;
    if (previous != null && previousAt != null && !validation.isEstimated) {
      final now = DateTime.now();
      final dt = now.difference(previousAt).inMilliseconds / 1000.0;
      final moved = _distanceBetween(
        LatLng(previous.lat, previous.lng),
        validationLoc,
      );
      if (dt > 0.12 && dt < 3.0 && moved >= 2.0) {
        _recentMovementBearingDeg = _bearingBetween(
          LatLng(previous.lat, previous.lng),
          validationLoc,
        );
      }
    }
    _previousValidationPosition = validation;
    _previousValidationAt = DateTime.now();

    if (!estimated) {
      _matchPositionToRoute(pos, nav.route.geometry);
    }

    _ensureRouteDriven(pos, nav);

    if (!estimated &&
        nav.state == NavigationState.navigating &&
        !_isRerouting) {
      final routeMatch = _bestRouteMatchNearProgress(
        validation,
        nav.route.geometry,
        _routeMatchLastProgressM ??
            _projectRouteProgressMeters(validation, nav.route.geometry),
      );
      final distFromRoute = routeMatch?.distanceMeters ?? double.infinity;
      final routeHeading = routeMatch == null
          ? null
          : _bearingBetween(
              nav.route.geometry[routeMatch.segmentIndex],
              nav.route.geometry[routeMatch.segmentIndex + 1],
            );

      final movementHeading = _recentMovementBearingDeg;
      final headingForValidation = movementHeading ?? validation.headingDeg;
      final headingMismatch = validation.speedKmh >= 15 &&
          distFromRoute >= 15.0 &&
          routeHeading != null &&
          headingForValidation.isFinite &&
          _angleDifference(headingForValidation, routeHeading).abs() > 50.0;

      const offRouteThresholdM = 18.0;
      final highConfidenceDeviation = validation.accuracyM <= 12.0 &&
          validation.speedKmh >= 8.0 &&
          (distFromRoute > offRouteThresholdM || headingMismatch);
      final wrongStreetOrDirection = distFromRoute > offRouteThresholdM ||
          (headingMismatch && distFromRoute >= 15.0 && distFromRoute <= 90.0);

      final now = DateTime.now();
      if (wrongStreetOrDirection) {
        _offRouteSince ??= now;
        _offRouteStrikeCount++;
      } else {
        _offRouteStrikeCount = 0;
        _offRouteSince = null;
      }

      final outsideFor = _offRouteSince == null
          ? Duration.zero
          : now.difference(_offRouteSince!);
      final requiredOutside = highConfidenceDeviation && distFromRoute >= 30.0
          ? const Duration(seconds: 1, milliseconds: 200)
          : const Duration(seconds: 2, milliseconds: 500);
      final cooldownOk = _lastRerouteAt == null ||
          now.difference(_lastRerouteAt!) > const Duration(seconds: 8);

      if (_offRouteStrikeCount >= 2 &&
          outsideFor >= requiredOutside &&
          cooldownOk &&
          ref.read(appearanceSettingsProvider).autoRerouteEnabled) {
        _offRouteStrikeCount = 0;
        _offRouteSince = null;
        _rerouteOffPath(distFromRoute, gpsPosition: validation);
        return;
      }
    }

    final lastIndex = nav.route.instructions.length - 1;
    final instructionProgressM = _ensureRouteInstructionProgress(nav.route);

    final vehicleProgressM = _routeMatchLastProgressM ??
        _projectLatLngProgressMeters(currentLoc, nav.route.geometry);

    int nearestInstructionIndex = nav.currentInstructionIndex;
    while (nearestInstructionIndex < lastIndex) {
      final instruction = nav.route.instructions[nearestInstructionIndex];
      var completionProgress =
          instructionProgressM[nearestInstructionIndex] + 5.0;
      final endLocation = instruction.maneuverEndLocation;
      if (endLocation != null &&
          (instruction.type == 'roundabout' || instruction.type == 'rotary')) {
        completionProgress = math.max(
          completionProgress,
          _projectLatLngProgressMeters(
                endLocation,
                nav.route.geometry,
                minProgressM:
                    instructionProgressM[nearestInstructionIndex] + 2.0,
                maxAheadM: 220.0,
                preferLast: true,
              ) +
              12.0,
        );
      }
      if (vehicleProgressM <= completionProgress) break;
      nearestInstructionIndex++;
    }

    final currentInstruction = nav.route.instructions[nearestInstructionIndex];
    var nextTargetProgress = instructionProgressM[nearestInstructionIndex];
    if ((currentInstruction.type == 'roundabout' ||
            currentInstruction.type == 'rotary') &&
        currentInstruction.maneuverEndLocation != null &&
        vehicleProgressM >= nextTargetProgress) {
      nextTargetProgress = _projectLatLngProgressMeters(
        currentInstruction.maneuverEndLocation!,
        nav.route.geometry,
        minProgressM: instructionProgressM[nearestInstructionIndex] + 2.0,
        maxAheadM: 220.0,
        preferLast: true,
      );
    }
    final distToNext = math.max(0.0, nextTargetProgress - vehicleProgressM);
    final distToDestination = math.max(
      0.0,
      instructionProgressM[lastIndex] - vehicleProgressM,
    );

    ref.read(activeNavigationProvider.notifier).updateProgress(
          nearestInstructionIndex,
          distToDestination / 1000,
          distanceToNextManeuverM: distToNext,
        );

    _beepForUpcomingRouteAlerts(nav, vehicleProgressM);

    if (nearestInstructionIndex != _lastSpokenInstructionIndex) {
      _lastSpokenInstructionIndex = nearestInstructionIndex;
      _spokenStages.removeWhere((key) => key ~/ 10 < nearestInstructionIndex);
    }

    if (ref.read(ttEnabledProvider)) {
      final instr = nav.route.instructions[nearestInstructionIndex];
      final speedKmh =
          ref.read(navigationPositionProvider).value?.speedKmh ?? 0;
      final speedMs = (speedKmh / 3.6).clamp(0.0, 60.0);

      final imminentAt = (speedMs * 6).clamp(40.0, 150.0);
      final firstAlert =
          ref.read(voiceFirstAlertDistanceProvider).clamp(50.0, 1000.0);
      final stages = <int, double>{
        0: firstAlert,
        1: (firstAlert * 0.5).clamp(50.0, firstAlert),
        2: (firstAlert * 0.2).clamp(40.0, firstAlert),
        3: imminentAt.clamp(40.0, firstAlert),
      };
      // مرحله‌های هم‌پوشان (فاصله‌ی یکسان/نامرتب) حذف می‌شوند تا یک پیام چندبار نیاید.
      final stage2 = stages[2]!;
      if (stages[3]! >= stage2 - 15) stages.remove(3);
      if ((stages[1]! - stage2) < 30) stages.remove(2);

      int? stageToSpeak;
      for (final entry in stages.entries) {
        final key = nearestInstructionIndex * 10 + entry.key;
        if (_spokenStages.contains(key)) continue;
        if (distToNext <= entry.value) {
          _spokenStages.add(key);
          stageToSpeak = entry.key;
        }
      }

      final chain = VoicePackFa.cueChainForManeuver(
        type: instr.type,
        modifier: instr.modifier,
        exit: instr.exit,
      );
      // «مستقیم بروید» فقط یک‌بار برای هر دستور (مرحله‌ی اول) گفته شود.
      if (stageToSpeak != null &&
          chain.first == 'continue_straight' &&
          stageToSpeak != 0) {
        stageToSpeak = null;
      }

      if (stageToSpeak != null) {
        final voice = ref.read(ttsServiceProvider)
          ..setVolume(ref.read(ttsVolumeProvider))
          ..setPlaybackRate(ref.read(ttsRateProvider));

        voice.playGuidance(
          prefix: VoicePackFa.distancePrefixCue(distToNext),
          chain: chain,
        );
      }
    }

    final arrivalSpeedKmh =
        ref.read(navigationPositionProvider).value?.speedKmh ?? 0;
    final arrivalRadiusM = arrivalSpeedKmh < 5 ? 35.0 : 20.0;
    if (!_arrivalHandled &&
        distToDestination < arrivalRadiusM &&
        nearestInstructionIndex >= lastIndex) {
      _arrivalHandled = true;
      _onArrived();
    }
  }

  void _beepForUpcomingRouteAlerts(
    ActiveNavigation nav,
    double vehicleProgressM,
  ) {
    final alerts = nav.route.alerts;
    if (alerts.isEmpty || !ref.read(alertsVoiceEnabledProvider)) return;
    final progress = _ensureRouteAlertProgress(nav.route);
    final range = _alertDisplayRangeM;
    for (var i = 0; i < alerts.length && i < progress.length; i++) {
      final alert = alerts[i];
      if (alert.type == RouteAlertType.trafficLight) continue;
      final remaining = progress[i] - vehicleProgressM;
      if (remaining < 0 || remaining > range) continue;
      final key =
          '${alert.type.name}:${alert.location.latitude.toStringAsFixed(5)}:${alert.location.longitude.toStringAsFixed(5)}';
      if (_beepedRouteAlerts.contains(key)) continue;
      final beepNow = DateTime.now();
      // هشدارهای نزدیک به هم بوق‌های پشت‌سرهم نسازند؛ تیک بعد دوباره امتحان می‌شود.
      if (_lastAlertBeepAt != null &&
          beepNow.difference(_lastAlertBeepAt!) < const Duration(seconds: 4)) {
        break;
      }
      _beepedRouteAlerts.add(key);
      _lastAlertBeepAt = beepNow;
      ref.read(ttsServiceProvider)
        ..setVolume(ref.read(ttsVolumeProvider))
        ..playAlert();
      break; // یک بوق در هر تیک؛ بقیه تیک بعد.
    }
  }

  double _distanceToSegmentMeters(LatLng p, LatLng a, LatLng b) {
    const metersPerDegLat = 111320.0;
    final metersPerDegLng = 111320.0 * math.cos(degToRad(p.latitude));

    double toX(LatLng q) => (q.longitude - a.longitude) * metersPerDegLng;
    double toY(LatLng q) => (q.latitude - a.latitude) * metersPerDegLat;

    const ax = 0.0, ay = 0.0;
    final bx = toX(b), by = toY(b);
    final px = toX(p), py = toY(p);

    final dx = bx - ax, dy = by - ay;
    final lenSq = dx * dx + dy * dy;
    var t = lenSq == 0 ? 0.0 : ((px - ax) * dx + (py - ay) * dy) / lenSq;
    t = t.clamp(0.0, 1.0);
    final projX = ax + t * dx, projY = ay + t * dy;
    final ddx = px - projX, ddy = py - projY;
    return math.sqrt(ddx * ddx + ddy * ddy);
  }

  double _calculateDistance(LatLng point1, LatLng point2) {
    const earthRadius = 6371000.0;

    final lat1 = degToRad(point1.latitude);
    final lat2 = degToRad(point2.latitude);
    final dLat = degToRad(point2.latitude - point1.latitude);
    final dLng = degToRad(point2.longitude - point1.longitude);

    final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1) *
            math.cos(lat2) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);

    final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));

    return earthRadius * c;
  }

  Future<void> _checkForAppUpdate() async {
    if (ref.read(appUpdateDismissedProvider)) return;
    final info = await ref.read(appUpdateProvider.future);
    if (info == null || !mounted) return;
    if (ref.read(activeNavigationProvider) != null) return;
    if (ref.read(appUpdateDismissedProvider)) return;
    ref.read(appUpdateDismissedProvider.notifier).state = true;
    final repo = ref.read(settingsRepositoryProvider);
    final prompted = await repo.getValue(
      SettingsRepository.keyUpdatePromptedVersion,
    );
    if (prompted == info.latestVersion) return;
    await repo.setValue(
      SettingsRepository.keyUpdatePromptedVersion,
      info.latestVersion,
    );
    if (!mounted) return;
    await showAppUpdateDialog(context, info);
  }

  void _onArrived() {
    _showGlassNotice(
      AppStrings.literal('به مقصد رسیدید!'),
      icon: Icons.flag_rounded,
      colors: const [AppColors.speedLow, Color(0xFF10D15C)],
    );
    if (ref.read(ttEnabledProvider)) {
      final voice = ref.read(ttsServiceProvider);
      voice.playCue(VoicePackFa.arrived);
    }

    final session = _navSession;
    _arrivalStopTimer?.cancel();
    _arrivalStopTimer = Timer(const Duration(seconds: 3), () {
      if (mounted && session == _navSession) {
        try {
          _stopNavigation();
        } catch (_) {}
      }
    });
  }
}

class _GpsWarningBanner extends ConsumerWidget {
  final LocationReadiness state;
  const _GpsWarningBanner({super.key, required this.state});

  String get _message {
    switch (state) {
      case LocationReadiness.serviceDisabled:
        return 'GPS دستگاه خاموش است. لطفاً آن را روشن کنید.';
      case LocationReadiness.permissionDenied:
        return 'برای ناوبری به مجوز موقعیت مکانی نیاز است. (ضربه بزنید تا دوباره بپرسیم)';
      case LocationReadiness.permissionDeniedForever:
        return 'مجوز موقعیت مکانی رد شده. برای فعال‌سازی از تنظیمات، ضربه بزنید.';
      case LocationReadiness.ready:
        return '';
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: state == LocationReadiness.ready
          ? null
          : () => ref.read(retryLocationPermissionProvider)(),
      child: _buildContent(),
    );
  }

  Widget _buildContent() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.fromLTRB(10, 10, 16, 10),
          decoration: BoxDecoration(
            color: const Color(0xFF1B1712).withOpacity(.72),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFFFB84D).withOpacity(.35)),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFF8A00).withOpacity(.22),
                blurRadius: 22,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [Color(0xFFFFB84D), Color(0xFFFF7A00)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: const AppIcon(
                  Icons.gps_off_rounded,
                  color: Colors.white,
                  size: 18,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  AppStrings.literal(_message),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                    height: 1.3,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EstimatedLocationBanner extends StatelessWidget {
  const _EstimatedLocationBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xE6233B55),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF75D6FF).withOpacity(.55)),
      ),
      child: Row(
        children: [
          AppIcon(
            Icons.network_check_rounded,
            color: Color(0xFF9FE7FF),
            size: 19,
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              AppStrings.literal('موقعیت تخمینی است؛ در انتظار بازگشت GPS'),
              style: TextStyle(color: Colors.white, fontSize: 12.5),
            ),
          ),
        ],
      ),
    );
  }
}

class _GpsStuckBanner extends StatelessWidget {
  final VoidCallback onRetry;
  const _GpsStuckBanner({super.key, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onRetry,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
          child: Container(
            padding: const EdgeInsets.fromLTRB(10, 10, 16, 10),
            decoration: BoxDecoration(
              color: const Color(0xFF1B1712).withOpacity(.72),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: const Color(0xFFFFB84D).withOpacity(.35),
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF8A00).withOpacity(.22),
                  blurRadius: 22,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [Color(0xFFFFB84D), Color(0xFFFF7A00)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: const AppIcon(
                    Icons.gps_not_fixed_rounded,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    AppStrings.literal(
                      'دریافت موقعیت GPS بیش از حد معمول طول کشیده. مطمئن شوید در فضای باز هستید، سپس برای تلاش دوباره ضربه بزنید.',
                    ),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                      height: 1.3,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _RouteChoiceStrip extends ConsumerWidget {
  const _RouteChoiceStrip({
    required this.routes,
    required this.selectedIndex,
    required this.onSelect,
  });

  final List<RouteInfo> routes;
  final int selectedIndex;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final accent = AppColors.primaryAccent(context);
    return DecoratedBox(
      decoration: BoxDecoration(
        color: AppColors.frameBackground(context).withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: Row(
          children: [
            for (var index = 0; index < routes.length; index++)
              Expanded(
                child: GestureDetector(
                  onTap: () => onSelect(index),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 160),
                    margin: EdgeInsets.only(
                      right: index == 0 ? 4 : 0,
                      left: index == routes.length - 1 ? 4 : 0,
                    ),
                    padding: const EdgeInsets.symmetric(
                      vertical: 8,
                      horizontal: 4,
                    ),
                    decoration: BoxDecoration(
                      color: index == selectedIndex
                          ? accent.withValues(alpha: 0.22)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(11),
                      border: index == selectedIndex
                          ? Border.all(color: accent, width: 1.2)
                          : null,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          index == selectedIndex
                              ? AppStrings.get(context, ref, 'route_selected')
                              : AppStrings.getWithParams(
                                  context,
                                  ref,
                                  'route_numbered',
                                  {'value': index + 1},
                                ),
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: index == selectedIndex
                                ? accent
                                : Colors.white70,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          AppStrings.getWithParams(
                            context,
                            ref,
                            'route_duration_minutes',
                            {'value': routes[index].durationMin.round()},
                          ),
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                          ),
                        ),
                        Text(
                          AppStrings.getWithParams(
                            context,
                            ref,
                            'route_distance_km',
                            {
                              'value': routes[index].distanceKm.toStringAsFixed(
                                    1,
                                  ),
                            },
                          ),
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white60,
                            fontSize: 10,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _StartRoutingButton extends ConsumerWidget {
  const _StartRoutingButton({required this.enabled, required this.onConfirm});

  final bool enabled;
  final VoidCallback? onConfirm;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GestureDetector(
      onTap: enabled ? onConfirm : null,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: enabled
              ? AppColors.surfaceMuted(context)
              : const Color(0xFF334155),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AppIcon(Icons.navigation_rounded, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            Text(
              !enabled
                  ? AppStrings.get(context, ref, 'finding_route_options')
                  : AppStrings.get(context, ref, 'start_button'),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DestinationCard extends ConsumerWidget {
  final SelectedDestination destination;
  final VoidCallback onClear;
  final VoidCallback? onStartNavigation;
  final Future<void> Function()? onSavedPlacesChanged;

  const _DestinationCard({
    required this.destination,
    required this.onClear,
    required this.onStartNavigation,
    this.onSavedPlacesChanged,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.glassPanel(context),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppColors.glassBorder(context)),
            boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 30)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.danger.withOpacity(.15),
                      ),
                      child: const AppIcon(
                        Icons.location_on_rounded,
                        color: AppColors.danger,
                        size: 22,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            AppStrings.get(
                              context,
                              ref,
                              'selected_destination',
                            ),
                            style: TextStyle(
                              color: AppColors.textSecondary(context),
                              fontSize: 12,
                            ),
                          ),
                          Text(
                            destination.label ??
                                AppStrings.get(context, ref, 'point_on_map'),
                            textAlign: TextAlign.right,
                            style: TextStyle(
                              color: AppColors.textPrimary(context),
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      icon: AppIcon(
                        Icons.close_rounded,
                        color: AppColors.textMuted(context),
                      ),
                      onPressed: onClear,
                    ),
                  ],
                ),
              ),
              Divider(
                color: AppColors.textMuted(context).withOpacity(.15),
                height: 1,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: _StartRoutingButton(
                        enabled: onStartNavigation != null,
                        onConfirm: onStartNavigation,
                      ),
                    ),
                    const SizedBox(width: 6),
                    _ActionIconButton(
                      icon: Icons.home_rounded,
                      onTap: () => _setHomeWork(context, ref, 'home'),
                    ),
                    const SizedBox(width: 6),
                    _ActionIconButton(
                      icon: Icons.work_rounded,
                      onTap: () => _setHomeWork(context, ref, 'work'),
                    ),
                    const SizedBox(width: 6),
                    _ActionIconButton(
                      icon: Icons.star_border_rounded,
                      onTap: () =>
                          _showSavePointDialog(context, ref, destination),
                    ),
                    const SizedBox(width: 6),
                    _ActionIconButton(
                      icon: Icons.share_rounded,
                      onTap: () {
                        ref.read(shareServiceProvider).shareCoordinates(
                              latitude: destination.point.latitude,
                              longitude: destination.point.longitude,
                            );
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _setHomeWork(
    BuildContext context,
    WidgetRef ref,
    String category,
  ) async {
    await saveHomeWork(
      context,
      ref,
      category: category,
      latitude: destination.point.latitude,
      longitude: destination.point.longitude,
      address: destination.label,
    );
    await onSavedPlacesChanged?.call();
  }

  void _showSavePointDialog(
    BuildContext context,
    WidgetRef ref,
    SelectedDestination destination,
  ) {
    final nameController = TextEditingController(text: destination.label ?? '');
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.background(context),
        title: Text(
          AppStrings.get(context, ref, 'add_current_location_title'),
          style: const TextStyle(color: Colors.white),
        ),
        content: TextField(
          controller: nameController,
          autofocus: true,
          textAlign: TextAlign.right,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: AppStrings.get(context, ref, 'place_name_hint2'),
            hintStyle: TextStyle(color: AppColors.textMuted(context)),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(AppStrings.get(context, ref, 'cancel')),
          ),
          TextButton(
            onPressed: () async {
              final name = nameController.text.trim();
              if (name.isEmpty) return;
              await ref.read(savedPlacesRepositoryProvider).add(
                    name: name,
                    latitude: destination.point.latitude,
                    longitude: destination.point.longitude,
                    category: 'favorite',
                  );
              await onSavedPlacesChanged?.call();
              if (ctx.mounted) Navigator.pop(ctx);
              if (context.mounted) {
                final message = AppStrings.get(
                  context,
                  ref,
                  'point_saved_snackbar',
                );
                unawaited(
                  ref.read(appNoticeProvider.notifier).show(
                        title: AppStrings.literal('آبتین مپس'),
                        message: message,
                        level: AppNoticeLevel.success,
                      ),
                );
                showGlassNotice(
                  context,
                  message,
                  icon: Icons.favorite_rounded,
                  colors: const [Color(0xFF7AD8A8), Color(0xFF3FAE73)],
                );
              }
            },
            child: Text(AppStrings.get(context, ref, 'save_label')),
          ),
        ],
      ),
    );
  }
}

class _ActionIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _ActionIconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: AppColors.surfaceMuted(context),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.glassBorder(context)),
        ),
        child: AppIcon(icon, color: AppColors.textSecondary(context), size: 22),
      ),
    );
  }
}

class _Compass extends StatelessWidget {
  final double mapBearingDeg;
  const _Compass({required this.mapBearingDeg});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 54,
      height: 54,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.black.withOpacity(.4),
        border: Border.all(color: Colors.white.withOpacity(.15)),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Transform.rotate(
            angle: -mapBearingDeg * 3.1415926535 / 180,
            child: CustomPaint(
              size: const Size(54, 54),
              painter: _CompassTicksPainter(),
            ),
          ),
          CustomPaint(
            size: const Size(54, 54),
            painter: _CompassNorthLabelPainter(mapBearingDeg: mapBearingDeg),
          ),
          Transform.rotate(
            angle: -mapBearingDeg * 3.1415926535 / 180,
            child: CustomPaint(
              size: const Size(30, 30),
              painter: _CompassNeedlePainter(
                southColor: AppColors.textSecondary(context),
              ),
            ),
          ),
          Container(
            width: 5,
            height: 5,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}

class _CompassNorthLabelPainter extends CustomPainter {
  final double mapBearingDeg;
  _CompassNorthLabelPainter({required this.mapBearingDeg});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;
    final angle = -mapBearingDeg * 3.1415926535 / 180;
    final pos = Offset(
      center.dx + radius * math.sin(angle),
      center.dy - radius * math.cos(angle),
    );
    final textPainter = TextPainter(
      text: const TextSpan(
        text: 'N',
        style: TextStyle(
          color: AppColors.danger,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    textPainter.paint(
      canvas,
      Offset(pos.dx - textPainter.width / 2, pos.dy - textPainter.height / 2),
    );
  }

  @override
  bool shouldRepaint(covariant _CompassNorthLabelPainter oldDelegate) =>
      oldDelegate.mapBearingDeg != mapBearingDeg;
}

class _CompassNeedlePainter extends CustomPainter {
  final Color southColor;
  _CompassNeedlePainter({required this.southColor});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final tip = size.height / 2 - 2;
    final tail = size.height / 2 - 2;
    const halfWidth = 4.0;

    final northPaint = Paint()..color = AppColors.danger;
    final southPaint = Paint()..color = southColor;

    final northPath = Path()
      ..moveTo(center.dx, center.dy - tip)
      ..lineTo(center.dx - halfWidth, center.dy)
      ..lineTo(center.dx + halfWidth, center.dy)
      ..close();

    final southPath = Path()
      ..moveTo(center.dx, center.dy + tail)
      ..lineTo(center.dx - halfWidth, center.dy)
      ..lineTo(center.dx + halfWidth, center.dy)
      ..close();

    canvas.drawPath(northPath, northPaint);
    canvas.drawPath(southPath, southPaint);
  }

  @override
  bool shouldRepaint(covariant _CompassNeedlePainter oldDelegate) =>
      oldDelegate.southColor != southColor;
}

class _CompassTicksPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;
    final tickPaint = Paint()
      ..color = Colors.white.withOpacity(.6)
      ..strokeWidth = 1.5;

    for (var i = 0; i < 4; i++) {
      final angle = (i * 90) * 3.1415926535 / 180;
      final outer = Offset(
        center.dx + radius * math.sin(angle),
        center.dy - radius * math.cos(angle),
      );
      final inner = Offset(
        center.dx + (radius - 5) * math.sin(angle),
        center.dy - (radius - 5) * math.cos(angle),
      );
      canvas.drawLine(inner, outer, tickPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _ArCameraButton extends StatelessWidget {
  const _ArCameraButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: 'نمای واقعی (دوربین)',
      child: Material(
        color: Colors.transparent,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Ink(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF1E6BFF).withOpacity(.92),
              border: Border.all(
                color: const Color(0xFF8D99AA).withOpacity(.72),
                width: 1.2,
              ),
            ),
            child: const AppIcon(
              Icons.videocam_rounded,
              color: Colors.white,
              size: 19,
            ),
          ),
        ),
      ),
    );
  }
}

class _NavigationCloseButton extends StatelessWidget {
  const _NavigationCloseButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: 'بستن مسیریابی',
      child: Material(
        color: Colors.transparent,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Ink(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFFE53935).withOpacity(.92),
              border: Border.all(
                color: const Color(0xFF8D99AA).withOpacity(.72),
                width: 1.2,
              ),
            ),
            child: const AppIcon(
              Icons.close_rounded,
              color: Colors.white,
              size: 19,
            ),
          ),
        ),
      ),
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final String? semanticLabel;

  final bool dot;
  const _RoundIconButton({
    required this.icon,
    required this.onTap,
    this.onLongPress,
    this.semanticLabel,
    this.dot = false,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: semanticLabel,
      child: GestureDetector(
        onTap: onTap,
        onLongPress: onLongPress,
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.primaryAccentDark(context),
            border: Border.all(color: AppColors.glassBorder(context)),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.22), blurRadius: 14),
            ],
          ),
          child: dot
              ? Center(
                  child: Container(
                    width: 14,
                    height: 14,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.primaryOnAccent(context),
                    ),
                  ),
                )
              : AppIcon(
                  icon,
                  color: AppColors.primaryOnAccent(context),
                  size: 21,
                ),
        ),
      ),
    );
  }
}

class _SpeedometerDial extends StatelessWidget {
  final double value;
  const _SpeedometerDial({required this.value});

  @override
  Widget build(BuildContext context) {
    const size = 96.0;
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.black.withOpacity(.6),
              border: Border.all(color: Colors.white.withOpacity(.1), width: 1),
              boxShadow: const [
                BoxShadow(color: Colors.black87, blurRadius: 12),
              ],
            ),
          ),
          CustomPaint(
            size: const Size(size, size),
            painter: _GradientArcPainter(
              progress: (value / 180).clamp(0, 1),
              colors: [Colors.green, Colors.yellow, Colors.red],
            ),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                value.round().toString(),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 34,
                  fontWeight: FontWeight.w800,
                  shadows: [
                    Shadow(
                      color: Colors.black87,
                      blurRadius: 8,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
              ),
              Text(
                'km/h',
                style: TextStyle(
                  color: AppColors.textPrimary(context),
                  fontSize: 13,
                  shadows: const [
                    Shadow(
                      color: Colors.black87,
                      blurRadius: 6,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SpeedLimitSign extends StatelessWidget {
  final String value;
  const _SpeedLimitSign({required this.value});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final maxW =
            constraints.maxWidth.isFinite ? constraints.maxWidth : 67.0;
        final maxH =
            constraints.maxHeight.isFinite ? constraints.maxHeight : 67.0;
        final size = math.min(maxW, maxH) > 0 ? math.min(maxW, maxH) : 67.0;
        final scale = size / 67.0;

        return Stack(
          alignment: Alignment.center,
          children: [
            Image.asset(
              'assets/images/speed-limit.webp',
              width: size,
              height: size,
              fit: BoxFit.contain,
            ),
            Text(
              value,
              style: TextStyle(
                color: Colors.white,
                fontSize: 20 * scale,
                fontWeight: FontWeight.w900,
                shadows: const [Shadow(color: Colors.black, blurRadius: 4)],
              ),
            ),
          ],
        );
      },
    );
  }
}

class _GradientArcPainter extends CustomPainter {
  final double progress;
  final List<Color> colors;
  final double thickness;

  _GradientArcPainter({
    required this.progress,
    required this.colors,
    this.thickness = 6,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(
      thickness / 2,
      thickness / 2,
      size.width - thickness,
      size.height - thickness,
    );
    const startAngle = 0.75 * math.pi;
    const sweepAngle = 1.5 * math.pi;

    final backgroundPaint = Paint()
      ..color = Colors.white.withOpacity(.05)
      ..style = PaintingStyle.stroke
      ..strokeWidth = thickness
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(rect, startAngle, sweepAngle, false, backgroundPaint);

    if (progress > 0) {
      final gradient = SweepGradient(
        startAngle: 0,
        endAngle: sweepAngle,
        colors: colors,
        transform: const GradientRotation(startAngle),
      );

      final paint = Paint()
        ..shader = gradient.createShader(rect)
        ..style = PaintingStyle.stroke
        ..strokeWidth = thickness
        ..strokeCap = StrokeCap.round;

      canvas.drawArc(rect, startAngle, sweepAngle * progress, false, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GradientArcPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

/// آیکن کارت مسیر: همان فلشی که روی نقشه کشیده می‌شود. برای میدان، شمارهٔ خروجی
/// هم به‌صورت یک نشان کوچک گوشهٔ آیکن می‌آید.
class _ShapeManeuverIcon extends StatelessWidget {
  const _ShapeManeuverIcon({
    required this.shape,
    required this.color,
    required this.outlineColor,
    required this.borderColor,
    required this.thickness,
    this.exitNumber,
  });

  final ManeuverShape shape;
  final Color color;
  final Color outlineColor;
  final Color borderColor;
  final double thickness;
  final int? exitNumber;

  @override
  Widget build(BuildContext context) {
    final icon = RouteShapeManeuverIcon(
      shape: shape,
      color: color,
      outlineColor: outlineColor,
      borderColor: borderColor,
      thickness: thickness,
    );
    final n = exitNumber;
    if (n == null || n <= 0) return icon;
    return LayoutBuilder(
      builder: (context, c) {
        final side = math.min(c.maxWidth, c.maxHeight);
        final badge = side * 0.30;
        return Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned.fill(child: icon),
            Positioned(
              right: 0,
              top: 0,
              width: badge,
              height: badge,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.black.withValues(alpha: 0.78),
                  border: Border.all(color: color, width: badge * 0.08),
                ),
                child: Center(
                  child: Text(
                    '$n',
                    style: TextStyle(
                      inherit: false,
                      color: Colors.white,
                      fontSize: badge * 0.62,
                      fontWeight: FontWeight.w800,
                      height: 1,
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _ActiveNavigationCard extends ConsumerWidget {
  final ActiveNavigation navigation;
  final VoidCallback onClose;
  final ManeuverShape? maneuverShape;
  const _ActiveNavigationCard({
    required this.navigation,
    required this.onClose,
    this.maneuverShape,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final instruction = navigation.currentInstruction;
    final remainingKm = navigation.remainingDistanceKm;
    final remainingMin = navigation.route.distanceKm > 0
        ? (navigation.route.durationMin *
                (remainingKm / navigation.route.distanceKm))
            .round()
        : 0;
    final dNext = navigation.distanceToNextManeuverM;
    final nextText = dNext >= 1000
        ? AppStrings.getWithParams(context, ref, 'route_distance_km', {
            'value': (dNext / 1000).toStringAsFixed(1),
          })
        : AppStrings.getWithParams(context, ref, 'route_distance_m', {
            'value': dNext.round(),
          });

    final eta = DateTime.now().add(Duration(minutes: remainingMin));
    final etaText =
        '${eta.hour.toString().padLeft(2, '0')}:${eta.minute.toString().padLeft(2, '0')}';
    final instructionParts = _splitRouteInstruction(instruction.text);

    final appearance = ref.watch(appearanceSettingsProvider);
    final isRoundabout =
        instruction.type == 'roundabout' || instruction.type == 'rotary';

    return RouteGuidanceCard(
      settings: appearance,
      data: RouteGuidanceCardData(
        icon: _getInstructionIcon(instruction.type, instruction.modifier),
        iconWidget: (maneuverShape != null && !isRoundabout)
            ? _ShapeManeuverIcon(
                shape: maneuverShape!,
                color: appearance.routeCardArrowColor,
                outlineColor: appearance.routeCardArrowOutlineColor,
                borderColor: appearance.routeCardArrowBorderColor,
                thickness: appearance.routeCardArrowThickness,
                exitNumber: isRoundabout ? instruction.exit : null,
              )
            : isRoundabout
            ? RoundaboutManeuverIcon(
                exit: instruction.exit,
                exitCount: instruction.roundaboutExitCount,
                angleDegrees: instruction.roundaboutAngleDegrees,
                branchAngles: instruction.roundaboutBranchAngles,
                entranceAngles: instruction.roundaboutEntranceAngles,
                exitAngles: instruction.roundaboutExitAngles,
                activeExitAngle: instruction.roundaboutActiveExitAngle,
                // Circulation direction follows the traffic side of the country we
                // are driving in (left-hand traffic circulates clockwise).
                drivingSide:
                    RoadSnapper.instance.leftHandTraffic ? 'left' : 'right',
                color: appearance.routeCardArrowColor,
                thickness: appearance.routeCardArrowThickness,
                sizeFactor: 0.88 * (appearance.roundaboutSizePercent / 100.0),
                style: RoundaboutStyle(
                  roundaboutColor: appearance.roundaboutRingColor,
                  entranceColor: appearance.roundaboutEntranceColor,
                  mainExitColor: appearance.roundaboutMainExitColor,
                  secondaryExitColor: appearance.roundaboutSecondaryExitColor,
                  laneMarkColor: appearance.roundaboutLaneColor,
                  glowColor: appearance.roundaboutGlowColor,
                  roundaboutOpacity: appearance.roundaboutOpacity,
                  entranceOpacity: appearance.roundaboutEntranceOpacity,
                  mainExitOpacity: 1,
                  secondaryExitOpacity: appearance.roundaboutSecondaryOpacity,
                  outlineColor: appearance.routeCardArrowOutlineColor,
                  borderColor: appearance.routeCardArrowBorderColor,
                  showExitNumber: true,
                ),
              )
            : ManeuverArrowIcon(
                modifier: instruction.modifier,
                angleDegrees: instruction.maneuverAngleDegrees,
                color: appearance.routeCardArrowColor,
                outlineColor: appearance.routeCardArrowOutlineColor,
                borderColor: appearance.routeCardArrowBorderColor,
                thickness: appearance.routeCardArrowThickness,
              ),
        distanceText: dNext > 0 ? nextText : '',
        streetText: instructionParts.maneuver,
        subtitleText: instructionParts.street,
        etaLabel: AppStrings.get(context, ref, 'route_eta'),
        etaValue: etaText,
        remainingLabel: AppStrings.get(context, ref, 'route_remaining'),
        remainingValue: _formatRemainingDistance(
          context,
          ref,
          remainingKm * 1000.0,
        ),
        durationLabel: AppStrings.get(context, ref, 'route_time'),
        durationValue: AppStrings.getWithParams(
          context,
          ref,
          'route_duration_minutes',
          {'value': remainingMin},
        ),
        onClose: onClose,
        iconScale:
            isRoundabout ? 1.0 : 0.7 + appearance.routeCardArrowSize * 0.6,
      ),
    );
  }

  ({String maneuver, String? street}) _splitRouteInstruction(String value) {
    var text = value.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (text.isEmpty) return (maneuver: '', street: null);

    var split = text.indexOf('،');
    if (split < 0) {
      final roadBoundary = RegExp(
        r'\s+(?=(?:به|در|روی|وارد)\s+(?:خیابان|بلوار|بزرگراه|جاده|کوچه|اتوبان|آزادراه|میدان)\b)',
      ).firstMatch(text);
      split = roadBoundary?.start ?? -1;
    }
    if (split < 0) {
      final generic = RegExp(
        r'\s+(?=(?:به|در|روی)\s+(?!(?:راست|چپ|سمت|جلو|مقصد|میدان|مسیر|ورودی|خروجی|طرف|دور|عقب|سوی)(?:\s|$))\S)',
      ).allMatches(text);
      if (generic.isNotEmpty) split = generic.last.start;
    }
    if (split < 0) {
      final englishBoundary = RegExp(
        r'\s+(?=(?:onto|on)\s+)',
        caseSensitive: false,
      ).firstMatch(text);
      split = englishBoundary?.start ?? -1;
    }

    if (split >= 0) {
      final maneuver = text.substring(0, split).trim();
      var street = text.substring(split + (text[split] == '،' ? 1 : 0)).trim();
      street = street.replaceFirst(
        RegExp(r'^(?:به|در|روی|وارد|onto|on)\s+', caseSensitive: false),
        '',
      );
      if (street.isNotEmpty) {
        return (
          maneuver: _compactRouteInstruction(maneuver),
          street: _compactRouteInstruction(street),
        );
      }
    }
    return (maneuver: _compactRouteInstruction(text), street: null);
  }

  String _compactRouteInstruction(String value) {
    final text = value.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (text.length <= 52) return text;
    return '${text.substring(0, 49).trimRight()}…';
  }

  String _formatRemainingDistance(
    BuildContext context,
    WidgetRef ref,
    double meters,
  ) {
    if (!meters.isFinite || meters < 0) return '--';
    if (meters < 1000) {
      return AppStrings.getWithParams(context, ref, 'route_distance_m', {
        'value': meters.round(),
      });
    }
    final km = meters / 1000.0;
    return AppStrings.getWithParams(context, ref, 'route_distance_km', {
      'value': km < 10 ? km.toStringAsFixed(1) : km.toStringAsFixed(0),
    });
  }

  IconData _getInstructionIcon(String type, String? modifier) {
    switch (type) {
      case 'turn':
      case 'on ramp':
      case 'off ramp':
      case 'fork':
      case 'uturn':
      case 'continue':
      case 'new name':
      case 'end of road':
        final m = (modifier ?? '')
            .toLowerCase()
            .replaceAll('-', ' ')
            .replaceAll('_', ' ');
        if (type == 'uturn' || m.contains('uturn') || m.contains('u turn')) {
          return m.contains('right')
              ? Icons.u_turn_right_rounded
              : Icons.u_turn_left_rounded;
        }
        if (m.contains('sharp left')) return Icons.turn_sharp_left_rounded;
        if (m.contains('sharp right')) return Icons.turn_sharp_right_rounded;
        if (m.contains('slight left')) return Icons.turn_slight_left_rounded;
        if (m.contains('slight right')) return Icons.turn_slight_right_rounded;
        if (m.contains('left')) return Icons.turn_left_rounded;
        if (m.contains('right')) return Icons.turn_right_rounded;
        if (m.contains('straight')) return Icons.straight_rounded;
        return Icons.arrow_upward_rounded;
      case 'arrive':
        return Icons.flag_rounded;
      case 'depart':
        return Icons.navigation_rounded;
      case 'merge':
        return Icons.merge_rounded;
      case 'roundabout':
      case 'rotary':
        return Icons.roundabout_right_rounded;
      default:
        return Icons.arrow_upward_rounded;
    }
  }
}

class _RouteAlertSpriteStack extends StatelessWidget {
  const _RouteAlertSpriteStack({
    required this.alerts,
    required this.sizePercent,
  });

  final List<RouteAlert> alerts;
  final double sizePercent;

  @override
  Widget build(BuildContext context) {
    final scale = (sizePercent / 100.0).clamp(0.65, 1.6).toDouble();
    return Wrap(
      spacing: 4,
      runSpacing: 4,
      children: [
        for (final alert in alerts.take(3))
          _RoadAlertIconOnly(alert: alert, size: 48 * scale),
      ],
    );
  }
}

class _RoadAlertIconOnly extends StatelessWidget {
  final RouteAlert alert;
  final double size;
  const _RoadAlertIconOnly({required this.alert, this.size = 48});

  String? get _asset => switch (alert.type) {
        RouteAlertType.speedCamera => 'assets/sprites/alert_camera.png',
        RouteAlertType.speedBump => 'assets/sprites/alert_speed_bump.png',
        RouteAlertType.trafficLight => 'assets/sprites/route_traffic_light.png',
        RouteAlertType.policeCheckpoint => 'assets/sprites/route_police.png',
      };

  @override
  Widget build(BuildContext context) {
    final asset = _asset;
    if (asset == null) {
      return SizedBox(
        width: size,
        height: size,
        child: AppIcon(
          Icons.local_police_rounded,
          color: AppColors.danger,
          size: size * .72,
        ),
      );
    }
    return SizedBox(
      width: size,
      height: size,
      child: Image.asset(
        asset,
        fit: BoxFit.contain,
        filterQuality: FilterQuality.high,
        gaplessPlayback: true,
      ),
    );
  }
}
