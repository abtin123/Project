# TODO

- Verify on device: small roundabouts / U-turns — car stays on route line, arrow shape + head direction correct (card icon too).
- If car still detaches: log `_routeMatchLastProgressM` vs animator `_routeProgressM` in roundabouts.
- Consider smoothing offline route geometry at creation (ManeuverGeometry.smoothRoute is unused) — needs instruction index remap.
- Mini-roundabouts: derive exit bearing from geometry instead of instruction modifier.
