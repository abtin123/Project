# TODO
## Done
- 3D buildings: height expr (render_height/height/levels, default 9m), height-based tint, vertical gradient, map light (`_apply3dBuildings` in abm_style_assets.dart); extrusion from z13; style revision v5.
## Left
- Test on device (offline + online); tune default height / light.
- If offline MBTiles lack height tags, add `height`/`levels` to buildings layer in Builder.
- Optional: raise default map pitch.

## Country SVGs (download screen)
- Done: assets/maps/countries/{iso2}.svg for all 37 countries in countries.json (Natural Earth 10m, simplified, single path each; ES has Canary inset, US has AK/HI inset, FR metropolitan only, UA includes Crimea).
- Optional: region-level SVGs for countries other than IR.

## Turn camera/car fix (2026-10-04)
- online_map_view.dart: camera target now lies along the commanded (smoothed) bearing instead of the route arc (removed lateral camera jump at corners); bearing target leads along the route by ~0.8s of travel; bearing rate limit 150->260 deg/s, deadband 1.5->0.6.
- Untested on device (no Flutter SDK). Step 2 done: vehicle screen projection EMA-smoothed (alpha 0.22) in follow+driving mode (_refreshScreenPositions).

## 2026-10-04 — Route modes
- Offline engine: fastest (highway-preferring class factors), shortest (pure distance, no hierarchy pruning), economic (50/50 time+distance). Online OSRM only re-ranks alternatives.
- `flutter analyze` not run here (no SDK); verify `main.dart` fireImmediately fix in CI.
- Camera: bearing held in tight curves/small roundabouts (route turns >100° in 60m); adaptive camera tick (500ms stopped / 66ms moving); road-snap timer 2.5s.
- Route card: street name split to 2nd line even without خیابان/بلوار prefix (generic به/در/روی boundary); subtitle size 0.55→0.7 of title.
- Free-drive: camera look-ahead 60dp (max 90m) instead of 150dp; RoadSnapper direction hysteresis (flip only ≥15km/h with GPS heading clearly opposite), robust oneway parsing (strings/bool/roundabout), road query 1s/5m/240px.
- Still unverified on device: whether rendered `abm-road-line` features carry `oneway` — if marker is still reversed on one-way streets, send /abm-log + short screen recording.

## 2026-10-04 — Turn/U-turn + alert icons
- abtinmap_routing_provider.dart: turn angle from ~20m look-around bearings; same-way turns >=45° now announced; sharp class (115–150°); two same-direction turns within 60m totalling >=140° merge into a U-turn.
- home_screen.dart `_getInstructionIcon`: fork / on-off ramp / use lane / roundabout turn now keep direction. Police alert uses assets/sprites/route_police.png.
- routing_instruction_localizer.dart: uturn / fork / use lane / exit roundabout texts.
- Speed bump icon replaced with supplied red-ring sign (route_speed_bump.png, 1024px transparent); new route_police.png (supplied police-officer avatar, background removed, inside the same red ring).
- road_alert_badge.dart (settings preview) uses the same two PNGs.
- Untested: no Flutter SDK here — run `flutter analyze` and test on device.
- route_traffic_light.png: now 1024px, traffic light inside the same red ring (was 3072px, no ring); settings preview badge uses it too.
- Settings: route-alert preview card (appearance_settings_screen.dart) now shows icon-only images (camera, traffic light, speed bump, police) via road_alert_badge.dart `roadAlertAsset`; old glass-card painters removed.
- Settings: map_settings_screen.dart POI toggles for speed camera / speed bump / traffic light show the same PNGs instead of Material icons (`_poiAsset`). No police POI toggle exists there (no `poi_police` locale key).
- Untested: no Flutter SDK here — run `flutter analyze` and check on device.
- route_camera.png: redrawn speed-camera pictogram (dark body, white lens ring, red waves) inside the same red ring, 1024px (was 3072px neon badge).
