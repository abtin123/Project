#!/usr/bin/env bash
set -euo pipefail
# Run weekly from CI/cron. The existing builder should accept OSM replication
# diffs and preserve unchanged chunks; then this script publishes only delta.
: "${COUNTRY:?COUNTRY required}"; : "${OLD_ABM:?OLD_ABM required}"; : "${NEW_ABM:?NEW_ABM required}"; : "${OUT_DIR:=release}"
python3 tool/maps/build_incremental_abm.py "$OLD_ABM" "$NEW_ABM" "$OUT_DIR" --code "$COUNTRY"
