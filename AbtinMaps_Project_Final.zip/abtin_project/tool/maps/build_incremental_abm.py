#!/usr/bin/env python3
"""Incremental ABM release planner.
Keeps one ABM container, but rebuilds only dirty regions/chunks and emits a
chunk patch understood by AbmMapService. Integrate after the existing country
builder: pass old/new ABM and an OSM replication sequence."""
import argparse, hashlib, json, pathlib, shutil, time

def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def main():
 a=argparse.ArgumentParser(); a.add_argument('old'); a.add_argument('new'); a.add_argument('out'); a.add_argument('--code',required=True); a.add_argument('--chunk-size',type=int,default=1<<20); ns=a.parse_args()
 old,new,out=map(pathlib.Path,(ns.old,ns.new,ns.out)); out.mkdir(parents=True,exist_ok=True)
 target_size=new.stat().st_size; blocks=[]; patch=out/f'{ns.code}.abmpatch'
 with old.open('rb') as fo,new.open('rb') as fn,patch.open('wb') as fp:
  i=0; off=0
  while True:
   nb=fn.read(ns.chunk_size); ob=fo.read(ns.chunk_size)
   if not nb: break
   if nb!=ob:
    pos=fp.tell(); fp.write(nb); blocks.append({'index':i,'offset':pos,'length':len(nb)})
   i+=1
 manifest={'version':1,'code':ns.code,'base_sha256':sha(old),'target_sha256':sha(new),'target_size':target_size,'chunk_size':ns.chunk_size,'blocks':blocks,'patch_sha256':sha(patch),'created_at':int(time.time())}
 mp=out/f'{ns.code}.patch.json'; mp.write_text(json.dumps(manifest,indent=2),encoding='utf8')
 print(json.dumps({'changed_blocks':len(blocks),'patch':str(patch),'manifest':str(mp)}))
if __name__=='__main__': main()
