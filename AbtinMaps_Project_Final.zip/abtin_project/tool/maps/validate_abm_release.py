#!/usr/bin/env python3
"""Release validation: PMTiles plus required ABM resources/search/style contracts."""
import argparse, json, pathlib, subprocess, sys

def main():
 p=argparse.ArgumentParser(); p.add_argument('abm'); p.add_argument('--style'); p.add_argument('--search-index'); ns=p.parse_args()
 subprocess.run(['pmtiles','verify',ns.abm],check=True)
 if ns.style:
  s=json.load(open(ns.style,encoding='utf8')); layers=s.get('layers',[])
  ids={x.get('id') for x in layers}; assert 'poi-symbols' in ids,'missing poi-symbols'
  road=[x for x in layers if 'road' in (x.get('id') or '') and x.get('type')=='symbol']
  assert road,'missing road label layers'
  assert max((x.get('minzoom',0) for x in road),default=0)<=13,'local labels start too late'
 if ns.search_index:
  d=json.load(open(ns.search_index,encoding='utf8')); places=d.get('places',d) if isinstance(d,dict) else d
  assert isinstance(places,list) and places,'offline search index empty'
  for x in places[:100]: assert x.get('name') and x.get('lat') is not None and x.get('lon') is not None
 print('ABM release validation OK')
if __name__=='__main__': main()
