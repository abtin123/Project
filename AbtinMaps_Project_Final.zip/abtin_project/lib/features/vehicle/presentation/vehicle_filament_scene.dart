/// سازگاری با مسیر قدیمی renderer خودرو.
///
/// نمایش خودرو اکنون تنها با مدل GLB در لایهٔ MapLibre انجام می‌شود.
library;

export 'glb_vehicle_marker.dart' show TopDownCarMarker, GlbVehicleMarker;
