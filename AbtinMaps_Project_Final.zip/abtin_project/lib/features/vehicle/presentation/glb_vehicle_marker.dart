import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:interactive_3d/interactive_3d.dart';

import 'vehicle_provider.dart';

double vehicleScreenRotationDegrees(double headingDeg) {
  final normalized = headingDeg.isFinite ? headingDeg : 0.0;
  final value = (normalized + 180.0) % 360.0;
  return value < 0 ? value + 360.0 : value;
}

/// Native Filament GLB renderer shared by the settings preview and map marker.
/// No WebView or user-facing lighting control is used — rendering is 100%
/// on-device via Google Filament (interactive_3d plugin), not a browser view.
class TopDownCarMarker extends StatefulWidget {
  const TopDownCarMarker({
    super.key,
    required this.size,
    required this.modelIndex,
    required this.bodyColor,
    this.headingDeg = 0,
    this.cameraTiltDegrees = 48,
    this.interactive = false,
  });

  final double size;
  final int modelIndex;
  final Color bodyColor;
  final double headingDeg;
  final double cameraTiltDegrees;
  final bool interactive;

  static const _bodyMaterialNames = <List<String>>[
    ['paint', 'body', 'carpaint'],
    ['material', 'body'],
    ['set1', 'body'],
    ['carpaint', 'pearl_paint', 'body'],
  ];

  List<MaterialOverride> _bodyOverrides(int index) {
    final rgba = <double>[
      bodyColor.r,
      bodyColor.g,
      bodyColor.b,
      bodyColor.a,
    ];
    return [
      for (final name in _bodyMaterialNames[index.clamp(0, 3).toInt()])
        MaterialOverride(
          name: name,
          color: rgba,
          roughness: 0.42,
          metallic: 0.15,
        ),
    ];
  }

  @override
  State<TopDownCarMarker> createState() => _TopDownCarMarkerState();
}

class _TopDownCarMarkerState extends State<TopDownCarMarker> {
  @override
  Widget build(BuildContext context) {
    final index = widget.modelIndex.clamp(0, vehicleModels.length - 1).toInt();
    final angle =
        vehicleScreenRotationDegrees(widget.headingDeg) * math.pi / 180.0;
    // The marker itself remains a real GLB. This transform only controls its
    // screen presentation: a top-down, slightly rear-biased view, while the
    // map camera tilt is allowed to adjust it without replacing the model.
    final tilt = widget.cameraTiltDegrees.clamp(25.0, 65.0).toDouble();
    final xTiltRadians = (tilt / 90.0) * (math.pi * 0.46);

    return SizedBox.square(
      dimension: widget.size,
      child: Transform(
        alignment: Alignment.center,
        transform: Matrix4.identity()
          ..setEntry(3, 2, 0.0012)
          ..rotateX(xTiltRadians),
        child: Transform.rotate(
          angle: angle,
          child: IgnorePointer(
            ignoring: !widget.interactive,
            child: Interactive3d(
              key: ValueKey(
                'filament-map-${vehicleModels[index]}-${widget.bodyColor.toARGB32()}',
              ),
              // همان GLB انتخاب‌شده در تنظیمات، مستقیماً روی نقشه نیز
              // توسط Filament نمایش داده می‌شود.
              modelPath: vehicleModels[index],
              // IBL فقط برای نوردهی مدل است؛ skybox و پس‌زمینه عمداً
              // استفاده نمی‌شوند تا خود نقشه پشت مدل دیده شود.
              iblPath: 'assets/models/venetian_crossroads_2k_ibl.ktx',
              defaultZoom: 1.35,
              initialMaterialOverrides: widget._bodyOverrides(index),
              loadingWidget: const SizedBox.shrink(),
            ),
          ),
        ),
      ),
    );
  }

}

/// Backwards-compatible name used by existing callers.
class GlbVehicleMarker extends TopDownCarMarker {
  const GlbVehicleMarker({
    super.key,
    required super.size,
    required super.modelIndex,
    required super.bodyColor,
    super.headingDeg,
    super.cameraTiltDegrees,
    super.interactive,
  });
}


/// Legacy alias retained for code that still references ThreeDVehicleMarker.
class ThreeDVehicleMarker extends GlbVehicleMarker {
  const ThreeDVehicleMarker({
    super.key,
    required super.size,
    required super.modelIndex,
    required super.bodyColor,
    super.headingDeg,
    super.cameraTiltDegrees,
    super.interactive,
  });
}
