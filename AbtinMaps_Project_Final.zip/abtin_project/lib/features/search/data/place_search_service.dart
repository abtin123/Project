import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:abtin_maps/core/geo/geo_types.dart';

/// یک نتیجهٔ جستجوی مکان.
class PlaceSearchResult {
  final String name;
  final String? region;
  final LatLng point;
  final bool isOffline;

  const PlaceSearchResult({
    required this.name,
    required this.point,
    this.region,
    this.isOffline = false,
  });
}

/// جستجوی مکان با استفاده از Nominatim (OpenStreetMap) — با اولویت‌دهی
/// به نتایج نزدیک موقعیت فعلی کاربر (biasLat/biasLng) در صورت وجود.
class PlaceSearchService {
  static const String _baseUrl = 'https://nominatim.openstreetmap.org/search';

  Future<List<PlaceSearchResult>> searchOnline(
    String query, {
    double? biasLat,
    double? biasLng,
  }) async {
    final trimmed = query.trim();
    if (trimmed.isEmpty) return const [];

    final params = {
      'q': trimmed,
      'format': 'jsonv2',
      'addressdetails': '1',
      'limit': '8',
      'accept-language': 'fa',
    };
    if (biasLat != null && biasLng != null) {
      // محدودهٔ اطراف موقعیت فعلی برای اولویت‌دهی به نتایج نزدیک‌تر.
      const delta = 2.5;
      params['viewbox'] =
          '${biasLng - delta},${biasLat + delta},${biasLng + delta},${biasLat - delta}';
      params['bounded'] = '0';
    }

    final uri = Uri.parse(_baseUrl).replace(queryParameters: params);
    final response = await http.get(
      uri,
      headers: const {'User-Agent': 'AbtinMaps/1.0'},
    ).timeout(const Duration(seconds: 8));

    if (response.statusCode != 200) {
      throw Exception('خطا در جستجو: ${response.statusCode}');
    }

    final List<dynamic> data = jsonDecode(response.body) as List<dynamic>;
    return data.map((raw) {
      final item = raw as Map<String, dynamic>;
      final address = item['address'] as Map<String, dynamic>?;
      final region = address == null
          ? null
          : ([
              address['state'],
              address['city'],
            ]..removeWhere((e) => e == null || (e as String).isEmpty))
              .cast<String>()
              .join('، ');
      return PlaceSearchResult(
        name: (item['display_name'] as String? ?? trimmed).split('،').first,
        region: region?.isEmpty == true ? null : region,
        point: LatLng(
          double.parse(item['lat'] as String),
          double.parse(item['lon'] as String),
        ),
      );
    }).toList(growable: false);
  }
}
