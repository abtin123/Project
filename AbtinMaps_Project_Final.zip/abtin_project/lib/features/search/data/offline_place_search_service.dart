import 'dart:io';
import 'package:sqlite3/sqlite3.dart';
import '../../../abtinmap/abm_container.dart';
import '../../../abtinmap/abm_map_service.dart';
import '../../../core/abm_debug_log.dart';
import '../../../core/geo/geo_types.dart';
import 'place_search_service.dart';

class OfflinePlaceSearchService {
  OfflinePlaceSearchService(this._maps);
  final AbmMapService _maps;
  String? _openedMap;
  String? _dbPath;

  Future<List<PlaceSearchResult>> search(String query, {required String mapFileName, double? biasLat, double? biasLng, int limit = 12}) async {
    final q = query.trim();
    if (q.length < 2 || mapFileName.isEmpty || mapFileName == '__none__.abm') return const [];
    final path = await _ensureIndex(mapFileName);
    if (path == null) return const [];
    Database? db;
    try {
      db = sqlite3.open(path, mode: OpenMode.readOnly);
      final rows = db.select('SELECT name,region,latitude,longitude,bm25(places_fts) AS rank FROM places_fts WHERE places_fts MATCH ? ORDER BY rank,name LIMIT ?', [_ftsQuery(q), limit]);
      return [for (final row in rows) if (row['latitude'] is num && row['longitude'] is num) PlaceSearchResult(name: (row['name'] as String?) ?? q, region: row['region'] as String?, point: LatLng((row['latitude'] as num).toDouble(), (row['longitude'] as num).toDouble()), isOffline: true)];
    } catch (e, st) {
      AbmDebugLog.add('[OFFLINE SEARCH] failed: $e\n$st');
      return const [];
    } finally { db?.dispose(); }
  }

  String _ftsQuery(String q) {
    final tokens = q.replaceAll(RegExp(r'[^\p{L}\p{N}\s]', unicode: true), ' ').trim().split(RegExp(r'\s+'));
    return tokens.where((e) => e.isNotEmpty).map((e) => '"${e.replaceAll('"', '""')}"*').join(' AND ');
  }

  Future<String?> _ensureIndex(String mapFileName) async {
    if (_openedMap == mapFileName && _dbPath != null && await File(_dbPath!).exists()) return _dbPath;
    final file = await _maps.localFile(mapFileName);
    final container = await AbtinMapContainer.tryOpen(file);
    if (container == null || !container.entries.containsKey('search/places.sqlite')) return null;
    final target = File('${file.path}.search.sqlite');
    if (!await target.exists()) {
      final tmp = File('${target.path}.part');
      await container.extractEntry('search/places.sqlite', tmp);
      if (await target.exists()) await target.delete();
      await tmp.rename(target.path);
    }
    _openedMap = mapFileName; _dbPath = target.path; return _dbPath;
  }
}
