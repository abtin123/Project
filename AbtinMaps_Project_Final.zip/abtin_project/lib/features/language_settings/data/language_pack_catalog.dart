library;

import '../../../core/localization/locale_flags.dart';

/// مانیفست و فایل‌های زبان در یک release مستقل منتشر می‌شوند. بسته‌ها فقط
/// رشته‌های رابط را دارند؛ هیچ دادهٔ نقشه، نام مکان یا برچسب جغرافیایی در آن‌ها
/// قرار نمی‌گیرد. [builtInLanguages] فقط زبان‌های همراه APK را مشخص می‌کند و
/// نباید برای فیلتر کردن ورودی‌های مانیفست استفاده شود.
const String kLangPacksManifestUrl =
    'https://github.com/abtin123/Make-langueg/releases/download/langpacks-latest/manifest.json';

class LanguagePack {
  const LanguagePack({
    required this.code,
    required this.name,
    required this.flag,
    this.direction = 'ltr',
    this.sizeBytes = 0,
    this.stringCount = 0,
    this.version = '',
    this.sha256 = '',
    String? downloadUrl,
  }) : _downloadUrl = downloadUrl;

  final String code;
  final String name;
  final String flag;
  final String direction;
  final int sizeBytes;
  final int stringCount;
  final String version;
  final String sha256;
  final String? _downloadUrl;
  String get downloadUrl =>
      _downloadUrl ??
      'https://github.com/abtin123/Make-langueg/releases/download/langpacks-latest/lang_$code.abl';

  String get localFileName => 'lang_$code.json';

  factory LanguagePack.fromManifestJson(Map<String, dynamic> json) {
    final rawCode = json['language_code'] ?? json['code'] ?? json['locale'];
    final rawUrl = json['download_url'] ?? json['url'] ?? json['download'];
    if (rawCode is! String || rawCode.trim().isEmpty ||
        rawUrl is! String || rawUrl.trim().isEmpty) {
      throw const FormatException('رکورد زبان، کد یا لینک دانلود معتبر ندارد.');
    }
    final code = rawCode.trim().toLowerCase();
    final rawName = json['language'] ?? json['name'] ?? json['language_name'];
    final rawDirection = json['direction'];
    return LanguagePack(
      code: code,
      name: rawName is String && rawName.trim().isNotEmpty
          ? cleanLocalizedLabel(rawName)
          : code,
      flag: flagAssetForLanguageCode(code),
      direction: rawDirection == 'rtl' ? 'rtl' : 'ltr',
      sizeBytes: (json['size'] ?? json['size_bytes']) is num
          ? ((json['size'] ?? json['size_bytes']) as num).toInt()
          : 0,
      stringCount: (json['string_count'] ?? json['strings']) is num
          ? ((json['string_count'] ?? json['strings']) as num).toInt()
          : 0,
      version: json['version']?.toString() ?? '',
      sha256: json['sha256']?.toString() ?? '',
      downloadUrl: rawUrl.trim(),
    );
  }
}

final List<LanguagePack> builtInLanguages = [
  LanguagePack(
      code: 'fa',
      name: 'فارسی',
      flag: flagAssetForLanguageCode('fa'),
      direction: 'rtl'),
  LanguagePack(
      code: 'en', name: 'English', flag: flagAssetForLanguageCode('en')),
];
