import 'dart:async';
import '../../../core/abm_debug_log.dart';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:maplibre_gl/maplibre_gl.dart' as ml;

import '../../../abtinmap/abm_models.dart';
import '../../../core/geo/geo_types.dart';
import '../../../shared/providers/map_style_providers.dart';
import '../../gps/data/location_service.dart';
import '../../vehicle/presentation/nav_arrow_painter.dart';
import '../../vehicle/presentation/glb_vehicle_marker.dart';
import '../../vehicle/presentation/vehicle_provider.dart';

/// زاویهٔ مکان‌نما نسبت به صفحه، بر پایهٔ heading جغرافیایی GPS و جهت فعلی
/// دوربین. خروجی در بازهٔ استاندارد ۰ تا کمتر از ۳۶۰ درجه است.
double mapRelativeHeading(double headingDeg, double mapBearingDeg) {
  final heading = headingDeg.isFinite ? headingDeg : 0.0;
  final bearing = mapBearingDeg.isFinite ? mapBearingDeg : 0.0;
  return (heading - bearing) % 360.0;
}

/// MapLibre Android موقعیت را با pixel فیزیکی View برمی‌گرداند، در حالی که
/// Positioned در Flutter با logical pixel کار می‌کند. بدون این تبدیل، marker
/// روی نمایشگرهای با تراکم بالاتر از ۱ به سمت لبهٔ پایین/راست جابه‌جا می‌شد.
const Map<int, List<String>> _offlinePoiClassesByKlass = {
  AbmKlass.poiFuel: ['fuel'],
  AbmKlass.poiParking: ['parking', 'bicycle_parking'],
  AbmKlass.poiHospital: ['hospital', 'clinic', 'doctors'],
  AbmKlass.poiPharmacy: ['pharmacy'],
  AbmKlass.poiPolice: ['police'],
  AbmKlass.poiSchool: ['school', 'college', 'university', 'kindergarten'],
  AbmKlass.poiRestaurant: ['restaurant', 'fast_food', 'food_court'],
  AbmKlass.poiCafe: ['cafe', 'ice_cream'],
  AbmKlass.poiBank: ['bank', 'atm'],
  AbmKlass.poiHotel: ['hotel', 'motel', 'hostel', 'guest_house', 'apartment'],
  AbmKlass.poiSupermarket: [
    'supermarket',
    'convenience',
    'department_store',
    'mall',
    'greengrocer',
  ],
  AbmKlass.poiMosque: ['place_of_worship'],
  AbmKlass.poiToilets: ['toilets'],
  AbmKlass.poiBusStation: ['bus_station', 'bus_stop'],
  AbmKlass.poiAirport: ['aerodrome', 'airport'],
  AbmKlass.poiAttraction: [
    'attraction',
    'museum',
    'viewpoint',
    'zoo',
    'theme_park',
    'monument',
    'memorial',
    'castle',
    'archaeological_site',
  ],
  AbmKlass.poiPark: ['park', 'garden', 'nature_reserve'],
  AbmKlass.poiPitch: ['pitch', 'sports_centre', 'stadium'],
  AbmKlass.poiPlace: [
    'city',
    'town',
    'village',
    'suburb',
    'neighbourhood',
    'quarter',
    'hamlet',
    'locality',
  ],
  AbmKlass.poiSpeedCamera: ['speed_camera'],
  AbmKlass.poiSpeedBump: ['bump', 'hump', 'table', 'cushion', 'chicane'],
  AbmKlass.poiTrafficLight: ['traffic_signals'],
};

List<dynamic> offlinePoiLayerFilter(Set<int>? visibleKlasses) {
  if (visibleKlasses != null && visibleKlasses.isEmpty) {
    return const <dynamic>['==', ['get', 'class'], '__abtin-hidden-poi__'];
  }
  final enabled = visibleKlasses ?? _offlinePoiClassesByKlass.keys.toSet();
  final classes = <String>{
    for (final klass in enabled) ...?_offlinePoiClassesByKlass[klass],
  }.toList(growable: false);
  // هر دو schema پشتیبانی می‌شود: class متنی در MVT یا klass عددی ABM.
  return <dynamic>[
    'all',
    ['has', 'name'],
    ['any',
      ['in', ['get', 'class'], ...classes],
      ['in', ['get', 'klass'], ...enabled],
    ],
  ];
}

bool sameOfflinePoiVisibility(Set<int>? a, Set<int>? b) {
  if (a == null || b == null) return a == null && b == null;
  return a.length == b.length && a.containsAll(b);
}

List<dynamic> roadWidthExpression(double scale, {double base = 1.0}) {
  final safeScale = scale.clamp(0.6, 1.8).toDouble();
  return <dynamic>[
    'interpolate',
    ['linear'],
    ['zoom'],
    6,
    base * safeScale,
    10,
    base * 1.35 * safeScale,
    14,
    base * 3.2 * safeScale,
    18,
    base * 8.0 * safeScale,
    20,
    base * 12.0 * safeScale,
  ];
}

Offset mapScreenPointToFlutterOffset(
  math.Point<dynamic> screenPoint,
  double devicePixelRatio,
) {
  final ratio = devicePixelRatio.isFinite && devicePixelRatio > 0
      ? devicePixelRatio
      : 1.0;
  return Offset(
    screenPoint.x.toDouble() / ratio,
    screenPoint.y.toDouble() / ratio,
  );
}

class OnlineRouteOverlay {
  const OnlineRouteOverlay({
    required this.geometry,
    required this.color,
    required this.width,
  });

  final List<LatLng> geometry;
  final Color color;
  final double width;
}

/// MapLibre Native نمایش نقشهٔ آنلاین را با همان renderer GPU نقشهٔ آفلاین
/// PMTiles هم‌راستا نگه می‌دارد. دادهٔ route و خودرو از سرویس‌های محلی آبتین
/// می‌آید و به provider نقشه وابسته نیست.
class OnlineMapView extends StatefulWidget {
  const OnlineMapView({
    super.key,
    required this.vehiclePosition,
    required this.vehicle,
    required this.modelIndex,
    required this.isDark,
    required this.followVehicle,
    required this.drivingMode,
    required this.markerColor,
    required this.vehicleColor,
    required this.pinSizePercent,
    required this.carSizePercent,
    required this.pinShadowEnabled,
    required this.cameraTiltDegrees,
    required this.locationFocusRequest,
    required this.palette,
    required this.visiblePoiKlasses,
    this.localStylePath,
    this.routeGeometry,
    this.routeOverlays,
    this.routeColor = const Color(0xFF2FE6C4),
    this.routeWidth = 7.0,
    this.destination,
    this.onLongPress,
    this.onRouteTap,
    this.onUserGestureStart,
    this.onCameraIdle,
    this.onCameraPositionChanged,
    this.onStyleLoaded,
  });

  /// null یعنی هنوز فیکس زنده و قابل اعتماد دریافت نشده است. در این حالت
  /// نقشه باز می‌ماند، اما marker و follow-camera عمداً فعال نمی‌شوند.
  final VehiclePosition? vehiclePosition;
  final VehicleType vehicle;
  final int modelIndex;
  final bool isDark;
  final bool followVehicle;
  final bool drivingMode;
  final Color markerColor;
  final Color vehicleColor;
  final double pinSizePercent;
  final double carSizePercent;
  final bool pinShadowEnabled;
  final double cameraTiltDegrees;
  final int locationFocusRequest;
  final OfflineMapPalette palette;

  /// null یعنی همهٔ دسته‌های POI، و set خالی یعنی همه پنهان هستند.
  final Set<int>? visiblePoiKlasses;

  /// در حالت آفلاین، مسیر JSON این style به PMTiles محلی اشاره می‌کند.
  /// null یعنی style آنلاینِ بدون API key استفاده شود.
  final String? localStylePath;
  final List<LatLng>? routeGeometry;
  final List<OnlineRouteOverlay>? routeOverlays;
  final Color routeColor;
  final double routeWidth;
  final LatLng? destination;
  final ValueChanged<LatLng>? onLongPress;
  final ValueChanged<int>? onRouteTap;
  final VoidCallback? onUserGestureStart;
  final VoidCallback? onCameraIdle;
  final ValueChanged<ml.CameraPosition>? onCameraPositionChanged;
  final VoidCallback? onStyleLoaded;

  @override
  State<OnlineMapView> createState() => _OnlineMapViewState();
}

class _OnlineMapViewState extends State<OnlineMapView> {
  static const _dayStyle = 'https://tiles.openfreemap.org/styles/liberty';
  static const _nightStyle = 'https://tiles.openfreemap.org/styles/dark';
  static const _cameraUpdateInterval = Duration(milliseconds: 100);
  static const _fallbackInitialTarget = ml.LatLng(32.5, 54.0);

  ml.MapLibreMapController? _controller;
  ml.CameraPosition? _camera;
  Offset? _vehicleScreen;
  Offset? _destinationScreen;
  bool _styleReady = false;
  bool _screenUpdateRunning = false;
  bool _screenUpdateQueued = false;
  DateTime _lastCameraUpdate = DateTime.fromMillisecondsSinceEpoch(0);
  final List<ml.Line> _routeLines = <ml.Line>[];
  int _routeRefreshGeneration = 0;
  int _pendingLocationFocusRequest = 0;
  bool _onlineTrunkLayerAdded = false;

  ml.LatLng _toMapLibrePoint(LatLng point) =>
      ml.LatLng(point.latitude, point.longitude);

  ml.LatLng _toMapLibreVehiclePoint(VehiclePosition point) =>
      ml.LatLng(point.lat, point.lng);

  List<OnlineRouteOverlay> get _routeOverlays =>
      widget.routeOverlays ??
      (widget.routeGeometry == null
          ? const <OnlineRouteOverlay>[]
          : <OnlineRouteOverlay>[
              OnlineRouteOverlay(
                geometry: widget.routeGeometry!,
                color: widget.routeColor,
                width: widget.routeWidth,
              ),
            ]);

  @override
  void initState() {
    super.initState();
    _pendingLocationFocusRequest = widget.locationFocusRequest;
  }

  @override
  void didUpdateWidget(covariant OnlineMapView oldWidget) {
    super.didUpdateWidget(oldWidget);
    final previousPosition = oldWidget.vehiclePosition;
    final nextPosition = widget.vehiclePosition;
    final positionChanged = previousPosition?.lat != nextPosition?.lat ||
        previousPosition?.lng != nextPosition?.lng ||
        previousPosition?.headingDeg != nextPosition?.headingDeg ||
        previousPosition?.speedKmh != nextPosition?.speedKmh;
    final tiltChanged = oldWidget.cameraTiltDegrees != widget.cameraTiltDegrees;
    final paletteChanged =
        oldWidget.palette.serialize() != widget.palette.serialize();
    final poiVisibilityChanged = !sameOfflinePoiVisibility(
      oldWidget.visiblePoiKlasses,
      widget.visiblePoiKlasses,
    );
    final routesChanged = oldWidget.routeOverlays != widget.routeOverlays ||
        oldWidget.routeGeometry != widget.routeGeometry ||
        oldWidget.routeColor != widget.routeColor ||
        oldWidget.routeWidth != widget.routeWidth;

    if (oldWidget.locationFocusRequest != widget.locationFocusRequest) {
      _pendingLocationFocusRequest = widget.locationFocusRequest;
      _focusGpsCamera();
    }
    if (oldWidget.destination != widget.destination &&
        widget.destination != null) {
      _focusDestination(widget.destination!);
    }
    if (widget.drivingMode &&
        nextPosition != null &&
        (positionChanged ||
            tiltChanged ||
            oldWidget.followVehicle != widget.followVehicle ||
            oldWidget.drivingMode != widget.drivingMode)) {
      _syncCamera(force: tiltChanged);
    } else if (tiltChanged && !widget.drivingMode) {
      final controller = _controller;
      if (controller != null) {
        unawaited(
          controller.animateCamera(
            ml.CameraUpdate.tiltTo(widget.cameraTiltDegrees.clamp(0, 60)),
            duration: const Duration(milliseconds: 220),
          ),
        );
      }
    }
    if (_styleReady && paletteChanged) {
      unawaited(_applyMapPalette());
    }
    if (_styleReady && poiVisibilityChanged) {
      unawaited(_applyOfflinePoiVisibility());
    }
    if (_styleReady && routesChanged) {
      unawaited(_refreshRouteAnnotations());
    }
    if (positionChanged || oldWidget.destination != widget.destination) {
      unawaited(_refreshScreenPositions());
    }
  }

  void _onMapCreated(ml.MapLibreMapController controller) {
    _controller = controller;
    _focusGpsCamera();
  }

  void _onStyleLoaded() {
    _styleReady = true;
    _routeLines.clear();
    _onlineTrunkLayerAdded = false;
    unawaited(_applyMapPalette());
    unawaited(_applyOfflinePoiVisibility());
    widget.onStyleLoaded?.call();
    unawaited(_refreshRouteAnnotations());
    if (_pendingLocationFocusRequest != 0) {
      _focusGpsCamera();
    } else if (widget.drivingMode && widget.vehiclePosition != null) {
      _syncCamera(force: true);
    } else {
      unawaited(_refreshScreenPositions());
    }
  }

  /// رنگ‌های ذخیره‌شدهٔ کاربر را بعد از آماده‌شدن style روی layerهای واقعی
  /// MapLibre اعمال می‌کند. برای style آفلاین، شناسه‌ها متعلق به JSON داخلی
  /// ABM هستند؛ برای online، فقط layerهای شناخته‌شدهٔ OpenFreeMap تغییر می‌کنند.
  Future<void> _applyMapPalette() async {
    final controller = _controller;
    if (controller == null || !_styleReady) return;
    final palette = widget.palette;
    final background = _hexColor(palette.background);
    final roadExpression = <dynamic>[
      'match',
      ['get', 'class'],
      'motorway',
      _hexColor(palette.roadMotorway),
      'trunk',
      _hexColor(palette.roadTrunk),
      'primary',
      _hexColor(palette.roadPrimary),
      'secondary',
      _hexColor(palette.roadSecondary),
      'tertiary',
      _hexColor(palette.roadSecondary),
      'residential',
      _hexColor(palette.roadLocal),
      'unclassified',
      _hexColor(palette.roadLocal),
      'service',
      _hexColor(palette.roadLocal),
      'track',
      _hexColor(palette.roadLocal),
      _hexColor(palette.roadLocal),
    ];
    try {
      await controller.setLayerProperties(
        'background',
        ml.BackgroundLayerProperties(backgroundColor: background),
      );
      if (widget.localStylePath != null) {
        await controller.setLayerProperties(
          'land-forest',
          ml.FillLayerProperties(fillColor: _hexColor(palette.green)),
        );
        await controller.setLayerProperties(
          'land-urban',
          ml.FillLayerProperties(fillColor: _hexColor(palette.urban)),
        );
        await controller.setLayerProperties(
          'land-other',
          ml.FillLayerProperties(fillColor: background),
        );
        await controller.setLayerProperties(
          'water-area',
          ml.FillLayerProperties(fillColor: _hexColor(palette.water)),
        );
        await controller.setLayerProperties(
          'road-casing',
          ml.LineLayerProperties(
            lineColor: _hexColor(palette.roadOutline),
            lineWidth: roadWidthExpression(
              palette.roadWidthScale,
              base: 1.35,
            ),
          ),
        );
        await controller.setLayerProperties(
          'road-fill',
          ml.LineLayerProperties(
            lineColor: roadExpression,
            lineWidth: roadWidthExpression(palette.roadWidthScale),
          ),
        );
        await controller.setLayerProperties(
          'buildings',
          ml.FillLayerProperties(fillColor: _hexColor(palette.building)),
        );
        return;
      }
      await controller.setLayerProperties(
        'highway_minor',
        ml.LineLayerProperties(
          lineColor: _hexColor(palette.roadLocal),
          lineWidth: roadWidthExpression(palette.roadWidthScale, base: 0.7),
        ),
      );
      await controller.setLayerProperties(
        'highway_major_casing',
        ml.LineLayerProperties(
          lineColor: _hexColor(palette.roadOutline),
          lineWidth: roadWidthExpression(palette.roadWidthScale, base: 1.45),
        ),
      );
      await controller.setLayerProperties(
        'highway_major_inner',
        ml.LineLayerProperties(
          lineColor: _hexColor(palette.roadPrimary),
          lineWidth: roadWidthExpression(palette.roadWidthScale, base: 1.0),
        ),
      );
      await controller.setLayerProperties(
        'highway_motorway_casing',
        ml.LineLayerProperties(
          lineColor: _hexColor(palette.roadOutline),
          lineWidth: roadWidthExpression(palette.roadWidthScale, base: 2.0),
        ),
      );
      await controller.setLayerProperties(
        'highway_motorway_inner',
        ml.LineLayerProperties(
          lineColor: _hexColor(palette.roadMotorway),
          lineWidth: roadWidthExpression(palette.roadWidthScale, base: 1.35),
        ),
      );
      if (!_onlineTrunkLayerAdded) {
        await controller.addLineLayer(
          'openmaptiles',
          'abtin-online-trunk',
          ml.LineLayerProperties(
            lineColor: _hexColor(palette.roadTrunk),
            lineWidth: roadWidthExpression(
              palette.roadWidthScale,
              base: 1.35,
            ),
            lineCap: 'round',
            lineJoin: 'round',
          ),
          belowLayerId: 'road_oneway',
          sourceLayer: 'transportation',
          minzoom: 6,
          filter: const <dynamic>[
            'all',
            [
              '==',
              ['get', 'class'],
              'trunk',
            ],
            [
              'match',
              ['geometry-type'],
              ['LineString', 'MultiLineString'],
              true,
              false,
            ],
          ],
          enableInteraction: false,
        );
        _onlineTrunkLayerAdded = true;
      } else {
        await controller.setLayerProperties(
          'abtin-online-trunk',
          ml.LineLayerProperties(
            lineColor: _hexColor(palette.roadTrunk),
            lineWidth: roadWidthExpression(
              palette.roadWidthScale,
              base: 1.35,
            ),
          ),
        );
      }
    } catch (_) {
      // تغییر رنگ نباید بارگذاری نقشه را به‌خاطر یک layer ناسازگار fail کند.
    }
  }

  /// `poi-symbols` فقط در style آفلاین ABM وجود دارد. کنترل دسته‌ای از
  /// source data کم نمی‌کند؛ filter خود MapLibre را عوض می‌کند، بنابراین
  /// واکنش آن فوری است و برای هر تغییر نیاز به بازکردن مجدد نقشه نیست.
  Future<void> _applyOfflinePoiVisibility() async {
    final controller = _controller;
    if (controller == null || !_styleReady || widget.localStylePath == null) {
      return;
    }
    try {
      final visible = widget.visiblePoiKlasses?.isNotEmpty ?? true;
      await controller.setLayerProperties(
        'poi-symbols',
        ml.SymbolLayerProperties(visibility: visible ? 'visible' : 'none'),
      );
      if (visible) {
        await controller.setFilter(
          'poi-symbols',
          offlinePoiLayerFilter(widget.visiblePoiKlasses),
        );
      }
    } catch (error) {
      // خطای schema را پنهان نکن؛ این دقیقاً برای تشخیص POIهای ناپدیدشده لازم است.
      debugPrint('[ABM POI] apply failed: $error');
    }
  }

  Future<void> _refreshRouteAnnotations() async {
    final controller = _controller;
    if (!_styleReady || controller == null) return;
    final generation = ++_routeRefreshGeneration;
    final routes = _routeOverlays
        .where((route) => route.geometry.length >= 2)
        .toList(growable: false);
    final options = <ml.LineOptions>[
      for (final route in routes)
        ml.LineOptions(
          geometry:
              route.geometry.map(_toMapLibrePoint).toList(growable: false),
          lineColor: _hexColor(route.color),
          lineWidth: route.width,
          lineOpacity: 1,
          lineJoin: 'round',
        ),
    ];
    try {
      // در لغو مسیر، حذف را مستقیم و قطعی انجام می‌دهیم. مسیرهای پیشنهادی
      // قبلی ممکن است هم‌زمان با تغییر provider در یک frame باقی مانده باشند؛
      // جایگزینی با لیست خالی نباید منتظر addLines بماند.
      if (options.isEmpty) {
        final previous = List<ml.Line>.from(_routeLines);
        _routeLines.clear();
        if (previous.isNotEmpty) await controller.removeLines(previous);
        return;
      }

      if (_routeLines.length == options.length) {
        for (var index = 0; index < options.length; index++) {
          if (generation != _routeRefreshGeneration) return;
          await controller.updateLine(_routeLines[index], options[index]);
        }
        return;
      }

      // خطوط تازه ابتدا اضافه می‌شوند و فقط پس از موفقیت، خطوط قبلی حذف
      // می‌گردند؛ بنابراین با انتخاب route جدید نقشه حتی یک frame بدون مسیر
      // نمی‌ماند و flicker رخ نمی‌دهد.
      final replacement = options.isEmpty
          ? const <ml.Line>[]
          : await controller.addLines(options);
      if (generation != _routeRefreshGeneration || controller != _controller) {
        if (replacement.isNotEmpty) await controller.removeLines(replacement);
        return;
      }
      final previous = List<ml.Line>.from(_routeLines);
      _routeLines
        ..clear()
        ..addAll(replacement);
      if (previous.isNotEmpty) await controller.removeLines(previous);
    } catch (_) {
      // در لحظهٔ جایگزینی style، annotation manager قدیمی ممکن است آزاد شده
      // باشد. callback بارگذاری style، خطوط route را دوباره ثبت می‌کند.
    }
  }

  String _hexColor(Color color) {
    final argb = color.toARGB32();
    return '#${((argb >> 16) & 0xFF).toRadixString(16).padLeft(2, '0')}${((argb >> 8) & 0xFF).toRadixString(16).padLeft(2, '0')}${(argb & 0xFF).toRadixString(16).padLeft(2, '0')}';
  }

  void _focusGpsCamera() {
    final controller = _controller;
    final position = widget.vehiclePosition;
    if (controller == null || position == null) return;
    _pendingLocationFocusRequest = 0;
    unawaited(
      controller.animateCamera(
        ml.CameraUpdate.newCameraPosition(
          ml.CameraPosition(
            target: _toMapLibreVehiclePoint(position),
            zoom: 16,
            bearing: 0,
            tilt: 0,
          ),
        ),
        duration: const Duration(milliseconds: 320),
      ),
    );
  }

  void _focusDestination(LatLng destination) {
    final controller = _controller;
    if (controller == null) return;
    unawaited(
      controller.animateCamera(
        ml.CameraUpdate.newCameraPosition(
          ml.CameraPosition(
            target: _toMapLibrePoint(destination),
            zoom: 15,
            bearing: 0,
            tilt: 0,
          ),
        ),
        duration: const Duration(milliseconds: 320),
      ),
    );
  }

  void _syncCamera({bool force = false}) {
    final controller = _controller;
    final position = widget.vehiclePosition;
    if (controller == null ||
        position == null ||
        !widget.followVehicle ||
        !widget.drivingMode) {
      return;
    }
    final now = DateTime.now();
    if (!force && now.difference(_lastCameraUpdate) < _cameraUpdateInterval) {
      return;
    }
    _lastCameraUpdate = now;
    final speed = position.speedKmh.clamp(0.0, 160.0).toDouble();
    final target = _toMapLibreVehiclePoint(position);
    final camera = ml.CameraPosition(
      target: target,
      zoom: _navigationZoom(speed),
      bearing: position.headingDeg,
      tilt: widget.cameraTiltDegrees.clamp(0.0, 60.0).toDouble(),
    );
    unawaited(
      controller.animateCamera(
        ml.CameraUpdate.newCameraPosition(camera),
        duration: const Duration(milliseconds: 220),
      ),
    );
  }

  double _navigationZoom(double speedKmh) {
    // The entire app is capped at zoom 16. Navigation used to request
    // 17+ which MapLibre then clamped internally; keeping the request inside
    // the same bound avoids camera churn at the ceiling.
    if (speedKmh < 20) return 16.0;
    if (speedKmh < 50) return 15.8;
    if (speedKmh < 90) return 15.4;
    return 14.8;
  }

  void _onCameraMove(ml.CameraPosition camera) {
    _camera = camera;
    widget.onCameraPositionChanged?.call(camera);
    unawaited(_refreshScreenPositions());
  }

  Future<void> _refreshScreenPositions() async {
    if (_screenUpdateRunning) {
      _screenUpdateQueued = true;
      return;
    }
    final controller = _controller;
    if (controller == null) return;
    _screenUpdateRunning = true;
    try {
      final position = widget.vehiclePosition;
      final vehiclePoint = position == null
          ? null
          : await controller
              .toScreenLocation(_toMapLibreVehiclePoint(position));
      final destination = widget.destination;
      final destinationPoint = destination == null
          ? null
          : await controller.toScreenLocation(_toMapLibrePoint(destination));
      if (!mounted || controller != _controller) return;
      final pixelRatio = MediaQuery.devicePixelRatioOf(context);
      setState(() {
        _vehicleScreen = vehiclePoint == null
            ? null
            : mapScreenPointToFlutterOffset(vehiclePoint, pixelRatio);
        _destinationScreen = destinationPoint == null
            ? null
            : mapScreenPointToFlutterOffset(destinationPoint, pixelRatio);
      });
    } catch (_) {
      // در لحظهٔ جایگزینی style، projection ممکن است موقتاً در دسترس نباشد.
    } finally {
      _screenUpdateRunning = false;
      if (_screenUpdateQueued) {
        _screenUpdateQueued = false;
        unawaited(_refreshScreenPositions());
      }
    }
  }

  void _onMapClick(math.Point<double> _, ml.LatLng point) {
    final tap = LatLng(point.latitude, point.longitude);
    final routeIndex = _hitTestRoute(tap, _routeOverlays);
    if (routeIndex != null) {
      widget.onRouteTap?.call(routeIndex);
    }
  }

  void _onMapLongClick(math.Point<double> _, ml.LatLng point) {
    widget.onLongPress?.call(LatLng(point.latitude, point.longitude));
  }

  int? _hitTestRoute(LatLng tap, List<OnlineRouteOverlay> overlays) {
    const hitRadiusMeters = 30.0;
    var bestDistance = hitRadiusMeters;
    int? bestIndex;
    for (var routeIndex = 0; routeIndex < overlays.length; routeIndex++) {
      final geometry = overlays[routeIndex].geometry;
      for (var pointIndex = 1; pointIndex < geometry.length; pointIndex++) {
        final distance = _distanceToSegmentMeters(
          tap,
          geometry[pointIndex - 1],
          geometry[pointIndex],
        );
        if (distance <= bestDistance) {
          bestDistance = distance;
          bestIndex = routeIndex;
        }
      }
    }
    return bestIndex;
  }

  double _distanceToSegmentMeters(LatLng point, LatLng start, LatLng end) {
    final latitudeRadians = point.latitude * math.pi / 180.0;
    final metersPerLongitude = 111320.0 * math.cos(latitudeRadians);
    final abX = (end.longitude - start.longitude) * metersPerLongitude;
    final abY = (end.latitude - start.latitude) * 110540.0;
    final apX = (point.longitude - start.longitude) * metersPerLongitude;
    final apY = (point.latitude - start.latitude) * 110540.0;
    final lengthSquared = abX * abX + abY * abY;
    if (lengthSquared <= 1e-6) return math.sqrt(apX * apX + apY * apY);
    final projection =
        ((apX * abX + apY * abY) / lengthSquared).clamp(0.0, 1.0);
    final nearestX = abX * projection;
    final nearestY = abY * projection;
    final dx = apX - nearestX;
    final dy = apY - nearestY;
    return math.sqrt(dx * dx + dy * dy);
  }

  double get _markerVisualSize {
    final isArrow = widget.vehicle == VehicleType.arrow;
    final percent = isArrow ? widget.pinSizePercent : widget.carSizePercent;
    final base = isArrow ? 40.0 : 52.0;
    return (base * (percent / 100)).clamp(30.0, 82.0).toDouble();
  }

  double _effectiveVehicleHeading(VehiclePosition position) {
    final route = widget.routeGeometry;
    // در سرعت کم، GPS معمولاً heading صفر/نویزدار می‌دهد. در حالت ناوبری
    // جهت نزدیک‌ترین قطعهٔ مسیر پایدارتر است و خودرو روی خط عمودی نمی‌ماند.
    if (route == null || route.length < 2 || position.speedKmh >= 3) {
      return position.headingDeg;
    }
    var bestDistance = double.infinity;
    var bestHeading = position.headingDeg;
    final point = LatLng(position.lat, position.lng);
    for (var i = 0; i < route.length - 1; i++) {
      final distance = _distanceToSegmentMeters(point, route[i], route[i + 1]);
      if (distance < bestDistance) {
        bestDistance = distance;
        bestHeading = _bearingBetween(route[i], route[i + 1]);
      }
    }
    return bestHeading;
  }

  double _bearingBetween(LatLng a, LatLng b) {
    final y = (b.longitude - a.longitude) *
        math.cos((a.latitude + b.latitude) * math.pi / 360.0);
    final x = b.latitude - a.latitude;
    return (math.atan2(y, x) * 180.0 / math.pi + 360.0) % 360.0;
  }

  @override
  Widget build(BuildContext context) {
    final vehiclePosition = _vehicleScreen;
    final destinationPosition = _destinationScreen;
    final markerSize = _markerVisualSize;
    final mapBearing = _camera?.bearing ?? 0;
    // asset پیکان در حالت پایه رو به بالای صفحه (شمال) است؛ بنابراین تنها
    // چرخش لازم، اختلاف heading جغرافیایی با bearing فعلی نقشه است. offset
    // قبلیِ -90 باعث می‌شد مکان‌نما یک ربع‌گردش از مسیر واقعی منحرف باشد.
    final geographicHeading = widget.vehiclePosition == null
        ? 0.0
        : _effectiveVehicleHeading(widget.vehiclePosition!);
    final screenHeading = mapRelativeHeading(geographicHeading, mapBearing);

    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: (_) => widget.onUserGestureStart?.call(),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          ml.MapLibreMap(
            key: ValueKey(
              'maplibre-${widget.localStylePath ?? (widget.isDark ? 'online-night' : 'online-day')}',
            ),
            styleString: widget.localStylePath ??
                (widget.isDark ? _nightStyle : _dayStyle),
            initialCameraPosition: ml.CameraPosition(
              target: widget.vehiclePosition == null
                  ? _fallbackInitialTarget
                  : _toMapLibreVehiclePoint(widget.vehiclePosition!),
              zoom: widget.vehiclePosition == null
                  ? 5.1
                  : (widget.drivingMode ? 16 : 10),
            ),
            minMaxZoomPreference: const ml.MinMaxZoomPreference(1, 16),
            compassEnabled: false,
            logoEnabled: false,
            scaleControlEnabled: false,
            rotateGesturesEnabled: true,
            scrollGesturesEnabled: true,
            zoomGesturesEnabled: true,
            tiltGesturesEnabled: true,
            trackCameraPosition: true,
            annotationOrder: const [ml.AnnotationType.line],
            annotationConsumeTapEvents: const [ml.AnnotationType.line],
            foregroundLoadColor: widget.palette.background,
            onMapCreated: _onMapCreated,
            onStyleLoadedCallback: _onStyleLoaded,
            onMapClick: _onMapClick,
            onMapLongClick: _onMapLongClick,
            onCameraMove: _onCameraMove,
            onCameraIdle: () {
              unawaited(_refreshScreenPositions());
              widget.onCameraIdle?.call();
            },
          ),
          if (destinationPosition != null)
            Positioned(
              left: destinationPosition.dx - 21,
              top: destinationPosition.dy - 42,
              child: const IgnorePointer(
                child: Icon(
                  Icons.location_on_rounded,
                  color: Color(0xFFE84A5F),
                  size: 42,
                  shadows: [Shadow(color: Colors.black54, blurRadius: 5)],
                ),
              ),
            ),
          if (vehiclePosition != null)
            Positioned(
              left: vehiclePosition.dx - markerSize / 2,
              top: vehiclePosition.dy - markerSize / 2,
              width: markerSize,
              height: markerSize,
              child: IgnorePointer(
                child: widget.vehicle == VehicleType.arrow
                    ? Stack(
                        alignment: Alignment.center,
                        children: [
                          // نقطهٔ آبی زیر پیکان، مشابه نشانگر استاندارد GPS؛
                          // چون این branch فقط با vehiclePosition ساخته می‌شود،
                          // بدون فیکس معتبر GPS اصلاً نمایش داده نمی‌شود.
                          const GpsLocationDot(size: 16),
                          Transform.rotate(
                            angle: screenHeading * math.pi / 180,
                            child: NavArrow(
                              size: markerSize,
                              color: widget.markerColor,
                              glow: widget.pinShadowEnabled,
                            ),
                          ),
                        ],
                      )
                    : TopDownCarMarker(
                        size: markerSize,
                        modelIndex: widget.modelIndex,
                        bodyColor: widget.vehicleColor,
                        headingDeg: geographicHeading,
                        cameraTiltDegrees: widget.cameraTiltDegrees,
                        interactive: false,
                      ),
              ),
            ),
        ],
      ),
    );
  }
}
