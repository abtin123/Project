import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_maps/features/offline_maps/data/vector_map_service.dart';

void main() {
  test('offline ABM style enforces the application zoom contract', () {
    const template = '''{
      "version": 8,
      "sources": {"abtin": {"type": "vector", "url": "__ABTIN_PMTILES_URI__"}},
      "layers": [
        {"id":"road-labels-major","type":"symbol","minzoom":9},
        {"id":"road-labels-local","type":"symbol","minzoom":14},
        {"id":"buildings","type":"fill","minzoom":14},
        {"id":"poi-symbols","type":"symbol","minzoom":13},
        {"id":"other","type":"line","maxzoom":22}
      ]
    }''';

    final resolved = VectorMapService.resolveStyleTemplate(
      template,
      archive: File('/maps/IR.abm'),
      directory: Directory('/cache/IR'),
    );
    final style = jsonDecode(resolved) as Map<String, dynamic>;
    final source = (style['sources'] as Map<String, dynamic>)['abtin']
        as Map<String, dynamic>;
    final layers = style['layers'] as List<dynamic>;
    final byId = <String, Map<String, dynamic>>{
      for (final raw in layers) (raw as Map<String, dynamic>)['id'] as String:
          raw,
    };

    expect(source['maxzoom'], 16);
    expect(byId['road-labels-major']!['minzoom'], 8);
    expect(byId['road-labels-local']!['minzoom'], 14);
    expect(byId['buildings']!['minzoom'], 14);
    expect(byId['poi-symbols']!['minzoom'], 12);
    expect(byId['other']!['maxzoom'], 16);
  });
}
