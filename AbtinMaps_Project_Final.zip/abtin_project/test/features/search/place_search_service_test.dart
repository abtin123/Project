import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_maps/features/search/data/place_search_service.dart';

void main() {
  test('online search service exists for global online-map search', () {
    expect(PlaceSearchService, isNotNull);
  });
}
