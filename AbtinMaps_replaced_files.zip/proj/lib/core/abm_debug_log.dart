/// In-memory diagnostic log (no file I/O, capped). Feeds Settings › گزارش.
class AbmDebugLog {
  static const int _maxLines = 400;
  static final List<String> logs = <String>[];
  /// بافر جدا: نویز نقشه (PREPARE/VIEWPORT) نباید لاگ HUD را از حلقه بیرون بریزد.
  static final List<String> hudLogs = <String>[];
  /// بافر جدا برای رخدادهای قفل نقشه/دوربین (سطحِ رندر، صف دوربین، lifecycle)؛
  /// تا لاگ‌های پرحجمِ مسیریابی (EDGE[...]) آن‌ها را از حلقه بیرون نریزند.
  static final List<String> freezeLogs = <String>[];

  static void _push(List<String> target, String tag, String text) {
    final t = DateTime.now().toIso8601String().substring(11, 23);
    target.add('$t [$tag] $text');
    if (target.length > _maxLines) {
      target.removeRange(0, target.length - _maxLines);
    }
  }

  static void addFreeze(String text) => _push(freezeLogs, 'FREEZE', text);

  /// همهٔ لاگ‌ها به ترتیب زمانی (جدیدترین اول).
  static List<String> merged() =>
      ([...logs, ...hudLogs, ...freezeLogs]..sort()).reversed.toList(growable: false);

  static void clear() {
    logs.clear();
    hudLogs.clear();
    freezeLogs.clear();
  }
}
