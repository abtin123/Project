# TODO
## Done
- 3D buildings: height expr (render_height/height/levels, default 9m), height-based tint, vertical gradient, map light (`_apply3dBuildings` in abm_style_assets.dart); extrusion from z13; style revision v5.
## Left
- Test on device (offline + online); tune default height / light.
- If offline MBTiles lack height tags, add `height`/`levels` to buildings layer in Builder.
- Optional: raise default map pitch.

## Country SVGs (download screen)
- Done: assets/maps/countries/{iso2}.svg for all 37 countries in countries.json (Natural Earth 10m, simplified, single path each; ES has Canary inset, US has AK/HI inset, FR metropolitan only, UA includes Crimea).
- Optional: region-level SVGs for countries other than IR.

## Turn camera/car fix (2026-10-04)
- online_map_view.dart: camera target now lies along the commanded (smoothed) bearing instead of the route arc (removed lateral camera jump at corners); bearing target leads along the route by ~0.8s of travel; bearing rate limit 150->260 deg/s, deadband 1.5->0.6.
- Untested on device (no Flutter SDK). Step 2 done: vehicle screen projection EMA-smoothed (alpha 0.22) in follow+driving mode (_refreshScreenPositions).

## 2026-10-04 — Route modes
- Offline engine: fastest (highway-preferring class factors), shortest (pure distance, no hierarchy pruning), economic (50/50 time+distance). Online OSRM only re-ranks alternatives.
- `flutter analyze` not run here (no SDK); verify `main.dart` fireImmediately fix in CI.
- Camera: bearing held in tight curves/small roundabouts (route turns >100° in 60m); adaptive camera tick (500ms stopped / 66ms moving); road-snap timer 2.5s.
- Route card: street name split to 2nd line even without خیابان/بلوار prefix (generic به/در/روی boundary); subtitle size 0.55→0.7 of title.
- Free-drive: camera look-ahead 60dp (max 90m) instead of 150dp; RoadSnapper direction hysteresis (flip only ≥15km/h with GPS heading clearly opposite), robust oneway parsing (strings/bool/roundabout), road query 1s/5m/240px.
- Still unverified on device: whether rendered `abm-road-line` features carry `oneway` — if marker is still reversed on one-way streets, send /abm-log + short screen recording.
- Merged user's abtin-fixes (Oct 5): offline city names, "تهران" search ranking (place_search_service/offline_place_search_service), R-tree POI/places/hazard queries (battery). Python side (`map_db.py`, `tests/test_search_proximity.py`) belongs to the map-build-pipeline repo (abtin-maps-main) — not in this zip.
- Offline routing: primary route now shown immediately; alternatives stream in afterwards (calculateRoutesProvider is a StreamProvider, primary stays index 0). Fastest-mode class factors softened (0.90..1.10) to keep A* heuristic tight. Not measured on device.
- ROOT CAUSE free-drive snapping: road query rect used logical px (_vehicleScreen) but queryRenderedFeaturesInRect on Android needs physical px -> multiplied by devicePixelRatio. Raw GPS heading ignored below 6 km/h when not snapped.
- Offline turn detection: maneuver angle now from route polyline geometry (~22m before/after junction), added 'sharp' (>=120°), slight >=10°, same-way turns >=55° no longer forced straight.
- Offline highway entry/exit: class change to/from motorway/trunk(_link) now emits 'on ramp'/'off ramp' instructions with slight left/right arrow (default slight right). Unverified on device.

## 2026-10-05 — AR (Real View)
- New: lib/features/ar/presentation/ar_navigation_screen.dart (route /ar-navigation), button under the nav close button in home_screen. Live camera + maneuver/distance/street, speed limit + speed, alert chip, ETA. No road line by design. Added camera dep + CAMERA permission. Untested on device (no Flutter SDK); run flutter pub get.
- Alert sprites: route_{camera,police,speed_bump,traffic_light}.png replaced with new art (red ring). Map atlas abtin(@2x).png/json: abm-hz-* camera/speed_camera/bump/traffic updated + new abm-hz-police slot (422,242); RoadHazards 'police' spec; badge/map settings/AR chip use sprites. Unverified on device.
- Fixed CI analyze errors: removed 4 duplicate const-map keys (سریع‌ترین/کوتاه‌ترین with \u200c) in app_localizations.dart.
- assets/local/{fa,en}.json: removed 248 unused keys (767->519). Kept keys referenced by code, by _literalKeyAliases, by Persian-literal reverse lookup, or by dynamic prefixes (turn_/keep_/style_/lang_/entrance_/...). Dart _localizedValues untouched (generate_locales.py would re-add them).
