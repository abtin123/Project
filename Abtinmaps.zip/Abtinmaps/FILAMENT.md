# Filament 3D car (native Kotlin)

- Code: `android/app/src/main/kotlin/ir/abtin/abtinmaps/FilamentCar.kt`
- Gradle: `android/app/build.gradle` -> `filament-android` + `gltfio-android` (version in `filamentVersion`)
- Dart: `lib/features/vehicle/presentation/car_marker.dart`
- Channel: `ir.abtin.abtinmaps/filament_car` (create / update / resize / model / dispose / status)
- Models: `assets/models/*.glb` (listed in `vehicle_provider.dart`)

Debug: Settings -> Debugger. Look for `[filament]` lines in the native log and `filament{...}` at the end of the `perf` line.
