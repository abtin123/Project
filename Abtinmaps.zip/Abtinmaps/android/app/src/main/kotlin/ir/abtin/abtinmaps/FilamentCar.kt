package ir.abtin.abtinmaps

import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.Surface
import com.google.android.filament.Box
import com.google.android.filament.Camera
import com.google.android.filament.Engine
import com.google.android.filament.EntityManager
import com.google.android.filament.Filament
import com.google.android.filament.IndirectLight
import com.google.android.filament.LightManager
import com.google.android.filament.Renderer
import com.google.android.filament.Scene
import com.google.android.filament.SwapChain
import com.google.android.filament.Texture
import com.google.android.filament.View
import com.google.android.filament.Viewport
import com.google.android.filament.gltfio.AssetLoader
import com.google.android.filament.gltfio.FilamentAsset
import com.google.android.filament.gltfio.Gltfio
import com.google.android.filament.gltfio.ResourceLoader
import com.google.android.filament.gltfio.UbershaderProvider
import io.flutter.FlutterInjector
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.view.TextureRegistry
import java.nio.ByteBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * خودروی سه‌بعدیِ نقشه با موتور Filament گوگل، کاملاً بومی (Kotlin) و بدون WebView
 * و بدون هیچ پکیج فلاتری.
 *
 * معماری:
 *  - یک Engine و یک ریسمان رندر (HandlerThread) برای کل برنامه ([FilamentHost]).
 *  - هر خودرو یک [CarView] است که روی Surfaceِ یک SurfaceProducer فلاتر رندر می‌کند و آن را با
 *    ویجت `Texture(textureId)` نشان می‌دهد (شفاف، بدون PlatformView).
 *  - رندر «به‌ازای تغییر» است، نه پیوسته: فقط وقتی زاویه/اندازه/مدل عوض شود فریم
 *    می‌سازیم (حداکثر ~۲۰ فریم در ثانیه). همین نشت sync_file و فشار GPU را که با
 *    WebView داشتیم از بین می‌برد.
 *  - همهٔ لاگ‌ها و آمار به NativeDebug (دیباگر برنامه) می‌رود: برچسب `filament`.
 */
private const val TAG = "filament"

/** وضعیت قابل‌خواندن برای دیباگر (از هر ریسمانی امن است). */
object FilamentStats {
    val frames = AtomicLong(0)
    val skipped = AtomicLong(0)
    val views = AtomicInteger(0)
    val modelsLoaded = AtomicInteger(0)
    @Volatile var backend: String = "-"
    @Volatile var engineUp: Boolean = false
    @Volatile var lastLoadMs: Long = -1
    @Volatile var lastFrameMs: Float = -1f
    @Volatile var lastError: String? = null

    fun line(): String =
        "engine=${if (engineUp) "up" else "down"} backend=$backend views=${views.get()} " +
            "frames=${frames.get()} skipped=${skipped.get()} models=${modelsLoaded.get()} " +
            "lastFrame=${if (lastFrameMs >= 0) "%.1f".format(lastFrameMs) + "ms" else "-"} " +
            "lastLoad=${if (lastLoadMs >= 0) "${lastLoadMs}ms" else "-"}" +
            (lastError?.let { " lastError=$it" } ?: "")
}

/** Engine + ریسمان رندر مشترک. همهٔ فراخوانی‌های Filament فقط روی [handler] انجام می‌شود. */
private class FilamentHost(private val appContext: Context) {
    private val thread = HandlerThread("abtin-filament").apply { start() }
    val handler = Handler(thread.looper)

    lateinit var engine: Engine
    lateinit var assetLoader: AssetLoader
    lateinit var resourceLoader: ResourceLoader
    private lateinit var materialProvider: UbershaderProvider
    var indirectLight: IndirectLight? = null
    private var iblTexture: Texture? = null
    private var sunEntity = 0
    private var fillEntity = 0
    var ready = false
        private set

    /** روی ریسمان Filament صدا زده شود. */
    fun init(): Boolean {
        if (ready) return true
        return try {
            Filament.init()
            Gltfio.init()
            val t0 = SystemClock.elapsedRealtime()
            engine = Engine.create()
            materialProvider = UbershaderProvider(engine)
            assetLoader = AssetLoader(engine, materialProvider, EntityManager.get())
            resourceLoader = ResourceLoader(engine)
            buildEnvironment()
            ready = true
            FilamentStats.engineUp = true
            FilamentStats.backend = try { engine.backend.name } catch (_: Throwable) { "?" }
            NativeDebug.log(TAG, "engine created backend=${FilamentStats.backend} in ${SystemClock.elapsedRealtime() - t0}ms")
            true
        } catch (t: Throwable) {
            FilamentStats.lastError = "init: ${t.javaClass.simpleName}: ${t.message}"
            try { if (::engine.isInitialized) engine.destroy() } catch (_: Throwable) {}
            NativeDebug.log(TAG, "ENGINE INIT FAILED: $t\n${t.stackTraceToString().take(1500)}")
            false
        }
    }

    /** نور محیطی ساده و رویه‌ای (بدون فایل IBL) تا بدنهٔ فلزی خودرو سیاه نشود. */
    private fun buildEnvironment() {
        val levels = 6 // 32,16,8,4,2,1
        val size0 = 32
        val tex = Texture.Builder()
            .width(size0).height(size0)
            .levels(levels)
            .sampler(Texture.Sampler.SAMPLER_CUBEMAP)
            .format(Texture.InternalFormat.RGBA8)
            .build(engine)
        for (level in 0 until levels) {
            val s = max(1, size0 shr level)
            val faceBytes = s * s * 4
            val buf = ByteBuffer.allocateDirect(faceBytes * 6)
            for (face in 0 until 6) {
                for (y in 0 until s) {
                    for (x in 0 until s) {
                        val u = 2f * (x + 0.5f) / s - 1f
                        val v = 2f * (y + 0.5f) / s - 1f
                        val d = faceDirection(face, u, v)
                        val c = environmentRadiance(d[0], d[1], d[2])
                        buf.put(toByte(c[0])).put(toByte(c[1])).put(toByte(c[2])).put(255.toByte())
                    }
                }
            }
            buf.flip()
            val pbd = Texture.PixelBufferDescriptor(buf, Texture.Format.RGBA, Texture.Type.UBYTE)
            tex.setImage(engine, level, pbd, IntArray(6) { it * faceBytes })
        }
        iblTexture = tex
        indirectLight = IndirectLight.Builder()
            .reflections(tex)
            .irradiance(1, floatArrayOf(0.78f, 0.80f, 0.84f))
            .intensity(IBL_INTENSITY)
            .build(engine)

        val em = EntityManager.get()
        sunEntity = em.create()
        LightManager.Builder(LightManager.Type.DIRECTIONAL)
            .color(1.0f, 0.97f, 0.92f)
            .intensity(SUN_INTENSITY)
            .direction(-0.45f, -0.85f, -0.55f)
            .castShadows(false)
            .build(engine, sunEntity)
        fillEntity = em.create()
        LightManager.Builder(LightManager.Type.DIRECTIONAL)
            .color(0.80f, 0.88f, 1.0f)
            .intensity(FILL_INTENSITY)
            .direction(0.6f, -0.3f, 0.7f)
            .castShadows(false)
            .build(engine, fillEntity)
    }

    fun addLights(scene: Scene) {
        scene.addEntity(sunEntity)
        scene.addEntity(fillEntity)
    }

    fun removeLights(scene: Scene) {
        scene.removeEntity(sunEntity)
        scene.removeEntity(fillEntity)
    }

    /** وقتی آخرین نما بسته شد. روی ریسمان Filament. */
    fun shutdown() {
        if (!ready) return
        try {
            val em = EntityManager.get()
            engine.lightManager.destroy(sunEntity)
            engine.lightManager.destroy(fillEntity)
            em.destroy(sunEntity)
            em.destroy(fillEntity)
            indirectLight?.let { engine.destroyIndirectLight(it) }
            iblTexture?.let { engine.destroyTexture(it) }
            indirectLight = null
            iblTexture = null
            resourceLoader.destroy()
            assetLoader.destroy()
            materialProvider.destroyMaterials()
            materialProvider.destroy()
            engine.destroy()
        } catch (t: Throwable) {
            NativeDebug.log(TAG, "shutdown error: $t")
        }
        ready = false
        FilamentStats.engineUp = false
        NativeDebug.log(TAG, "engine destroyed")
    }

    fun quit() {
        thread.quitSafely()
    }

    // ---- محیط رویه‌ای ----
    private fun toByte(v: Float): Byte = (min(1f, max(0f, v)) * 255f + 0.5f).toInt().toByte()

    private fun faceDirection(face: Int, u: Float, v: Float): FloatArray {
        val x: Float; val y: Float; val z: Float
        when (face) {
            0 -> { x = 1f; y = -v; z = -u }
            1 -> { x = -1f; y = -v; z = u }
            2 -> { x = u; y = 1f; z = v }
            3 -> { x = u; y = -1f; z = -v }
            4 -> { x = u; y = -v; z = 1f }
            else -> { x = -u; y = -v; z = -1f }
        }
        val l = sqrt(x * x + y * y + z * z)
        return floatArrayOf(x / l, y / l, z / l)
    }

    private fun environmentRadiance(x: Float, y: Float, z: Float): FloatArray {
        // آسمان روشن ← افق ← زمین تیره + دو «سافت‌باکس» برای هایلایت روی بدنه.
        val t = (y * 0.5f + 0.5f)
        val sky = floatArrayOf(0.62f, 0.76f, 0.98f)
        val hor = floatArrayOf(0.88f, 0.89f, 0.90f)
        val gnd = floatArrayOf(0.20f, 0.19f, 0.18f)
        val c = FloatArray(3)
        for (i in 0..2) {
            c[i] = if (y >= 0f) hor[i] + (sky[i] - hor[i]) * min(1f, y * 1.6f)
            else hor[i] + (gnd[i] - hor[i]) * min(1f, -y * 2.2f)
        }
        val k1 = max(0f, x * 0.55f + y * 0.62f + z * 0.56f).pow(18f) * 0.9f
        val k2 = max(0f, -x * 0.70f + y * 0.30f - z * 0.64f).pow(14f) * 0.45f
        for (i in 0..2) c[i] = c[i] * (0.55f + 0.45f * t) + k1 + k2
        return c
    }

    companion object {
        // مقادیر فیزیکی Filament (اکسپوژر پیش‌فرض دوربین: f/16، 1/125s، ISO100).
        const val SUN_INTENSITY = 55_000f
        const val FILL_INTENSITY = 14_000f
        const val IBL_INTENSITY = 22_000f
    }
}

/** یک خودرو: View + Scene + Camera + SwapChain روی Surfaceِ SurfaceProducer فلاتر. فقط روی ریسمان Filament. */
private class CarView(
    private val host: FilamentHost,
    private val producer: TextureRegistry.SurfaceProducer,
    private val appContext: Context,
    var asset: String,
    var widthPx: Int,
    var heightPx: Int,
    var theta: Double,
    var phi: Double,
) {
    val id: Long = producer.id()

    private val engine get() = host.engine
    private var surface: Surface? = null
    private var swapChain: SwapChain? = null
    private var renderer: Renderer? = null
    private var scene: Scene? = null
    private var view: View? = null
    private var camera: Camera? = null
    private var cameraEntity = 0
    private var filamentAsset: FilamentAsset? = null
    private var disposed = false
    private var renderPending = false
    private var lastRenderAt = 0L
    private var loadToken = 0
    private var framesSinceCreate = 0

    private val renderRunnable = Runnable {
        renderPending = false
        renderNow()
    }

    fun create() {
        FilamentStats.views.incrementAndGet()
        val eng = engine
        renderer = eng.createRenderer().also {
            // خروجی شفاف: پاک کردن به (0,0,0,0)
            it.clearOptions = Renderer.ClearOptions().apply { clear = true }
        }
        scene = eng.createScene()
        view = eng.createView().apply {
            scene = this@CarView.scene
            blendMode = View.BlendMode.TRANSLUCENT
            antiAliasing = View.AntiAliasing.FXAA
            isPostProcessingEnabled = true
            dithering = View.Dithering.NONE
        }
        cameraEntity = EntityManager.get().create()
        camera = eng.createCamera(cameraEntity).also {
            it.setExposure(16f, 1f / 125f, 100f)
        }
        view!!.camera = camera
        scene!!.indirectLight = host.indirectLight
        host.addLights(scene!!)
        installSurfaceCallback()
        recreateSurface()
        loadModel(asset)
        NativeDebug.log(TAG, "view #$id created ${widthPx}x$heightPx asset=$asset")
    }

    /** Surface متعلق به SurfaceProducer فلاتر است؛ ما فقط SwapChain روی آن می‌سازیم. */
    private fun recreateSurface() {
        swapChain?.let { engine.destroySwapChain(it) }
        swapChain = null
        producer.setSize(widthPx, heightPx)
        val s = producer.surface
        surface = s
        if (s != null && s.isValid) {
            swapChain = engine.createSwapChain(s, SwapChain.CONFIG_TRANSPARENT)
        } else {
            NativeDebug.log(TAG, "view #$id surface not valid yet")
        }
        view?.viewport = Viewport(0, 0, widthPx, heightPx)
        updateCamera()
    }

    /** فلاتر Surface را (مثلاً هنگام رفتن برنامه به پس‌زمینه) باطل می‌کند. روی ریسمان Filament. */
    private fun onSurfaceCleanup() {
        if (disposed) return
        host.handler.removeCallbacks(renderRunnable)
        renderPending = false
        swapChain?.let { engine.destroySwapChain(it) }
        swapChain = null
        surface = null
        try { engine.flushAndWait() } catch (_: Throwable) {}
        NativeDebug.log(TAG, "view #$id surface cleanup (swapchain destroyed)")
    }

    private fun onSurfaceAvailable() {
        if (disposed) return
        recreateSurface()
        requestRender(force = true)
        NativeDebug.log(TAG, "view #$id surface available again (swapchain recreated)")
    }

    private fun installSurfaceCallback() {
        producer.setCallback(object : TextureRegistry.SurfaceProducer.Callback {
            override fun onSurfaceAvailable() {
                host.handler.post { this@CarView.onSurfaceAvailable() }
            }

            override fun onSurfaceCleanup() {
                // باید قبل از برگشتن، دیگر از Surface استفاده نشود → منتظر ریسمان Filament می‌مانیم.
                val latch = CountDownLatch(1)
                host.handler.post {
                    try { this@CarView.onSurfaceCleanup() } finally { latch.countDown() }
                }
                latch.await(1, TimeUnit.SECONDS)
            }
        })
    }

    fun resize(w: Int, h: Int) {
        if (disposed || (w == widthPx && h == heightPx)) return
        widthPx = w
        heightPx = h
        recreateSurface()
        engine.flushAndWait()
        requestRender(force = true)
    }

    fun setOrbit(t: Double, p: Double) {
        if (disposed) return
        theta = t
        phi = p
        updateCamera()
        requestRender()
    }

    fun setModel(newAsset: String) {
        if (disposed || newAsset == asset && filamentAsset != null) return
        asset = newAsset
        loadModel(newAsset)
    }

    private fun loadModel(path: String) {
        val token = ++loadToken
        val t0 = SystemClock.elapsedRealtime()
        try {
            val key = FlutterInjector.instance().flutterLoader().getLookupKeyForAsset(path)
            val bytes = appContext.assets.open(key).use { it.readBytes() }
            val buf = ByteBuffer.allocateDirect(bytes.size).put(bytes)
            buf.flip()

            val a = host.assetLoader.createAsset(buf)
                ?: throw IllegalStateException("createAsset returned null for $path")
            if (token != loadToken || disposed) {
                host.assetLoader.destroyAsset(a)
                return
            }
            host.resourceLoader.loadResources(a)
            a.releaseSourceData()

            // مدل قبلی را حذف کن
            unloadModel()

            // نرمال‌سازی: مرکز مدل در مبدأ و شعاع کرهٔ محیطی = ۱
            val box: Box = a.boundingBox
            val c = box.center
            val h = box.halfExtent
            val radius = max(1e-4f, sqrt(h[0] * h[0] + h[1] * h[1] + h[2] * h[2]))
            val s = 1f / radius
            val tm = engine.transformManager
            val inst = tm.getInstance(a.root)
            tm.setTransform(
                inst,
                floatArrayOf(
                    s, 0f, 0f, 0f,
                    0f, s, 0f, 0f,
                    0f, 0f, s, 0f,
                    -c[0] * s, -c[1] * s, -c[2] * s, 1f,
                )
            )
            scene!!.addEntities(a.entities)
            filamentAsset = a
            val ms = SystemClock.elapsedRealtime() - t0
            FilamentStats.lastLoadMs = ms
            FilamentStats.modelsLoaded.incrementAndGet()
            NativeDebug.log(
                TAG,
                "view #$id model loaded $path ${bytes.size / 1024}KB in ${ms}ms " +
                    "entities=${a.entities.size} half=(${"%.2f".format(h[0])},${"%.2f".format(h[1])},${"%.2f".format(h[2])})"
            )
            requestRender(force = true)
            // فریم اول روی بعضی GPUها خالی می‌آید؛ یکی دیگر هم بساز.
            host.handler.postDelayed({ if (!disposed) requestRender(force = true) }, 80)
        } catch (t: Throwable) {
            FilamentStats.lastError = "model $path: ${t.javaClass.simpleName}: ${t.message}"
            NativeDebug.log(TAG, "MODEL LOAD FAILED $path: $t\n${t.stackTraceToString().take(1200)}")
        }
    }

    private fun unloadModel() {
        val a = filamentAsset ?: return
        try {
            scene?.removeEntities(a.entities)
            host.assetLoader.destroyAsset(a)
        } catch (t: Throwable) {
            NativeDebug.log(TAG, "unload error: $t")
        }
        filamentAsset = null
    }

    /** دوربین مداری: همان قرارداد model-viewer (theta افقی، phi از بالا). */
    private fun updateCamera() {
        val cam = camera ?: return
        val th = Math.toRadians(theta)
        val ph = Math.toRadians(phi)
        val dist = CAMERA_DISTANCE
        val ex = dist * sin(ph) * sin(th)
        val ey = dist * cos(ph)
        val ez = dist * sin(ph) * cos(th)
        val aspect = widthPx.toDouble() / max(1, heightPx)
        cam.setProjection(FOV_DEGREES, aspect, 0.05, 20.0, Camera.Fov.VERTICAL)
        cam.lookAt(ex, ey, ez, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0)
    }

    /** رندر «تنبل»: حداکثر یک فریم در هر MIN_FRAME_GAP_MS. */
    fun requestRender(force: Boolean = false) {
        if (disposed || renderPending) return
        val since = SystemClock.elapsedRealtime() - lastRenderAt
        val wait = if (force) 0L else max(0L, MIN_FRAME_GAP_MS - since)
        renderPending = true
        host.handler.postDelayed(renderRunnable, wait)
    }

    private fun renderNow() {
        if (disposed) return
        val sc = swapChain ?: return
        val r = renderer ?: return
        val v = view ?: return
        val t0 = SystemClock.elapsedRealtimeNanos()
        try {
            if (r.beginFrame(sc, System.nanoTime())) {
                r.render(v)
                r.endFrame()
                FilamentStats.frames.incrementAndGet()
                framesSinceCreate++
            } else {
                FilamentStats.skipped.incrementAndGet()
            }
        } catch (t: Throwable) {
            FilamentStats.lastError = "render: ${t.javaClass.simpleName}: ${t.message}"
            NativeDebug.log(TAG, "RENDER FAILED view #$id: $t")
        }
        lastRenderAt = SystemClock.elapsedRealtime()
        FilamentStats.lastFrameMs = (SystemClock.elapsedRealtimeNanos() - t0) / 1_000_000f
    }

    fun dispose() {
        if (disposed) return
        disposed = true
        host.handler.removeCallbacks(renderRunnable)
        try {
            unloadModel()
            scene?.let { host.removeLights(it) }
            swapChain?.let { engine.destroySwapChain(it) }
            view?.let { engine.destroyView(it) }
            scene?.let { engine.destroyScene(it) }
            renderer?.let { engine.destroyRenderer(it) }
            camera?.let { engine.destroyCameraComponent(cameraEntity) }
            if (cameraEntity != 0) EntityManager.get().destroy(cameraEntity)
            engine.flushAndWait()
        } catch (t: Throwable) {
            NativeDebug.log(TAG, "dispose error view #$id: $t")
        }
        swapChain = null; view = null; scene = null; renderer = null; camera = null
        surface = null
        try { producer.setCallback(null) } catch (_: Throwable) {}
        try { producer.release() } catch (_: Throwable) {}
        FilamentStats.views.decrementAndGet()
        NativeDebug.log(TAG, "view #$id disposed (frames rendered for it: $framesSinceCreate)")
    }

    companion object {
        const val FOV_DEGREES = 32.0
        // کره‌ای به شعاع ۱ باید کامل در کادر بنشیند، با کمی حاشیه.
        val CAMERA_DISTANCE: Double = 1.0 / sin(Math.toRadians(FOV_DEGREES / 2.0)) * 1.04
        const val MIN_FRAME_GAP_MS = 45L // ~22fps
    }
}

/**
 * MethodChannel "ir.abtin.abtinmaps/filament_car":
 *   create{asset,width,height,theta,phi} → textureId
 *   update{id,theta,phi} · resize{id,width,height} · model{id,asset} · dispose{id} · status
 */
class FilamentCarPlugin(
    private val context: Context,
    private val textures: TextureRegistry,
    messenger: BinaryMessenger,
) : MethodChannel.MethodCallHandler {

    private val channel = MethodChannel(messenger, "ir.abtin.abtinmaps/filament_car")
    private var host: FilamentHost? = null
    private val views = HashMap<Long, CarView>() // فقط روی ریسمان Filament دست‌کاری می‌شود

    init {
        channel.setMethodCallHandler(this)
        NativeDebug.filamentStatus = { FilamentStats.line() }
    }

    private fun ensureHost(): FilamentHost = host ?: FilamentHost(context.applicationContext).also { host = it }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "create" -> {
                val asset = call.argument<String>("asset")
                val w = call.argument<Int>("width") ?: 0
                val h = call.argument<Int>("height") ?: 0
                if (asset == null || w <= 0 || h <= 0) {
                    result.error("bad_args", "asset/width/height required", null)
                    return
                }
                val theta = call.argument<Double>("theta") ?: 180.0
                val phi = call.argument<Double>("phi") ?: 60.0
                val hst = ensureHost()
                val producer = try {
                    textures.createSurfaceProducer()
                } catch (t: Throwable) {
                    result.error("texture", t.toString(), null)
                    return
                }
                hst.handler.post {
                    if (!hst.init()) {
                        producer.release()
                        postResult { result.error("engine", FilamentStats.lastError ?: "engine init failed", null) }
                        return@post
                    }
                    val cv = CarView(hst, producer, context.applicationContext, asset, w, h, theta, phi)
                    try {
                        cv.create()
                        views[cv.id] = cv
                        postResult { result.success(cv.id) }
                    } catch (t: Throwable) {
                        FilamentStats.lastError = "create: ${t.javaClass.simpleName}: ${t.message}"
                        NativeDebug.log(TAG, "CREATE FAILED: $t\n${t.stackTraceToString().take(1200)}")
                        try { cv.dispose() } catch (_: Throwable) {}
                        postResult { result.error("create", t.toString(), null) }
                    }
                }
            }
            "update" -> {
                val id = (call.argument<Number>("id") ?: return result.success(null)).toLong()
                val t = call.argument<Double>("theta") ?: 180.0
                val p = call.argument<Double>("phi") ?: 60.0
                host?.handler?.post { views[id]?.setOrbit(t, p) }
                result.success(null)
            }
            "resize" -> {
                val id = (call.argument<Number>("id") ?: return result.success(null)).toLong()
                val w = call.argument<Int>("width") ?: 0
                val h = call.argument<Int>("height") ?: 0
                if (w > 0 && h > 0) host?.handler?.post { views[id]?.resize(w, h) }
                result.success(null)
            }
            "model" -> {
                val id = (call.argument<Number>("id") ?: return result.success(null)).toLong()
                val a = call.argument<String>("asset")
                if (a != null) host?.handler?.post { views[id]?.setModel(a) }
                result.success(null)
            }
            "dispose" -> {
                val id = (call.argument<Number>("id") ?: return result.success(null)).toLong()
                val hst = host
                if (hst == null) {
                    result.success(null)
                } else {
                    hst.handler.post {
                        views.remove(id)?.dispose()
                        if (views.isEmpty()) {
                            // آخرین نما بسته شد: Engine را هم آزاد کن (حافظهٔ GPU).
                            hst.shutdown()
                        }
                    }
                    result.success(null)
                }
            }
            "status" -> result.success(FilamentStats.line())
            else -> result.notImplemented()
        }
    }

    private fun postResult(block: () -> Unit) {
        android.os.Handler(android.os.Looper.getMainLooper()).post(block)
    }

    fun dispose() {
        channel.setMethodCallHandler(null)
        NativeDebug.filamentStatus = null
        val hst = host ?: return
        host = null
        hst.handler.post {
            for (v in views.values) v.dispose()
            views.clear()
            hst.shutdown()
            hst.quit()
        }
    }
}
