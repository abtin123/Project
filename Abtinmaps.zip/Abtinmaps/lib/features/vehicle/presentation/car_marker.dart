import 'dart:async';
import 'dart:io' show Platform;
import 'dart:math' as math;

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../core/debug/app_debugger.dart';
import 'nav_arrow_painter.dart';
import 'vehicle_provider.dart';

/// Used only by the main map. OnlineMapView is re-created (new ValueKey) when the
/// map style / reload key changes; without a GlobalKey that also destroyed the
/// native Filament view of the 3D car and built a new one each time.
/// With it Flutter moves the existing State (and its texture) to the new map.
/// Do NOT use it twice at the same time (e.g. in the settings preview).
final GlobalKey mapCarMarkerKey = GlobalKey(debugLabel: 'map-car-marker');

const _yawCorrectionDegrees = <double>[0.0, 0.0, 0.0, 0.0];

double vehicleModelYawCorrectionDegrees(int modelIndex) {
  return _yawCorrectionDegrees[modelIndex.clamp(0, vehicleModels.length - 1)];
}

double vehicleScreenRotationDegrees(double headingDeg) {
  final normalized = headingDeg.isFinite ? headingDeg : 0.0;
  final value = normalized % 360.0;
  return value < 0 ? value + 360.0 : value;
}

// قرارداد دوربین مداری (مثل model-viewer): theta = زاویهٔ افقی، phi = از بالا.
double _orbitTheta(double screenHeadingDeg) =>
    (vehicleScreenRotationDegrees(screenHeadingDeg) + 180.0) % 360.0;

double _orbitPhi(double tiltDegrees) =>
    (tiltDegrees.isFinite ? tiltDegrees : 0.0).clamp(2.0, 78.0).toDouble();

/// پل Dart ↔ Filament بومی (Kotlin: FilamentCar.kt). بدون پکیج فلاتر، فقط MethodChannel + Texture.
class FilamentCarChannel {
  FilamentCarChannel._();
  static const MethodChannel _ch = MethodChannel('ir.abtin.abtinmaps/filament_car');

  /// فقط اندروید؛ در بقیهٔ پلتفرم‌ها فلش جهت‌نما نشان داده می‌شود.
  static bool get supported => !kIsWeb && Platform.isAndroid;

  static Future<int?> create({
    required String asset,
    required int width,
    required int height,
    required double theta,
    required double phi,
  }) =>
      _ch.invokeMethod<int>('create', {
        'asset': asset,
        'width': width,
        'height': height,
        'theta': theta,
        'phi': phi,
      });

  static Future<void> update(int id, double theta, double phi) =>
      _ch.invokeMethod<void>('update', {'id': id, 'theta': theta, 'phi': phi});

  static Future<void> resize(int id, int width, int height) =>
      _ch.invokeMethod<void>('resize', {'id': id, 'width': width, 'height': height});

  static Future<void> setModel(int id, String asset) =>
      _ch.invokeMethod<void>('model', {'id': id, 'asset': asset});

  static Future<void> dispose(int id) => _ch.invokeMethod<void>('dispose', {'id': id});

  static Future<String?> status() => _ch.invokeMethod<String>('status');
}

class CarMarker3D extends StatefulWidget {
  const CarMarker3D({
    super.key,
    required this.size,
    required this.modelIndex,
    this.headingDeg = 0,
    this.cameraAngleDegrees = 0,
    this.sizePercent = 80,
    this.interactive = false,
  });

  final double size;
  final int modelIndex;
  final double headingDeg;
  final double cameraAngleDegrees;
  final double sizePercent;
  final bool interactive;

  @override
  State<CarMarker3D> createState() => _CarMarker3DState();
}

class _CarMarker3DState extends State<CarMarker3D> {
  int? _textureId;
  bool _creating = false;
  bool _failed = false;
  bool _disposed = false;
  int _texW = 0;
  double _devicePixelRatio = 1.0;

  // آخرین زاویه‌ای که واقعاً به Filament فرستاده شده.
  double? _sentTheta;
  double? _sentPhi;

  // رندر Filament «به‌ازای تغییر» است؛ برای اینکه جیتر ۱ درجه‌ای GPS فریم الکی نسازد،
  // فقط با تغییر واقعی زاویه و حداکثر ~۱۵ بار در ثانیه می‌فرستیم.
  static const Duration _minPushGap = Duration(milliseconds: 66);
  static const double _minThetaStepDeg = 1.5;
  static const double _minPhiStepDeg = 1.0;
  DateTime _lastPushAt = DateTime.fromMillisecondsSinceEpoch(0);
  Timer? _pendingPush;

  static const int _maxTexturePx = 768;

  double get _visualScale => widget.sizePercent.clamp(45.0, 150.0) / 100.0;

  /// برای اینکه با بزرگ‌نمایی (تا ۱۵۰٪) تصویر کدر نشود، بافت را به اندازهٔ بزرگ‌ترین حالت می‌سازیم.
  double get _renderScale => math.max(1.0, _visualScale);

  int get _wantedPx =>
      (widget.size * _devicePixelRatio * _renderScale).round().clamp(32, _maxTexturePx);

  @override
  void initState() {
    super.initState();
    if (!FilamentCarChannel.supported) _failed = true;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _devicePixelRatio = MediaQuery.maybeOf(context)?.devicePixelRatio ?? 1.0;
    if (_textureId == null && !_creating && !_failed) {
      unawaited(_create());
    } else {
      _maybeResize();
    }
  }

  Future<void> _create() async {
    _creating = true;
    final idx = widget.modelIndex.clamp(0, vehicleModels.length - 1);
    final px = _wantedPx;
    final theta = _orbitTheta(widget.headingDeg);
    final phi = _orbitPhi(widget.cameraAngleDegrees);
    try {
      final id = await FilamentCarChannel.create(
        asset: vehicleModels[idx],
        width: px,
        height: px,
        theta: theta,
        phi: phi,
      );
      if (id == null) throw StateError('native create returned null');
      if (_disposed) {
        unawaited(FilamentCarChannel.dispose(id));
        return;
      }
      _texW = px;
      _sentTheta = theta;
      _sentPhi = phi;
      AppDebugger.instance.i('filament', 'car texture #$id ${px}px model=$idx');
      if (mounted) setState(() => _textureId = id);
      _push(); // اگر در حین ساخت چیزی عوض شده بود
    } catch (e) {
      // موتور بالا نیامد (مثلاً GPU/ABI پشتیبانی نمی‌شود): با فلش جهت‌نما ادامه بده.
      AppDebugger.instance.w('filament', 'native car unavailable, using arrow: $e');
      if (mounted) setState(() => _failed = true);
    } finally {
      _creating = false;
    }
  }

  void _maybeResize() {
    final id = _textureId;
    if (id == null) return;
    final px = _wantedPx;
    if (px != _texW) {
      _texW = px;
      FilamentCarChannel.resize(id, px, px).catchError((_) {});
    }
  }

  void _push() {
    final id = _textureId;
    if (id == null || _disposed) return;
    final theta = _orbitTheta(widget.headingDeg);
    final phi = _orbitPhi(widget.cameraAngleDegrees);
    final lastTheta = _sentTheta;
    final lastPhi = _sentPhi;
    if (lastTheta != null && lastPhi != null) {
      var dTheta = (theta - lastTheta).abs() % 360.0;
      if (dTheta > 180.0) dTheta = 360.0 - dTheta;
      final dPhi = (phi - lastPhi).abs();
      if (dTheta < _minThetaStepDeg && dPhi < _minPhiStepDeg) return;
    }
    final since = DateTime.now().difference(_lastPushAt);
    if (since < _minPushGap) {
      _pendingPush ??= Timer(_minPushGap - since, () {
        _pendingPush = null;
        if (mounted) _push();
      });
      return;
    }
    _lastPushAt = DateTime.now();
    _sentTheta = theta;
    _sentPhi = phi;
    FilamentCarChannel.update(id, theta, phi).catchError((_) {});
  }

  @override
  void didUpdateWidget(CarMarker3D old) {
    super.didUpdateWidget(old);
    final id = _textureId;
    if (id != null && old.modelIndex != widget.modelIndex) {
      final idx = widget.modelIndex.clamp(0, vehicleModels.length - 1);
      FilamentCarChannel.setModel(id, vehicleModels[idx]).catchError((_) {});
    }
    _maybeResize();
    _push();
  }

  @override
  void dispose() {
    _disposed = true;
    _pendingPush?.cancel();
    _pendingPush = null;
    final id = _textureId;
    _textureId = null;
    if (id != null) {
      FilamentCarChannel.dispose(id).catchError((_) {});
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final id = _textureId;
    final Widget content;
    if (_failed) {
      content = Transform.rotate(
        angle: vehicleScreenRotationDegrees(widget.headingDeg) * math.pi / 180,
        child: NavArrow(size: widget.size * 0.8),
      );
    } else if (id == null) {
      content = const SizedBox.shrink();
    } else {
      // بافت به اندازهٔ renderScale ساخته شده؛ نمایش با visualScale/renderScale.
      final shown = widget.size * _renderScale;
      content = Transform.scale(
        scale: _visualScale / _renderScale,
        alignment: Alignment.center,
        child: OverflowBox(
          minWidth: shown,
          maxWidth: shown,
          minHeight: shown,
          maxHeight: shown,
          child: SizedBox.square(
            dimension: shown,
            child: Texture(textureId: id, filterQuality: FilterQuality.medium),
          ),
        ),
      );
    }
    return SizedBox.square(
      dimension: widget.size,
      child: IgnorePointer(ignoring: !widget.interactive, child: content),
    );
  }
}
