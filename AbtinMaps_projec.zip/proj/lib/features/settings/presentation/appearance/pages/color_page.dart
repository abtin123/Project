import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../core/localization/app_localizations.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../shared/providers/app_settings_providers.dart';
import '../../../../../shared/providers/map_style_providers.dart';
import '../../../../../shared/widgets/glass_panel.dart' show GlassPanel;
import '../../../data/settings_repository.dart';
import '../../appearance_settings_providers.dart';
import '../../settings_repository_provider.dart';
import '../shared_widgets.dart';

/// یک [Color] را به رشته‌ی هگزِ `#RRGGBB` تبدیل می‌کند (بدون آلفا).
String _colorToHex(Color c) {
  return '#${(c.value & 0xFFFFFF).toRadixString(16).padLeft(6, '0').toUpperCase()}';
}

/// تبِ «رنگ‌بندی»: رنگ اصلی اپ + پالت رنگی + حالت روز/شب + ویجت آب‌وهوا.
class ColorPage extends StatelessWidget {
  const ColorPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(16, 12, 16, 32),
      child: AppAppearanceContent(),
    );
  }
}

/// محتوای ظاهری اپ، مستقل از آب‌وهوا تا در آکاردئون خودش نمایش داده شود.
class AppAppearanceContent extends StatelessWidget {
  const AppAppearanceContent({super.key});

  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _AppColorCard(),
        SizedBox(height: 12),
        _DisplayModeCard(),
      ],
    );
  }
}

/// کارتِ «رنگ اپلیکیشن»: هشت سواچِ آماده + نوار گرادیانِ رنگین‌کمانی که با
/// کشیدنِ آن، رنگ اصلی UI به‌صورت پیوسته تغییر می‌کند.
class _AppColorCard extends ConsumerWidget {
  const _AppColorCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final current = ref.watch(primaryColorProvider);
    final repo = ref.read(settingsRepositoryProvider);

    void applyColor(Color c) {
      final normalized = normalizeAppPrimaryColor(c);
      ref
          .read(appearanceSettingsProvider.notifier)
          .update((s) => s.copyWith(primaryColor: normalized));
      repo.setValue(
        SettingsRepository.keyAppColor,
        normalized.value.toString(),
      );
    }

    return GlassPanel(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          CardHeader(
            title: AppStrings.get(context, ref, 'as_app_color_title'),
            icon: Icons.palette_rounded,
          ),
          const SizedBox(height: 6),
          Text(
            AppStrings.get(context, ref, 'as_app_color_subtitle'),
            textAlign: TextAlign.start,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppColors.textSecondary(context),
                ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              for (final c in appColorPresets)
                AppColorSwatch(
                  color: c,
                  selected: _colorToHex(current) == _colorToHex(c),
                  onTap: () => applyColor(c),
                ),
            ],
          ),
          const SizedBox(height: 18),
          Text(
            AppStrings.get(context, ref, 'as_palette_title'),
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: AppColors.textPrimary(context),
                  fontWeight: FontWeight.w700,
                ),
          ),
          const SizedBox(height: 10),
          _RainbowPaletteBar(
            selectedColor: current,
            onChanged: applyColor,
          ),
        ],
      ),
    );
  }
}

/// نوار افقیِ گرادیانِ رنگین‌کمانی؛ لمس یا کشیدن روی آن، رنگِ زیرِ انگشت را
/// به‌عنوان رنگ اصلی UI اعمال می‌کند. دستگیره‌ی سفید موقعیت رنگ فعلی را
/// نشان می‌دهد (نزدیک‌ترین رنگِ گرادیان به رنگ اصلیِ فعلی).
class _RainbowPaletteBar extends StatefulWidget {
  const _RainbowPaletteBar({
    required this.selectedColor,
    required this.onChanged,
  });

  final Color selectedColor;
  final ValueChanged<Color> onChanged;

  static const List<Color> _stops = [
    Color(0xFF8A3FD0), // بنفش
    Color(0xFF2F80ED), // آبی
    Color(0xFF3FD0E0), // فیروزه‌ای
    Color(0xFF52C24C), // سبز
    Color(0xFFE0D23F), // زرد
    Color(0xFFE0973F), // نارنجی
    Color(0xFFE0523F), // قرمز
  ];

  @override
  State<_RainbowPaletteBar> createState() => _RainbowPaletteBarState();
}

class _RainbowPaletteBarState extends State<_RainbowPaletteBar> {
  double? _dragFraction;

  Color _colorAtFraction(double t) {
    final stops = _RainbowPaletteBar._stops;
    final scaled = (t.clamp(0.0, 1.0) * (stops.length - 1));
    final index = scaled.floor().clamp(0, stops.length - 2);
    final localT = scaled - index;
    return Color.lerp(stops[index], stops[index + 1], localT)!;
  }

  double _fractionForColor(Color color) {
    final stops = _RainbowPaletteBar._stops;
    var bestT = 0.0;
    var bestDistance = double.infinity;
    const steps = 200;
    for (var i = 0; i <= steps; i++) {
      final t = i / steps;
      final c = _colorAtFraction(t);
      final dr = c.red - color.red;
      final dg = c.green - color.green;
      final db = c.blue - color.blue;
      final distance = (dr * dr + dg * dg + db * db).toDouble();
      if (distance < bestDistance) {
        bestDistance = distance;
        bestT = t;
      }
    }
    return bestT;
  }

  void _handleUpdate(Offset localPosition, double width) {
    final fraction = (localPosition.dx / width).clamp(0.0, 1.0);
    setState(() => _dragFraction = fraction);
    widget.onChanged(_colorAtFraction(fraction));
  }

  @override
  Widget build(BuildContext context) {
    final fraction = _dragFraction ?? _fractionForColor(widget.selectedColor);
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        return GestureDetector(
          onTapDown: (d) => _handleUpdate(d.localPosition, width),
          onHorizontalDragStart: (d) => _handleUpdate(d.localPosition, width),
          onHorizontalDragUpdate: (d) => _handleUpdate(d.localPosition, width),
          child: Container(
            height: 44,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: LinearGradient(colors: _RainbowPaletteBar._stops),
            ),
            child: Align(
              alignment: Alignment(fraction * 2 - 1, 0),
              child: Container(
                width: 28,
                height: 28,
                margin: const EdgeInsets.symmetric(horizontal: 4),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  border: Border.all(color: Colors.white, width: 3),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black38,
                      blurRadius: 6,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// کارتِ «حالت نمایش»: دو دکمه‌ی روز/شب برای کل تمِ اپ (نه فقط تایل‌های
/// نقشه) — روی themeModeProvider سوار است که در main.dart مستقیماً به
/// MaterialApp.themeMode داده می‌شود، پس تغییر اینجا بلافاصله کل اپ را
/// عوض می‌کند. به‌صورت هم‌زمان، حالتِ نمایشِ خودِ تایل‌های نقشه
/// (mapStyleModeProvider) هم با همین دکمه هماهنگ می‌شود.
class _DisplayModeCard extends ConsumerWidget {
  const _DisplayModeCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mode = ref.watch(themeModeProvider);
    final repo = ref.read(settingsRepositoryProvider);
    final isDark = mode == ThemeMode.dark;

    void select(bool dark) {
      final newMode = dark ? ThemeMode.dark : ThemeMode.light;
      ref
          .read(appearanceSettingsProvider.notifier)
          .update((s) => s.copyWith(themeMode: newMode));
      repo.setValue(
        SettingsRepository.keyThemeMode,
        dark ? 'dark' : 'light',
      );

      final newMapStyle = dark ? MapStyleMode.night : MapStyleMode.day;
      ref.read(mapStyleModeProvider.notifier).state = newMapStyle;
      repo.setValue(SettingsRepository.keyMapDisplayMode, newMapStyle.name);
    }

    return GlassPanel(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          CardHeader(
            title: AppStrings.get(context, ref, 'as_theme_mode_title'),
            icon: Icons.contrast_rounded,
          ),
          const SizedBox(height: 6),
          Text(
            AppStrings.get(context, ref, 'as_display_mode_subtitle'),
            textAlign: TextAlign.start,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppColors.textSecondary(context),
                ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: PillChoice(
                  label: AppStrings.get(context, ref, 'as_theme_light'),
                  icon: Icons.wb_sunny_rounded,
                  selected: !isDark,
                  onTap: () => select(false),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: PillChoice(
                  label: AppStrings.get(context, ref, 'as_theme_dark'),
                  icon: Icons.nightlight_round,
                  selected: isDark,
                  onTap: () => select(true),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// محتوای مستقل آب‌وهوا؛ دو اسلایدر برای موقعیت افقی/عمودی ویجت روی نقشه،
/// به‌علاوه‌ی رنگ پس‌زمینه‌ی ویجت. درصدها مستقیماً به لایه‌ی واقعی آب‌وهوا و
/// پیش‌نمایش زنده‌ی نقشه می‌رسند.
class WeatherSettingsContent extends ConsumerWidget {
  const WeatherSettingsContent({super.key});

  static const _bgPalette = <Color>[
    Colors.black,
    Color(0xFF1E293B),
    Color(0xFF0B3D5C),
    Color(0xFF0F6B4F),
    Color(0xFF6B4A0F),
    Color(0xFF6B0F1E),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final verticalPercent = ref.watch(weatherWidgetVerticalPercentProvider);
    final horizontalPercent = ref.watch(weatherWidgetHorizontalPercentProvider);
    final bgColor = ref.watch(weatherWidgetBgColorProvider);
    final repo = ref.read(settingsRepositoryProvider);

    return GlassPanel(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          CardHeader(
            title: AppStrings.get(context, ref, 'weather_settings_title'),
            icon: Icons.wb_cloudy_rounded,
          ),
          const SizedBox(height: 6),
          Text(
            AppStrings.get(context, ref, 'as_weather_widget_subtitle'),
            textAlign: TextAlign.start,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppColors.textSecondary(context),
                ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: AppColors.surfaceMuted(context),
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.glassBorder(context)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  AppStrings.get(context, ref, 'as_weather_bg_color'),
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppColors.textPrimary(context),
                      ),
                ),
              ),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final c in _bgPalette)
                    AppColorSwatch(
                      color: c,
                      selected: c.value == bgColor.value,
                      onTap: () {
                        ref.read(weatherWidgetBgColorProvider.notifier).state =
                            c;
                        repo.setValue(
                          SettingsRepository.keyWeatherBgColor,
                          c.value.toString(),
                        );
                      },
                    ),
                  RainbowSwatch(
                    selected:
                        !_bgPalette.any((c) => c.value == bgColor.value),
                    onTap: () async {
                      final c = await ColorPickerSheet.show(context, bgColor);
                      if (c == null || !context.mounted) return;
                      ref.read(weatherWidgetBgColorProvider.notifier).state =
                          c;
                      repo.setValue(
                        SettingsRepository.keyWeatherBgColor,
                        c.value.toString(),
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 18),
          _WeatherPositionSlider(
            label: AppStrings.get(context, ref, 'weather_widget_horizontal'),
            value: horizontalPercent,
            startLabel: AppStrings.get(context, ref, 'position_left'),
            endLabel: AppStrings.get(context, ref, 'position_right'),
            onChanged: (value) => ref
                .read(weatherWidgetHorizontalPercentProvider.notifier)
                .state = value,
          ),
          const SizedBox(height: 18),
          _WeatherPositionSlider(
            label: AppStrings.get(context, ref, 'weather_widget_height'),
            value: verticalPercent,
            startLabel: AppStrings.get(context, ref, 'position_top'),
            endLabel: AppStrings.get(context, ref, 'position_bottom'),
            onChanged: (value) => ref
                .read(weatherWidgetVerticalPercentProvider.notifier)
                .state = value,
          ),
        ],
      ),
    );
  }
}

class _WeatherPositionSlider extends StatelessWidget {
  const _WeatherPositionSlider({
    required this.label,
    required this.value,
    required this.startLabel,
    required this.endLabel,
    required this.onChanged,
  });

  final String label;
  final double value;
  final String startLabel;
  final String endLabel;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.primaryAccent(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Text(
              label,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: AppColors.textPrimary(context),
                    fontWeight: FontWeight.w600,
                  ),
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
              decoration: BoxDecoration(
                color: accent,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                '${value.round()}%',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            activeTrackColor: accent,
            inactiveTrackColor: AppColors.surfaceMuted(context),
            thumbColor: Colors.white,
            overlayColor: accent.withOpacity(0.15),
            trackHeight: 4,
          ),
          child: Slider(
            value: value.clamp(0.0, 100.0).toDouble(),
            min: 0,
            max: 100,
            divisions: 100,
            onChanged: onChanged,
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(startLabel,
                style: TextStyle(
                    color: AppColors.textMuted(context), fontSize: 11)),
            Text(endLabel,
                style: TextStyle(
                    color: AppColors.textMuted(context), fontSize: 11)),
          ],
        ),
      ],
    );
  }
}
