package ir.abtin.abtinmaps

import android.app.Application

class AbtinApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        NativeDebug.init(this)
    }
}
